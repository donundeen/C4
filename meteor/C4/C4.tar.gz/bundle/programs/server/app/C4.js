(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// C4.js                                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
Widgets = new Mongo.Collection("widgets");                             // 2
                                                                       //
// set GLOBAL VARS                                                     //
//In the client side                                                   //
SERVER_NAME = "localhost";                                             // 6
SERVER_IP = "localhost";                                               // 7
                                                                       //
if (Meteor.isClient) {                                                 // 9
  Meteor.call('getServerName', function (err, results) {               // 10
    SERVER_NAME = results;                                             // 11
  });                                                                  //
  Meteor.call('getServerIP', function (err, results) {                 // 13
    SERVER_IP = results;                                               // 14
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 19
                                                                       //
  Meteor.methods({                                                     // 21
    getServerName: function () {                                       // 22
      SERVER_NAME = process.env.SERVER_NAME;                           // 23
      if (typeof SERVER_NAME === "undefined") {                        // 24
        SERVER_NAME = "localhost";                                     // 25
      }                                                                //
      return SERVER_NAME;                                              // 27
    },                                                                 //
    getServerIP: function () {                                         // 29
      SERVER_IP = process.env.SERVER_IP;                               // 30
      if (typeof SERVER_IP === "undefined") {                          // 31
        SERVER_IP = "localhost";                                       // 32
      }                                                                //
      return SERVER_IP;                                                // 34
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isClient) {                                                 // 39
                                                                       //
  Meteor.startup(function () {                                         // 41
    $(window).bind('beforeunload', function () {                       // 42
      $(".save").trigger("click");                                     // 43
    });                                                                //
  });                                                                  //
  console.log("starting meteor");                                      // 46
                                                                       //
  ////// HELPERS                                                       //
  UI.registerHelper('shortIt', function (stringToShorten, maxCharsAmount) {
    if (stringToShorten.length > maxCharsAmount) {                     // 52
      return stringToShorten.substring(0, maxCharsAmount) + '...';     // 53
    }                                                                  //
    return stringToShorten;                                            // 55
  });                                                                  //
                                                                       //
  UI.registerHelper('encodeURIComponent', function (string) {          // 58
    return encodeURIComponent(string);                                 // 59
  });                                                                  //
                                                                       //
  UI.registerHelper('absoluteUrl', function () {                       // 62
    return Meteor.absoluteUrl();                                       // 63
  });                                                                  //
                                                                       //
  Accounts.ui.config({                                                 // 66
    passwordSignupFields: "USERNAME_AND_EMAIL"                         // 67
  });                                                                  //
                                                                       //
  Template.registerHelper("pageid", function () {                      // 70
    return pageinfo().pageid;                                          // 71
  });                                                                  //
                                                                       //
  Template.registerHelper("pageurl", function () {                     // 74
    return pageinfo().pageurl;                                         // 75
  });                                                                  //
  Template.registerHelper("pagetype", function () {                    // 77
    return pageinfo().pagetype;                                        // 78
  });                                                                  //
  Template.registerHelper("SERVER_NAME", function () {                 // 80
    return SERVER_NAME;                                                // 81
  });                                                                  //
  Template.registerHelper("SERVER_IP", function () {                   // 83
    return SERVER_IP;                                                  // 84
  });                                                                  //
  Template.body.helpers({                                              // 86
    widgets: function () {                                             // 87
      // Otherwise, return all of the tasks                            //
      var find = { this_page_only: { $in: [false, null] },             // 89
        pagetype: pageinfo().pagetype };                               // 90
                                                                       //
      return Widgets.find(find, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
    widgetTemplates: function () {                                     // 94
      // Otherwise, return all of the tasks                            //
      return Widgets.find({ isTemplate: true }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
    libraryWidgets: function () {                                      // 98
      // Otherwise, return all of the tasks                            //
      var find = { inLibrary: true };                                  // 100
      find["createdBy.userid"] = Meteor.userId();                      // 101
      return Widgets.find(find, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
    thisPageWidgets: function () {                                     // 104
      // Otherwise, return all of the tasks                            //
      var find = { this_page_only: true,                               // 106
        pagetype: pageinfo().pagetype,                                 // 107
        pageid: pageinfo().pageid };                                   // 108
      return Widgets.find(find, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    }                                                                  //
                                                                       //
  });                                                                  //
  ////// END HELPERS                                                   //
                                                                       //
  ////// TEMPLATE ONRENDERED                                           //
  Template.body.onRendered(function () {                               // 118
    $(".tooltip-right").tooltip({ placement: "right" });               // 119
    $("[title]").tooltip({ placement: "auto" });                       // 120
  });                                                                  //
  ////// END ONRENDERED                                                //
                                                                       //
  /////// EVENTS                                                       //
  Template.body.events({                                               // 127
                                                                       //
    "click .lockall": function () {                                    // 130
      $(".lock").trigger("click");                                     // 131
      $(".lockall").hide();                                            // 132
      $(".unlockall").show();                                          // 133
      giphy_modal("unlock", "Unlocking all widgets you have access to");
      return false;                                                    // 135
    },                                                                 //
    "click .unlockall": function () {                                  // 138
      $(".unlock").trigger("click");                                   // 139
      $(".lockall").show();                                            // 140
      $(".unlockall").hide();                                          // 141
      giphy_modal("lock", "Locking all Widgets");                      // 142
      return false;                                                    // 143
    },                                                                 //
                                                                       //
    "click .giphy": function (e, t) {                                  // 146
      $(e.target).hide();                                              // 147
    },                                                                 //
                                                                       //
    'click .copy_from_template': function () {                         // 152
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 156
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 158
        newWidget = { _id: results.data.url,                           // 159
          createdBy: { username: Meteor.user().username,               // 160
            userid: Meteor.userId() },                                 // 161
          isTemplate: false,                                           // 162
          html: results.data.html,                                     // 163
          javascript: results.data.javascript,                         // 164
          css: results.data.css,                                       // 165
          displayWidth: results.data.displayWidth,                     // 166
          displayHeight: results.data.displayHeight,                   // 167
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: results.data.widgetStyle,                       // 169
          name: "copy of " + template.name,                            // 170
          pagetype: pageinfo().pagetype,                               // 171
          pageurl: pageinfo().pageurl,                                 // 172
          pageid: pageinfo().pageid,                                   // 173
          url: results.data.url,                                       // 174
          createdAt: new Date(),                                       // 175
          rand: Math.random() };                                       // 176
        Widgets.insert(newWidget);                                     // 177
      });                                                              //
                                                                       //
      giphy_modal("copy", "New Widget Copied From Template");          // 180
                                                                       //
      return false;                                                    // 183
    },                                                                 //
                                                                       //
    'click .deletetemplate': function () {                             // 186
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      template.isTemplate = false;                                     // 188
      Widgets.update(template._id, template);                          // 189
    },                                                                 //
                                                                       //
    'click .addwidget': function () {                                  // 192
      //add jsbin widget                                               //
                                                                       //
      var htmlstring = '<html>\n ' + '<head>\n ' + '<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>\n ' + '<script src="/c4libs/locallib.js"></script>\n ' + '   <script type="application/json" class="c4_data">{"data" : "data placed here gets passed along"}</script>\n ' + '</head>\n ' + '<body>\n ' + '  <div class="c4_html">\n ' + '  html placed here gets passed along\n ' + '  </div>\n ' + '</body>\n ' + '</html>\n';
      var csstring = "";                                               // 207
      var jsstring = "function doTheThings(data){\n" + "// everything you want to do should happen inside this function\n " + "// the data var will be populated with whatever you've requested from other widgets\n" + "// and this function will be call when all those widgets have complete \n" + "   c4_done(); // this message is required at the end of all the processing, so the system knows this widget is done \n " + "} \n" + "requireWidgetData( \n" + "// all requests to other widgets go here (automatically if you use the 'pull from' interface): \n" + "// c4_requires \n" + "{} \n" + "// end_c4_requires \n" + "// end other widget requests \n" + ", doTheThings)";
      var dataobj = { html: htmlstring, css: csstring, javascript: jsstring };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 223
      HTTP.post(url, options, function (error, results) {              // 224
        newWidget = { _id: results.data.url,                           // 225
          createdBy: { username: Meteor.user().username,               // 226
            userid: Meteor.userId() },                                 // 227
          isTemplate: false,                                           // 228
          name: results.data.url,                                      // 229
          description: "",                                             // 230
          html: results.data.html,                                     // 231
          javascript: results.data.javascript,                         // 232
          css: results.data.css,                                       // 233
          displayWidth: "",                                            // 234
          displayHeight: "",                                           // 235
          widgetStyle: "",                                             // 236
          pagetype: pageinfo().pagetype,                               // 237
          pageurl: pageinfo().pageurl,                                 // 238
          pageid: pageinfo().pageid,                                   // 239
          url: results.data.url,                                       // 240
          createdAt: new Date(),                                       // 241
          rand: Math.random() };                                       // 242
        Widgets.insert(newWidget);                                     // 243
      });                                                              //
      return false;                                                    // 245
    },                                                                 //
                                                                       //
    'click .test': function () {                                       // 248
      return false;                                                    // 249
    }                                                                  //
  });                                                                  //
                                                                       //
  ///// END EVENTS                                                     //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 259
  Meteor.startup(function () {                                         // 260
    // code to run on server at startup                                //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=C4.js.map
