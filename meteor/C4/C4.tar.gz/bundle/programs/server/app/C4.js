(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// C4.js                                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
Widgets = new Mongo.Collection("widgets");                             // 2
                                                                       //
// set GLOBAL VARS                                                     //
//In the client side                                                   //
SERVER_NAME = "localhost";                                             // 6
SERVER_IP = "localhost";                                               // 7
                                                                       //
if (Meteor.isClient) {                                                 // 9
  Meteor.call('getServerName', function (err, results) {               // 10
    SERVER_NAME = results;                                             // 11
  });                                                                  //
  Meteor.call('getServerIP', function (err, results) {                 // 13
    SERVER_IP = results;                                               // 14
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 19
                                                                       //
  Meteor.methods({                                                     // 21
    getServerName: function () {                                       // 22
      SERVER_NAME = process.env.SERVER_NAME;                           // 23
      if (typeof SERVER_NAME === "undefined") {                        // 24
        SERVER_NAME = "localhost";                                     // 25
      }                                                                //
      return SERVER_NAME;                                              // 27
    },                                                                 //
    getServerIP: function () {                                         // 29
      SERVER_IP = process.env.SERVER_IP;                               // 30
      if (typeof SERVER_IP === "undefined") {                          // 31
        SERVER_IP = "localhost";                                       // 32
      }                                                                //
      return SERVER_IP;                                                // 34
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isClient) {                                                 // 39
                                                                       //
  Meteor.startup(function () {                                         // 41
    $(window).bind('beforeunload', function () {                       // 42
      $(".save").trigger("click");                                     // 43
    });                                                                //
  });                                                                  //
  console.log("starting meteor");                                      // 46
                                                                       //
  ////// HELPERS                                                       //
  UI.registerHelper('shortIt', function (stringToShorten, maxCharsAmount) {
    if (stringToShorten.length > maxCharsAmount) {                     // 52
      return stringToShorten.substring(0, maxCharsAmount) + '...';     // 53
    }                                                                  //
    return stringToShorten;                                            // 55
  });                                                                  //
                                                                       //
  UI.registerHelper('encodeURIComponent', function (string) {          // 58
    return encodeURIComponent(string);                                 // 59
  });                                                                  //
                                                                       //
  UI.registerHelper('absoluteUrl', function () {                       // 62
    return Meteor.absoluteUrl();                                       // 63
  });                                                                  //
                                                                       //
  Accounts.ui.config({                                                 // 66
    passwordSignupFields: "USERNAME_AND_EMAIL"                         // 67
  });                                                                  //
                                                                       //
  Template.registerHelper("pageid", function () {                      // 70
    return pageinfo().pageid;                                          // 71
  });                                                                  //
                                                                       //
  Template.registerHelper("pageurl", function () {                     // 74
    return pageinfo().pageurl;                                         // 75
  });                                                                  //
  Template.registerHelper("pagetype", function () {                    // 77
    return pageinfo().pagetype;                                        // 78
  });                                                                  //
  Template.registerHelper("SERVER_NAME", function () {                 // 80
    return SERVER_NAME;                                                // 81
  });                                                                  //
  Template.registerHelper("SERVER_IP", function () {                   // 83
    return SERVER_IP;                                                  // 84
  });                                                                  //
  Template.body.helpers({                                              // 86
    widgets: function () {                                             // 87
      // Otherwise, return all of the tasks                            //
      var find = {                                                     // 89
        this_page_only: { $in: [false, null] },                        // 90
        pagetype: pageinfo().pagetype,                                 // 91
        $or: [{ visibility: "public" }, { $and: [{ visibility: "private" }, { "createdBy.userid": Meteor.userId() }] }, { visibility: null }]
      };                                                               //
                                                                       //
      return Widgets.find(find, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
    widgetTemplates: function () {                                     // 104
      // Otherwise, return all of the tasks                            //
      return Widgets.find({ isTemplate: true }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
    libraryWidgets: function () {                                      // 108
      // Otherwise, return all of the tasks                            //
      var find = { inLibrary: true };                                  // 110
      find["createdBy.userid"] = Meteor.userId();                      // 111
      return Widgets.find(find, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
    thisPageWidgets: function () {                                     // 114
      // Otherwise, return all of the tasks                            //
      var find = { this_page_only: true,                               // 116
        pagetype: pageinfo().pagetype,                                 // 117
        pageid: pageinfo().pageid };                                   // 118
      return Widgets.find(find, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    }                                                                  //
                                                                       //
  });                                                                  //
  ////// END HELPERS                                                   //
                                                                       //
  ////// TEMPLATE ONRENDERED                                           //
  Template.body.onRendered(function () {                               // 128
    $(".tooltip-right").tooltip({ placement: "right" });               // 129
    $("[title]").tooltip({ placement: "auto" });                       // 130
  });                                                                  //
  ////// END ONRENDERED                                                //
                                                                       //
  /////// EVENTS                                                       //
  Template.body.events({                                               // 137
                                                                       //
    "click .lockall": function () {                                    // 140
      $(".lock").trigger("click");                                     // 141
      $(".lockall").hide();                                            // 142
      $(".unlockall").show();                                          // 143
      giphy_modal("unlock", "Unlocking all widgets you have access to");
      return false;                                                    // 145
    },                                                                 //
    "click .unlockall": function () {                                  // 148
      $(".unlock").trigger("click");                                   // 149
      $(".lockall").show();                                            // 150
      $(".unlockall").hide();                                          // 151
      giphy_modal("lock", "Locking all Widgets");                      // 152
      return false;                                                    // 153
    },                                                                 //
                                                                       //
    "click .giphy": function (e, t) {                                  // 156
      $(e.target).hide();                                              // 157
    },                                                                 //
                                                                       //
    'click .copy_from_template': function () {                         // 162
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 166
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 168
        newWidget = { _id: results.data.url,                           // 169
          createdBy: { username: Meteor.user().username,               // 170
            userid: Meteor.userId() },                                 // 171
          isTemplate: false,                                           // 172
          html: results.data.html,                                     // 173
          javascript: results.data.javascript,                         // 174
          css: results.data.css,                                       // 175
          displayWidth: results.data.displayWidth,                     // 176
          displayHeight: results.data.displayHeight,                   // 177
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: results.data.widgetStyle,                       // 179
          name: "copy of " + template.name,                            // 180
          pagetype: pageinfo().pagetype,                               // 181
          pageurl: pageinfo().pageurl,                                 // 182
          pageid: pageinfo().pageid,                                   // 183
          url: results.data.url,                                       // 184
          createdAt: new Date(),                                       // 185
          visibility: "private",                                       // 186
          rand: Math.random() };                                       // 187
        Widgets.insert(newWidget);                                     // 188
      });                                                              //
                                                                       //
      giphy_modal("copy", "New Widget Copied From Template");          // 191
                                                                       //
      return false;                                                    // 194
    },                                                                 //
                                                                       //
    'click .deletetemplate': function () {                             // 197
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      template.isTemplate = false;                                     // 199
      Widgets.update(template._id, template);                          // 200
    },                                                                 //
                                                                       //
    'click .addwidget': function () {                                  // 203
      //add jsbin widget                                               //
                                                                       //
      var htmlstring = '<html>\n ' + '<head>\n ' + '<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>\n ' + '<script src="/c4libs/locallib.js"></script>\n ' + '   <script type="application/json" class="c4_data">{"data" : "data placed here gets passed along"}</script>\n ' + '</head>\n ' + '<body>\n ' + '  <div class="c4_html">\n ' + '  html placed here gets passed along\n ' + '  </div>\n ' + '</body>\n ' + '</html>\n';
      var csstring = "";                                               // 218
      var jsstring = "function doTheThings(data){\n" + "// everything you want to do should happen inside this function\n " + "// the data var will be populated with whatever you've requested from other widgets\n" + "// and this function will be call when all those widgets have complete \n" + "   c4_done(); // this message is required at the end of all the processing, so the system knows this widget is done \n " + "} \n" + "requireWidgetData( \n" + "// all requests to other widgets go here (automatically if you use the 'pull from' interface): \n" + "// c4_requires \n" + "{} \n" + "// end_c4_requires \n" + "// end other widget requests \n" + ", doTheThings)";
      var dataobj = { html: htmlstring, css: csstring, javascript: jsstring };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 234
      HTTP.post(url, options, function (error, results) {              // 235
        newWidget = { _id: results.data.url,                           // 236
          createdBy: { username: Meteor.user().username,               // 237
            userid: Meteor.userId() },                                 // 238
          isTemplate: false,                                           // 239
          name: results.data.url,                                      // 240
          description: "",                                             // 241
          html: results.data.html,                                     // 242
          javascript: results.data.javascript,                         // 243
          css: results.data.css,                                       // 244
          displayWidth: "",                                            // 245
          displayHeight: "",                                           // 246
          widgetStyle: "",                                             // 247
          pagetype: pageinfo().pagetype,                               // 248
          pageurl: pageinfo().pageurl,                                 // 249
          pageid: pageinfo().pageid,                                   // 250
          url: results.data.url,                                       // 251
          visibility: "private",                                       // 252
          createdAt: new Date(),                                       // 253
          rand: Math.random() };                                       // 254
        Widgets.insert(newWidget);                                     // 255
      });                                                              //
      return false;                                                    // 257
    },                                                                 //
                                                                       //
    'click .test': function () {                                       // 260
      return false;                                                    // 261
    }                                                                  //
  });                                                                  //
                                                                       //
  ///// END EVENTS                                                     //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 271
  Meteor.startup(function () {                                         // 272
    // code to run on server at startup                                //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=C4.js.map
