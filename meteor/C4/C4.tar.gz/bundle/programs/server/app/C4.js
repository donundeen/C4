(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// C4.js                                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
Widgets = new Mongo.Collection("widgets");                             // 2
                                                                       //
// set GLOBAL VARS                                                     //
//In the client side                                                   //
SERVER_NAME = "localhost";                                             // 6
SERVER_IP = "localhost";                                               // 7
                                                                       //
if (Meteor.isClient) {                                                 // 9
  Meteor.call('getServerName', function (err, results) {               // 10
    SERVER_NAME = results;                                             // 11
  });                                                                  //
  Meteor.call('getServerIP', function (err, results) {                 // 13
    SERVER_IP = results;                                               // 14
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 19
                                                                       //
  Meteor.methods({                                                     // 21
    getServerName: function () {                                       // 22
      SERVER_NAME = process.env.SERVER_NAME;                           // 23
      if (typeof SERVER_NAME === "undefined") {                        // 24
        SERVER_NAME = "localhost";                                     // 25
      }                                                                //
      return SERVER_NAME;                                              // 27
    },                                                                 //
    getServerIP: function () {                                         // 29
      SERVER_IP = process.env.SERVER_IP;                               // 30
      if (typeof SERVER_IP === "undefined") {                          // 31
        SERVER_IP = "localhost";                                       // 32
      }                                                                //
      return SERVER_IP;                                                // 34
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isClient) {                                                 // 39
                                                                       //
  Meteor.startup(function () {                                         // 41
    $(window).bind('beforeunload', function () {                       // 42
      $(".save").trigger("click");                                     // 43
    });                                                                //
  });                                                                  //
  console.log("starting meteor");                                      // 46
                                                                       //
  /// comments config                                                  //
  // On the Client                                                     //
  Comments.ui.config({                                                 // 51
    template: 'bootstrap' // or ionic, semantic-ui                     // 52
  });                                                                  //
                                                                       //
  ////// HELPERS                                                       //
  UI.registerHelper('shortIt', function (stringToShorten, maxCharsAmount) {
    if (stringToShorten.length > maxCharsAmount) {                     // 57
      return stringToShorten.substring(0, maxCharsAmount) + '...';     // 58
    }                                                                  //
    return stringToShorten;                                            // 60
  });                                                                  //
                                                                       //
  UI.registerHelper('encodeURIComponent', function (string) {          // 63
    return encodeURIComponent(string);                                 // 64
  });                                                                  //
                                                                       //
  UI.registerHelper('absoluteUrl', function () {                       // 67
    return Meteor.absoluteUrl();                                       // 68
  });                                                                  //
                                                                       //
  Accounts.ui.config({                                                 // 71
    passwordSignupFields: "USERNAME_AND_EMAIL"                         // 72
  });                                                                  //
                                                                       //
  Template.registerHelper("pageid", function () {                      // 75
    return pageinfo().pageid;                                          // 76
  });                                                                  //
                                                                       //
  Template.registerHelper("pageurl", function () {                     // 79
    return pageinfo().pageurl;                                         // 80
  });                                                                  //
  Template.registerHelper("pagetype", function () {                    // 82
    return pageinfo().pagetype;                                        // 83
  });                                                                  //
  Template.registerHelper("SERVER_NAME", function () {                 // 85
    return SERVER_NAME;                                                // 86
  });                                                                  //
  Template.registerHelper("SERVER_IP", function () {                   // 88
    return SERVER_IP;                                                  // 89
  });                                                                  //
  Template.body.helpers({                                              // 91
    widgets: function () {                                             // 92
      // Otherwise, return all of the tasks                            //
      var find = {                                                     // 94
        this_page_only: { $in: [false, null] },                        // 95
        pagetype: pageinfo().pagetype,                                 // 96
        $or: [{ visibility: "public" }, { $and: [{ visibility: "private" }, { "createdBy.userid": Meteor.userId() }] }, { visibility: null }]
      };                                                               //
                                                                       //
      return Widgets.find(find, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
    widgetTemplates: function () {                                     // 109
      // Otherwise, return all of the tasks                            //
      return Widgets.find({ isTemplate: true }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
    libraryWidgets: function () {                                      // 113
      // Otherwise, return all of the tasks                            //
      var find = { inLibrary: true };                                  // 115
      find["createdBy.userid"] = Meteor.userId();                      // 116
      return Widgets.find(find, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
    thisPageWidgets: function () {                                     // 119
      // Otherwise, return all of the tasks                            //
      var find = { this_page_only: true,                               // 121
        pagetype: pageinfo().pagetype,                                 // 122
        pageid: pageinfo().pageid };                                   // 123
      return Widgets.find(find, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    }                                                                  //
                                                                       //
  });                                                                  //
  ////// END HELPERS                                                   //
                                                                       //
  ////// TEMPLATE ONRENDERED                                           //
  Template.body.onRendered(function () {                               // 133
    //$(".tooltip-right").tooltip({placement: "right"});               //
    //  $("[title]").tooltip({placement: "auto"});                     //
  });                                                                  //
  ////// END ONRENDERED                                                //
                                                                       //
  /////// EVENTS                                                       //
  Template.body.events({                                               // 142
                                                                       //
    "click .lockall": function () {                                    // 145
      $(".lock").trigger("click");                                     // 146
      $(".lockall").hide();                                            // 147
      $(".unlockall").show();                                          // 148
      giphy_modal("unlock", "Unlocking all widgets you have access to");
      return false;                                                    // 150
    },                                                                 //
    "click .unlockall": function () {                                  // 153
      $(".unlock").trigger("click");                                   // 154
      $(".lockall").show();                                            // 155
      $(".unlockall").hide();                                          // 156
      giphy_modal("lock", "Locking all Widgets");                      // 157
      return false;                                                    // 158
    },                                                                 //
                                                                       //
    "click .giphy": function (e, t) {                                  // 161
      $(e.target).hide();                                              // 162
    },                                                                 //
                                                                       //
    'click .copy_from_template': function () {                         // 167
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 171
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 173
        newWidget = { _id: results.data.url,                           // 174
          createdBy: { username: Meteor.user().username,               // 175
            userid: Meteor.userId() },                                 // 176
          isTemplate: false,                                           // 177
          html: results.data.html,                                     // 178
          javascript: results.data.javascript,                         // 179
          css: results.data.css,                                       // 180
          displayWidth: results.data.displayWidth,                     // 181
          displayHeight: results.data.displayHeight,                   // 182
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: results.data.widgetStyle,                       // 184
          name: "copy of " + template.name,                            // 185
          pagetype: pageinfo().pagetype,                               // 186
          pageurl: pageinfo().pageurl,                                 // 187
          pageid: pageinfo().pageid,                                   // 188
          url: results.data.url,                                       // 189
          createdAt: new Date(),                                       // 190
          visibility: "private",                                       // 191
          rand: Math.random() };                                       // 192
        Widgets.insert(newWidget);                                     // 193
      });                                                              //
                                                                       //
      giphy_modal("copy", "New Widget Copied From Template");          // 196
                                                                       //
      return false;                                                    // 199
    },                                                                 //
                                                                       //
    'click .deletetemplate': function () {                             // 202
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      template.isTemplate = false;                                     // 204
      Widgets.update(template._id, template);                          // 205
    },                                                                 //
                                                                       //
    'click .addwidget': function () {                                  // 208
      //add jsbin widget                                               //
                                                                       //
      var htmlstring = '<html>\n ' + '<head>\n ' + '<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>\n ' + '<script src="/c4libs/locallib.js"></script>\n ' + '   <script type="application/json" class="c4_data">{"data" : "data placed here gets passed along"}</script>\n ' + '</head>\n ' + '<body>\n ' + '  <div class="c4_html">\n ' + '  html placed here gets passed along\n ' + '  </div>\n ' + '</body>\n ' + '</html>\n';
      var csstring = "";                                               // 223
      var jsstring = "function doTheThings(data){\n" + "// everything you want to do should happen inside this function\n " + "// the data var will be populated with whatever you've requested from other widgets\n" + "// and this function will be call when all those widgets have complete \n" + "   c4_done(); // this message is required at the end of all the processing, so the system knows this widget is done \n " + "} \n" + "requireWidgetData( \n" + "// all requests to other widgets go here (automatically if you use the 'pull from' interface): \n" + "// c4_requires \n" + "{} \n" + "// end_c4_requires \n" + "// end other widget requests \n" + ", doTheThings)";
      var dataobj = { html: htmlstring, css: csstring, javascript: jsstring };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 239
      HTTP.post(url, options, function (error, results) {              // 240
        newWidget = { _id: results.data.url,                           // 241
          createdBy: { username: Meteor.user().username,               // 242
            userid: Meteor.userId() },                                 // 243
          isTemplate: false,                                           // 244
          name: results.data.url,                                      // 245
          description: "",                                             // 246
          html: results.data.html,                                     // 247
          javascript: results.data.javascript,                         // 248
          css: results.data.css,                                       // 249
          displayWidth: "",                                            // 250
          displayHeight: "",                                           // 251
          widgetStyle: "",                                             // 252
          pagetype: pageinfo().pagetype,                               // 253
          pageurl: pageinfo().pageurl,                                 // 254
          pageid: pageinfo().pageid,                                   // 255
          url: results.data.url,                                       // 256
          visibility: "private",                                       // 257
          createdAt: new Date(),                                       // 258
          rand: Math.random() };                                       // 259
        Widgets.insert(newWidget);                                     // 260
      });                                                              //
      return false;                                                    // 262
    },                                                                 //
                                                                       //
    'click .test': function () {                                       // 265
      return false;                                                    // 266
    }                                                                  //
  });                                                                  //
                                                                       //
  ///// END EVENTS                                                     //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 276
  Meteor.startup(function () {                                         // 277
    // code to run on server at startup                                //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=C4.js.map
