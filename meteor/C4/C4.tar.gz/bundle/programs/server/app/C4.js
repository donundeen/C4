(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// C4.js                                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
Widgets = new Mongo.Collection("widgets");                             // 2
                                                                       //
// set GLOBAL VARS                                                     //
//In the client side                                                   //
SERVER_NAME = "localhost";                                             // 6
SERVER_IP = "localhost";                                               // 7
                                                                       //
if (Meteor.isClient) {                                                 // 9
  Meteor.call('getServerName', function (err, results) {               // 10
    SERVER_NAME = results;                                             // 11
  });                                                                  //
  Meteor.call('getServerIP', function (err, results) {                 // 13
    SERVER_IP = results;                                               // 14
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 19
                                                                       //
  Meteor.methods({                                                     // 21
    getServerName: function () {                                       // 22
      SERVER_NAME = process.env.SERVER_NAME;                           // 23
      if (typeof SERVER_NAME === "undefined") {                        // 24
        SERVER_NAME = "localhost";                                     // 25
      }                                                                //
      return SERVER_NAME;                                              // 27
    },                                                                 //
    getServerIP: function () {                                         // 29
      SERVER_IP = process.env.SERVER_IP;                               // 30
      if (typeof SERVER_IP === "undefined") {                          // 31
        SERVER_IP = "localhost";                                       // 32
      }                                                                //
      return SERVER_IP;                                                // 34
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isClient) {                                                 // 39
                                                                       //
  Meteor.startup(function () {                                         // 41
    $(window).bind('beforeunload', function () {                       // 42
      $(".save").trigger("click");                                     // 43
    });                                                                //
  });                                                                  //
  console.log("starting meteor");                                      // 46
                                                                       //
  ////// HELPERS                                                       //
  UI.registerHelper('shortIt', function (stringToShorten, maxCharsAmount) {
    if (stringToShorten.length > maxCharsAmount) {                     // 52
      return stringToShorten.substring(0, maxCharsAmount) + '...';     // 53
    }                                                                  //
    return stringToShorten;                                            // 55
  });                                                                  //
                                                                       //
  UI.registerHelper('encodeURIComponent', function (string) {          // 58
    return encodeURIComponent(string);                                 // 59
  });                                                                  //
                                                                       //
  UI.registerHelper('absoluteUrl', function () {                       // 62
    return Meteor.absoluteUrl();                                       // 63
  });                                                                  //
                                                                       //
  Accounts.ui.config({                                                 // 66
    passwordSignupFields: "USERNAME_AND_EMAIL"                         // 67
  });                                                                  //
                                                                       //
  Template.registerHelper("pageid", function () {                      // 70
    return pageinfo().pageid;                                          // 71
  });                                                                  //
                                                                       //
  Template.registerHelper("pageurl", function () {                     // 74
    return pageinfo().pageurl;                                         // 75
  });                                                                  //
  Template.registerHelper("pagetype", function () {                    // 77
    return pageinfo().pagetype;                                        // 78
  });                                                                  //
  Template.registerHelper("SERVER_NAME", function () {                 // 80
    return SERVER_NAME;                                                // 81
  });                                                                  //
  Template.registerHelper("SERVER_IP", function () {                   // 83
    return SERVER_IP;                                                  // 84
  });                                                                  //
  Template.body.helpers({                                              // 86
    widgets: function () {                                             // 87
      // Otherwise, return all of the tasks                            //
      var find = { this_page_only: { $in: [false, null] },             // 89
        pagetype: pageinfo().pagetype };                               // 90
                                                                       //
      return Widgets.find(find, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
    widgetTemplates: function () {                                     // 94
      // Otherwise, return all of the tasks                            //
      return Widgets.find({ isTemplate: true }, { sort: { createdAt: -1 } });
    },                                                                 //
    libraryWidgets: function () {                                      // 98
      // Otherwise, return all of the tasks                            //
      var find = { inLibrary: true };                                  // 100
      find["createdBy.userid"] = Meteor.userId();                      // 101
      return Widgets.find(find, { sort: { createdAt: -1 } });          // 102
    },                                                                 //
    thisPageWidgets: function () {                                     // 104
      // Otherwise, return all of the tasks                            //
      var find = { this_page_only: true,                               // 106
        pagetype: pageinfo().pagetype,                                 // 107
        pageid: pageinfo().pageid };                                   // 108
      return Widgets.find(find, { sort: { createdAt: -1 } });          // 109
    }                                                                  //
                                                                       //
  });                                                                  //
  ////// END HELPERS                                                   //
                                                                       //
  ////// TEMPLATE ONRENDERED                                           //
  Template.body.onRendered(function () {                               // 118
    $(".tooltip-right").tooltip({ placement: "right" });               // 119
    $("[title]").tooltip({ placement: "auto" });                       // 120
  });                                                                  //
  ////// END ONRENDERED                                                //
                                                                       //
  /////// EVENTS                                                       //
  Template.body.events({                                               // 127
                                                                       //
    "click .lockall": function () {                                    // 130
      console.log("locked" + this._id);                                // 131
      console.log("locking");                                          // 132
                                                                       //
      $(".lock").trigger("click");                                     // 134
                                                                       //
      $(".lockall").hide();                                            // 136
      $(".unlockall").show();                                          // 137
      giphy_modal("unlock", "Unlocking all widgets you have access to");
                                                                       //
      return false;                                                    // 141
    },                                                                 //
    "click .unlockall": function () {                                  // 144
      console.log("unlocking");                                        // 145
      $(".unlock").trigger("click");                                   // 146
      $(".lockall").show();                                            // 147
      $(".unlockall").hide();                                          // 148
                                                                       //
      giphy_modal("lock", "Locking all Widgets");                      // 150
                                                                       //
      return false;                                                    // 152
    },                                                                 //
                                                                       //
    "click .giphy": function (e, t) {                                  // 155
      $(e.target).hide();                                              // 156
    },                                                                 //
                                                                       //
    'click .copy_from_template': function () {                         // 161
      console.log("copy from template " + this.url);                   // 162
                                                                       //
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 167
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 169
        console.log("data submitted");                                 // 170
        newWidget = { _id: results.data.url,                           // 171
          createdBy: { username: Meteor.user().username,               // 172
            userid: Meteor.userId() },                                 // 173
          isTemplate: false,                                           // 174
          html: results.data.html,                                     // 175
          javascript: results.data.javascript,                         // 176
          css: results.data.css,                                       // 177
          displayWidth: results.data.displayWidth,                     // 178
          displayHeight: results.data.displayHeight,                   // 179
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: results.data.widgetStyle,                       // 181
          name: "copy of " + template.name,                            // 182
          pagetype: pageinfo().pagetype,                               // 183
          pageurl: pageinfo().pageurl,                                 // 184
          pageid: pageinfo().pageid,                                   // 185
          url: results.data.url,                                       // 186
          createdAt: new Date(),                                       // 187
          rand: Math.random() };                                       // 188
        console.log("creating new widget");                            // 189
        console.log(newWidget);                                        // 190
        Widgets.insert(newWidget);                                     // 191
      });                                                              //
                                                                       //
      giphy_modal("copy", "New Widget Copied From Template");          // 194
                                                                       //
      return false;                                                    // 197
    },                                                                 //
                                                                       //
    'click .deletetemplate': function () {                             // 200
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      template.isTemplate = false;                                     // 202
      Widgets.update(template._id, template);                          // 203
    },                                                                 //
                                                                       //
    'click .addwidget': function () {                                  // 206
      //add jsbin widget                                               //
      console.log("clicked");                                          // 208
                                                                       //
      var htmlstring = '<html>\n ' + '<head>\n ' + '<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>\n ' + '<script src="/c4libs/locallib.js"></script>\n ' + '   <script type="application/json" class="c4_data">{"data" : "data placed here gets passed along"}</script>\n ' + '</head>\n ' + '<body>\n ' + '  <div class="c4_html">\n ' + '  html placed here gets passed along\n ' + '  </div>\n ' + '</body>\n ' + '</html>\n';
      var csstring = "";                                               // 222
      var jsstring = "function doTheThings(data){\n" + "// everything you want to do should happen inside this function\n " + "// the data var will be populated with whatever you've requested from other widgets\n" + "// and this function will be call when all those widgets have complete \n" + "   c4_done(); // this message is required at the end of all the processing, so the system knows this widget is done \n " + "} \n" + "requireWidgetData( \n" + "// all requests to other widgets go here (automatically if you use the 'pull from' interface): \n" + "// c4_requires \n" + "{} \n" + "// end_c4_requires \n" + "// end other widget requests \n" + ", doTheThings)";
      var dataobj = { html: htmlstring, css: csstring, javascript: jsstring };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 238
      HTTP.post(url, options, function (error, results) {              // 239
        console.log("data submitted");                                 // 240
        console.log(results);                                          // 241
        console.log(error);                                            // 242
        console.log(results.data.url);                                 // 243
        newWidget = { _id: results.data.url,                           // 244
          createdBy: { username: Meteor.user().username,               // 245
            userid: Meteor.userId() },                                 // 246
          isTemplate: false,                                           // 247
          name: results.data.url,                                      // 248
          description: "",                                             // 249
          html: results.data.html,                                     // 250
          javascript: results.data.javascript,                         // 251
          css: results.data.css,                                       // 252
          displayWidth: "",                                            // 253
          displayHeight: "",                                           // 254
          widgetStyle: "",                                             // 255
          pagetype: pageinfo().pagetype,                               // 256
          pageurl: pageinfo().pageurl,                                 // 257
          pageid: pageinfo().pageid,                                   // 258
          url: results.data.url,                                       // 259
          createdAt: new Date(),                                       // 260
          rand: Math.random() };                                       // 261
        Widgets.insert(newWidget);                                     // 262
      });                                                              //
      return false;                                                    // 264
    },                                                                 //
                                                                       //
    'click .test': function () {                                       // 267
      console.log("testing");                                          // 268
      return false;                                                    // 269
    }                                                                  //
  });                                                                  //
                                                                       //
  ///// END EVENTS                                                     //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 279
  Meteor.startup(function () {                                         // 280
    // code to run on server at startup                                //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=C4.js.map
