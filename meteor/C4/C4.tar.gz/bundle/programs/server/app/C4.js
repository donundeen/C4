(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// C4.js                                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
Widgets = new Mongo.Collection("widgets");                             // 2
                                                                       //
// set GLOBAL VARS                                                     //
//In the client side                                                   //
SERVER_NAME = "localhost";                                             // 6
SERVER_IP = "localhost";                                               // 7
                                                                       //
if (Meteor.isClient) {                                                 // 9
  Meteor.call('getServerName', function (err, results) {               // 10
    SERVER_NAME = results;                                             // 11
  });                                                                  //
  Meteor.call('getServerIP', function (err, results) {                 // 13
    SERVER_IP = results;                                               // 14
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 19
                                                                       //
  Meteor.methods({                                                     // 21
    getServerName: function () {                                       // 22
      SERVER_NAME = process.env.SERVER_NAME;                           // 23
      if (typeof SERVER_NAME === "undefined") {                        // 24
        SERVER_NAME = "localhost";                                     // 25
      }                                                                //
      return SERVER_NAME;                                              // 27
    },                                                                 //
    getServerIP: function () {                                         // 29
      SERVER_IP = process.env.SERVER_IP;                               // 30
      if (typeof SERVER_IP === "undefined") {                          // 31
        SERVER_IP = "localhost";                                       // 32
      }                                                                //
      return SERVER_IP;                                                // 34
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isClient) {                                                 // 39
                                                                       //
  Meteor.startup(function () {                                         // 41
    $(window).bind('beforeunload', function () {                       // 42
      $(".save").trigger("click");                                     // 43
    });                                                                //
  });                                                                  //
  console.log("starting meteor");                                      // 46
                                                                       //
  ////// HELPERS                                                       //
  UI.registerHelper('shortIt', function (stringToShorten, maxCharsAmount) {
    if (stringToShorten.length > maxCharsAmount) {                     // 52
      return stringToShorten.substring(0, maxCharsAmount) + '...';     // 53
    }                                                                  //
    return stringToShorten;                                            // 55
  });                                                                  //
                                                                       //
  UI.registerHelper('encodeURIComponent', function (string) {          // 58
    return encodeURIComponent(string);                                 // 59
  });                                                                  //
                                                                       //
  UI.registerHelper('absoluteUrl', function () {                       // 62
    return Meteor.absoluteUrl();                                       // 63
  });                                                                  //
                                                                       //
  Accounts.ui.config({                                                 // 66
    passwordSignupFields: "USERNAME_AND_EMAIL"                         // 67
  });                                                                  //
                                                                       //
  Template.registerHelper("pageid", function () {                      // 70
    return pageinfo().pageid;                                          // 71
  });                                                                  //
                                                                       //
  Template.registerHelper("pageurl", function () {                     // 74
    return pageinfo().pageurl;                                         // 75
  });                                                                  //
  Template.registerHelper("pagetype", function () {                    // 77
    return pageinfo().pagetype;                                        // 78
  });                                                                  //
  Template.registerHelper("SERVER_NAME", function () {                 // 80
    return SERVER_NAME;                                                // 81
  });                                                                  //
  Template.registerHelper("SERVER_IP", function () {                   // 83
    return SERVER_IP;                                                  // 84
  });                                                                  //
  Template.body.helpers({                                              // 86
    widgets: function () {                                             // 87
      // Otherwise, return all of the tasks                            //
      return Widgets.find({ pagetype: pageinfo().pagetype }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
    widgetTemplates: function () {                                     // 91
      // Otherwise, return all of the tasks                            //
      return Widgets.find({ isTemplate: true }, { sort: { createdAt: -1 } });
    }                                                                  //
  });                                                                  //
  ////// END HELPERS                                                   //
                                                                       //
  ////// TEMPLATE ONRENDERED                                           //
  Template.body.onRendered(function () {                               // 100
    $(".tooltip-right").tooltip({ placement: "right" });               // 101
    $("[title]").tooltip({ placement: "auto" });                       // 102
  });                                                                  //
  ////// END ONRENDERED                                                //
                                                                       //
  /////// EVENTS                                                       //
  Template.body.events({                                               // 109
                                                                       //
    "click .lockall": function () {                                    // 112
      console.log("locked" + this._id);                                // 113
      console.log("locking");                                          // 114
                                                                       //
      $(".lock").trigger("click");                                     // 116
                                                                       //
      $(".lockall").hide();                                            // 118
      $(".unlockall").show();                                          // 119
      giphy_modal("unlock", "Unlocking all widgets you have access to");
                                                                       //
      return false;                                                    // 123
    },                                                                 //
    "click .unlockall": function () {                                  // 126
      console.log("unlocking");                                        // 127
      $(".unlock").trigger("click");                                   // 128
      $(".lockall").show();                                            // 129
      $(".unlockall").hide();                                          // 130
                                                                       //
      giphy_modal("lock", "Locking all Widgets");                      // 132
                                                                       //
      return false;                                                    // 134
    },                                                                 //
                                                                       //
    "click .giphy": function (e, t) {                                  // 137
      $(e.target).hide();                                              // 138
    },                                                                 //
                                                                       //
    'click .copy_from_template': function () {                         // 143
      console.log("copy from template " + this.url);                   // 144
                                                                       //
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 149
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 151
        console.log("data submitted");                                 // 152
        newWidget = { _id: results.data.url,                           // 153
          createdBy: { username: Meteor.user().username,               // 154
            userid: Meteor.userId() },                                 // 155
          isTemplate: false,                                           // 156
          html: results.data.html,                                     // 157
          javascript: results.data.javascript,                         // 158
          css: results.data.css,                                       // 159
          displayWidth: results.data.displayWidth,                     // 160
          displayHeight: results.data.displayHeight,                   // 161
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: results.data.widgetStyle,                       // 163
          name: "copy of " + template.name,                            // 164
          pagetype: pageinfo().pagetype,                               // 165
          pageurl: pageinfo().pageurl,                                 // 166
          pageid: pageinfo().pageid,                                   // 167
          url: results.data.url,                                       // 168
          createdAt: new Date(),                                       // 169
          rand: Math.random() };                                       // 170
        console.log("creating new widget");                            // 171
        console.log(newWidget);                                        // 172
        Widgets.insert(newWidget);                                     // 173
      });                                                              //
                                                                       //
      giphy_modal("copy", "New Widget Copied From Template");          // 176
                                                                       //
      return false;                                                    // 179
    },                                                                 //
                                                                       //
    'click .deletetemplate': function () {                             // 182
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      template.isTemplate = false;                                     // 184
      Widgets.update(template._id, template);                          // 185
    },                                                                 //
                                                                       //
    'click .addwidget': function () {                                  // 188
      //add jsbin widget                                               //
      console.log("clicked");                                          // 190
                                                                       //
      var htmlstring = '<html>\n ' + '<head>\n ' + '<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>\n ' + '<script src="/c4libs/locallib.js"></script>\n ' + '   <script type="application/json" class="c4_data">{"data" : "data placed here gets passed along"}</script>\n ' + '</head>\n ' + '<body>\n ' + '  <div class="c4_html">\n ' + '  html placed here gets passed along\n ' + '  </div>\n ' + '</body>\n ' + '</html>\n';
      var csstring = "";                                               // 204
      var jsstring = "function doTheThings(data){\n" + "// everything you want to do should happen inside this function\n " + "// the data var will be populated with whatever you've requested from other widgets\n" + "// and this function will be call when all those widgets have complete \n" + "   c4_done(); // this message is required at the end of all the processing, so the system knows this widget is done \n " + "} \n" + "requireWidgetData( \n" + "// all requests to other widgets go here (automatically if you use the 'pull from' interface): \n" + "// c4_requires \n" + "{} \n" + "// end_c4_requires \n" + "// end other widget requests \n" + ", doTheThings)";
      var dataobj = { html: htmlstring, css: csstring, javascript: jsstring };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 220
      HTTP.post(url, options, function (error, results) {              // 221
        console.log("data submitted");                                 // 222
        console.log(results);                                          // 223
        console.log(error);                                            // 224
        console.log(results.data.url);                                 // 225
        newWidget = { _id: results.data.url,                           // 226
          createdBy: { username: Meteor.user().username,               // 227
            userid: Meteor.userId() },                                 // 228
          isTemplate: false,                                           // 229
          name: results.data.url,                                      // 230
          description: "",                                             // 231
          html: results.data.html,                                     // 232
          javascript: results.data.javascript,                         // 233
          css: results.data.css,                                       // 234
          displayWidth: "",                                            // 235
          displayHeight: "",                                           // 236
          widgetStyle: "",                                             // 237
          pagetype: pageinfo().pagetype,                               // 238
          pageurl: pageinfo().pageurl,                                 // 239
          pageid: pageinfo().pageid,                                   // 240
          url: results.data.url,                                       // 241
          createdAt: new Date(),                                       // 242
          rand: Math.random() };                                       // 243
        Widgets.insert(newWidget);                                     // 244
      });                                                              //
      return false;                                                    // 246
    },                                                                 //
                                                                       //
    'click .test': function () {                                       // 249
      console.log("testing");                                          // 250
      return false;                                                    // 251
    }                                                                  //
  });                                                                  //
                                                                       //
  ///// END EVENTS                                                     //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 261
  Meteor.startup(function () {                                         // 262
    // code to run on server at startup                                //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=C4.js.map
