(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// common_functions.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
pageinfo = setWidgetDefaults = giphy_modal = null;                     // 1
                                                                       //
if (Meteor.isClient) {                                                 // 3
                                                                       //
  giphy_modal = function (term, text) {                                // 6
    $("#giphy_modal").modal('show');                                   // 7
    $(".giphy_modal_header").text(text);                               // 8
    var url = "/giphy_proxy/" + encodeURIComponent(term);              // 9
    $(".giphy_modal_image_div").empty();                               // 10
    var imgurl = url + "?" + new Date().getTime();                     // 11
    $(".giphy_modal_image_div").html("<img src='" + imgurl + "' width='200' class='giphy_modal_image_img'/>");
                                                                       //
    setTimeout(function () {                                           // 14
      $("#giphy_modal").modal('hide');                                 // 15
    }, 2000);                                                          //
  };                                                                   //
                                                                       //
  pageinfo = function () {                                             // 20
    var pagetype = "";                                                 // 21
    var pageid = "";                                                   // 22
    var pathname = window.location.pathname;                           // 23
    var split = pathname.split("/");                                   // 24
    split.shift();                                                     // 25
    var pageurl = split.join("/");                                     // 26
                                                                       //
    if (split.length > 0) {                                            // 28
      pagetype = split.shift();                                        // 29
    }                                                                  //
    if (split.length > 0) {                                            // 31
      pageid = split.shift();                                          // 32
    }                                                                  //
    pageid = pageid.replace(/:script/, "");                            // 34
    return { pageurl: pageurl,                                         // 35
      pagetype: pagetype,                                              // 36
      pageid: pageid };                                                // 37
  };                                                                   //
                                                                       //
  setWidgetDefaults = function (doc) {                                 // 41
                                                                       //
    console.log("mapping");                                            // 43
    if (typeof doc.displayWidth === "undefined" || !doc.displayWidth || doc.displayWidth.trim() == "" || doc.displayWidth == "width" || doc.displayWidth == "default") {
      doc.displayWidth = "default";                                    // 45
      doc.displayUsableWidth = "";                                     // 46
    } else {                                                           //
      doc.displayUsableWidth = doc.displayWidth;                       // 48
    }                                                                  //
    if (typeof doc.displayHeight === "undefined" || !doc.displayHeight || doc.displayHeight.trim() == "" || doc.displayHeight == "height" || doc.displayHeight == "default") {
      doc.displayHeight = "default";                                   // 51
      doc.displayUsableHeight = "";                                    // 52
    } else {                                                           //
      doc.displayUsableHeight = doc.displayHeight;                     // 54
    }                                                                  //
    if (typeof doc.widgetStyle === "undefined" || !doc.widgetStyle || doc.widgetStyle.trim() == "" || doc.widgetStyle == "css" || doc.widgetStyle == "default") {
      doc.widgetStyle = "default";                                     // 57
      doc.usableWidgetStyle = "";                                      // 58
    } else {                                                           //
      doc.usableWidgetStyle = doc.widgetStyle;                         // 60
    }                                                                  //
    if (!doc.createdBy) {                                              // 62
      doc.createdBy = {};                                              // 63
    }                                                                  //
                                                                       //
    if (doc.displayUsableHeight.match(/px/)) {                         // 66
      var height = doc.displayUsableHeight.replace(/px/, "");          // 67
      doc.jsbinHeight = height - 20;                                   // 68
      doc.jsbinHeight += "px";                                         // 69
    } else {                                                           //
      doc.jsbinHeight = "";                                            // 71
    }                                                                  //
                                                                       //
    return doc;                                                        // 74
  };                                                                   //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=common_functions.js.map
