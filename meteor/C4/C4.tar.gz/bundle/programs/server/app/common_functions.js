(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// common_functions.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
pageinfo = setWidgetDefaults = giphy_modal = getUserXtras = null;      // 1
                                                                       //
if (Meteor.isClient) {                                                 // 3
                                                                       //
  getUserXtras = function () {                                         // 5
    var userxtras = false;                                             // 6
    var user = Meteor.user();                                          // 7
    if (user) {                                                        // 8
      console.log(user.username);                                      // 9
      console.log(user._id);                                           // 10
      console.log("getting for " + user._id);                          // 11
      var userxtras = UserXtras.findOne({ _id: user._id });            // 12
      if (!userxtras || !userxtras.foo) {                              // 13
        console.log("userxtras " + userxtras);                         // 14
        userxtras = { _id: user._id, admin: false, godmode: false, foo: "var" };
        if (user.username == "donundeen") {                            // 16
          userxtras.admin = true;                                      // 17
        }                                                              //
        console.log("saving for " + user._id);                         // 19
        UserXtras.upsert({ _id: user._id }, userxtras);                // 20
        var userxtras2 = UserXtras.findOne({ _id: user._id });         // 21
      }                                                                //
      console.log(userxtras);                                          // 23
    }                                                                  //
    return userxtras;                                                  // 25
  };                                                                   //
                                                                       //
  giphy_modal = function (term, text) {                                // 31
    $("#giphy_modal").modal('show');                                   // 32
    $(".giphy_modal_header").text(text);                               // 33
    var url = "/giphy_proxy/" + encodeURIComponent(term);              // 34
    $(".giphy_modal_image_div").empty();                               // 35
    var imgurl = url + "?" + new Date().getTime();                     // 36
    $(".giphy_modal_image_div").html("<img src='" + imgurl + "' width='200' class='giphy_modal_image_img'/>");
                                                                       //
    setTimeout(function () {                                           // 39
      $("#giphy_modal").modal('hide');                                 // 40
    }, 2000);                                                          //
  };                                                                   //
                                                                       //
  pageinfo = function () {                                             // 45
    var pagetype = "";                                                 // 46
    var pageid = "";                                                   // 47
    var pathname = window.location.pathname;                           // 48
    var split = pathname.split("/");                                   // 49
    split.shift();                                                     // 50
    var pageurl = split.join("/");                                     // 51
                                                                       //
    if (split.length > 0) {                                            // 53
      pagetype = split.shift();                                        // 54
    }                                                                  //
    if (split.length > 0) {                                            // 56
      pageid = split.shift();                                          // 57
    }                                                                  //
    pageid = pageid.replace(/:script/, "");                            // 59
    return { pageurl: pageurl,                                         // 60
      pagetype: pagetype,                                              // 61
      pageid: pageid };                                                // 62
  };                                                                   //
                                                                       //
  setWidgetDefaults = function (doc) {                                 // 66
    if (typeof doc.displayWidth === "undefined" || !doc.displayWidth || doc.displayWidth.trim() == "" || doc.displayWidth == "width" || doc.displayWidth == "default") {
      doc.displayWidth = "320px";                                      // 68
      doc.displayUsableWidth = "320px";                                // 69
    } else {                                                           //
      doc.displayUsableWidth = doc.displayWidth;                       // 71
    }                                                                  //
    if (typeof doc.displayHeight === "undefined" || !doc.displayHeight || doc.displayHeight.trim() == "" || doc.displayHeight == "height" || doc.displayHeight == "default") {
      doc.displayHeight = "400px";                                     // 74
      doc.displayUsableHeight = "400px";                               // 75
    } else {                                                           //
      doc.displayUsableHeight = doc.displayHeight;                     // 77
    }                                                                  //
    if (typeof doc.widgetStyle === "undefined" || !doc.widgetStyle || doc.widgetStyle.trim() == "" || doc.widgetStyle == "css" || doc.widgetStyle == "default") {
      doc.widgetStyle = "default";                                     // 80
      doc.usableWidgetStyle = "";                                      // 81
    } else {                                                           //
      doc.usableWidgetStyle = doc.widgetStyle;                         // 83
    }                                                                  //
    if (!doc.createdBy) {                                              // 85
      doc.createdBy = {};                                              // 86
    }                                                                  //
                                                                       //
    if (doc.displayUsableHeight.match(/px/)) {                         // 89
      var height = doc.displayUsableHeight.replace(/px/, "");          // 90
      doc.jsbinHeight = height - 20;                                   // 91
      doc.jsbinHeight += "px";                                         // 92
    } else {                                                           //
      doc.jsbinHeight = "";                                            // 94
    }                                                                  //
                                                                       //
    if (!doc.this_page_only) {                                         // 97
      doc.this_page_only = false;                                      // 98
    }                                                                  //
                                                                       //
    if (!doc.sort_order) {                                             // 101
      doc.sort_order = 0;                                              // 102
    }                                                                  //
                                                                       //
    if (!doc.visibility) {                                             // 105
      doc.visibility = "public";                                       // 106
    }                                                                  //
                                                                       //
    if (!doc.cacheConfig) {                                            // 109
      doc.cacheConfig = {};                                            // 110
    }                                                                  //
                                                                       //
    if (!doc.cacheConfig.ttl) {                                        // 113
      doc.cacheConfig.ttl = 60;                                        // 114
    }                                                                  //
                                                                       //
    return doc;                                                        // 118
  };                                                                   //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=common_functions.js.map
