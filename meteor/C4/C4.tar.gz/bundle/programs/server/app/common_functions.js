(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// common_functions.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
pageinfo = setWidgetDefaults = giphy_modal = null;                     // 1
                                                                       //
if (Meteor.isClient) {                                                 // 3
                                                                       //
  giphy_modal = function (term, text) {                                // 6
    $("#giphy_modal").modal('show');                                   // 7
    $(".giphy_modal_header").text(text);                               // 8
    var url = "/giphy_proxy/" + encodeURIComponent(term);              // 9
    $(".giphy_modal_image_div").empty();                               // 10
    var imgurl = url + "?" + new Date().getTime();                     // 11
    $(".giphy_modal_image_div").html("<img src='" + imgurl + "' width='200' class='giphy_modal_image_img'/>");
                                                                       //
    setTimeout(function () {                                           // 14
      $("#giphy_modal").modal('hide');                                 // 15
    }, 2000);                                                          //
  };                                                                   //
                                                                       //
  pageinfo = function () {                                             // 20
    var pagetype = "";                                                 // 21
    var pageid = "";                                                   // 22
    var pathname = window.location.pathname;                           // 23
    var split = pathname.split("/");                                   // 24
    split.shift();                                                     // 25
    var pageurl = split.join("/");                                     // 26
                                                                       //
    if (split.length > 0) {                                            // 28
      pagetype = split.shift();                                        // 29
    }                                                                  //
    if (split.length > 0) {                                            // 31
      pageid = split.shift();                                          // 32
    }                                                                  //
    pageid = pageid.replace(/:script/, "");                            // 34
    return { pageurl: pageurl,                                         // 35
      pagetype: pagetype,                                              // 36
      pageid: pageid };                                                // 37
  };                                                                   //
                                                                       //
  setWidgetDefaults = function (doc) {                                 // 41
    if (typeof doc.displayWidth === "undefined" || !doc.displayWidth || doc.displayWidth.trim() == "" || doc.displayWidth == "width" || doc.displayWidth == "default") {
      doc.displayWidth = "default";                                    // 43
      doc.displayUsableWidth = "";                                     // 44
    } else {                                                           //
      doc.displayUsableWidth = doc.displayWidth;                       // 46
    }                                                                  //
    if (typeof doc.displayHeight === "undefined" || !doc.displayHeight || doc.displayHeight.trim() == "" || doc.displayHeight == "height" || doc.displayHeight == "default") {
      doc.displayHeight = "default";                                   // 49
      doc.displayUsableHeight = "";                                    // 50
    } else {                                                           //
      doc.displayUsableHeight = doc.displayHeight;                     // 52
    }                                                                  //
    if (typeof doc.widgetStyle === "undefined" || !doc.widgetStyle || doc.widgetStyle.trim() == "" || doc.widgetStyle == "css" || doc.widgetStyle == "default") {
      doc.widgetStyle = "default";                                     // 55
      doc.usableWidgetStyle = "";                                      // 56
    } else {                                                           //
      doc.usableWidgetStyle = doc.widgetStyle;                         // 58
    }                                                                  //
    if (!doc.createdBy) {                                              // 60
      doc.createdBy = {};                                              // 61
    }                                                                  //
                                                                       //
    if (doc.displayUsableHeight.match(/px/)) {                         // 64
      var height = doc.displayUsableHeight.replace(/px/, "");          // 65
      doc.jsbinHeight = height - 20;                                   // 66
      doc.jsbinHeight += "px";                                         // 67
    } else {                                                           //
      doc.jsbinHeight = "";                                            // 69
    }                                                                  //
                                                                       //
    if (!doc.this_page_only) {                                         // 72
      doc.this_page_only = false;                                      // 73
    }                                                                  //
                                                                       //
    return doc;                                                        // 76
  };                                                                   //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=common_functions.js.map
