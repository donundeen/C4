(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// widget.js                                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
if (Meteor.isClient) {                                                 // 2
                                                                       //
  /////// FUNCTION DEFS                                                //
  var dix = 0;                                                         // 5
  function setDisplayModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin, widgetid) {
                                                                       //
    dix++;                                                             // 8
    var di = dix;                                                      // 9
    var newbintop = 0;                                                 // 10
    $(menu).hide();                                                    // 11
                                                                       //
    if (!widgetData.displayUsableWidth || widgetData.displayUsableWidth.trim() == "") {
      widgetData.displayUsableWidth = "50%";                           // 14
    }                                                                  //
                                                                       //
    console.log("height " + widgetData.displayUsableHeight);           // 18
                                                                       //
    console.log(widgetData);                                           // 20
                                                                       //
    $(".editmodeonly", widgetElement).hide();                          // 22
    $(".displaymodeonly", widgetElement).show();                       // 23
    iframeElement.oldbintop = $(bin).css("top");                       // 24
    $(bin).css("top", newbintop);                                      // 25
    $(widgetElement).attr("style", widgetData.usableWidgetStyle);      // 26
    $(widgetElement).css("width", widgetData.displayUsableWidth);      // 27
    $(widgetElement).css("height", widgetData.displayUsableHeight);    // 28
    $(widgetElement).css("border-radius", "20px");                     // 29
    $(".widgetDisplayHeader", widgetElement).hide();                   // 30
                                                                       //
    if (jsbin && jsbin.panels) {                                       // 33
      jsbin.panels.hide("html");                                       // 34
      jsbin.panels.hide("javascript");                                 // 35
      jsbin.panels.hide("css");                                        // 36
      jsbin.panels.hide("console");                                    // 37
    }                                                                  //
    $(".lock", widgetElement).show();                                  // 39
    $(".unlock", widgetElement).hide();                                // 40
    $(widgetElement).data("mode", "display");                          // 41
                                                                       //
    $(iframeElement).css("max-height", "");                            // 43
    $(iframeElement).css("max-width", "");                             // 44
    $(iframeElement).width($(widgetElement).width());                  // 45
    $(iframeElement).height($(widgetElement).height());                // 46
    $(iframeElement).css("border-radius", "20px");                     // 47
                                                                       //
    (function (wn, wd, ifr) {                                          // 49
      $(wn).resize(function () {                                       // 50
        console.log("resizing");                                       // 51
        $(ifr).width($(wd).width());                                   // 52
        $(ifr).height($(wd).height());                                 // 53
      });                                                              //
    })(window, widgetElement, iframeElement);                          //
  }                                                                    //
                                                                       //
  function setEditModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin) {
                                                                       //
    if (jsbin) {                                                       // 61
      jsbin.panels.show("html");                                       // 62
      jsbin.panels.show("javascript");                                 // 63
    }                                                                  //
    $(".lock", widgetElement).hide();                                  // 65
    $(".unlock", widgetElement).show();                                // 66
    //      editors.panels.show("css");                                //
                                                                       //
    var newbintop = 0;                                                 // 69
                                                                       //
    // put it in EDIT MODE                                             //
    $(menu).show();                                                    // 72
    $(".editmodeonly", widgetElement).show();                          // 73
    $(".displaymodeonly", widgetElement).hide();                       // 74
    $(bin).css("top", iframeElement.oldbintop);                        // 75
    $(widgetElement).css("width", $(window).width());                  // 76
    $(widgetElement).css("height", $(window).height());                // 77
    $(widgetElement).css("border-radius", "20px");                     // 78
                                                                       //
    $(iframeElement).css("max-height", "");                            // 80
    $(iframeElement).width($(widgetElement).width());                  // 81
    $(iframeElement).height($(widgetElement).height() - 80);           // 82
    $(iframeElement).css("border-radius", "20px");                     // 83
  }                                                                    //
  /////// END FUNCTION DEFS                                            //
                                                                       //
  /////// WIDGET ONRENDERED                                            //
  // In the client code, below everything else                         //
  Template.widget.onRendered(function () {                             // 92
                                                                       //
    (function (widget) {                                               // 94
      $("[title]").tooltip({ placement: "auto" });                     // 95
      var thisid = widget.data._id;                                    // 96
      var element = document.getElementById('jsbin_' + thisid);        // 97
      var thiselement = document.getElementById('widgetContainer_' + thisid);
      $(".widgetDisplayHeader", thiselement).hide();                   // 99
                                                                       //
      // maybe already exists?                                         //
      var theElement = document.getElementById('jsbin_' + thisid);     // 102
      if (theElement && theElement.contentWindow && theElement.contentWindow.document) {
        $(theElement).load(function () {                               // 104
          var widgetElement = document.getElementById('widgetContainer_' + thisid);
          var editors = jsbin = menu = bin = null;                     // 106
          if (theElement) {                                            // 107
            console.log("found element for jsbin_" + thisid);          // 108
            editors = theElement.contentWindow.editors;                // 109
            jsbin = theElement.contentWindow.jsbin;                    // 110
            menu = theElement.contentWindow.document.getElementById("control");
            bin = theElement.contentWindow.document.getElementById("bin");
            var thiselement = document.getElementById('widgetContainer_' + thisid);
            if (jsbin && jsbin.panels) {                               // 114
              jsbin.panels.saveOnExit = true;                          // 115
            }                                                          //
            setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, thisid);
          } else {                                                     //
            console.log("no element found for jsbin_" + thisid);       // 119
          }                                                            //
        });                                                            //
      }                                                                //
      // this part here happens when the JSBIN stuff is loaded.        //
      (function (this_id) {                                            // 124
        document.addEventListener("DOMNodeInserted", function (evt, item) {
          (function (_evt, _this_id) {                                 // 126
            if ($(_evt.target)[0].tagName == "IFRAME" && $(_evt.target)[0].id.replace("jsbin_", "") == _this_id) {
              console.log($(_evt.target)[0].id);                       // 128
              $(_evt.target).load(function () {                        // 129
                var widgetElement = document.getElementById('widgetContainer_' + _this_id);
                var editors = jsbin = menu = bin = null;               // 131
                var theElement = document.getElementById('jsbin_' + _this_id);
                if (theElement) {                                      // 133
                  editors = theElement.contentWindow.editors;          // 134
                  jsbin = theElement.contentWindow.jsbin;              // 135
                  menu = theElement.contentWindow.document.getElementById("control");
                  bin = theElement.contentWindow.document.getElementById("bin");
                } else {                                               //
                  console.log("no element found for jsbin_" + _this_id);
                }                                                      //
                if (jsbin && jsbin.panels) {                           // 141
                  jsbin.panels.saveOnExit = true;                      // 142
                }                                                      //
                setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, _this_id);
              });                                                      //
            }                                                          //
          })(evt, this_id);                                            //
        });                                                            //
      })(thisid);                                                      //
    })(this);                                                          //
  });                                                                  //
  /////////// END WIDGET ONRENDERED                                    //
                                                                       //
  //////////// EVENTS                                                  //
                                                                       //
  function insert_code(jsbin_id, codeString, codeStringRe, comments) {
                                                                       //
    var editors = document.getElementById(jsbin_id).contentWindow.editors;
                                                                       //
    if (!editors) {                                                    // 162
      return true;                                                     // 163
    }                                                                  //
    var code = editors.javascript.getCode();                           // 165
    var line = editors.javascript.editor.getCursor().line;             // 166
    var charpos = editors.javascript.editor.getCursor().ch;            // 167
    // make sure it's not already in there:                            //
    var codeRe = new RegExp("\/\/ *c4_requires[\\s\\S]*\\[[\\s\\S]*" + codeStringRe + "[\\s\\S]*\\] *,[\\s\\S]*\/\/ *end_c4_requires");
    var codeMatch = code.match(codeRe);                                // 170
    if (!codeMatch) {                                                  // 171
      // match to empty array                                          //
      var match = /(\/\/ *c4_requires[\s\S]*\[)\s*(\] *,[\s\S]*\/\/ *end_c4_requires)/;
      var results = code.match(match);                                 // 174
      newcode = code.replace(match, "$1\n" + codeString + " // " + comments + "\n$2");
                                                                       //
      if (newcode == code) {                                           // 177
        // match to non-empty array                                    //
        var match = /(\/\/ *c4_requires[\s\S]*\[)([^\]]*\] *,[\s\S]*\/\/ *end_c4_requires)/;
        var results = code.match(match);                               // 180
        newcode = code.replace(match, "$1\n" + codeString + ", // " + comments + "$2");
      }                                                                //
      code = newcode;                                                  // 183
      var state = { line: editors.javascript.editor.currentLine(),     // 184
        character: editors.javascript.editor.getCursor().ch,           // 185
        add: 0                                                         // 186
      };                                                               //
                                                                       //
      editors.javascript.setCode(code);                                // 189
      editors.javascript.editor.setCursor({ line: state.line + state.add, ch: state.character });
    }                                                                  //
  }                                                                    //
                                                                       //
  Template.help.events({                                               // 195
    "click .giphy": function (e, t) {                                  // 196
      $(e.target).hide();                                              // 197
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.widget.events({                                             // 201
                                                                       //
    "click .giphy": function (e, t) {                                  // 203
      $(e.target).hide();                                              // 204
    },                                                                 //
                                                                       //
    "click .delete": function () {                                     // 207
      if (this.isTemplate) {                                           // 208
        this.pagetype = "template";                                    // 209
        Widgets.update(this._id, this);                                // 210
      } else {                                                         //
        Widgets.remove(this._id);                                      // 212
      }                                                                //
      giphy_modal("erase", "Widget Deleted");                          // 214
      return false;                                                    // 215
    },                                                                 //
                                                                       //
    "click .save": function () {                                       // 218
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
      var revision = jsbin.state.revision;                             // 221
                                                                       //
      this.html = editors.html.getCode();                              // 223
      this.javascript = editors.javascript.getCode();                  // 224
      this.css = editors.css.getCode();                                // 225
      jsbin.saveDisabled = false;                                      // 226
      jsbin.panels.save();                                             // 227
      jsbin.panels.savecontent();                                      // 228
      Widgets.update(this._id, this);                                  // 229
                                                                       //
      // also trigger the jsbin save                                   //
      var dataobj = { html: this.html, css: this.css, javascript: this.javascript };
      var url = "/api/" + this.url + "/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 234
      HTTP.post(url, options, function (error, results) {});           // 235
                                                                       //
      giphy_modal("saved", "Widget Content Saved");                    // 238
                                                                       //
      return false;                                                    // 240
    },                                                                 //
                                                                       //
    "click .call_webservice_url": function (evt, template) {           // 244
      console.log("calling webservice url");                           // 245
      $("#webservice_insert_modal").modal('show');                     // 246
                                                                       //
      $("#webservice_insert_modal_submit").click(function () {         // 248
        var jsbin_id = 'jsbin_' + template.data.url;                   // 249
                                                                       //
        var url = $("#webservice_insert_url").val().trim();            // 252
        var name = $("#webservice_insert_name").val().trim();          // 253
        var auth_token = $("#webservice_insert_auth_token").val().trim();
        var return_type = $("input[name=webservice_insert_return_type]:checked").val().trim();
                                                                       //
        url = url.replace("||PAGEID||", "'+pageId()+'");               // 257
        url = url.replace("||PAGETYPE||", "'+pageType()+'");           // 258
                                                                       //
        var token_string;                                              // 260
        if (auth_token) {                                              // 261
          token_string = " \n authentication_token : '" + auth_token + "',";
        }                                                              //
                                                                       //
        var codeString = "{\n id:'" + name + "', \n type: 'webservice', " + token_string + " \n return_type: '" + return_type + "', \n url: '" + url + "' \n}";
        var codeStringRe = "\\{\n id:'" + name + "', \n type: 'webservice', \n return_type: '" + return_type + "', \n url: '" + url + "' \n\\}";
        var comments = " this will hold a " + return_type + " object";
                                                                       //
        insert_code(jsbin_id, codeString, codeStringRe, comments);     // 269
                                                                       //
        /* need to insert something like:                              //
        {                                                              //
        id : "vasearch",                                               //
        type :"webservice",                                            //
        return_type : "JSON" or "HTML"                                 //
        url : "http://www.vam.ac.uk/api/json/museumobject/search?q="+pageid()}
         */                                                            //
      });                                                              //
    },                                                                 //
                                                                       //
    "click .add_code": function (evt, template) {                      // 285
                                                                       //
      var pullfrom = evt.currentTarget.dataset.pullfrom;               // 287
      var pulltype = evt.currentTarget.dataset.pulltype;               // 288
                                                                       //
      if (this.url == template.data.url) {                             // 290
        return false;                                                  // 291
      }                                                                //
                                                                       //
      var type;                                                        // 294
      var comments = "";                                               // 295
      if (pulltype == "data") {                                        // 296
        type = "data";                                                 // 297
        comments = " This will hold a JSON object";                    // 298
      }                                                                //
      if (pulltype == "html") {                                        // 300
        type = "html";                                                 // 301
        comments = " This will hold a jQuery object";                  // 302
      }                                                                //
      var codeString = "{from: '" + pullfrom + "', type : '" + pulltype + "'}";
      var codeStringRe = "\\{from: '" + pullfrom + "', type : '" + pulltype + "'\\}";
                                                                       //
      var jsbin_id = 'jsbin_' + template.data.url;                     // 307
                                                                       //
      insert_code(jsbin_id, codeString, codeStringRe, comments);       // 309
                                                                       //
      return true;                                                     // 311
    },                                                                 //
                                                                       //
    "click .test": function () {                                       // 316
      console.log("testing widget thing");                             // 317
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
      //      console.log(editors);                                    //
      //      console.log(jsbin);                                      //
                                                                       //
      //      console.log(thiselement);                                //
                                                                       //
      var newbintop = 0;                                               // 328
      this.maxed = !this.maxed;                                        // 329
      if (this.maxed) {                                                // 330
        $(menu).hide();                                                // 331
        $(".editmodeonly", thiselement).hide();                        // 332
        this.oldbintop = $(bin).css("top");                            // 333
        $(bin).css("top", newbintop);                                  // 334
      } else {                                                         //
        $(menu).show();                                                // 336
        $(".editmodeonly", thiselement).show();                        // 337
        $(bin).css("top", this.oldbintop);                             // 338
      }                                                                //
      return false;                                                    // 340
    },                                                                 //
    /*                                                                 //
    panel ids: html, css, javascript, console, live                    //
    */                                                                 //
                                                                       //
    // this sets it to EDIT mode                                       //
    "click .lock": function () {                                       // 347
                                                                       //
      var widgetElement = document.getElementById('widgetContainer_' + this._id);
      var iframeElement = document.getElementById('jsbin_' + this._id);
                                                                       //
      var editors = iframeElement.contentWindow.editors;               // 352
      var jsbin = iframeElement.contentWindow.jsbin;                   // 353
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
                                                                       //
      setEditModeOn(this, iframeElement, widgetElement, menu, bin, jsbin);
                                                                       //
      return false;                                                    // 360
    },                                                                 //
                                                                       //
    // this sets it to DISPLAY mode                                    //
    "click .unlock": function () {                                     // 366
                                                                       //
      var widgetElement = document.getElementById('widgetContainer_' + this._id);
      var iframeElement = document.getElementById('jsbin_' + this._id);
                                                                       //
      var editors = iframeElement.contentWindow.editors;               // 371
      var jsbin = iframeElement.contentWindow.jsbin;                   // 372
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
      setDisplayModeOn(this, iframeElement, widgetElement, menu, bin, jsbin, this._id);
                                                                       //
      return false;                                                    // 377
    },                                                                 //
                                                                       //
    'click .copy': function () {                                       // 381
      console.log("copy from template " + this.url);                   // 382
                                                                       //
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 388
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 390
        console.log("data submitted");                                 // 391
        newWidget = { _id: results.data.url,                           // 392
          createdBy: { username: Meteor.user().username,               // 393
            userid: Meteor.userId() },                                 // 394
          isTemplate: false,                                           // 395
          html: results.data.html,                                     // 396
          javascript: results.data.javascript,                         // 397
          css: results.data.css,                                       // 398
          displayWidth: template.displayWidth,                         // 399
          displayHeight: template.displayHeight,                       // 400
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: template.widgetStyle,                           // 402
          name: "copy of " + template.name,                            // 403
          pagetype: pageinfo().pagetype,                               // 404
          pageurl: pageinfo().pageurl,                                 // 405
          pageid: pageinfo().pageid,                                   // 406
          url: results.data.url,                                       // 407
          createdAt: new Date(),                                       // 408
          rand: Math.random() };                                       // 409
        Widgets.insert(newWidget);                                     // 410
      });                                                              //
                                                                       //
      giphy_modal("copy", "widget copied");                            // 413
                                                                       //
      console.log("copied");                                           // 415
      return false;                                                    // 416
    },                                                                 //
                                                                       //
    "click .save_template": function () {                              // 420
      this.isTemplate = !this.isTemplate;                              // 421
      Widgets.update(this._id, this);                                  // 422
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
                                                                       //
      giphy_modal("promotion", "widget saved as a template");          // 426
                                                                       //
      return false;                                                    // 428
    },                                                                 //
                                                                       //
    "click .save_to_library": function () {                            // 431
      this.isTemplate = !this.isTemplate;                              // 432
      //      Widgets.update(this._id, this);                          //
                                                                       //
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 438
                                                                       //
      var newpagetype = "user_libs";                                   // 440
      var newpageid = Meteor.user().username;                          // 441
      var newpageurl = newpagetype + "/" + newpageurl;                 // 442
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 444
        console.log("data submitted");                                 // 445
        newWidget = { _id: results.data.url,                           // 446
          createdBy: { username: Meteor.user().username,               // 447
            userid: Meteor.userId() },                                 // 448
          inLibrary: true,                                             // 449
          html: results.data.html,                                     // 450
          javascript: results.data.javascript,                         // 451
          css: results.data.css,                                       // 452
          displayWidth: template.displayWidth,                         // 453
          displayHeight: template.displayHeight,                       // 454
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: template.widgetStyle,                           // 456
          name: "copy of " + template.name,                            // 457
          pagetype: newpagetype,                                       // 458
          pageurl: newpageurl,                                         // 459
          pageid: newpageid,                                           // 460
          this_page_only: true,                                        // 461
          url: results.data.url,                                       // 462
          createdAt: new Date(),                                       // 463
          rand: Math.random() };                                       // 464
        Widgets.insert(newWidget);                                     // 465
      });                                                              //
                                                                       //
      giphy_modal("library", "widget added to your library");          // 468
                                                                       //
      return false;                                                    // 470
    },                                                                 //
                                                                       //
    "mouseenter .widgetMouseOverTarget": function () {                 // 474
      console.log("mouseover");                                        // 475
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      var mode = $(thiselement).data("mode");                          // 477
      if (!mode || mode == "display") {                                // 478
        //      $(".widgetMouseOverTarget", thiselement ).css("background", "red");
        $(".widgetDisplayHeader", thiselement).show();                 // 480
        $(".widgetMouseOverTarget", thiselement).css("z-index", 5);    // 481
        $(".widgetDisplayHeader", thiselement).css("z-index", 10);     // 482
      }                                                                //
    },                                                                 //
                                                                       //
    "mouseleave .widgetDisplayHeader": function () {                   // 486
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      $(".widgetMouseOverTarget", thiselement).css("background", "transparent");
      $(".widgetDisplayHeader", thiselement).hide();                   // 489
      $(".widgetMouseOverTarget", thiselement).css("z-index", 10);     // 490
      $(".widgetDisplayHeader", thiselement).css("z-index", 5);        // 491
    }                                                                  //
                                                                       //
  });                                                                  //
  ////// END EVENTS                                                    //
                                                                       //
  ////// HELPERS                                                       //
                                                                       //
  Template.widget.helpers({                                            // 501
    otherwidgets: function () {                                        // 502
      // Otherwise, return all of the tasks                            //
      return Widgets.find({ pagetype: pageinfo().pagetype, _id: { $ne: this._id } }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
                                                                       //
    isMyWidget: function () {                                          // 507
      // is this a widget I created?                                   //
      if (this.createdBy && Meteor.user()) {                           // 509
        return this.createdBy.username = Meteor.user().username;       // 510
      } else {                                                         //
        return false;                                                  // 512
      }                                                                //
    }                                                                  //
  });                                                                  //
  //////// END HELPERS                                                 //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=widget.js.map
