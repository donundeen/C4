(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// widget.js                                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
if (Meteor.isClient) {                                                 // 2
                                                                       //
  /////// FUNCTION DEFS                                                //
  var dix = 0;                                                         // 5
  function setDisplayModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin, widgetid) {
                                                                       //
    dix++;                                                             // 8
    var di = dix;                                                      // 9
    var newbintop = 0;                                                 // 10
    $(menu).hide();                                                    // 11
                                                                       //
    if (!widgetData.displayUsableWidth || widgetData.displayUsableWidth.trim() == "") {
      widgetData.displayUsableWidth = "50%";                           // 14
    }                                                                  //
                                                                       //
    $(".editmodeonly", widgetElement).hide();                          // 17
    $(".displaymodeonly", widgetElement).show();                       // 18
    iframeElement.oldbintop = $(bin).css("top");                       // 19
    $(bin).css("top", newbintop);                                      // 20
    $(widgetElement).attr("style", widgetData.usableWidgetStyle);      // 21
    $(widgetElement).css("width", widgetData.displayUsableWidth);      // 22
    $(widgetElement).css("height", widgetData.displayUsableHeight);    // 23
    $(widgetElement).css("border-radius", "20px");                     // 24
    $(".widgetDisplayHeader", widgetElement).hide();                   // 25
                                                                       //
    if (jsbin && jsbin.panels) {                                       // 28
      jsbin.panels.hide("html");                                       // 29
      jsbin.panels.hide("javascript");                                 // 30
      jsbin.panels.hide("css");                                        // 31
      jsbin.panels.hide("console");                                    // 32
    }                                                                  //
    $(".lock", widgetElement).show();                                  // 34
    $(".unlock", widgetElement).hide();                                // 35
    $(widgetElement).data("mode", "display");                          // 36
                                                                       //
    $(iframeElement).css("max-height", "");                            // 38
    $(iframeElement).css("max-width", "");                             // 39
    $(iframeElement).width($(widgetElement).width());                  // 40
    $(iframeElement).height($(widgetElement).height());                // 41
    $(iframeElement).css("border-radius", "20px");                     // 42
                                                                       //
    (function (wn, wd, ifr) {                                          // 44
      $(wn).resize(function () {                                       // 45
        $(ifr).width($(wd).width());                                   // 46
        $(ifr).height($(wd).height());                                 // 47
      });                                                              //
    })(window, widgetElement, iframeElement);                          //
  }                                                                    //
                                                                       //
  function setEditModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin) {
                                                                       //
    if (jsbin) {                                                       // 55
      jsbin.panels.show("html");                                       // 56
      jsbin.panels.show("javascript");                                 // 57
    }                                                                  //
    $(".lock", widgetElement).hide();                                  // 59
    $(".unlock", widgetElement).show();                                // 60
    //      editors.panels.show("css");                                //
                                                                       //
    var newbintop = 0;                                                 // 63
                                                                       //
    // put it in EDIT MODE                                             //
    $(menu).show();                                                    // 66
    $(".editmodeonly", widgetElement).show();                          // 67
    $(".displaymodeonly", widgetElement).hide();                       // 68
    $(bin).css("top", iframeElement.oldbintop);                        // 69
    $(widgetElement).css("width", $(window).width());                  // 70
    $(widgetElement).css("height", $(window).height());                // 71
    $(widgetElement).css("border-radius", "20px");                     // 72
                                                                       //
    $(iframeElement).css("max-height", "");                            // 74
    $(iframeElement).width($(widgetElement).width());                  // 75
    $(iframeElement).height($(widgetElement).height() - 80);           // 76
    $(iframeElement).css("border-radius", "20px");                     // 77
  }                                                                    //
  /////// END FUNCTION DEFS                                            //
                                                                       //
  /////// WIDGET ONRENDERED                                            //
  // In the client code, below everything else                         //
  Template.widget.onRendered(function () {                             // 86
                                                                       //
    (function (widget) {                                               // 88
      $("[title]").tooltip({ placement: "auto" });                     // 89
      var thisid = widget.data._id;                                    // 90
      var element = document.getElementById('jsbin_' + thisid);        // 91
      var thiselement = document.getElementById('widgetContainer_' + thisid);
      $(".widgetDisplayHeader", thiselement).hide();                   // 93
                                                                       //
      // maybe already exists?                                         //
      var theElement = document.getElementById('jsbin_' + thisid);     // 96
      if (theElement && theElement.contentWindow && theElement.contentWindow.document) {
        $(theElement).load(function () {                               // 98
          var widgetElement = document.getElementById('widgetContainer_' + thisid);
          var editors = jsbin = menu = bin = null;                     // 100
          if (theElement) {                                            // 101
            editors = theElement.contentWindow.editors;                // 102
            jsbin = theElement.contentWindow.jsbin;                    // 103
            menu = theElement.contentWindow.document.getElementById("control");
            bin = theElement.contentWindow.document.getElementById("bin");
            var thiselement = document.getElementById('widgetContainer_' + thisid);
            if (jsbin && jsbin.panels) {                               // 107
              jsbin.panels.saveOnExit = true;                          // 108
            }                                                          //
            setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, thisid);
          } else {                                                     //
            console.log("no element found for jsbin_" + thisid);       // 112
          }                                                            //
        });                                                            //
      }                                                                //
      // this part here happens when the JSBIN stuff is loaded.        //
      (function (this_id) {                                            // 117
        document.addEventListener("DOMNodeInserted", function (evt, item) {
          (function (_evt, _this_id) {                                 // 119
            if ($(_evt.target)[0].tagName == "IFRAME" && $(_evt.target)[0].id.replace("jsbin_", "") == _this_id) {
              $(_evt.target).load(function () {                        // 121
                var widgetElement = document.getElementById('widgetContainer_' + _this_id);
                var editors = jsbin = menu = bin = null;               // 123
                var theElement = document.getElementById('jsbin_' + _this_id);
                if (theElement) {                                      // 125
                  editors = theElement.contentWindow.editors;          // 126
                  jsbin = theElement.contentWindow.jsbin;              // 127
                  menu = theElement.contentWindow.document.getElementById("control");
                  bin = theElement.contentWindow.document.getElementById("bin");
                } else {                                               //
                  console.log("no element found for jsbin_" + _this_id);
                }                                                      //
                if (jsbin && jsbin.panels) {                           // 133
                  jsbin.panels.saveOnExit = true;                      // 134
                }                                                      //
                setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, _this_id);
              });                                                      //
            }                                                          //
          })(evt, this_id);                                            //
        });                                                            //
      })(thisid);                                                      //
    })(this);                                                          //
  });                                                                  //
  /////////// END WIDGET ONRENDERED                                    //
                                                                       //
  //////////// EVENTS                                                  //
                                                                       //
  function insert_code(jsbin_id, codeString, codeStringRe, comments) {
                                                                       //
    var editors = document.getElementById(jsbin_id).contentWindow.editors;
                                                                       //
    if (!editors) {                                                    // 154
      return true;                                                     // 155
    }                                                                  //
    var code = editors.javascript.getCode();                           // 157
    var line = editors.javascript.editor.getCursor().line;             // 158
    var charpos = editors.javascript.editor.getCursor().ch;            // 159
    // make sure it's not already in there:                            //
    var codeRe = new RegExp("\/\/ *c4_requires[\\s\\S]*\\[[\\s\\S]*" + codeStringRe + "[\\s\\S]*\\] *,[\\s\\S]*\/\/ *end_c4_requires");
    var codeMatch = code.match(codeRe);                                // 162
    if (!codeMatch) {                                                  // 163
      // match to empty array                                          //
      var match = /(\/\/ *c4_requires[\s\S]*\[)\s*(\] *,[\s\S]*\/\/ *end_c4_requires)/;
      var results = code.match(match);                                 // 166
      newcode = code.replace(match, "$1\n" + codeString + " // " + comments + "\n$2");
                                                                       //
      if (newcode == code) {                                           // 169
        // match to non-empty array                                    //
        var match = /(\/\/ *c4_requires[\s\S]*\[)([^\]]*\] *,[\s\S]*\/\/ *end_c4_requires)/;
        var results = code.match(match);                               // 172
        newcode = code.replace(match, "$1\n" + codeString + ", // " + comments + "$2");
      }                                                                //
      code = newcode;                                                  // 175
      var state = { line: editors.javascript.editor.currentLine(),     // 176
        character: editors.javascript.editor.getCursor().ch,           // 177
        add: 0                                                         // 178
      };                                                               //
                                                                       //
      editors.javascript.setCode(code);                                // 181
      editors.javascript.editor.setCursor({ line: state.line + state.add, ch: state.character });
    }                                                                  //
  }                                                                    //
                                                                       //
  Template.help.events({                                               // 187
    "click .giphy": function (e, t) {                                  // 188
      $(e.target).hide();                                              // 189
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.widget.events({                                             // 193
                                                                       //
    "click .giphy": function (e, t) {                                  // 195
      $(e.target).hide();                                              // 196
    },                                                                 //
                                                                       //
    "click .delete": function () {                                     // 199
      if (this.isTemplate) {                                           // 200
        this.pagetype = "template";                                    // 201
        Widgets.update(this._id, this);                                // 202
      } else {                                                         //
        Widgets.remove(this._id);                                      // 204
      }                                                                //
      giphy_modal("erase", "Widget Deleted");                          // 206
      return false;                                                    // 207
    },                                                                 //
                                                                       //
    "click .save": function () {                                       // 210
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
      var revision = jsbin.state.revision;                             // 213
                                                                       //
      this.html = editors.html.getCode();                              // 215
      this.javascript = editors.javascript.getCode();                  // 216
      this.css = editors.css.getCode();                                // 217
      jsbin.saveDisabled = false;                                      // 218
      jsbin.panels.save();                                             // 219
      jsbin.panels.savecontent();                                      // 220
      Widgets.update(this._id, this);                                  // 221
                                                                       //
      // also trigger the jsbin save                                   //
      var dataobj = { html: this.html, css: this.css, javascript: this.javascript };
      var url = "/api/" + this.url + "/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 226
      HTTP.post(url, options, function (error, results) {});           // 227
                                                                       //
      giphy_modal("saved", "Widget Content Saved");                    // 230
                                                                       //
      return false;                                                    // 232
    },                                                                 //
                                                                       //
    "click .call_webservice_url": function (evt, template) {           // 236
      $("#webservice_insert_modal").modal('show');                     // 237
                                                                       //
      $("#webservice_insert_modal_submit").click(function () {         // 239
        var jsbin_id = 'jsbin_' + template.data.url;                   // 240
                                                                       //
        var url = $("#webservice_insert_url").val().trim();            // 243
        var name = $("#webservice_insert_name").val().trim();          // 244
        var auth_token = $("#webservice_insert_auth_token").val().trim();
        var return_type = $("input[name=webservice_insert_return_type]:checked").val().trim();
                                                                       //
        url = url.replace("||PAGEID||", "'+pageId()+'");               // 248
        url = url.replace("||PAGETYPE||", "'+pageType()+'");           // 249
                                                                       //
        var token_string;                                              // 251
        if (auth_token) {                                              // 252
          token_string = " \n authentication_token : '" + auth_token + "',";
        }                                                              //
                                                                       //
        var codeString = "{\n id:'" + name + "', \n type: 'webservice', " + token_string + " \n return_type: '" + return_type + "', \n url: '" + url + "' \n}";
        var codeStringRe = "\\{\n id:'" + name + "', \n type: 'webservice', \n return_type: '" + return_type + "', \n url: '" + url + "' \n\\}";
        var comments = " this will hold a " + return_type + " object";
                                                                       //
        insert_code(jsbin_id, codeString, codeStringRe, comments);     // 260
                                                                       //
        /* need to insert something like:                              //
        {                                                              //
        id : "vasearch",                                               //
        type :"webservice",                                            //
        return_type : "JSON" or "HTML"                                 //
        url : "http://www.vam.ac.uk/api/json/museumobject/search?q="+pageid()}
         */                                                            //
      });                                                              //
    },                                                                 //
                                                                       //
    "click .add_code": function (evt, template) {                      // 276
                                                                       //
      var pullfrom = evt.currentTarget.dataset.pullfrom;               // 278
      var pulltype = evt.currentTarget.dataset.pulltype;               // 279
                                                                       //
      if (this.url == template.data.url) {                             // 281
        return false;                                                  // 282
      }                                                                //
                                                                       //
      var type;                                                        // 285
      var comments = "";                                               // 286
      if (pulltype == "data") {                                        // 287
        type = "data";                                                 // 288
        comments = " This will hold a JSON object";                    // 289
      }                                                                //
      if (pulltype == "html") {                                        // 291
        type = "html";                                                 // 292
        comments = " This will hold a jQuery object";                  // 293
      }                                                                //
      var codeString = "{from: '" + pullfrom + "', type : '" + pulltype + "'}";
      var codeStringRe = "\\{from: '" + pullfrom + "', type : '" + pulltype + "'\\}";
                                                                       //
      var jsbin_id = 'jsbin_' + template.data.url;                     // 298
                                                                       //
      insert_code(jsbin_id, codeString, codeStringRe, comments);       // 300
                                                                       //
      return true;                                                     // 302
    },                                                                 //
                                                                       //
    "click .test": function () {                                       // 307
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
                                                                       //
      var newbintop = 0;                                               // 314
      this.maxed = !this.maxed;                                        // 315
      if (this.maxed) {                                                // 316
        $(menu).hide();                                                // 317
        $(".editmodeonly", thiselement).hide();                        // 318
        this.oldbintop = $(bin).css("top");                            // 319
        $(bin).css("top", newbintop);                                  // 320
      } else {                                                         //
        $(menu).show();                                                // 322
        $(".editmodeonly", thiselement).show();                        // 323
        $(bin).css("top", this.oldbintop);                             // 324
      }                                                                //
      return false;                                                    // 326
    },                                                                 //
    /*                                                                 //
    panel ids: html, css, javascript, console, live                    //
    */                                                                 //
                                                                       //
    // this sets it to EDIT mode                                       //
    "click .lock": function () {                                       // 333
                                                                       //
      var widgetElement = document.getElementById('widgetContainer_' + this._id);
      var iframeElement = document.getElementById('jsbin_' + this._id);
                                                                       //
      var editors = iframeElement.contentWindow.editors;               // 338
      var jsbin = iframeElement.contentWindow.jsbin;                   // 339
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
                                                                       //
      setEditModeOn(this, iframeElement, widgetElement, menu, bin, jsbin);
                                                                       //
      return false;                                                    // 346
    },                                                                 //
                                                                       //
    // this sets it to DISPLAY mode                                    //
    "click .unlock": function () {                                     // 352
                                                                       //
      var widgetElement = document.getElementById('widgetContainer_' + this._id);
      var iframeElement = document.getElementById('jsbin_' + this._id);
                                                                       //
      var editors = iframeElement.contentWindow.editors;               // 357
      var jsbin = iframeElement.contentWindow.jsbin;                   // 358
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
      setDisplayModeOn(this, iframeElement, widgetElement, menu, bin, jsbin, this._id);
                                                                       //
      return false;                                                    // 363
    },                                                                 //
                                                                       //
    'click .copy': function () {                                       // 367
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 371
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 373
        newWidget = { _id: results.data.url,                           // 374
          createdBy: { username: Meteor.user().username,               // 375
            userid: Meteor.userId() },                                 // 376
          isTemplate: false,                                           // 377
          html: results.data.html,                                     // 378
          javascript: results.data.javascript,                         // 379
          css: results.data.css,                                       // 380
          displayWidth: template.displayWidth,                         // 381
          displayHeight: template.displayHeight,                       // 382
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: template.widgetStyle,                           // 384
          name: "copy of " + template.name,                            // 385
          pagetype: pageinfo().pagetype,                               // 386
          pageurl: pageinfo().pageurl,                                 // 387
          pageid: pageinfo().pageid,                                   // 388
          url: results.data.url,                                       // 389
          createdAt: new Date(),                                       // 390
          rand: Math.random() };                                       // 391
        Widgets.insert(newWidget);                                     // 392
      });                                                              //
                                                                       //
      giphy_modal("copy", "widget copied");                            // 395
                                                                       //
      return false;                                                    // 397
    },                                                                 //
                                                                       //
    "click .save_template": function () {                              // 401
      this.isTemplate = !this.isTemplate;                              // 402
      Widgets.update(this._id, this);                                  // 403
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
                                                                       //
      giphy_modal("promotion", "widget saved as a template");          // 407
                                                                       //
      return false;                                                    // 409
    },                                                                 //
                                                                       //
    "click .save_to_library": function () {                            // 412
      this.isTemplate = !this.isTemplate;                              // 413
      //      Widgets.update(this._id, this);                          //
                                                                       //
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 419
                                                                       //
      var newpagetype = "user_libs";                                   // 421
      var newpageid = Meteor.user().username;                          // 422
      var newpageurl = newpagetype + "/" + newpageurl;                 // 423
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 425
        newWidget = { _id: results.data.url,                           // 426
          createdBy: { username: Meteor.user().username,               // 427
            userid: Meteor.userId() },                                 // 428
          inLibrary: true,                                             // 429
          html: results.data.html,                                     // 430
          javascript: results.data.javascript,                         // 431
          css: results.data.css,                                       // 432
          displayWidth: template.displayWidth,                         // 433
          displayHeight: template.displayHeight,                       // 434
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: template.widgetStyle,                           // 436
          name: "copy of " + template.name,                            // 437
          pagetype: newpagetype,                                       // 438
          pageurl: newpageurl,                                         // 439
          pageid: newpageid,                                           // 440
          this_page_only: true,                                        // 441
          url: results.data.url,                                       // 442
          createdAt: new Date(),                                       // 443
          rand: Math.random() };                                       // 444
        Widgets.insert(newWidget);                                     // 445
      });                                                              //
                                                                       //
      giphy_modal("library", "widget added to your library");          // 448
                                                                       //
      return false;                                                    // 450
    },                                                                 //
                                                                       //
    "mouseenter .widgetMouseOverTarget": function () {                 // 454
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      var mode = $(thiselement).data("mode");                          // 456
      if (!mode || mode == "display") {                                // 457
        //      $(".widgetMouseOverTarget", thiselement ).css("background", "red");
        $(".widgetDisplayHeader", thiselement).show();                 // 459
        $(".widgetMouseOverTarget", thiselement).css("z-index", 5);    // 460
        $(".widgetDisplayHeader", thiselement).css("z-index", 10);     // 461
      }                                                                //
    },                                                                 //
                                                                       //
    "mouseleave .widgetDisplayHeader": function () {                   // 465
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      $(".widgetMouseOverTarget", thiselement).css("background", "transparent");
      $(".widgetDisplayHeader", thiselement).hide();                   // 468
      $(".widgetMouseOverTarget", thiselement).css("z-index", 10);     // 469
      $(".widgetDisplayHeader", thiselement).css("z-index", 5);        // 470
    }                                                                  //
                                                                       //
  });                                                                  //
  ////// END EVENTS                                                    //
                                                                       //
  ////// HELPERS                                                       //
                                                                       //
  Template.widget.helpers({                                            // 480
    otherwidgets: function () {                                        // 481
      // Otherwise, return all of the tasks                            //
      return Widgets.find({ pagetype: pageinfo().pagetype, _id: { $ne: this._id } }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
                                                                       //
    isMyWidget: function () {                                          // 486
      // is this a widget I created?                                   //
      if (this.createdBy && Meteor.user()) {                           // 488
        return this.createdBy.username = Meteor.user().username;       // 489
      } else {                                                         //
        return false;                                                  // 491
      }                                                                //
    }                                                                  //
  });                                                                  //
  //////// END HELPERS                                                 //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=widget.js.map
