(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// widget.js                                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
if (Meteor.isClient) {                                                 // 2
                                                                       //
  /////// FUNCTION DEFS                                                //
  var dix = 0;                                                         // 5
  function setDisplayModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin, widgetid) {
                                                                       //
    dix++;                                                             // 8
    var di = dix;                                                      // 9
    var newbintop = 0;                                                 // 10
    $(menu).hide();                                                    // 11
                                                                       //
    if (!widgetData.displayUsableWidth || widgetData.displayUsableWidth.trim() == "") {
      widgetData.displayUsableWidth = "50%";                           // 14
    }                                                                  //
                                                                       //
    $(".editmodeonly", widgetElement).hide();                          // 17
    $(".displaymodeonly", widgetElement).show();                       // 18
    iframeElement.oldbintop = $(bin).css("top");                       // 19
    $(bin).css("top", newbintop);                                      // 20
    $(widgetElement).attr("style", widgetData.usableWidgetStyle);      // 21
    $(widgetElement).css("width", widgetData.displayUsableWidth);      // 22
    $(widgetElement).css("height", widgetData.displayUsableHeight);    // 23
    $(widgetElement).css("border-radius", "20px");                     // 24
    $(".widgetDisplayHeader", widgetElement).hide();                   // 25
                                                                       //
    if (jsbin && jsbin.panels) {                                       // 28
      jsbin.panels.hide("html");                                       // 29
      jsbin.panels.hide("javascript");                                 // 30
      jsbin.panels.hide("css");                                        // 31
      jsbin.panels.hide("console");                                    // 32
    }                                                                  //
    $(".lock", widgetElement).show();                                  // 34
    $(".unlock", widgetElement).hide();                                // 35
    $(widgetElement).data("mode", "display");                          // 36
                                                                       //
    $(iframeElement).css("max-height", "");                            // 38
    $(iframeElement).css("max-width", "");                             // 39
    $(iframeElement).width($(widgetElement).width());                  // 40
    $(iframeElement).height($(widgetElement).height());                // 41
    $(iframeElement).css("border-radius", "20px");                     // 42
                                                                       //
    (function (wn, wd, ifr) {                                          // 44
      $(wn).resize(function () {                                       // 45
        console.log("resizing");                                       // 46
        $(ifr).width($(wd).width());                                   // 47
        $(ifr).height($(wd).height());                                 // 48
      });                                                              //
    })(window, widgetElement, iframeElement);                          //
  }                                                                    //
                                                                       //
  function setEditModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin) {
                                                                       //
    if (jsbin) {                                                       // 56
      jsbin.panels.show("html");                                       // 57
      jsbin.panels.show("javascript");                                 // 58
    }                                                                  //
    $(".lock", widgetElement).hide();                                  // 60
    $(".unlock", widgetElement).show();                                // 61
    //      editors.panels.show("css");                                //
                                                                       //
    var newbintop = 0;                                                 // 64
                                                                       //
    // put it in EDIT MODE                                             //
    $(menu).show();                                                    // 67
    $(".editmodeonly", widgetElement).show();                          // 68
    $(".displaymodeonly", widgetElement).hide();                       // 69
    $(bin).css("top", iframeElement.oldbintop);                        // 70
    $(widgetElement).css("width", $(window).width());                  // 71
    $(widgetElement).css("height", $(window).height());                // 72
    $(widgetElement).css("border-radius", "20px");                     // 73
                                                                       //
    $(iframeElement).css("max-height", "");                            // 75
    $(iframeElement).width($(widgetElement).width());                  // 76
    $(iframeElement).height($(widgetElement).height() - 80);           // 77
    $(iframeElement).css("border-radius", "20px");                     // 78
  }                                                                    //
  /////// END FUNCTION DEFS                                            //
                                                                       //
  /////// WIDGET ONRENDERED                                            //
  // In the client code, below everything else                         //
  Template.widget.onRendered(function () {                             // 87
                                                                       //
    (function (widget) {                                               // 89
      $("[title]").tooltip({ placement: "auto" });                     // 90
      var thisid = widget.data._id;                                    // 91
      var element = document.getElementById('jsbin_' + thisid);        // 92
      var thiselement = document.getElementById('widgetContainer_' + thisid);
      $(".widgetDisplayHeader", thiselement).hide();                   // 94
                                                                       //
      // maybe already exists?                                         //
      var theElement = document.getElementById('jsbin_' + thisid);     // 97
      if (theElement && theElement.contentWindow && theElement.contentWindow.document) {
        $(theElement).load(function () {                               // 99
          var widgetElement = document.getElementById('widgetContainer_' + thisid);
          var editors = jsbin = menu = bin = null;                     // 101
          if (theElement) {                                            // 102
            console.log("found element for jsbin_" + thisid);          // 103
            editors = theElement.contentWindow.editors;                // 104
            jsbin = theElement.contentWindow.jsbin;                    // 105
            menu = theElement.contentWindow.document.getElementById("control");
            bin = theElement.contentWindow.document.getElementById("bin");
            var thiselement = document.getElementById('widgetContainer_' + thisid);
            if (jsbin && jsbin.panels) {                               // 109
              jsbin.panels.saveOnExit = true;                          // 110
            }                                                          //
            console.log("$?$?$?$?$?$??$?$?$?$$?$??$$");                // 112
            setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, thisid);
          } else {                                                     //
            console.log("no element found for jsbin_" + thisid);       // 115
          }                                                            //
        });                                                            //
      }                                                                //
      // this part here happens when the JSBIN stuff is loaded.        //
      (function (this_id) {                                            // 120
        document.addEventListener("DOMNodeInserted", function (evt, item) {
          (function (_evt, _this_id) {                                 // 122
            if ($(_evt.target)[0].tagName == "IFRAME" && $(_evt.target)[0].id.replace("jsbin_", "") == _this_id) {
              console.log($(_evt.target)[0].id);                       // 124
              $(_evt.target).load(function () {                        // 125
                var widgetElement = document.getElementById('widgetContainer_' + _this_id);
                var editors = jsbin = menu = bin = null;               // 127
                var theElement = document.getElementById('jsbin_' + _this_id);
                if (theElement) {                                      // 129
                  editors = theElement.contentWindow.editors;          // 130
                  jsbin = theElement.contentWindow.jsbin;              // 131
                  menu = theElement.contentWindow.document.getElementById("control");
                  bin = theElement.contentWindow.document.getElementById("bin");
                } else {                                               //
                  console.log("no element found for jsbin_" + _this_id);
                }                                                      //
                if (jsbin && jsbin.panels) {                           // 137
                  jsbin.panels.saveOnExit = true;                      // 138
                }                                                      //
                setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, _this_id);
              });                                                      //
            }                                                          //
          })(evt, this_id);                                            //
        });                                                            //
      })(thisid);                                                      //
    })(this);                                                          //
  });                                                                  //
  /////////// END WIDGET ONRENDERED                                    //
                                                                       //
  //////////// EVENTS                                                  //
                                                                       //
  function insert_code(jsbin_id, codeString, codeStringRe, comments) {
                                                                       //
    var editors = document.getElementById(jsbin_id).contentWindow.editors;
                                                                       //
    if (!editors) {                                                    // 158
      return true;                                                     // 159
    }                                                                  //
    var code = editors.javascript.getCode();                           // 161
    var line = editors.javascript.editor.getCursor().line;             // 162
    var charpos = editors.javascript.editor.getCursor().ch;            // 163
    // make sure it's not already in there:                            //
    var codeRe = new RegExp("\/\/ *c4_requires[\\s\\S]*\\[[\\s\\S]*" + codeStringRe + "[\\s\\S]*\\] *,[\\s\\S]*\/\/ *end_c4_requires");
    var codeMatch = code.match(codeRe);                                // 166
    if (!codeMatch) {                                                  // 167
      // match to empty array                                          //
      var match = /(\/\/ *c4_requires[\s\S]*\[)\s*(\] *,[\s\S]*\/\/ *end_c4_requires)/;
      var results = code.match(match);                                 // 170
      newcode = code.replace(match, "$1\n" + codeString + " // " + comments + "\n$2");
                                                                       //
      if (newcode == code) {                                           // 173
        // match to non-empty array                                    //
        var match = /(\/\/ *c4_requires[\s\S]*\[)([^\]]*\] *,[\s\S]*\/\/ *end_c4_requires)/;
        var results = code.match(match);                               // 176
        newcode = code.replace(match, "$1\n" + codeString + ", // " + comments + "$2");
      }                                                                //
      code = newcode;                                                  // 179
      var state = { line: editors.javascript.editor.currentLine(),     // 180
        character: editors.javascript.editor.getCursor().ch,           // 181
        add: 0                                                         // 182
      };                                                               //
                                                                       //
      editors.javascript.setCode(code);                                // 185
      editors.javascript.editor.setCursor({ line: state.line + state.add, ch: state.character });
    }                                                                  //
  }                                                                    //
                                                                       //
  Template.help.events({                                               // 191
    "click .giphy": function (e, t) {                                  // 192
      $(e.target).hide();                                              // 193
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.widget.events({                                             // 197
                                                                       //
    "click .giphy": function (e, t) {                                  // 199
      $(e.target).hide();                                              // 200
    },                                                                 //
                                                                       //
    "click .delete": function () {                                     // 203
      if (this.isTemplate) {                                           // 204
        this.pagetype = "template";                                    // 205
        Widgets.update(this._id, this);                                // 206
      } else {                                                         //
        Widgets.remove(this._id);                                      // 208
      }                                                                //
      giphy_modal("erase", "Widget Deleted");                          // 210
      return false;                                                    // 211
    },                                                                 //
                                                                       //
    "click .save": function () {                                       // 214
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
      var revision = jsbin.state.revision;                             // 217
                                                                       //
      this.html = editors.html.getCode();                              // 219
      this.javascript = editors.javascript.getCode();                  // 220
      this.css = editors.css.getCode();                                // 221
      jsbin.saveDisabled = false;                                      // 222
      jsbin.panels.save();                                             // 223
      jsbin.panels.savecontent();                                      // 224
      Widgets.update(this._id, this);                                  // 225
                                                                       //
      // also trigger the jsbin save                                   //
      var dataobj = { html: this.html, css: this.css, javascript: this.javascript };
      var url = "/api/" + this.url + "/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 230
      HTTP.post(url, options, function (error, results) {});           // 231
                                                                       //
      giphy_modal("saved", "Widget Content Saved");                    // 234
                                                                       //
      return false;                                                    // 236
    },                                                                 //
                                                                       //
    "click .call_webservice_url": function (evt, template) {           // 240
      console.log("calling webservice url");                           // 241
      $("#webservice_insert_modal").modal('show');                     // 242
                                                                       //
      $("#webservice_insert_modal_submit").click(function () {         // 244
        var jsbin_id = 'jsbin_' + template.data.url;                   // 245
                                                                       //
        var url = $("#webservice_insert_url").val().trim();            // 248
        var name = $("#webservice_insert_name").val().trim();          // 249
        var auth_token = $("#webservice_insert_auth_token").val().trim();
        var return_type = $("input[name=webservice_insert_return_type]:checked").val().trim();
                                                                       //
        url = url.replace("||PAGEID||", "'+pageId()+'");               // 253
        url = url.replace("||PAGETYPE||", "'+pageType()+'");           // 254
                                                                       //
        var token_string;                                              // 256
        if (auth_token) {                                              // 257
          token_string = " \n authentication_token : '" + auth_token + "',";
        }                                                              //
                                                                       //
        var codeString = "{\n id:'" + name + "', \n type: 'webservice', " + token_string + " \n return_type: '" + return_type + "', \n url: '" + url + "' \n}";
        var codeStringRe = "\\{\n id:'" + name + "', \n type: 'webservice', \n return_type: '" + return_type + "', \n url: '" + url + "' \n\\}";
        var comments = " this will hold a " + return_type + " object";
                                                                       //
        insert_code(jsbin_id, codeString, codeStringRe, comments);     // 265
                                                                       //
        /* need to insert something like:                              //
        {                                                              //
        id : "vasearch",                                               //
        type :"webservice",                                            //
        return_type : "JSON" or "HTML"                                 //
        url : "http://www.vam.ac.uk/api/json/museumobject/search?q="+pageid()}
         */                                                            //
      });                                                              //
    },                                                                 //
                                                                       //
    "click .add_code": function (evt, template) {                      // 281
                                                                       //
      var pullfrom = evt.currentTarget.dataset.pullfrom;               // 283
      var pulltype = evt.currentTarget.dataset.pulltype;               // 284
                                                                       //
      if (this.url == template.data.url) {                             // 286
        return false;                                                  // 287
      }                                                                //
                                                                       //
      var type;                                                        // 290
      var comments = "";                                               // 291
      if (pulltype == "data") {                                        // 292
        type = "data";                                                 // 293
        comments = " This will hold a JSON object";                    // 294
      }                                                                //
      if (pulltype == "html") {                                        // 296
        type = "html";                                                 // 297
        comments = " This will hold a jQuery object";                  // 298
      }                                                                //
      var codeString = "{from: '" + pullfrom + "', type : '" + pulltype + "'}";
      var codeStringRe = "\\{from: '" + pullfrom + "', type : '" + pulltype + "'\\}";
                                                                       //
      var jsbin_id = 'jsbin_' + template.data.url;                     // 303
                                                                       //
      insert_code(jsbin_id, codeString, codeStringRe, comments);       // 305
                                                                       //
      return true;                                                     // 307
    },                                                                 //
                                                                       //
    "click .test": function () {                                       // 312
      console.log("testing widget thing");                             // 313
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
      //      console.log(editors);                                    //
      //      console.log(jsbin);                                      //
                                                                       //
      //      console.log(thiselement);                                //
                                                                       //
      var newbintop = 0;                                               // 324
      this.maxed = !this.maxed;                                        // 325
      if (this.maxed) {                                                // 326
        $(menu).hide();                                                // 327
        $(".editmodeonly", thiselement).hide();                        // 328
        this.oldbintop = $(bin).css("top");                            // 329
        $(bin).css("top", newbintop);                                  // 330
      } else {                                                         //
        $(menu).show();                                                // 332
        $(".editmodeonly", thiselement).show();                        // 333
        $(bin).css("top", this.oldbintop);                             // 334
      }                                                                //
      return false;                                                    // 336
    },                                                                 //
    /*                                                                 //
    panel ids: html, css, javascript, console, live                    //
    */                                                                 //
                                                                       //
    // this sets it to EDIT mode                                       //
    "click .lock": function () {                                       // 343
                                                                       //
      var widgetElement = document.getElementById('widgetContainer_' + this._id);
      var iframeElement = document.getElementById('jsbin_' + this._id);
                                                                       //
      var editors = iframeElement.contentWindow.editors;               // 348
      var jsbin = iframeElement.contentWindow.jsbin;                   // 349
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
                                                                       //
      setEditModeOn(this, iframeElement, widgetElement, menu, bin, jsbin);
                                                                       //
      return false;                                                    // 356
    },                                                                 //
                                                                       //
    // this sets it to DISPLAY mode                                    //
    "click .unlock": function () {                                     // 362
                                                                       //
      var widgetElement = document.getElementById('widgetContainer_' + this._id);
      var iframeElement = document.getElementById('jsbin_' + this._id);
                                                                       //
      var editors = iframeElement.contentWindow.editors;               // 367
      var jsbin = iframeElement.contentWindow.jsbin;                   // 368
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
      setDisplayModeOn(this, iframeElement, widgetElement, menu, bin, jsbin, this._id);
                                                                       //
      return false;                                                    // 373
    },                                                                 //
                                                                       //
    'click .copy': function () {                                       // 377
      console.log("copy from template " + this.url);                   // 378
                                                                       //
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 384
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 386
        console.log("data submitted");                                 // 387
        newWidget = { _id: results.data.url,                           // 388
          createdBy: { username: Meteor.user().username,               // 389
            userid: Meteor.userId() },                                 // 390
          isTemplate: false,                                           // 391
          html: results.data.html,                                     // 392
          javascript: results.data.javascript,                         // 393
          css: results.data.css,                                       // 394
          displayWidth: template.displayWidth,                         // 395
          displayHeight: template.displayHeight,                       // 396
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: template.widgetStyle,                           // 398
          name: "copy of " + template.name,                            // 399
          pagetype: pageinfo().pagetype,                               // 400
          pageurl: pageinfo().pageurl,                                 // 401
          pageid: pageinfo().pageid,                                   // 402
          url: results.data.url,                                       // 403
          createdAt: new Date(),                                       // 404
          rand: Math.random() };                                       // 405
        Widgets.insert(newWidget);                                     // 406
      });                                                              //
                                                                       //
      giphy_modal("copy", "widget copied");                            // 409
                                                                       //
      console.log("copied");                                           // 411
      return false;                                                    // 412
    },                                                                 //
                                                                       //
    "click .save_template": function () {                              // 416
      this.isTemplate = !this.isTemplate;                              // 417
      Widgets.update(this._id, this);                                  // 418
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
                                                                       //
      giphy_modal("promotion", "widget saved as a template");          // 422
                                                                       //
      return false;                                                    // 424
    },                                                                 //
                                                                       //
    "click .save_to_library": function () {                            // 427
      this.isTemplate = !this.isTemplate;                              // 428
      //      Widgets.update(this._id, this);                          //
                                                                       //
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 434
                                                                       //
      var newpagetype = "user_libs";                                   // 436
      var newpageid = Meteor.user().username;                          // 437
      var newpageurl = newpagetype + "/" + newpageurl;                 // 438
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 440
        console.log("data submitted");                                 // 441
        newWidget = { _id: results.data.url,                           // 442
          createdBy: { username: Meteor.user().username,               // 443
            userid: Meteor.userId() },                                 // 444
          inLibrary: true,                                             // 445
          html: results.data.html,                                     // 446
          javascript: results.data.javascript,                         // 447
          css: results.data.css,                                       // 448
          displayWidth: template.displayWidth,                         // 449
          displayHeight: template.displayHeight,                       // 450
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: template.widgetStyle,                           // 452
          name: "copy of " + template.name,                            // 453
          pagetype: newpagetype,                                       // 454
          pageurl: newpageurl,                                         // 455
          pageid: newpageid,                                           // 456
          this_page_only: true,                                        // 457
          url: results.data.url,                                       // 458
          createdAt: new Date(),                                       // 459
          rand: Math.random() };                                       // 460
        Widgets.insert(newWidget);                                     // 461
      });                                                              //
                                                                       //
      giphy_modal("library", "widget added to your library");          // 464
                                                                       //
      return false;                                                    // 466
    },                                                                 //
                                                                       //
    "mouseenter .widgetMouseOverTarget": function () {                 // 470
      console.log("mouseover");                                        // 471
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      var mode = $(thiselement).data("mode");                          // 473
      if (!mode || mode == "display") {                                // 474
        //      $(".widgetMouseOverTarget", thiselement ).css("background", "red");
        $(".widgetDisplayHeader", thiselement).show();                 // 476
        $(".widgetMouseOverTarget", thiselement).css("z-index", 5);    // 477
        $(".widgetDisplayHeader", thiselement).css("z-index", 10);     // 478
      }                                                                //
    },                                                                 //
                                                                       //
    "mouseleave .widgetDisplayHeader": function () {                   // 482
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      $(".widgetMouseOverTarget", thiselement).css("background", "transparent");
      $(".widgetDisplayHeader", thiselement).hide();                   // 485
      $(".widgetMouseOverTarget", thiselement).css("z-index", 10);     // 486
      $(".widgetDisplayHeader", thiselement).css("z-index", 5);        // 487
    }                                                                  //
                                                                       //
  });                                                                  //
  ////// END EVENTS                                                    //
                                                                       //
  ////// HELPERS                                                       //
                                                                       //
  Template.widget.helpers({                                            // 497
    otherwidgets: function () {                                        // 498
      // Otherwise, return all of the tasks                            //
      return Widgets.find({ pagetype: pageinfo().pagetype, _id: { $ne: this._id } }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
                                                                       //
    isMyWidget: function () {                                          // 503
      // is this a widget I created?                                   //
      if (this.createdBy && Meteor.user()) {                           // 505
        return this.createdBy.username = Meteor.user().username;       // 506
      } else {                                                         //
        return false;                                                  // 508
      }                                                                //
    }                                                                  //
  });                                                                  //
  //////// END HELPERS                                                 //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=widget.js.map
