(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// widget.js                                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
if (Meteor.isClient) {                                                 // 2
                                                                       //
  /////// FUNCTION DEFS                                                //
  var dix = 0;                                                         // 5
  function setDisplayModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin, widgetid) {
                                                                       //
    dix++;                                                             // 8
    var di = dix;                                                      // 9
    var newbintop = 0;                                                 // 10
    $(menu).hide();                                                    // 11
                                                                       //
    if (!widgetData.displayUsableWidth || widgetData.displayUsableWidth.trim() == "") {
      widgetData.displayUsableWidth = "50%";                           // 14
    }                                                                  //
                                                                       //
    $(".editmodeonly", widgetElement).hide();                          // 17
    $(".displaymodeonly", widgetElement).show();                       // 18
    iframeElement.oldbintop = $(bin).css("top");                       // 19
    $(bin).css("top", newbintop);                                      // 20
    $(widgetElement).attr("style", widgetData.usableWidgetStyle);      // 21
    $(widgetElement).width(widgetData.displayUsableWidth);             // 22
    $(widgetElement).height(widgetData.displayUsableHeight);           // 23
    $(widgetElement).css("border-radius", "10px");                     // 24
    $(".widgetDisplayHeader", widgetElement).hide();                   // 25
                                                                       //
    if (jsbin && jsbin.panels) {                                       // 27
      jsbin.panels.hide("html");                                       // 28
      jsbin.panels.hide("javascript");                                 // 29
      jsbin.panels.hide("css");                                        // 30
      jsbin.panels.hide("console");                                    // 31
    }                                                                  //
    $(".lock", widgetElement).show();                                  // 33
    $(".unlock", widgetElement).hide();                                // 34
    $(widgetElement).data("mode", "display");                          // 35
                                                                       //
    console.log("setting display mode");                               // 37
                                                                       //
    $(iframeElement).css("max-height", "");                            // 39
    $(iframeElement).css("max-width", "");                             // 40
    $(iframeElement).width($(widgetElement).width());                  // 41
    $(iframeElement).height($(widgetElement).height());                // 42
    $(iframeElement).css("border-radius", "10px");                     // 43
                                                                       //
    (function (wn, wd, ifr) {                                          // 45
      $(wn).resize(function () {                                       // 46
        console.log("display mode resizing");                          // 47
        $(ifr).width($(wd).width());                                   // 48
        $(ifr).height($(wd).height());                                 // 49
      });                                                              //
    })(window, widgetElement, iframeElement);                          //
                                                                       //
    console.log($(widgetElement).width() + ", " + $(widgetElement).height());
    console.log($(iframeElement).width() + ", " + $(iframeElement).height());
  }                                                                    //
                                                                       //
  function setEditModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin) {
                                                                       //
    if (jsbin) {                                                       // 60
      jsbin.panels.show("html");                                       // 61
      jsbin.panels.show("javascript");                                 // 62
    }                                                                  //
    $(".lock", widgetElement).hide();                                  // 64
    $(".unlock", widgetElement).show();                                // 65
    //      editors.panels.show("css");                                //
                                                                       //
    var newbintop = 0;                                                 // 68
                                                                       //
    // put it in EDIT MODE                                             //
    $(menu).show();                                                    // 71
    $(".editmodeonly", widgetElement).show();                          // 72
    $(".displaymodeonly", widgetElement).hide();                       // 73
    $(bin).css("top", iframeElement.oldbintop);                        // 74
    $(widgetElement).width($(window).width());                         // 75
    $(widgetElement).height($(window).height());                       // 76
    $(widgetElement).css("border-radius", "10px");                     // 77
                                                                       //
    console.log("setting edit mode");                                  // 79
                                                                       //
    $(iframeElement).css("max-height", "");                            // 81
    $(iframeElement).width($(widgetElement).width());                  // 82
    $(iframeElement).height($(widgetElement).height() - 80);           // 83
    $(iframeElement).css("border-radius", "10px");                     // 84
                                                                       //
    (function (wn, wd, ifr) {                                          // 86
      $(wn).resize(function () {                                       // 87
        console.log("edit mode resizing");                             // 88
                                                                       //
        $(ifr).width($(wd).width());                                   // 90
        $(ifr).height($(wd).height());                                 // 91
      });                                                              //
    })(window, widgetElement, iframeElement);                          //
  }                                                                    //
  /////// END FUNCTION DEFS                                            //
                                                                       //
  /////// WIDGET ONRENDERED                                            //
  // In the client code, below everything else                         //
  Template.widget.onRendered(function () {                             // 103
                                                                       //
    (function (widget) {                                               // 105
      var thisid = widget.data._id;                                    // 106
      var element = document.getElementById('jsbin_' + thisid);        // 107
      var thiselement = document.getElementById('widgetContainer_' + thisid);
      $(".widgetDisplayHeader", thiselement).hide();                   // 109
                                                                       //
      // maybe already exists?                                         //
      var theElement = document.getElementById('jsbin_' + thisid);     // 112
      if (theElement && theElement.contentWindow && theElement.contentWindow.document) {
        $(theElement).load(function () {                               // 114
          var widgetElement = document.getElementById('widgetContainer_' + thisid);
          var editors = jsbin = menu = bin = null;                     // 116
          if (theElement) {                                            // 117
            editors = theElement.contentWindow.editors;                // 118
            jsbin = theElement.contentWindow.jsbin;                    // 119
            menu = theElement.contentWindow.document.getElementById("control");
            bin = theElement.contentWindow.document.getElementById("bin");
            var thiselement = document.getElementById('widgetContainer_' + thisid);
            if (jsbin && jsbin.panels) {                               // 123
              jsbin.panels.saveOnExit = true;                          // 124
            }                                                          //
            setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, thisid);
          } else {                                                     //
            console.log("no element found for jsbin_" + thisid);       // 128
          }                                                            //
        });                                                            //
      }                                                                //
      // this part here happens when the JSBIN stuff is loaded.        //
      (function (this_id) {                                            // 133
        document.addEventListener("DOMNodeInserted", function (evt, item) {
          (function (_evt, _this_id) {                                 // 135
            if ($(_evt.target)[0].tagName == "IFRAME" && $(_evt.target)[0].id.replace("jsbin_", "") == _this_id) {
              $(_evt.target).load(function () {                        // 137
                var widgetElement = document.getElementById('widgetContainer_' + _this_id);
                var editors = jsbin = menu = bin = null;               // 139
                var theElement = document.getElementById('jsbin_' + _this_id);
                if (theElement) {                                      // 141
                  editors = theElement.contentWindow.editors;          // 142
                  console.log(editors.live.el);                        // 143
                  jsbin = theElement.contentWindow.jsbin;              // 144
                  console.log(jsbin);                                  // 145
                  menu = theElement.contentWindow.document.getElementById("control");
                  bin = theElement.contentWindow.document.getElementById("bin");
                  console.log(bin);                                    // 148
                } else {                                               //
                  console.log("no element found for jsbin_" + _this_id);
                }                                                      //
                if (jsbin && jsbin.panels) {                           // 152
                  jsbin.panels.saveOnExit = true;                      // 153
                }                                                      //
                setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, _this_id);
              });                                                      //
            }                                                          //
          })(evt, this_id);                                            //
        });                                                            //
      })(thisid);                                                      //
    })(this);                                                          //
  });                                                                  //
  /////////// END WIDGET ONRENDERED                                    //
                                                                       //
  //////////// EVENTS                                                  //
                                                                       //
  function insert_code(jsbin_id, codeString, codeStringRe, comments) {
                                                                       //
    var editors = document.getElementById(jsbin_id).contentWindow.editors;
                                                                       //
    if (!editors) {                                                    // 173
      return true;                                                     // 174
    }                                                                  //
    var code = editors.javascript.getCode();                           // 176
    var line = editors.javascript.editor.getCursor().line;             // 177
    var charpos = editors.javascript.editor.getCursor().ch;            // 178
    // make sure it's not already in there:                            //
    var codeRe = new RegExp("\/\/ *c4_requires[\\s\\S]*\\[[\\s\\S]*" + codeStringRe + "[\\s\\S]*\\] *,[\\s\\S]*\/\/ *end_c4_requires");
    var codeMatch = code.match(codeRe);                                // 181
    if (!codeMatch) {                                                  // 182
      // match to empty array                                          //
      var match = /(\/\/ *c4_requires[\s\S]*\[)\s*(\] *,[\s\S]*\/\/ *end_c4_requires)/;
      var results = code.match(match);                                 // 185
      newcode = code.replace(match, "$1\n" + codeString + " // " + comments + "\n$2");
                                                                       //
      if (newcode == code) {                                           // 188
        // match to non-empty array                                    //
        var match = /(\/\/ *c4_requires[\s\S]*\[)([^\]]*\] *,[\s\S]*\/\/ *end_c4_requires)/;
        var results = code.match(match);                               // 191
        newcode = code.replace(match, "$1\n" + codeString + ", // " + comments + "$2");
      }                                                                //
      code = newcode;                                                  // 194
      var state = { line: editors.javascript.editor.currentLine(),     // 195
        character: editors.javascript.editor.getCursor().ch,           // 196
        add: 0                                                         // 197
      };                                                               //
                                                                       //
      editors.javascript.setCode(code);                                // 200
      editors.javascript.editor.setCursor({ line: state.line + state.add, ch: state.character });
    }                                                                  //
  }                                                                    //
                                                                       //
  Template.help.events({                                               // 206
    "click .giphy": function (e, t) {                                  // 207
      $(e.target).hide();                                              // 208
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.widget.events({                                             // 212
                                                                       //
    "click .giphy": function (e, t) {                                  // 214
      $(e.target).hide();                                              // 215
    },                                                                 //
                                                                       //
    "click .delete": function () {                                     // 218
      if (this.isTemplate) {                                           // 219
        this.pagetype = "template";                                    // 220
        Widgets.update(this._id, this);                                // 221
      } else {                                                         //
        Widgets.remove(this._id);                                      // 223
      }                                                                //
      giphy_modal("erase", "Widget Deleted");                          // 225
      return false;                                                    // 226
    },                                                                 //
                                                                       //
    "click .save": function () {                                       // 229
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
      var revision = jsbin.state.revision;                             // 232
                                                                       //
      this.html = editors.html.getCode();                              // 234
      this.javascript = editors.javascript.getCode();                  // 235
      this.css = editors.css.getCode();                                // 236
      jsbin.saveDisabled = false;                                      // 237
      jsbin.panels.save();                                             // 238
      jsbin.panels.savecontent();                                      // 239
      Widgets.update(this._id, this);                                  // 240
                                                                       //
      // also trigger the jsbin save                                   //
      var dataobj = { html: this.html, css: this.css, javascript: this.javascript };
      var url = "/api/" + this.url + "/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 245
      HTTP.post(url, options, function (error, results) {});           // 246
                                                                       //
      giphy_modal("saved", "Widget Content Saved");                    // 249
                                                                       //
      return false;                                                    // 251
    },                                                                 //
                                                                       //
    "click .call_webservice_url": function (evt, template) {           // 255
      $("#webservice_insert_modal").modal('show');                     // 256
                                                                       //
      $("#webservice_insert_modal_submit").click(function () {         // 258
        var jsbin_id = 'jsbin_' + template.data.url;                   // 259
                                                                       //
        var url = $("#webservice_insert_url").val().trim();            // 262
        var name = $("#webservice_insert_name").val().trim();          // 263
        var auth_token = $("#webservice_insert_auth_token").val().trim();
        var return_type = $("input[name=webservice_insert_return_type]:checked").val().trim();
                                                                       //
        url = url.replace("||PAGEID||", "'+pageId()+'");               // 267
        url = url.replace("||PAGETYPE||", "'+pageType()+'");           // 268
                                                                       //
        var token_string;                                              // 270
        if (auth_token) {                                              // 271
          token_string = " \n authentication_token : '" + auth_token + "',";
        }                                                              //
                                                                       //
        var codeString = "{\n id:'" + name + "', \n type: 'webservice', " + token_string + " \n return_type: '" + return_type + "', \n url: '" + url + "' \n}";
        var codeStringRe = "\\{\n id:'" + name + "', \n type: 'webservice', \n return_type: '" + return_type + "', \n url: '" + url + "' \n\\}";
        var comments = " this will hold a " + return_type + " object";
                                                                       //
        insert_code(jsbin_id, codeString, codeStringRe, comments);     // 279
      });                                                              //
    },                                                                 //
                                                                       //
    "click .add_code": function (evt, template) {                      // 286
                                                                       //
      var pullfrom = evt.currentTarget.dataset.pullfrom;               // 288
      var pulltype = evt.currentTarget.dataset.pulltype;               // 289
                                                                       //
      if (this.url == template.data.url) {                             // 291
        return false;                                                  // 292
      }                                                                //
                                                                       //
      var type;                                                        // 295
      var comments = "";                                               // 296
      if (pulltype == "data") {                                        // 297
        type = "data";                                                 // 298
        comments = " This will hold a JSON object";                    // 299
      }                                                                //
      if (pulltype == "html") {                                        // 301
        type = "html";                                                 // 302
        comments = " This will hold a jQuery object";                  // 303
      }                                                                //
      var codeString = "{from: '" + pullfrom + "', type : '" + pulltype + "'}";
      var codeStringRe = "\\{from: '" + pullfrom + "', type : '" + pulltype + "'\\}";
                                                                       //
      var jsbin_id = 'jsbin_' + template.data.url;                     // 308
                                                                       //
      insert_code(jsbin_id, codeString, codeStringRe, comments);       // 310
                                                                       //
      return true;                                                     // 312
    },                                                                 //
                                                                       //
    "click .test": function () {                                       // 317
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
                                                                       //
      var newbintop = 0;                                               // 324
      this.maxed = !this.maxed;                                        // 325
      if (this.maxed) {                                                // 326
        $(menu).hide();                                                // 327
        $(".editmodeonly", thiselement).hide();                        // 328
        this.oldbintop = $(bin).css("top");                            // 329
        $(bin).css("top", newbintop);                                  // 330
      } else {                                                         //
        $(menu).show();                                                // 332
        $(".editmodeonly", thiselement).show();                        // 333
        $(bin).css("top", this.oldbintop);                             // 334
      }                                                                //
      return false;                                                    // 336
    },                                                                 //
    /*                                                                 //
    panel ids: html, css, javascript, console, live                    //
    */                                                                 //
                                                                       //
    // this sets it to EDIT mode                                       //
    "click .lock": function () {                                       // 343
                                                                       //
      var widgetElement = document.getElementById('widgetContainer_' + this._id);
      var iframeElement = document.getElementById('jsbin_' + this._id);
                                                                       //
      var editors = iframeElement.contentWindow.editors;               // 348
      var jsbin = iframeElement.contentWindow.jsbin;                   // 349
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
                                                                       //
      setEditModeOn(this, iframeElement, widgetElement, menu, bin, jsbin);
                                                                       //
      return false;                                                    // 355
    },                                                                 //
                                                                       //
    // this sets it to DISPLAY mode                                    //
    "click .unlock": function () {                                     // 360
                                                                       //
      var widgetElement = document.getElementById('widgetContainer_' + this._id);
      var iframeElement = document.getElementById('jsbin_' + this._id);
                                                                       //
      var editors = iframeElement.contentWindow.editors;               // 365
      var jsbin = iframeElement.contentWindow.jsbin;                   // 366
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
      setDisplayModeOn(this, iframeElement, widgetElement, menu, bin, jsbin, this._id);
                                                                       //
      return false;                                                    // 371
    },                                                                 //
                                                                       //
    // setting visibility on widgets (public or private)               //
    "click .setpublic": function () {                                  // 376
      console.log("setpublic");                                        // 377
      this.visibility = "public";                                      // 378
      Widgets.update(this._id, this);                                  // 379
      return false;                                                    // 380
    },                                                                 //
    "click .setprivate": function () {                                 // 382
      console.log("setprivate");                                       // 383
      this.visibility = "private";                                     // 384
      Widgets.update(this._id, this);                                  // 385
      return false;                                                    // 386
    },                                                                 //
                                                                       //
    'click .copy': function () {                                       // 390
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 394
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 396
        newWidget = { _id: results.data.url,                           // 397
          createdBy: { username: Meteor.user().username,               // 398
            userid: Meteor.userId() },                                 // 399
          isTemplate: false,                                           // 400
          html: results.data.html,                                     // 401
          javascript: results.data.javascript,                         // 402
          css: results.data.css,                                       // 403
          displayWidth: template.displayWidth,                         // 404
          displayHeight: template.displayHeight,                       // 405
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: template.widgetStyle,                           // 407
          name: "copy of " + template.name,                            // 408
          pagetype: pageinfo().pagetype,                               // 409
          pageurl: pageinfo().pageurl,                                 // 410
          pageid: pageinfo().pageid,                                   // 411
          url: results.data.url,                                       // 412
          createdAt: new Date(),                                       // 413
          visibility: "private",                                       // 414
          rand: Math.random() };                                       // 415
        Widgets.insert(newWidget);                                     // 416
      });                                                              //
                                                                       //
      giphy_modal("copy", "widget copied");                            // 419
                                                                       //
      return false;                                                    // 421
    },                                                                 //
                                                                       //
    "click .save_template": function () {                              // 425
      this.isTemplate = !this.isTemplate;                              // 426
      Widgets.update(this._id, this);                                  // 427
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
                                                                       //
      giphy_modal("promotion", "widget saved as a template");          // 431
                                                                       //
      return false;                                                    // 433
    },                                                                 //
                                                                       //
    "click .save_to_library": function () {                            // 436
      this.isTemplate = !this.isTemplate;                              // 437
      //      Widgets.update(this._id, this);                          //
                                                                       //
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 443
                                                                       //
      var newpagetype = "user_libs";                                   // 445
      var newpageid = Meteor.user().username;                          // 446
      var newpageurl = newpagetype + "/" + newpageurl;                 // 447
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 449
        newWidget = { _id: results.data.url,                           // 450
          createdBy: { username: Meteor.user().username,               // 451
            userid: Meteor.userId() },                                 // 452
          inLibrary: true,                                             // 453
          html: results.data.html,                                     // 454
          javascript: results.data.javascript,                         // 455
          css: results.data.css,                                       // 456
          displayWidth: template.displayWidth,                         // 457
          displayHeight: template.displayHeight,                       // 458
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: template.widgetStyle,                           // 460
          name: "copy of " + template.name,                            // 461
          pagetype: newpagetype,                                       // 462
          pageurl: newpageurl,                                         // 463
          pageid: newpageid,                                           // 464
          this_page_only: true,                                        // 465
          url: results.data.url,                                       // 466
          createdAt: new Date(),                                       // 467
          visibility: "private",                                       // 468
          rand: Math.random() };                                       // 469
        Widgets.insert(newWidget);                                     // 470
      });                                                              //
                                                                       //
      giphy_modal("library", "widget added to your library");          // 473
                                                                       //
      return false;                                                    // 475
    },                                                                 //
                                                                       //
    "click .openinfo": function () {                                   // 478
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      var mode = $(thiselement).data("mode");                          // 480
      if (!mode || mode == "display") {                                // 481
        //      $(".widgetMouseOverTarget", thiselement ).css("background", "red");
        $(".widgetDisplayHeader", thiselement).show();                 // 483
        $(".widgetMouseOverTarget", thiselement).css("z-index", 5);    // 484
        $(".widgetDisplayHeader", thiselement).css("z-index", 10);     // 485
      }                                                                //
    },                                                                 //
                                                                       //
    "mouseleave .widgetDisplayHeader": function () {                   // 490
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      $(".widgetMouseOverTarget", thiselement).css("background", "transparent");
      $(".widgetDisplayHeader", thiselement).hide();                   // 493
      $(".widgetMouseOverTarget", thiselement).css("z-index", 10);     // 494
      $(".widgetDisplayHeader", thiselement).css("z-index", 5);        // 495
    }                                                                  //
                                                                       //
  });                                                                  //
  ////// END EVENTS                                                    //
                                                                       //
  ////// HELPERS                                                       //
                                                                       //
  Template.widget.helpers({                                            // 505
    otherwidgets: function () {                                        // 506
      // Otherwise, return all of the tasks                            //
      return Widgets.find({ pagetype: pageinfo().pagetype, _id: { $ne: this._id } }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
                                                                       //
    isPublic: function () {                                            // 511
      if (this.visibility == "public") {                               // 512
        return true;                                                   // 513
      }                                                                //
      return false;                                                    // 515
    },                                                                 //
                                                                       //
    pageTypeAndUrl: function () {                                      // 518
                                                                       //
      return this.pagetype + "/" + this.url;                           // 520
    },                                                                 //
                                                                       //
    pageUrlAndUrl: function () {                                       // 523
      return pageinfo().pageurl + "/" + this.url;                      // 524
    },                                                                 //
                                                                       //
    commentsCount: function (id) {                                     // 527
      console.log("in commentsCount " + id);                           // 528
      var value = Meteor.call("comments/count", id, function (item) {  // 529
        console.log("in callbakc" + item);                             // 529
      });                                                              //
      console.log("value is " + value);                                // 530
      return value;                                                    // 531
    },                                                                 //
                                                                       //
    isMyWidget: function () {                                          // 534
      // is this a widget I created?                                   //
      if (this.createdBy && Meteor.user()) {                           // 536
        return this.createdBy.username == Meteor.user().username;      // 537
      } else {                                                         //
        return false;                                                  // 539
      }                                                                //
    }                                                                  //
  });                                                                  //
  //////// END HELPERS                                                 //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=widget.js.map
