(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// widget.js                                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
if (Meteor.isClient) {                                                 // 2
                                                                       //
  /////// FUNCTION DEFS                                                //
  function setDisplayModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin) {
    var newbintop = 0;                                                 // 6
    $(menu).hide();                                                    // 7
    $(".editmodeonly", widgetElement).hide();                          // 8
    $(".displaymodeonly", widgetElement).show();                       // 9
    iframeElement.oldbintop = $(bin).css("top");                       // 10
    $(bin).css("top", newbintop);                                      // 11
    $(widgetElement).attr("style", widgetData.usableWidgetStyle);      // 12
    $(widgetElement).css("width", widgetData.displayUsableWidth);      // 13
    $(widgetElement).css("height", widgetData.displayUsableHeight);    // 14
    $(".widgetDisplayHeader", widgetElement).hide();                   // 15
                                                                       //
    if (jsbin && jsbin.panels) {                                       // 17
      jsbin.panels.hide("html");                                       // 18
      jsbin.panels.hide("javascript");                                 // 19
      jsbin.panels.hide("css");                                        // 20
      jsbin.panels.hide("console");                                    // 21
    }                                                                  //
    $(".lock", widgetElement).show();                                  // 23
    $(".unlock", widgetElement).hide();                                // 24
    $(widgetElement).data("mode", "display");                          // 25
  }                                                                    //
                                                                       //
  function setEditModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin) {
                                                                       //
    if (jsbin) {                                                       // 31
      jsbin.panels.show("html");                                       // 32
      jsbin.panels.show("javascript");                                 // 33
    }                                                                  //
    $(".lock", widgetElement).hide();                                  // 35
    $(".unlock", widgetElement).show();                                // 36
    //      editors.panels.show("css");                                //
                                                                       //
    var newbintop = 0;                                                 // 39
                                                                       //
    // put it in EDIT MODE                                             //
    $(menu).show();                                                    // 42
    $(".editmodeonly", widgetElement).show();                          // 43
    $(".displaymodeonly", widgetElement).hide();                       // 44
    $(bin).css("top", iframeElement.oldbintop);                        // 45
    $(widgetElement).css("width", "100%");                             // 46
    $(widgetElement).css("height", "100%");                            // 47
  }                                                                    //
  /////// END FUNCTION DEFS                                            //
                                                                       //
  /////// WIDGET ONRENDERED                                            //
  // In the client code, below everything else                         //
  Template.widget.onRendered(function () {                             // 56
                                                                       //
    (function (widget) {                                               // 58
      $("[title]").tooltip({ placement: "auto" });                     // 59
      var thisid = widget.data._id;                                    // 60
      var element = document.getElementById('jsbin_' + thisid);        // 61
      var thiselement = document.getElementById('widgetContainer_' + thisid);
      $(".widgetDisplayHeader", thiselement).hide();                   // 63
                                                                       //
      // maybe already exists?                                         //
      var theElement = document.getElementById('jsbin_' + thisid);     // 66
      if (theElement && theElement.contentWindow && theElement.contentWindow.document) {
        $(theElement).load(function () {                               // 68
          var widgetElement = document.getElementById('widgetContainer_' + thisid);
          var editors = jsbin = menu = bin = null;                     // 70
          if (theElement) {                                            // 71
            console.log("found element for jsbin_" + thisid);          // 72
            editors = theElement.contentWindow.editors;                // 73
            jsbin = theElement.contentWindow.jsbin;                    // 74
            menu = theElement.contentWindow.document.getElementById("control");
            bin = theElement.contentWindow.document.getElementById("bin");
            var thiselement = document.getElementById('widgetContainer_' + thisid);
            if (jsbin && jsbin.panels) {                               // 78
              jsbin.panels.saveOnExit = true;                          // 79
            }                                                          //
            setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin);
          } else {                                                     //
            console.log("no element found for jsbin_" + thisid);       // 83
          }                                                            //
        });                                                            //
      }                                                                //
      // this part here happens when the JSBIN stuff is loaded.        //
      document.addEventListener("DOMNodeInserted", function (evt, item) {
        if ($(evt.target)[0].tagName == "IFRAME") {                    // 89
          $(evt.target).load(function () {                             // 90
            console.log("target load " + thisid);                      // 91
            var widgetElement = document.getElementById('widgetContainer_' + thisid);
            var editors = jsbin = menu = bin = null;                   // 93
            var theElement = document.getElementById('jsbin_' + thisid);
            if (theElement) {                                          // 95
              editors = theElement.contentWindow.editors;              // 96
              jsbin = theElement.contentWindow.jsbin;                  // 97
              menu = theElement.contentWindow.document.getElementById("control");
              bin = theElement.contentWindow.document.getElementById("bin");
            } else {                                                   //
              console.log("no element found for jsbin_" + thisid);     // 101
            }                                                          //
            if (jsbin && jsbin.panels) {                               // 103
              jsbin.panels.saveOnExit = true;                          // 104
            }                                                          //
            setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin);
          });                                                          //
        }                                                              //
      });                                                              //
    })(this);                                                          //
  });                                                                  //
  /////////// END WIDGET ONRENDERED                                    //
                                                                       //
  //////////// EVENTS                                                  //
                                                                       //
  function insert_code(jsbin_id, codeString, codeStringRe, comments) {
                                                                       //
    var editors = document.getElementById(jsbin_id).contentWindow.editors;
                                                                       //
    if (!editors) {                                                    // 122
      return true;                                                     // 123
    }                                                                  //
    var code = editors.javascript.getCode();                           // 125
    var line = editors.javascript.editor.getCursor().line;             // 126
    var charpos = editors.javascript.editor.getCursor().ch;            // 127
    // make sure it's not already in there:                            //
    var codeRe = new RegExp("\/\/ *c4_requires[\\s\\S]*\\[[\\s\\S]*" + codeStringRe + "[\\s\\S]*\\] *,[\\s\\S]*\/\/ *end_c4_requires");
    var codeMatch = code.match(codeRe);                                // 130
    if (!codeMatch) {                                                  // 131
      // match to empty array                                          //
      var match = /(\/\/ *c4_requires[\s\S]*\[)\s*(\] *,[\s\S]*\/\/ *end_c4_requires)/;
      var results = code.match(match);                                 // 134
      newcode = code.replace(match, "$1\n" + codeString + " // " + comments + "\n$2");
                                                                       //
      if (newcode == code) {                                           // 137
        // match to non-empty array                                    //
        var match = /(\/\/ *c4_requires[\s\S]*\[)([^\]]*\] *,[\s\S]*\/\/ *end_c4_requires)/;
        var results = code.match(match);                               // 140
        newcode = code.replace(match, "$1\n" + codeString + ", // " + comments + "$2");
      }                                                                //
      code = newcode;                                                  // 143
      var state = { line: editors.javascript.editor.currentLine(),     // 144
        character: editors.javascript.editor.getCursor().ch,           // 145
        add: 0                                                         // 146
      };                                                               //
                                                                       //
      editors.javascript.setCode(code);                                // 149
      editors.javascript.editor.setCursor({ line: state.line + state.add, ch: state.character });
    }                                                                  //
  }                                                                    //
                                                                       //
  Template.help.events({                                               // 155
    "click .giphy": function (e, t) {                                  // 156
      $(e.target).hide();                                              // 157
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.widget.events({                                             // 161
                                                                       //
    "click .giphy": function (e, t) {                                  // 163
      $(e.target).hide();                                              // 164
    },                                                                 //
                                                                       //
    "click .delete": function () {                                     // 167
      if (this.isTemplate) {                                           // 168
        this.pagetype = "template";                                    // 169
        Widgets.update(this._id, this);                                // 170
      } else {                                                         //
        Widgets.remove(this._id);                                      // 172
      }                                                                //
      giphy_modal("erase", "Widget Deleted");                          // 174
      return false;                                                    // 175
    },                                                                 //
                                                                       //
    "click .save": function () {                                       // 178
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
      var revision = jsbin.state.revision;                             // 181
                                                                       //
      this.html = editors.html.getCode();                              // 183
      this.javascript = editors.javascript.getCode();                  // 184
      this.css = editors.css.getCode();                                // 185
      jsbin.saveDisabled = false;                                      // 186
      jsbin.panels.save();                                             // 187
      jsbin.panels.savecontent();                                      // 188
      Widgets.update(this._id, this);                                  // 189
                                                                       //
      // also trigger the jsbin save                                   //
      var dataobj = { html: this.html, css: this.css, javascript: this.javascript };
      var url = "/api/" + this.url + "/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 194
      HTTP.post(url, options, function (error, results) {});           // 195
                                                                       //
      giphy_modal("saved", "Widget Content Saved");                    // 198
                                                                       //
      return false;                                                    // 200
    },                                                                 //
                                                                       //
    "click .call_webservice_url": function (evt, template) {           // 204
      console.log("calling webservice url");                           // 205
      $("#webservice_insert_modal").modal('show');                     // 206
                                                                       //
      $("#webservice_insert_modal_submit").click(function () {         // 208
        var jsbin_id = 'jsbin_' + template.data.url;                   // 209
                                                                       //
        var url = $("#webservice_insert_url").val().trim();            // 212
        var name = $("#webservice_insert_name").val().trim();          // 213
        var auth_token = $("#webservice_insert_auth_token").val().trim();
        var return_type = $("input[name=webservice_insert_return_type]:checked").val().trim();
                                                                       //
        url = url.replace("||PAGEID||", "'+pageId()+'");               // 217
        url = url.replace("||PAGETYPE||", "'+pageType()+'");           // 218
                                                                       //
        var token_string;                                              // 220
        if (auth_token) {                                              // 221
          token_string = " \n authentication_token : '" + auth_token + "',";
        }                                                              //
                                                                       //
        var codeString = "{\n id:'" + name + "', \n type: 'webservice', " + token_string + " \n return_type: '" + return_type + "', \n url: '" + url + "' \n}";
        var codeStringRe = "\\{\n id:'" + name + "', \n type: 'webservice', \n return_type: '" + return_type + "', \n url: '" + url + "' \n\\}";
        var comments = " this will hold a " + return_type + " object";
                                                                       //
        insert_code(jsbin_id, codeString, codeStringRe, comments);     // 229
                                                                       //
        /* need to insert something like:                              //
        {                                                              //
        id : "vasearch",                                               //
        type :"webservice",                                            //
        return_type : "JSON" or "HTML"                                 //
        url : "http://www.vam.ac.uk/api/json/museumobject/search?q="+pageid()}
         */                                                            //
      });                                                              //
    },                                                                 //
                                                                       //
    "click .add_code": function (evt, template) {                      // 245
                                                                       //
      var pullfrom = evt.currentTarget.dataset.pullfrom;               // 247
      var pulltype = evt.currentTarget.dataset.pulltype;               // 248
                                                                       //
      if (this.url == template.data.url) {                             // 250
        return false;                                                  // 251
      }                                                                //
                                                                       //
      var type;                                                        // 254
      var comments = "";                                               // 255
      if (pulltype == "data") {                                        // 256
        type = "data";                                                 // 257
        comments = " This will hold a JSON object";                    // 258
      }                                                                //
      if (pulltype == "html") {                                        // 260
        type = "html";                                                 // 261
        comments = " This will hold a jQuery object";                  // 262
      }                                                                //
      var codeString = "{from: '" + pullfrom + "', type : '" + pulltype + "'}";
      var codeStringRe = "\\{from: '" + pullfrom + "', type : '" + pulltype + "'\\}";
                                                                       //
      var jsbin_id = 'jsbin_' + template.data.url;                     // 267
                                                                       //
      insert_code(jsbin_id, codeString, codeStringRe, comments);       // 269
                                                                       //
      return true;                                                     // 271
    },                                                                 //
                                                                       //
    "click .test": function () {                                       // 276
      console.log("testing widget thing");                             // 277
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
      console.log(editors);                                            // 283
      console.log(jsbin);                                              // 284
                                                                       //
      console.log(thiselement);                                        // 286
                                                                       //
      var newbintop = 0;                                               // 288
      this.maxed = !this.maxed;                                        // 289
      if (this.maxed) {                                                // 290
        $(menu).hide();                                                // 291
        $(".editmodeonly", thiselement).hide();                        // 292
        this.oldbintop = $(bin).css("top");                            // 293
        $(bin).css("top", newbintop);                                  // 294
      } else {                                                         //
        $(menu).show();                                                // 296
        $(".editmodeonly", thiselement).show();                        // 297
        $(bin).css("top", this.oldbintop);                             // 298
      }                                                                //
      return false;                                                    // 300
    },                                                                 //
    /*                                                                 //
    panel ids: html, css, javascript, console, live                    //
    */                                                                 //
                                                                       //
    // this sets it to EDIT mode                                       //
    "click .lock": function () {                                       // 307
                                                                       //
      var widgetElement = document.getElementById('widgetContainer_' + this._id);
      var iframeElement = document.getElementById('jsbin_' + this._id);
                                                                       //
      var editors = iframeElement.contentWindow.editors;               // 312
      var jsbin = iframeElement.contentWindow.jsbin;                   // 313
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
                                                                       //
      setEditModeOn(this, iframeElement, widgetElement, menu, bin, jsbin);
                                                                       //
      return false;                                                    // 320
    },                                                                 //
                                                                       //
    // this sets it to DISPLAY mode                                    //
    "click .unlock": function () {                                     // 326
                                                                       //
      var widgetElement = document.getElementById('widgetContainer_' + this._id);
      var iframeElement = document.getElementById('jsbin_' + this._id);
                                                                       //
      var editors = iframeElement.contentWindow.editors;               // 331
      var jsbin = iframeElement.contentWindow.jsbin;                   // 332
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
      setDisplayModeOn(this, iframeElement, widgetElement, menu, bin, jsbin);
                                                                       //
      return false;                                                    // 337
    },                                                                 //
                                                                       //
    'click .copy': function () {                                       // 341
      console.log("copy from template " + this.url);                   // 342
                                                                       //
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 348
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 350
        console.log("data submitted");                                 // 351
        newWidget = { _id: results.data.url,                           // 352
          createdBy: { username: Meteor.user().username,               // 353
            userid: Meteor.userId() },                                 // 354
          isTemplate: false,                                           // 355
          html: results.data.html,                                     // 356
          javascript: results.data.javascript,                         // 357
          css: results.data.css,                                       // 358
          displayWidth: results.data.displayWidth,                     // 359
          displayHeight: results.data.displayHeight,                   // 360
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: results.data.widgetStyle,                       // 362
          name: "copy of " + template.name,                            // 363
          pagetype: pageinfo().pagetype,                               // 364
          pageurl: pageinfo().pageurl,                                 // 365
          pageid: pageinfo().pageid,                                   // 366
          url: results.data.url,                                       // 367
          createdAt: new Date(),                                       // 368
          rand: Math.random() };                                       // 369
        Widgets.insert(newWidget);                                     // 370
      });                                                              //
                                                                       //
      giphy_modal("copy", "widget copied");                            // 373
                                                                       //
      console.log("copied");                                           // 375
      return false;                                                    // 376
    },                                                                 //
                                                                       //
    "click .save_template": function () {                              // 380
      this.isTemplate = !this.isTemplate;                              // 381
      Widgets.update(this._id, this);                                  // 382
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
                                                                       //
      giphy_modal("promotion", "widget saved as a template");          // 386
                                                                       //
      return false;                                                    // 388
    },                                                                 //
                                                                       //
    "mouseenter .widgetMouseOverTarget": function () {                 // 392
      console.log("mouseover");                                        // 393
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      var mode = $(thiselement).data("mode");                          // 395
      if (!mode || mode == "display") {                                // 396
        //      $(".widgetMouseOverTarget", thiselement ).css("background", "red");
        $(".widgetDisplayHeader", thiselement).show();                 // 398
        $(".widgetMouseOverTarget", thiselement).css("z-index", 5);    // 399
        $(".widgetDisplayHeader", thiselement).css("z-index", 10);     // 400
      }                                                                //
    },                                                                 //
                                                                       //
    "mouseleave .widgetDisplayHeader": function () {                   // 404
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      $(".widgetMouseOverTarget", thiselement).css("background", "transparent");
      $(".widgetDisplayHeader", thiselement).hide();                   // 407
      $(".widgetMouseOverTarget", thiselement).css("z-index", 10);     // 408
      $(".widgetDisplayHeader", thiselement).css("z-index", 5);        // 409
    }                                                                  //
                                                                       //
  });                                                                  //
  ////// END EVENTS                                                    //
                                                                       //
  ////// HELPERS                                                       //
                                                                       //
  Template.widget.helpers({                                            // 419
    otherwidgets: function () {                                        // 420
      // Otherwise, return all of the tasks                            //
      return Widgets.find({ pagetype: pageinfo().pagetype, _id: { $ne: this._id } }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
                                                                       //
    isMyWidget: function () {                                          // 425
      // is this a widget I created?                                   //
      if (this.createdBy && Meteor.user()) {                           // 427
        return this.createdBy.username = Meteor.user().username;       // 428
      } else {                                                         //
        return false;                                                  // 430
      }                                                                //
    }                                                                  //
  });                                                                  //
  //////// END HELPERS                                                 //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=widget.js.map
