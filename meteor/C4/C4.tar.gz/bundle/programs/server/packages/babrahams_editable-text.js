(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var sanitizeHtml = Package['djedi:sanitize-html'].sanitizeHtml;

/* Package-scope variables */
var EditableText, sanitizeHtml, callbackMutatedDoc;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/babrahams_editable-text/lib/editable_text_common.js                                                     //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
if (typeof EditableText === 'undefined') {                                                                          // 1
  EditableText = {};                                                                                                // 2
}                                                                                                                   // 3
                                                                                                                    // 4
                                                                                                                    // 5
// ******************************************                                                                       // 6
// CONFIG that affects BOTH CLIENT AND SERVER                                                                       // 7
// ******************************************                                                                       // 8
                                                                                                                    // 9
EditableText.userCanEdit = function(doc,Collection) {                                                               // 10
  // e.g. return doc.user_id = Meteor.userId();                                                                     // 11
  return true;                                                                                                      // 12
}                                                                                                                   // 13
                                                                                                                    // 14
EditableText.useTransactions = (typeof tx !== 'undefined' && _.isObject(tx.Transactions)) ? true : false;           // 15
EditableText.clientControlsTransactions = false;                                                                    // 16
                                                                                                                    // 17
EditableText.maximumImageSize = 0; // Can't put image data in the editor by default                                 // 18
                                                                                                                    // 19
// This is the set of defaults for sanitizeHtml on the server (as set by the library itself)                        // 20
// Required on the client for consistency of filtering on the paste event                                           // 21
if (Meteor.isClient) {                                                                                              // 22
  sanitizeHtml = {};                                                                                                // 23
  sanitizeHtml.defaults = {                                                                                         // 24
    allowedTags: [ 'h3', 'h4', 'h5', 'h6', 'blockquote', 'p', 'a', 'ul', 'ol', 'nl', 'li', 'b', 'i', 'strong', 'em', 'strike', 'code', 'hr', 'br', 'div', 'table', 'thead', 'caption', 'tbody', 'tr', 'th', 'td', 'pre' ],
    allowedAttributes: { a: [ 'href', 'name', 'target' ] },                                                         // 26
    selfClosing: [ 'img', 'br', 'hr', 'area', 'base', 'basefont', 'input', 'link', 'meta' ],                        // 27
    allowedSchemes: [ 'http', 'https', 'ftp', 'mailto' ]                                                            // 28
  };                                                                                                                // 29
}                                                                                                                   // 30
                                                                                                                    // 31
Meteor.startup(function () {                                                                                        // 32
  // The startup block is to allow apps to overwrite the sanitizeHtml defaults                                      // 33
  EditableText.allowedHtml = {                                                                                      // 34
	allowedTags: sanitizeHtml.defaults.allowedTags.concat(['sub','sup','font','u']),                                   // 35
	allowedAttributes: _.extend(sanitizeHtml.defaults.allowedAttributes,{font:['size','face'],div:['align','style'],td:['rowspan','colspan','style'],a:['href','target','class'],i:['class']}),
	allowedSchemes:['http','https','ftp','mailto']                                                                     // 37
  }                                                                                                                 // 38
});;                                                                                                                // 39
                                                                                                                    // 40
                                                                                                                    // 41
// ******************************************                                                                       // 42
// Functions that are intended for use in app                                                                       // 43
// ******************************************                                                                       // 44
                                                                                                                    // 45
// Function for setting multiple config variable via a hash                                                         // 46
                                                                                                                    // 47
EditableText.config = function(config) {                                                                            // 48
  if (_.isObject(config)) {                                                                                         // 49
     _.each(config,function(val,key) {                                                                              // 50
       if (_.contains(['userCanEdit','insert','update','remove'],key)) {                                            // 51
         if (_.isFunction(val)) {                                                                                   // 52
           EditableText[key] = val;                                                                                 // 53
         }                                                                                                          // 54
         else {                                                                                                     // 55
           throw new Meteor.Error(key + ' must be a function');                                                     // 56
         }                                                                                                          // 57
       }                                                                                                            // 58
       if (_.contains(['useTransactions','clientControlsTransactions','saveOnFocusout','trustHtml','useMethods'],key)) {
         if (_.isBoolean(val)) {                                                                                    // 60
           EditableText[key] = val;                                                                                 // 61
         }                                                                                                          // 62
         else {                                                                                                     // 63
           throw new Meteor.Error(key + ' must be a boolean');                                                      // 64
         }                                                                                                          // 65
       }                                                                                                            // 66
       if (_.contains(['collection2Options'], key)) {                                                               // 67
         if (_.isObject(val)) {                                                                                     // 68
            EditableText[key] = val;                                                                                // 69
         }                                                                                                          // 70
       }                                                                                                            // 71
     });                                                                                                            // 72
  }                                                                                                                 // 73
  else {                                                                                                            // 74
    throw new Meteor.Error('Editable text config object must be a hash of key value pairs. Config not changed.');  
  }                                                                                                                 // 76
}                                                                                                                   // 77
                                                                                                                    // 78
// Function for registering callbacks                                                                               // 79
                                                                                                                    // 80
EditableText.registerCallbacks = function(obj) {                                                                    // 81
  if (_.isObject(obj)) {                                                                                            // 82
    _.each(obj,function(val,key) {                                                                                  // 83
      if (_.isFunction(val)) {                                                                                      // 84
        EditableText._callbacks[key] = val;                                                                         // 85
      }                                                                                                             // 86
      else {                                                                                                        // 87
        throw new Meteor.Error('Callbacks need to be functions. You passed a ' + typeof(val) + '.');                // 88
      }                                                                                                             // 89
    });                                                                                                             // 90
  }                                                                                                                 // 91
  else {                                                                                                            // 92
    throw new Meteor.Error('You must pass an object to register callbacks');                                        // 93
  }                                                                                                                 // 94
}                                                                                                                   // 95
                                                                                                                    // 96
                                                                                                                    // 97
// *********************************                                                                                // 98
// INTERNAL PROPERTIES AND FUNCTIONS                                                                                // 99
// *********************************                                                                                // 100
                                                                                                                    // 101
EditableText._callbacks = {};                                                                                       // 102
                                                                                                                    // 103
EditableText._mutatedDocIsObject = function (mutatedDoc) {                                                          // 104
  return _.isObject(mutatedDoc) && !_.isArray(mutatedDoc) && !_.isDate(mutatedDoc) && !_.isFunction(mutatedDoc); // Just want real key-value pair type objects
}                                                                                                                   // 106
                                                                                                                    // 107
EditableText._callback = function(callback, doc, originalValue) {                                                   // 108
  // Note: 'beforeUpdate' and 'beforeInsertMultiple' callbacks are special-cased to use return values of any type, not just objects
  // originalValue is only set on beforeUpdate and beforeInsertMultiple callbacks. It is of the form { value: <actual original value> }
  // otherwise originalValue should be undefined                                                                    // 111
  callback = String(callback);                                                                                      // 112
  var self = this;                                                                                                  // 113
  var callbackRan = false;                                                                                          // 114
  if (self[callback] && _.isString(self[callback])) {                                                               // 115
    var mutatedDoc = EditableText._executeCallback(self[callback], self, doc, originalValue);                       // 116
	callbackRan = true;                                                                                                // 117
	var mutatedDocIsObject = EditableText._mutatedDocIsObject(mutatedDoc);                                             // 118
	if (!originalValue && !mutatedDocIsObject) {                                                                       // 119
	  throw new Meteor.Error('Wrong type returned', 'Your callback function "' + callback + '" returned a ' + typeof mutatedDoc + '. An object was expected.');	
	}                                                                                                                  // 121
    doc = (originalValue) ? mutatedDoc : mutatedDocIsObject && mutatedDoc || doc;                                   // 122
  }                                                                                                                 // 123
  if (originalValue) {                                                                                              // 124
	// if the callback hasn't run, then the                                                                            // 125
	// doc is still the whole document,                                                                                // 126
	// not the new value for the field                                                                                 // 127
	if (!callbackRan) {                                                                                                // 128
	  doc = originalValue.value;	                                                                                      // 129
	}                                                                                                                  // 130
	if (callbackRan && mutatedDocIsObject && (_.has(doc, '$set') || _.has(doc, '$addToSet') || _.has(doc, '$push'))) {
	  return {modifier: doc};                                                                                          // 132
	}                                                                                                                  // 133
	else {                                                                                                             // 134
	  return {value: doc};                                                                                             // 135
	}                                                                                                                  // 136
  }                                                                                                                 // 137
  return doc;                                                                                                       // 138
}                                                                                                                   // 139
                                                                                                                    // 140
EditableText._executeCallback = function(callbackFunctionName, self, doc, originalValue) { // originalValue.value is the default to return if no updates have been made
  var mutatedDoc = (originalValue && {value: originalValue.value}) || doc;                                          // 142
  var callbackFunction = EditableText._callbacks[callbackFunctionName];                                             // 143
  if (callbackFunction && _.isFunction(callbackFunction)) {                                                         // 144
    callbackMutatedDoc = callbackFunction.call(self, doc, Mongo.Collection.get(self.collection), originalValue && originalValue.value || undefined, originalValue && originalValue.modifier || undefined);
	if (!_.isUndefined(callbackMutatedDoc)) {                                                                          // 146
	  mutatedDoc = callbackMutatedDoc;                                                                                 // 147
	}                                                                                                                  // 148
  }                                                                                                                 // 149
  else {                                                                                                            // 150
    throw new Meteor.Error('Callback not a function', 'Could not execute callback. Reason: ' + ((callbackFunction) ? '"' + callbackFunctionName + '" is not a function, it\'s a ' + typeof(callbackFunction) + '.' : 'no callback function called "' + callbackFunctionName + '" has been registered via EditableText.registerCallbacks.'));    
  }                                                                                                                 // 152
  return mutatedDoc;                                                                                                // 153
}                                                                                                                   // 154
                                                                                                                    // 155
EditableText._drillDown = function(obj,key) {                                                                       // 156
  return Meteor._get.apply(null,[obj].concat(key.split('.')));                                                      // 157
}                                                                                                                   // 158
                                                                                                                    // 159
EditableText._allowedHtml = function() {                                                                            // 160
  var allowed = EditableText.allowedHtml;                                                                           // 161
  if (EditableText.maximumImageSize && _.isNumber(EditableText.maximumImageSize) && allowed) {                      // 162
    allowed.allowedTags.push('img');                                                                                // 163
    allowed.allowedAttributes.img = ['src'];                                                                        // 164
    allowed.allowedSchemes.push('data');                                                                            // 165
  }                                                                                                                 // 166
  return allowed;                                                                                                   // 167
}                                                                                                                   // 168
                                                                                                                    // 169
                                                                                                                    // 170
// *************                                                                                                    // 171
// UPDATE METHOD                                                                                                    // 172
// *************                                                                                                    // 173
                                                                                                                    // 174
Meteor.methods({                                                                                                    // 175
  _editableTextWrite : function(action, data, modifier, transaction) {                                              // 176
    check(action,String);                                                                                           // 177
    check(data,Object);                                                                                             // 178
    check(data.collection,String);                                                                                  // 179
    check(data.context,(typeof FS !== "undefined" && FS.File) ? Match.OneOf(Object, FS.File) : Object);             // 180
    check(modifier,(action === 'update') ? Object : null);                                                          // 181
    check(transaction,Boolean);                                                                                     // 182
    check(data.objectTypeText,Match.OneOf(String,undefined));                                                       // 183
    var hasPackageCollection2 = !!Package['aldeed:collection2'];                                                    // 184
    var hasPackageSimpleSchema = !!Package['aldeed:simple-schema'];                                                 // 185
    var Collection = Mongo.Collection.get(data.collection);                                                         // 186
    var c2optionsHashRequired = hasPackageCollection2 && hasPackageSimpleSchema && _.isFunction(Collection.simpleSchema) && Collection._c2;
    if (Collection && EditableText.userCanEdit.call(data,data.context,Collection)) {                                // 188
	  if (Meteor.isServer) {                                                                                           // 189
        if (_.isBoolean(EditableText.useTransactions) && !EditableText.clientControlsTransactions) {                // 190
          transaction = EditableText.useTransactions;                                                               // 191
        }                                                                                                           // 192
      }                                                                                                             // 193
      if (typeof tx === 'undefined') {                                                                              // 194
        transaction = false;                                                                                        // 195
      }                                                                                                             // 196
      var setStatus = function(err,res) {                                                                           // 197
        data.status = {error:err,result:res};                                                                       // 198
      }                                                                                                             // 199
	  var options = (transaction) ? {instant:true} : {};                                                               // 200
      if (c2optionsHashRequired) {                                                                                  // 201
        options = _.extend(options, EditableText.collection2options || {});                                         // 202
      }                                                                                                             // 203
      switch (action) {                                                                                             // 204
        case 'insert' :                                                                                             // 205
          if (Meteor.isServer) {                                                                                    // 206
            // run all string fields through sanitizeHtml                                                           // 207
            data.context = EditableText.sanitizeObject(data.context);                                               // 208
          }                                                                                                         // 209
          if (transaction) {                                                                                        // 210
            if (data.objectTypeText || data.transactionInsertText) {                                                // 211
              tx.start(data.transactionInsertText || 'add ' + data.objectTypeText);                                 // 212
            }                                                                                                       // 213
            data.context = EditableText._callback.call(data,'beforeInsert',data.context) || data.context;           // 214
            var new_id = tx.insert(Collection,data.context,options,setStatus);                                      // 215
            EditableText._callback.call(data,'afterInsert',Collection.findOne({_id:new_id}));                       // 216
            if (data.objectTypeText || data.transactionInsertText) {                                                // 217
              tx.commit();                                                                                          // 218
            }                                                                                                       // 219
          }                                                                                                         // 220
          else {                                                                                                    // 221
            data.context = EditableText._callback.call(data,'beforeInsert',data.context) || data.context;           // 222
            var new_id = (c2optionsHashRequired) ? Collection.insert(data.context,options,setStatus) : Collection.insert(data.context,setStatus);
            EditableText._callback.call(data,'afterInsert',Collection.findOne({_id:new_id}));                       // 224
          }                                                                                                         // 225
          return new_id;                                                                                            // 226
          break;                                                                                                    // 227
        case 'update' :                                                                                             // 228
          if (Meteor.isServer) {                                                                                    // 229
            var newValue, sanitized = false;                                                                        // 230
            if (modifier["$set"] && _.isString(modifier["$set"][data.field])) {                                     // 231
            // run through sanitizeHtml                                                                             // 232
              newValue = modifier["$set"][data.field] = EditableText.sanitizeString(modifier["$set"][data.field],data.wysiwyg);
              sanitized = true;                                                                                     // 234
            }                                                                                                       // 235
            if (modifier["$set"] && _.isArray(modifier["$set"][data.field])) {                                      // 236
              newValue = modifier["$set"][data.field] = _.map(modifier["$set"][data.field],function(str) {return EditableText.sanitizeString(str,data.wysiwyg);});
              sanitized = true;                                                                                     // 238
            }                                                                                                       // 239
            if (modifier["$set"] && _.isNumber(modifier["$set"][data.field])) {                                     // 240
              newValue = modifier["$set"][data.field];                                                              // 241
              sanitized = true;                                                                                     // 242
            }                                                                                                       // 243
            if (modifier["$addToSet"] && _.isString(modifier["$addToSet"][data.field])) {                           // 244
              newValue = modifier["$addToSet"][data.field] = EditableText.sanitizeString(modifier["$addToSet"][data.field],data.wysiwyg);
              sanitized = true;                                                                                     // 246
            }                                                                                                       // 247
            if (modifier["$push"] && _.isString(modifier["$push"][data.field])) {                                   // 248
              newValue = modifier["$push"][data.field] = EditableText.sanitizeString(modifier["$push"][data.field],data.wysiwyg);
              sanitized = true;                                                                                     // 250
            }                                                                                                       // 251
            if (!sanitized) {                                                                                       // 252
              throw new Meteor.Error('Wrong data type sent for update');                                            // 253
			  return;                                                                                                        // 254
            }                                                                                                       // 255
          }                                                                                                         // 256
          else {                                                                                                    // 257
            newValue = (modifier["$set"] && modifier["$set"][data.field]) || (modifier["$addToSet"] && modifier["$addToSet"][data.field]) || (modifier["$push"] && modifier["$push"][data.field]);
          }                                                                                                         // 259
          data.newValue = newValue;                                                                                 // 260
          data.oldValue = EditableText._drillDown(data.context,data.field);                                         // 261
		  var callbackModifier = function (modifier, key, val) {                                                          // 262
			/*if (val === undefined) {                                                                                       // 263
			  return modifier;                                                                                               // 264
			}*/                                                                                                              // 265
			var modifierTypes = ["$set", "$addToSet", "$push"];                                                              // 266
			var modType = _.find(modifierTypes, function (mt) {                                                              // 267
			  return _.has(modifier, mt);                                                                                    // 268
			});                                                                                                              // 269
			if (modType) {                                                                                                   // 270
			  modifier[modType][key] = val;                                                                                  // 271
			}                                                                                                                // 272
			return modifier;                                                                                                 // 273
		  }                                                                                                               // 274
          if (transaction) {                                                                                        // 275
            if (data.transactionUpdateText || data.objectTypeText) {                                                // 276
              tx.start(data.transactionUpdateText || 'update ' + data.objectTypeText);                              // 277
            }                                                                                                       // 278
            var newVal = EditableText._callback.call(data,'beforeUpdate',data.context, {value: data.newValue, modifier: modifier}); // By setting the fourth parameter, we are expecting a value, not the whole doc, to be returned from the callback
			modifier = callbackModifier(newVal.modifier || modifier, data.field, newVal.value);                              // 280
            tx.update(Collection,data.context._id, modifier, options, setStatus);                                   // 281
            EditableText._callback.call(data, 'afterUpdate', Collection.findOne({_id: data.context._id}));          // 282
            if (data.transactionUpdateText || data.objectTypeText) {                                                // 283
              tx.commit();                                                                                          // 284
            }                                                                                                       // 285
          }                                                                                                         // 286
          else {                                                                                                    // 287
            var newVal = EditableText._callback.call(data, 'beforeUpdate', data.context, {value: data.newValue, modifier: modifier});
			modifier = callbackModifier(newVal.modifier || modifier, data.field, newVal.value);                              // 289
            if (c2optionsHashRequired) {                                                                            // 290
              Collection.update({_id: data.context._id}, modifier, options, setStatus);                             // 291
            }                                                                                                       // 292
            else {                                                                                                  // 293
              Collection.update({_id: data.context._id}, modifier, setStatus);                                      // 294
            }                                                                                                       // 295
            EditableText._callback.call(data, 'afterUpdate', Collection.findOne({_id: data.context._id}));          // 296
          }                                                                                                         // 297
          break;                                                                                                    // 298
        case 'remove' :                                                                                             // 299
          if (transaction) {                                                                                        // 300
            if (data.transactionRemoveText || data.objectTypeText) {                                                // 301
              tx.start(data.transactionRemoveText || 'remove ' + data.objectTypeText);                              // 302
            }                                                                                                       // 303
            data.context = EditableText._callback.call(data, 'beforeRemove', data.context) || data.context;         // 304
            tx.remove(Collection, data.context._id, {instant: true}, setStatus);                                    // 305
            EditableText._callback.call(data, 'afterRemove', data.context);                                         // 306
            if (data.transactionRemoveText || data.objectTypeText) {                                                // 307
              tx.commit();                                                                                          // 308
            }                                                                                                       // 309
          }                                                                                                         // 310
          else {                                                                                                    // 311
            data.context = EditableText._callback.call(data, 'beforeRemove', data.context) || data.context;         // 312
            Collection.remove({_id: data.context._id}, setStatus);                                                  // 313
            EditableText._callback.call(data, 'afterRemove', data.context);                                         // 314
          }                                                                                                         // 315
          break;                                                                                                    // 316
      }                                                                                                             // 317
    }                                                                                                               // 318
  }                                                                                                                 // 319
});                                                                                                                 // 320
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/babrahams_editable-text/lib/editable_text_server.js                                                     //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
if (typeof EditableText === 'undefined') {                                                                          // 1
  EditableText = {};                                                                                                // 2
}                                                                                                                   // 3
                                                                                                                    // 4
// Only used in the _editableTextWrite method detects the presence of aldeed:collection2                            // 5
EditableText.collection2Options = {filter: true, validate: true};                                                   // 6
                                                                                                                    // 7
EditableText.sanitizeString = function(string, html) {                                                              // 8
  var sanitizedString = (html) ? sanitizeHtml(string,EditableText._allowedHtml()) : EditableText.stripTags(string);
  /*if (string !== sanitizedString) {                                                                               // 10
    console.log("Sanitized: ", string);                                                                             // 11
    console.log("To: ", sanitizedString);                                                                           // 12
  }*/                                                                                                               // 13
  return sanitizedString;                                                                                           // 14
}                                                                                                                   // 15
                                                                                                                    // 16
EditableText.sanitizeObject = function(obj) {                                                                       // 17
  _.each(obj,function(val,key) {                                                                                    // 18
    if (_.isString(obj[key])) {                                                                                     // 19
      var original = obj[key];                                                                                      // 20
	  // FIrst check if stripTags has an effect                                                                        // 21
	  // If so, assume it's html and put the string through the html sanitizer                                         // 22
	  // TODO - check with people who know more about XSS whether this leaves a security hole                          // 23
	  if (obj[key] !== EditableText.stripTags(obj[key])) {                                                             // 24
		var html = true;                                                                                                  // 25
        obj[key] = EditableText.sanitizeString(obj[key],html);                                                      // 26
        if (original !== obj[key]) {                                                                                // 27
          console.log("Sanitized: ", original);                                                                     // 28
          console.log("To: ",obj[key]);                                                                             // 29
        }                                                                                                           // 30
	  }                                                                                                                // 31
    }                                                                                                               // 32
    // If it's another object, need to recurse into that object and clean up strings                                // 33
    if (_.isObject(obj[key])) {                                                                                     // 34
      obj[key] = EditableText.sanitizeObject(obj[key]);                                                             // 35
    }                                                                                                               // 36
  });                                                                                                               // 37
  return obj;                                                                                                       // 38
}                                                                                                                   // 39
                                                                                                                    // 40
EditableText.stripTags = function(input) { // stolen from phpjs.org                                                 // 41
  // var allowed = '';                                                                                              // 42
  /*allowed = (((allowed || '') + '')                                                                               // 43
    .toLowerCase()                                                                                                  // 44
    .match(/<[a-z][a-z0-9]*>/g) || [])                                                                              // 45
    .join(''); // making sure the allowed arg is a string containing only tags in lowercase (<a><b><c>)*/           // 46
  var tags = /<\/?([a-z][a-z0-9]*)\b[^>]*>/gi,                                                                      // 47
    comments = /<!--[\s\S]*?-->/gi;                                                                                 // 48
  return input.replace(comments, '')                                                                                // 49
    .replace(tags, '' /*function($0, $1) {                                                                          // 50
      return allowed.indexOf('<' + $1.toLowerCase() + '>') > -1 ? $0 : '';                                          // 51
    }*/);	                                                                                                          // 52
}                                                                                                                   // 53
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['babrahams:editable-text'] = {
  EditableText: EditableText,
  sanitizeHtml: sanitizeHtml
};

})();

//# sourceMappingURL=babrahams_editable-text.js.map
