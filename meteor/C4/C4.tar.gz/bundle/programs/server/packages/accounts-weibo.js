(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var Weibo = Package.weibo.Weibo;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/accounts-weibo/packages/accounts-weibo.js                                                        //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
(function(){                                                                                                 // 1
                                                                                                             // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////    // 3
//                                                                                                     //    // 4
// packages/accounts-weibo/weibo.js                                                                    //    // 5
//                                                                                                     //    // 6
/////////////////////////////////////////////////////////////////////////////////////////////////////////    // 7
                                                                                                       //    // 8
Accounts.oauth.registerService('weibo');                                                               // 1  // 9
                                                                                                       // 2  // 10
if (Meteor.isClient) {                                                                                 // 3  // 11
  Meteor.loginWithWeibo = function(options, callback) {                                                // 4  // 12
    // support a callback without options                                                              // 5  // 13
    if (! callback && typeof options === "function") {                                                 // 6  // 14
      callback = options;                                                                              // 7  // 15
      options = null;                                                                                  // 8  // 16
    }                                                                                                  // 9  // 17
                                                                                                       // 10
    var credentialRequestCompleteCallback = Accounts.oauth.credentialRequestCompleteHandler(callback);       // 19
    Weibo.requestCredential(options, credentialRequestCompleteCallback);                               // 12
  };                                                                                                   // 13
} else {                                                                                               // 14
  Accounts.addAutopublishFields({                                                                      // 15
    // publish all fields including access token, which can legitimately                               // 16
    // be used from the client (if transmitted over ssl or on localhost)                               // 17
    forLoggedInUser: ['services.weibo'],                                                               // 18
    forOtherUsers: ['services.weibo.screenName']                                                       // 19
  });                                                                                                  // 20
}                                                                                                      // 21
                                                                                                       // 22
/////////////////////////////////////////////////////////////////////////////////////////////////////////    // 31
                                                                                                             // 32
}).call(this);                                                                                               // 33
                                                                                                             // 34
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['accounts-weibo'] = {};

})();

//# sourceMappingURL=accounts-weibo.js.map
