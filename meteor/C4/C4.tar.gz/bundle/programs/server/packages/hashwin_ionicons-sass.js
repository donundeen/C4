(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['hashwin:ionicons-sass'] = {};

})();

//# sourceMappingURL=hashwin_ionicons-sass.js.map
