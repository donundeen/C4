(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var Random = Package.random.Random;
var Showdown = Package.markdown.Showdown;
var ReactiveDict = Package['reactive-dict'].ReactiveDict;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var moment = Package['momentjs:moment'].moment;
var Avatar = Package['utilities:avatar'].Avatar;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

/* Package-scope variables */
var AnonymousUserCollection, CommentsCollection, imageAnalyzer, youtubeAnalyzer, userService, timeTickService, mediaService, Comments, hashingService;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arkham_comments-ui/lib/collections/anonymous-user.js                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
AnonymousUserCollection = new Mongo.Collection('commentsui-anonymoususer');                                         // 1
                                                                                                                    //
AnonymousUserCollection.allow({                                                                                     // 3
  insert: function () {                                                                                             // 4
    return false;                                                                                                   //
  },                                                                                                                //
  update: function () {                                                                                             // 5
    return false;                                                                                                   //
  },                                                                                                                //
  remove: function () {                                                                                             // 6
    return false;                                                                                                   //
  }                                                                                                                 //
});                                                                                                                 //
                                                                                                                    //
AnonymousUserCollection.attachSchema(new SimpleSchema({                                                             // 9
  username: {                                                                                                       // 10
    type: String,                                                                                                   // 11
    optional: true                                                                                                  // 12
  },                                                                                                                //
  email: {                                                                                                          // 14
    type: String,                                                                                                   // 15
    optional: true                                                                                                  // 16
  },                                                                                                                //
  anonIp: {                                                                                                         // 18
    type: String                                                                                                    // 19
  },                                                                                                                //
  salt: {                                                                                                           // 21
    type: String                                                                                                    // 22
  },                                                                                                                //
  createdAt: {                                                                                                      // 24
    type: Date,                                                                                                     // 25
    autoValue: function () {                                                                                        // 26
      if (this.isInsert) {                                                                                          // 27
        return new Date();                                                                                          // 28
      } else if (this.isUpsert) {                                                                                   //
        return { $setOnInsert: new Date() };                                                                        // 30
      } else {                                                                                                      //
        this.unset();                                                                                               // 32
      }                                                                                                             //
    }                                                                                                               //
  }                                                                                                                 //
}));                                                                                                                //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arkham_comments-ui/lib/collections/comments.js                                                          //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
CommentsCollection = new Mongo.Collection('comments');                                                              // 1
                                                                                                                    //
CommentsCollection.schemas = {};                                                                                    // 3
                                                                                                                    //
/**                                                                                                                 //
 * Return a comment schema enhanced with the given schema config.                                                   //
 *                                                                                                                  //
 * @param additionalSchemaConfig                                                                                    //
 *                                                                                                                  //
 * @returns {Object}                                                                                                //
 */                                                                                                                 //
function getCommonCommentSchema() {                                                                                 // 12
  var additionalSchemaConfig = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];             //
                                                                                                                    //
  return babelHelpers._extends({                                                                                    // 13
    userId: {                                                                                                       // 14
      type: String                                                                                                  // 15
    },                                                                                                              //
    isAnonymous: {                                                                                                  // 17
      type: Boolean,                                                                                                // 18
      autoValue: function () {                                                                                      // 19
        if (this.isInsert) {                                                                                        // 20
          return false;                                                                                             // 21
        }                                                                                                           //
      }                                                                                                             //
    },                                                                                                              //
    'media.type': {                                                                                                 // 25
      type: String,                                                                                                 // 26
      optional: true                                                                                                // 27
    },                                                                                                              //
    'media.content': {                                                                                              // 29
      type: String,                                                                                                 // 30
      optional: true                                                                                                // 31
    },                                                                                                              //
    content: {                                                                                                      // 33
      type: String,                                                                                                 // 34
      min: 1,                                                                                                       // 35
      max: 10000                                                                                                    // 36
    },                                                                                                              //
    replies: {                                                                                                      // 38
      type: [Object],                                                                                               // 39
      autoValue: function () {                                                                                      // 40
        if (this.isInsert) {                                                                                        // 41
          return [];                                                                                                // 42
        }                                                                                                           //
      },                                                                                                            //
      optional: true                                                                                                // 45
    },                                                                                                              //
    likes: {                                                                                                        // 47
      type: [String],                                                                                               // 48
      autoValue: function () {                                                                                      // 49
        if (this.isInsert) {                                                                                        // 50
          return [];                                                                                                // 51
        }                                                                                                           //
      },                                                                                                            //
      optional: true                                                                                                // 54
    },                                                                                                              //
    createdAt: {                                                                                                    // 56
      type: Date,                                                                                                   // 57
      autoValue: function () {                                                                                      // 58
        if (this.isInsert) {                                                                                        // 59
          return new Date();                                                                                        // 60
        } else if (this.isUpsert) {                                                                                 //
          return { $setOnInsert: new Date() };                                                                      // 62
        } else {                                                                                                    //
          this.unset();                                                                                             // 64
        }                                                                                                           //
      }                                                                                                             //
    },                                                                                                              //
    lastUpdatedAt: {                                                                                                // 68
      type: Date,                                                                                                   // 69
      autoValue: function () {                                                                                      // 70
        if (this.isUpdate) {                                                                                        // 71
          return new Date();                                                                                        // 72
        }                                                                                                           //
      },                                                                                                            //
      denyInsert: true,                                                                                             // 75
      optional: true                                                                                                // 76
    }                                                                                                               //
  }, additionalSchemaConfig);                                                                                       //
}                                                                                                                   //
                                                                                                                    //
/**                                                                                                                 //
 * Enhance nested replies with correct data.                                                                        //
 *                                                                                                                  //
 * @param {Object} scope                                                                                            //
 * @param {Array} position                                                                                          //
 *                                                                                                                  //
 * @returns {Array}                                                                                                 //
 */                                                                                                                 //
function enhanceReplies(scope, position) {                                                                          // 90
  if (!position) {                                                                                                  // 91
    position = [];                                                                                                  // 92
  }                                                                                                                 //
                                                                                                                    //
  return _.map(scope.replies, function (reply, index) {                                                             // 95
    position.push(index);                                                                                           // 96
                                                                                                                    //
    reply = Object.assign(reply, {                                                                                  // 98
      position: position.slice(0),                                                                                  // 99
      documentId: scope._id,                                                                                        // 100
      user: scope.user.bind(reply),                                                                                 // 101
      likesCount: scope.likesCount.bind(reply),                                                                     // 102
      createdAgo: scope.createdAgo.bind(reply)                                                                      // 103
    });                                                                                                             //
                                                                                                                    //
    if (reply.replies) {                                                                                            // 106
      // recursive!                                                                                                 //
      reply.enhancedReplies = _.bind(enhanceReplies, null, _.extend(_.clone(scope), { replies: reply.replies }), position)();
    }                                                                                                               //
                                                                                                                    //
    position.pop();                                                                                                 // 116
                                                                                                                    //
    return reply;                                                                                                   // 118
  });                                                                                                               //
}                                                                                                                   //
                                                                                                                    //
CommentsCollection.schemas.ReplySchema = new SimpleSchema(getCommonCommentSchema({                                  // 122
  replyId: {                                                                                                        // 123
    type: String                                                                                                    // 124
  }                                                                                                                 //
}));                                                                                                                //
                                                                                                                    //
CommentsCollection.schemas.CommentSchema = new SimpleSchema(getCommonCommentSchema({                                // 128
  referenceId: {                                                                                                    // 129
    type: String                                                                                                    // 130
  }                                                                                                                 //
}));                                                                                                                //
                                                                                                                    //
CommentsCollection.attachSchema(CommentsCollection.schemas.CommentSchema);                                          // 134
                                                                                                                    //
// Is handled with Meteor.methods                                                                                   //
CommentsCollection.allow({                                                                                          // 137
  insert: function () {                                                                                             // 138
    return false;                                                                                                   //
  },                                                                                                                //
  update: function () {                                                                                             // 139
    return false;                                                                                                   //
  },                                                                                                                //
  remove: function () {                                                                                             // 140
    return false;                                                                                                   //
  }                                                                                                                 //
});                                                                                                                 //
                                                                                                                    //
CommentsCollection.helpers({                                                                                        // 143
  likesCount: function () {                                                                                         // 144
    if (this.likes && this.likes.length) {                                                                          // 145
      return this.likes.length;                                                                                     // 146
    }                                                                                                               //
                                                                                                                    //
    return 0;                                                                                                       // 149
  },                                                                                                                //
  user: function () {                                                                                               // 151
    return userService.getUserById(this.userId);                                                                    // 152
  },                                                                                                                //
  createdAgo: function () {                                                                                         // 154
    return timeTickService.fromNowReactive(moment(this.createdAt));                                                 // 155
  },                                                                                                                //
  enhancedReplies: function (position) {                                                                            // 157
    return enhanceReplies(this, position);                                                                          // 158
  }                                                                                                                 //
});                                                                                                                 //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arkham_comments-ui/lib/collections/methods/anonymous-user.js                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Meteor.methods({                                                                                                    // 1
  'commentsUiAnonymousUser/add': function (data) {                                                                  // 2
    check(data, {                                                                                                   // 3
      username: String,                                                                                             // 4
      email: String                                                                                                 // 5
    });                                                                                                             //
                                                                                                                    //
    if (Meteor.isServer) {                                                                                          // 8
      data.salt = hashingService.hash(data);                                                                        // 9
      data.anonIp = this.connection.clientAddress;                                                                  // 10
    } else {                                                                                                        //
      data.salt = 'fake';                                                                                           // 12
      data.anonIp = 'fake';                                                                                         // 13
    }                                                                                                               //
                                                                                                                    //
    if (AnonymousUserCollection.find({ anonIp: data.anonIp, createdAt: { $gte: moment().subtract(10, 'days').toDate() } }).count() >= 5) {
      throw new Meteor.Error('More than 5 anonymous accounts with the same IP');                                    // 17
    }                                                                                                               //
                                                                                                                    //
    return {                                                                                                        // 20
      _id: AnonymousUserCollection.insert(data),                                                                    // 21
      salt: data.salt                                                                                               // 22
    };                                                                                                              //
  },                                                                                                                //
  'commentsUiAnonymousUser/update': function (_id, salt, data) {                                                    // 25
    check(_id, String);                                                                                             // 26
    check(salt, String);                                                                                            // 27
    check(data, {                                                                                                   // 28
      username: Match.Optional(String),                                                                             // 29
      email: Match.Optional(String)                                                                                 // 30
    });                                                                                                             //
                                                                                                                    //
    return AnonymousUserCollection.update({ _id: _id, salt: salt }, { $set: data });                                // 33
  }                                                                                                                 //
});                                                                                                                 //
                                                                                                                    //
AnonymousUserCollection.methods = {                                                                                 // 37
  add: function (data, cb) {                                                                                        // 38
    return Meteor.call('commentsUiAnonymousUser/add', data, cb);                                                    //
  },                                                                                                                //
  update: function (id, salt, data, cb) {                                                                           // 39
    return Meteor.call('commentsUiAnonymousUser/update', id, salt, data, cb);                                       //
  }                                                                                                                 //
};                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arkham_comments-ui/lib/collections/methods/comments.js                                                  //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var noOptOptions = {                                                                                                // 1
  validate: false,                                                                                                  // 2
  filter: false,                                                                                                    // 3
  getAutoValues: false,                                                                                             // 4
  removeEmptyStrings: false                                                                                         // 5
};                                                                                                                  //
                                                                                                                    //
/**                                                                                                                 //
 * Modify replies with a callback in a nested array.                                                                //
 *                                                                                                                  //
 * @param {Array} nestedArray                                                                                       //
 * @param {Array} position Array of numbers with indexes throughout the reply tree.                                 //
 * @param {Function} callback                                                                                       //
 */                                                                                                                 //
function modifyNestedReplies(nestedArray, position, callback) {                                                     // 15
  var currentPos = position.shift();                                                                                // 16
                                                                                                                    //
  if (nestedArray[currentPos]) {                                                                                    // 18
    if (position.length && nestedArray[currentPos] && nestedArray[currentPos].replies) {                            // 19
      modifyNestedReplies(nestedArray[currentPos].replies, position, callback);                                     // 20
    } else {                                                                                                        //
      callback(nestedArray, currentPos);                                                                            // 22
    }                                                                                                               //
  }                                                                                                                 //
}                                                                                                                   //
                                                                                                                    //
/**                                                                                                                 //
 * Call a meteor method with anonymous user id if there is as the last argument.                                    //
 *                                                                                                                  //
 * @param {String} methodName                                                                                       //
 * @param {Array} methodArgs                                                                                        //
 */                                                                                                                 //
function callWithAnonUserData(methodName) {                                                                         // 33
  var anonUserData = userService.isAnonymous() ? userService.getUserData() : {};                                    // 34
                                                                                                                    //
  for (var _len = arguments.length, methodArgs = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {   //
    methodArgs[_key - 1] = arguments[_key];                                                                         // 33
  }                                                                                                                 //
                                                                                                                    //
  Meteor.apply(methodName, [].concat(methodArgs, [anonUserData]));                                                  // 35
}                                                                                                                   //
                                                                                                                    //
/**                                                                                                                 //
 * Return a mongodb style field descriptor                                                                          //
 *                                                                                                                  //
 * e.g "replies.0.replies.1" which points at the second reply of the first reply.                                   //
 *                                                                                                                  //
 * @param {undefined|Array} position                                                                                //
 *                                                                                                                  //
 * @return {String}                                                                                                 //
 */                                                                                                                 //
function getMongoReplyFieldDescriptor(position) {                                                                   // 47
  if (!position) {                                                                                                  // 48
    return '';                                                                                                      // 49
  }                                                                                                                 //
                                                                                                                    //
  var descriptorWithLeadingDot = _.reduce(position, function (descriptor, positionNumber) {                         // 52
    return descriptor + 'replies.' + positionNumber + '.';                                                          // 53
  }, '');                                                                                                           //
                                                                                                                    //
  return descriptorWithLeadingDot.substr(0, descriptorWithLeadingDot.length - 1);                                   // 56
}                                                                                                                   //
                                                                                                                    //
Meteor.methods({                                                                                                    // 59
  'comments/add': function (referenceId, content, anonUserData) {                                                   // 60
    check(referenceId, String);                                                                                     // 61
    check(content, String);                                                                                         // 62
                                                                                                                    //
    userService.verifyAnonUserData(anonUserData);                                                                   // 64
    var userId = this.userId || anonUserData._id;                                                                   // 65
                                                                                                                    //
    content = content.trim();                                                                                       // 67
                                                                                                                    //
    if (userId && content) {                                                                                        // 69
      CommentsCollection.insert({                                                                                   // 70
        referenceId: referenceId,                                                                                   // 71
        content: content,                                                                                           // 72
        userId: userId,                                                                                             // 73
        createdAt: new Date(),                                                                                      // 74
        likes: [],                                                                                                  // 75
        replies: [],                                                                                                // 76
        isAnonymous: !!anonUserData._id,                                                                            // 77
        media: mediaService.getMediaFromContent(content)                                                            // 78
      });                                                                                                           //
    }                                                                                                               //
  },                                                                                                                //
  'comments/edit': function (documentId, newContent, anonUserData) {                                                // 82
    check(documentId, String);                                                                                      // 83
    check(newContent, String);                                                                                      // 84
                                                                                                                    //
    userService.verifyAnonUserData(anonUserData);                                                                   // 86
    var userId = this.userId || anonUserData._id;                                                                   // 87
                                                                                                                    //
    newContent = newContent.trim();                                                                                 // 89
                                                                                                                    //
    if (!userId || !newContent) {                                                                                   // 91
      return;                                                                                                       // 92
    }                                                                                                               //
                                                                                                                    //
    CommentsCollection.update({ _id: documentId, userId: userId }, { $set: { content: newContent, likes: [], media: mediaService.getMediaFromContent(newContent) } });
  },                                                                                                                //
  'comments/remove': function (documentId, anonUserData) {                                                          // 100
    check(documentId, String);                                                                                      // 101
                                                                                                                    //
    userService.verifyAnonUserData(anonUserData);                                                                   // 103
    var userId = this.userId || anonUserData._id;                                                                   // 104
                                                                                                                    //
    CommentsCollection.remove({ _id: documentId, userId: userId });                                                 // 106
  },                                                                                                                //
  'comments/like': function (documentId, anonUserData) {                                                            // 108
    check(documentId, String);                                                                                      // 109
                                                                                                                    //
    userService.verifyAnonUserData(anonUserData);                                                                   // 111
    var userId = this.userId || anonUserData._id;                                                                   // 112
                                                                                                                    //
    if (!userId) {                                                                                                  // 114
      return;                                                                                                       // 115
    }                                                                                                               //
                                                                                                                    //
    if (CommentsCollection.findOne({ _id: documentId, likes: { $in: [userId] } })) {                                // 118
      CommentsCollection.update({ _id: documentId }, { $pull: { likes: userId } }, noOptOptions);                   // 119
    } else {                                                                                                        //
      CommentsCollection.update({ _id: documentId }, { $push: { likes: userId } }, noOptOptions);                   // 121
    }                                                                                                               //
  },                                                                                                                //
  'comments/reply/add': function (documentId, docScope, content, anonUserData) {                                    // 124
    var _$push;                                                                                                     //
                                                                                                                    //
    check(documentId, String);                                                                                      // 125
    check(docScope, Object);                                                                                        // 126
    check(content, String);                                                                                         // 127
    userService.verifyAnonUserData(anonUserData);                                                                   // 128
                                                                                                                    //
    var doc = CommentsCollection.findOne({ _id: documentId }),                                                      // 130
        userId = this.userId || anonUserData._id;                                                                   //
                                                                                                                    //
    content = content.trim();                                                                                       // 133
                                                                                                                    //
    if (!doc || !userId || !content || !Comments.config().replies) {                                                // 135
      return false;                                                                                                 // 136
    }                                                                                                               //
                                                                                                                    //
    var reply = {                                                                                                   // 139
      replyId: Random.id(),                                                                                         // 140
      content: content,                                                                                             // 141
      userId: userId,                                                                                               // 142
      createdAt: new Date(),                                                                                        // 143
      replies: [], likes: [],                                                                                       // 144
      lastUpdatedAt: new Date(),                                                                                    // 145
      isAnonymous: !!anonUserData._id,                                                                              // 146
      media: mediaService.getMediaFromContent(content)                                                              // 147
    };                                                                                                              //
                                                                                                                    //
    check(reply, CommentsCollection.schemas.ReplySchema);                                                           // 150
                                                                                                                    //
    var fieldDescriptor = 'replies';                                                                                // 153
                                                                                                                    //
    if (docScope.position) {                                                                                        // 155
      fieldDescriptor = getMongoReplyFieldDescriptor(docScope.position) + '.replies';                               // 156
    }                                                                                                               //
                                                                                                                    //
    var modifier = {                                                                                                // 159
      $push: (_$push = {}, _$push[fieldDescriptor] = {                                                              // 160
        $each: [reply],                                                                                             // 162
        $position: 0                                                                                                // 163
      }, _$push)                                                                                                    //
    };                                                                                                              //
                                                                                                                    //
    CommentsCollection.update({ _id: documentId }, modifier, noOptOptions);                                         // 168
  },                                                                                                                //
  'comments/reply/edit': function (documentId, docScope, newContent, anonUserData) {                                // 170
    check(documentId, String);                                                                                      // 171
    check(docScope, Object);                                                                                        // 172
    check(newContent, String);                                                                                      // 173
                                                                                                                    //
    userService.verifyAnonUserData(anonUserData);                                                                   // 175
                                                                                                                    //
    var doc = CommentsCollection.findOne(documentId),                                                               // 177
        userId = this.userId || anonUserData._id;                                                                   //
                                                                                                                    //
    newContent = newContent.trim();                                                                                 // 180
                                                                                                                    //
    if (!userId || !newContent || !Comments.config().replies) {                                                     // 182
      return;                                                                                                       // 183
    }                                                                                                               //
                                                                                                                    //
    modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                                 // 186
      if (replies[index].userId === userId) {                                                                       // 187
        replies[index].content = newContent;                                                                        // 188
        replies[index].likes = [];                                                                                  // 189
        replies[index].media = mediaService.getMediaFromContent(newContent);                                        // 190
      }                                                                                                             //
    });                                                                                                             //
                                                                                                                    //
    CommentsCollection.update({ _id: documentId }, { $set: { replies: doc.replies } }, noOptOptions);               // 194
  },                                                                                                                //
  'comments/reply/like': function (documentId, docScope, anonUserData) {                                            // 196
    check(documentId, String);                                                                                      // 197
    check(docScope, Object);                                                                                        // 198
    userService.verifyAnonUserData(anonUserData);                                                                   // 199
                                                                                                                    //
    var doc = CommentsCollection.findOne({ _id: documentId }),                                                      // 201
        userId = this.userId || anonUserData._id;                                                                   //
                                                                                                                    //
    if (!userId || !Comments.config().replies) {                                                                    // 204
      return false;                                                                                                 // 205
    }                                                                                                               //
                                                                                                                    //
    modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                                 // 208
      if (replies[index].likes.indexOf(userId) > -1) {                                                              // 209
        replies[index].likes.splice(replies[index].likes.indexOf(userId), 1);                                       // 210
      } else {                                                                                                      //
        replies[index].likes.push(userId);                                                                          // 212
      }                                                                                                             //
    });                                                                                                             //
                                                                                                                    //
    CommentsCollection.update({ _id: documentId }, { $set: { replies: doc.replies } }, noOptOptions);               // 216
  },                                                                                                                //
  'comments/reply/remove': function (documentId, docScope, anonUserData) {                                          // 218
    check(documentId, String);                                                                                      // 219
    check(docScope, Object);                                                                                        // 220
    userService.verifyAnonUserData(anonUserData);                                                                   // 221
                                                                                                                    //
    var doc = CommentsCollection.findOne({ _id: documentId }),                                                      // 223
        userId = this.userId || anonUserData._id;                                                                   //
                                                                                                                    //
    if (!userId || !Comments.config().replies) {                                                                    // 226
      return;                                                                                                       // 227
    }                                                                                                               //
                                                                                                                    //
    modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                                 // 230
      if (replies[index].userId === userId) {                                                                       // 231
        replies.splice(index, 1);                                                                                   // 232
      }                                                                                                             //
    });                                                                                                             //
                                                                                                                    //
    CommentsCollection.update({ _id: documentId }, { $set: { replies: doc.replies } }, noOptOptions);               // 236
  },                                                                                                                //
  'comments/count': function (referenceId) {                                                                        // 238
    check(referenceId, String);                                                                                     // 239
    return CommentsCollection.find({ referenceId: referenceId }).count();                                           // 240
  }                                                                                                                 //
});                                                                                                                 //
                                                                                                                    //
CommentsCollection.methods = {                                                                                      // 244
  add: function (referenceId, content) {                                                                            // 245
    return callWithAnonUserData('comments/add', referenceId, content);                                              //
  },                                                                                                                //
  reply: function (documentId, docScope, content) {                                                                 // 246
    return callWithAnonUserData('comments/reply/add', documentId, docScope, content);                               //
  },                                                                                                                //
  like: function (documentId) {                                                                                     // 247
    return callWithAnonUserData('comments/like', documentId);                                                       //
  },                                                                                                                //
  edit: function (documentId, newContent) {                                                                         // 248
    return callWithAnonUserData('comments/edit', documentId, newContent);                                           //
  },                                                                                                                //
  remove: function (documentId) {                                                                                   // 249
    return callWithAnonUserData('comments/remove', documentId);                                                     //
  },                                                                                                                //
  likeReply: function (documentId, docScope) {                                                                      // 250
    return callWithAnonUserData('comments/reply/like', documentId, docScope);                                       //
  },                                                                                                                //
  editReply: function (documentId, docScope, content) {                                                             // 251
    return callWithAnonUserData('comments/reply/edit', documentId, docScope, content);                              //
  },                                                                                                                //
  removeReply: function (documentId, docScope) {                                                                    // 252
    return callWithAnonUserData('comments/reply/remove', documentId, docScope);                                     //
  }                                                                                                                 //
};                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arkham_comments-ui/lib/services/media-analyzers/image.js                                                //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
imageAnalyzer = {                                                                                                   // 1
  name: 'image',                                                                                                    // 2
  /**                                                                                                               //
   * @param {String} content                                                                                        //
   *                                                                                                                //
   * @return {String}                                                                                               //
   */                                                                                                               //
  getMediaFromContent: function (content) {                                                                         // 8
    if (content) {                                                                                                  // 9
      var urls = content.match(/(\S+\.[^/\s]+(\/\S+|\/|))(.jpg|.png|.gif)/g);                                       // 10
                                                                                                                    //
      if (urls && urls[0]) {                                                                                        // 12
        return urls[0];                                                                                             // 13
      }                                                                                                             //
    }                                                                                                               //
                                                                                                                    //
    return '';                                                                                                      // 17
  },                                                                                                                //
  /**                                                                                                               //
   * @param {String} mediaContent                                                                                   //
   *                                                                                                                //
   * @return {String}                                                                                               //
   */                                                                                                               //
  getMarkup: function (mediaContent) {                                                                              // 24
    return '<img src="' + mediaContent + '" />';                                                                    //
  }                                                                                                                 //
};                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arkham_comments-ui/lib/services/media-analyzers/youtube.js                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
youtubeAnalyzer = {                                                                                                 // 1
  name: 'youtube',                                                                                                  // 2
  /**                                                                                                               //
   * @see http://stackoverflow.com/questions/19377262/regex-for-youtube-url                                         //
   *                                                                                                                //
   * @param {String} content                                                                                        //
   *                                                                                                                //
   * @return {String}                                                                                               //
   */                                                                                                               //
  getMediaFromContent: function (content) {                                                                         // 10
    var parts = /(https?\:\/\/)?(www\.youtube\.com|youtu\.?be)\/([\w\=\?]+)/gm.exec(content);                       // 11
    var mediaContent = '';                                                                                          // 12
                                                                                                                    //
    if (parts && parts[3]) {                                                                                        // 14
      var id = parts[3];                                                                                            // 15
                                                                                                                    //
      if (id.indexOf('v=') > -1) {                                                                                  // 17
        var subParts = /v=([\w]+)+/g.exec(id);                                                                      // 18
                                                                                                                    //
        if (subParts && subParts[1]) {                                                                              // 20
          id = subParts[1];                                                                                         // 21
        }                                                                                                           //
      }                                                                                                             //
                                                                                                                    //
      mediaContent = 'http://www.youtube.com/embed/' + id;                                                          // 25
    }                                                                                                               //
                                                                                                                    //
    return mediaContent;                                                                                            // 28
  },                                                                                                                //
  /**                                                                                                               //
   * @param {String} mediaContent                                                                                   //
   *                                                                                                                //
   * @return {String}                                                                                               //
   */                                                                                                               //
  getMarkup: function (mediaContent) {                                                                              // 35
    return '<iframe src="' + mediaContent + '" type="text/html" frameborder="0"></iframe>';                         //
  }                                                                                                                 //
};                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arkham_comments-ui/lib/services/user.js                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
userService = (function () {                                                                                        // 1
  if (Meteor.isClient) {                                                                                            // 2
    Meteor.startup(function () {                                                                                    // 3
      userService.setUserData({                                                                                     // 4
        _id: userService.getUserId(),                                                                               // 5
        salt: localStorage.getItem('commentsui-anonSalt') || ''                                                     // 6
      });                                                                                                           //
    });                                                                                                             //
  }                                                                                                                 //
                                                                                                                    //
  return {                                                                                                          // 11
    /**                                                                                                             //
     * Return the user id with logic for anonymous users.                                                           //
     *                                                                                                              //
     * @returns {String}                                                                                            //
     */                                                                                                             //
    getUserId: function () {                                                                                        // 17
      var userId = '';                                                                                              // 18
                                                                                                                    //
      if (userService.isAnonymous()) {                                                                              // 20
        userId = localStorage.getItem('commentsui-anonUserId');                                                     // 21
      }                                                                                                             //
                                                                                                                    //
      if (!userId) {                                                                                                // 24
        userId = Meteor.userId();                                                                                   // 25
      }                                                                                                             //
                                                                                                                    //
      return userId;                                                                                                // 28
    },                                                                                                              //
                                                                                                                    //
    /**                                                                                                             //
     * Set reactive user data                                                                                       //
     *                                                                                                              //
     * @param {Object} userData                                                                                     //
     */                                                                                                             //
    setUserData: function (userData) {                                                                              // 36
      Session.set('commentsui-anonData', userData);                                                                 // 37
    },                                                                                                              //
                                                                                                                    //
    /**                                                                                                             //
     * Return user id and salt as an object                                                                         //
     *                                                                                                              //
     * @returns {Object}                                                                                            //
     */                                                                                                             //
    getUserData: function () {                                                                                      // 45
      return Session.get('commentsui-anonData');                                                                    // 46
    },                                                                                                              //
                                                                                                                    //
    /**                                                                                                             //
     * Return anonymous user data                                                                                   //
     *                                                                                                              //
     * @returns {Object}                                                                                            //
     */                                                                                                             //
    getAnonymousUserData: function (_id) {                                                                          // 54
      return AnonymousUserCollection.findOne({ _id: _id });                                                         //
    },                                                                                                              //
                                                                                                                    //
    /**                                                                                                             //
     * Return true if current user has changed it's profile data.                                                   //
     */                                                                                                             //
    userHasChanged: function (data) {                                                                               // 59
      var userData = this.getAnonymousUserData(this.getUserData()._id);                                             // 60
                                                                                                                    //
      return data.username && data.email && userData && (userData.username !== data.username || userData.email !== data.email);
    },                                                                                                              //
                                                                                                                    //
    /**                                                                                                             //
     * Update anonymous user based on given data.                                                                   //
     *                                                                                                              //
     * @param {Object} data                                                                                         //
     * @param {Function} callback                                                                                   //
     */                                                                                                             //
    updateAnonymousUser: function (data, callback) {                                                                // 75
      var userData = userService.getUserData();                                                                     // 76
                                                                                                                    //
      // check if user still exists                                                                                 //
      if (userData._id && userData.salt && !AnonymousUserCollection.findOne({ _id: userData._id, salt: userData.salt })) {
        userData._id = null;                                                                                        // 80
        userData.salt = null;                                                                                       // 81
      }                                                                                                             //
                                                                                                                    //
      if (!userData._id || !userData.salt) {                                                                        // 84
        AnonymousUserCollection.methods.add(data, function (err, data) {                                            // 85
          if (err) throw new Error(err);                                                                            // 86
                                                                                                                    //
          localStorage.setItem('commentsui-anonUserId', data._id);                                                  // 89
          localStorage.setItem('commentsui-anonSalt', data.salt);                                                   // 90
          userService.setUserData(data);                                                                            // 91
          callback(data);                                                                                           // 92
        });                                                                                                         //
      } else if (this.userHasChanged(data)) {                                                                       //
        AnonymousUserCollection.methods.update(userData._id, userData.salt, data, function () {                     // 95
          return callback(data);                                                                                    //
        });                                                                                                         //
      } else {                                                                                                      //
        callback(data);                                                                                             // 97
      }                                                                                                             //
    },                                                                                                              //
                                                                                                                    //
    /**                                                                                                             //
     * Return true if anonymous form fields should be displayed                                                     //
     *                                                                                                              //
     * @returns {Boolean}                                                                                           //
     */                                                                                                             //
    isAnonymous: function () {                                                                                      // 106
      return Comments.config().anonymous && !Meteor.userId();                                                       //
    },                                                                                                              //
                                                                                                                    //
    /**                                                                                                             //
     * Return user information of the provided userId                                                               //
     *                                                                                                              //
     * @returns {Object}                                                                                            //
     */                                                                                                             //
    getUserById: function (userId) {                                                                                // 113
      var user = Meteor.users.findOne(userId),                                                                      // 114
          anonymousUser = AnonymousUserCollection.findOne({ _id: userId }),                                         //
          generateUsername = Comments.config().generateUsername;                                                    //
                                                                                                                    //
      if (user) {                                                                                                   // 118
        var displayName = undefined;                                                                                // 119
                                                                                                                    //
        //oauth facebook users (maybe others)                                                                       //
        if (user.profile) {                                                                                         // 122
          displayName = user.profile.name;                                                                          // 123
        }                                                                                                           //
                                                                                                                    //
        if (user.emails && user.emails[0]) {                                                                        // 126
          displayName = user.emails[0].address;                                                                     // 127
        }                                                                                                           //
                                                                                                                    //
        if (user.username) {                                                                                        // 130
          displayName = user.username;                                                                              // 131
        }                                                                                                           //
                                                                                                                    //
        if (generateUsername) {                                                                                     // 134
          displayName = generateUsername(user);                                                                     // 135
        }                                                                                                           //
                                                                                                                    //
        return { displayName: displayName };                                                                        // 138
      } else if (anonymousUser) {                                                                                   //
        return { displayName: anonymousUser.username };                                                             // 140
      }                                                                                                             //
    },                                                                                                              //
                                                                                                                    //
    /**                                                                                                             //
     * Throw an error if provided anon user data is invalid.                                                        //
     *                                                                                                              //
     * @params {Object} anonUserData                                                                                //
     */                                                                                                             //
    verifyAnonUserData: function (anonUserData) {                                                                   // 149
      if (anonUserData._id) {                                                                                       // 150
        check(anonUserData, {                                                                                       // 151
          _id: String,                                                                                              // 152
          salt: String                                                                                              // 153
        });                                                                                                         //
                                                                                                                    //
        if (Meteor.isServer && !AnonymousUserCollection.findOne(anonUserData)) {                                    // 156
          throw new Error('Invalid anon user data provided');                                                       // 157
        }                                                                                                           //
      } else {                                                                                                      //
        check(anonUserData, {});                                                                                    // 160
      }                                                                                                             //
    }                                                                                                               //
  };                                                                                                                //
})();                                                                                                               //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arkham_comments-ui/lib/services/time-tick.js                                                            //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
timeTickService = (function () {                                                                                    // 1
  var timeTick = new Tracker.Dependency();                                                                          // 2
                                                                                                                    //
  // Reactive moment changes                                                                                        //
  Meteor.setInterval(function () {                                                                                  // 5
    return timeTick.changed();                                                                                      //
  }, 1000);                                                                                                         //
                                                                                                                    //
  moment.locale('en');                                                                                              // 7
                                                                                                                    //
  return {                                                                                                          // 9
    fromNowReactive: function (mmt) {                                                                               // 10
      timeTick.depend();                                                                                            // 11
      return mmt.fromNow();                                                                                         // 12
    }                                                                                                               //
  };                                                                                                                //
})();                                                                                                               //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arkham_comments-ui/lib/services/media.js                                                                //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
mediaService = (function () {                                                                                       // 1
  return {                                                                                                          // 2
    getMediaFromContent: function (content) {                                                                       // 3
      var analyzers = Comments.config().mediaAnalyzers;                                                             // 4
      var media = {};                                                                                               // 5
                                                                                                                    //
      if (analyzers && _.isArray(analyzers)) {                                                                      // 7
        _.forEach(analyzers, function (analyzer) {                                                                  // 8
          var mediaContent = analyzer.getMediaFromContent(content);                                                 // 9
                                                                                                                    //
          if (mediaContent && !media.content) {                                                                     // 11
            media = {                                                                                               // 12
              type: analyzer.name,                                                                                  // 13
              content: mediaContent                                                                                 // 14
            };                                                                                                      //
          }                                                                                                         //
        });                                                                                                         //
      }                                                                                                             //
                                                                                                                    //
      return media;                                                                                                 // 20
    },                                                                                                              //
    getMarkup: function (media) {                                                                                   // 22
      var analyzers = Comments.config().mediaAnalyzers;                                                             // 23
                                                                                                                    //
      var filteredAnalyzers = _.filter(analyzers, function (filter) {                                               // 25
        return filter.name === media.type;                                                                          // 26
      });                                                                                                           //
                                                                                                                    //
      if (filteredAnalyzers && filteredAnalyzers.length > 0) {                                                      // 29
        return filteredAnalyzers[0].getMarkup(media.content);                                                       // 30
      }                                                                                                             //
    }                                                                                                               //
  };                                                                                                                //
})();                                                                                                               //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arkham_comments-ui/lib/api.js                                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
Comments = {                                                                                                        // 1
  config: (function () {                                                                                            // 2
    var config = {                                                                                                  // 3
      replies: true,                                                                                                // 4
      anonymous: false,                                                                                             // 5
      anonymousSalt: 'changeMe',                                                                                    // 6
      mediaAnalyzers: [imageAnalyzer, youtubeAnalyzer],                                                             // 7
      publishUserFields: { profile: 1, emails: 1, username: 1 }                                                     // 8
    };                                                                                                              //
                                                                                                                    //
    return function (newConfig) {                                                                                   // 11
      if (!newConfig) {                                                                                             // 12
        return config;                                                                                              // 13
      }                                                                                                             //
                                                                                                                    //
      config = _.extend(config, newConfig);                                                                         // 16
    };                                                                                                              //
  })(),                                                                                                             //
  get: function (id) {                                                                                              // 19
    return CommentsCollection.find({ referenceId: id }, { sort: { createdAt: -1 } });                               //
  },                                                                                                                //
  getOne: function (id) {                                                                                           // 20
    return CommentsCollection.findOne({ _id: id });                                                                 //
  },                                                                                                                //
  getAll: function () {                                                                                             // 21
    return CommentsCollection.find({}, { sort: { createdAt: -1 } });                                                //
  },                                                                                                                //
  add: CommentsCollection.methods.add,                                                                              // 22
  reply: CommentsCollection.methods.reply,                                                                          // 23
  remove: CommentsCollection.methods.remove,                                                                        // 24
  edit: CommentsCollection.methods.edit,                                                                            // 25
  like: CommentsCollection.methods.like,                                                                            // 26
  likeReply: CommentsCollection.methods.likeReply,                                                                  // 27
  editReply: CommentsCollection.methods.editReply,                                                                  // 28
  removeReply: CommentsCollection.methods.removeReply,                                                              // 29
  session: new ReactiveDict('commentsUi'),                                                                          // 30
  changeSchema: function (cb) {                                                                                     // 31
    var currentSchema = CommentsCollection.simpleSchema().schema(),                                                 // 32
        callbackResult = cb(currentSchema),                                                                         //
        newSchema;                                                                                                  //
                                                                                                                    //
    newSchema = callbackResult ? callbackResult : currentSchema;                                                    // 36
    !!newSchema && CommentsCollection.attachSchema(newSchema, { replace: true });                                   // 37
  },                                                                                                                //
  analyzers: {                                                                                                      // 39
    image: imageAnalyzer,                                                                                           // 40
    youtube: youtubeAnalyzer                                                                                        // 41
  },                                                                                                                //
  getCollection: function () {                                                                                      // 43
    return CommentsCollection;                                                                                      //
  },                                                                                                                //
  _collection: CommentsCollection,                                                                                  // 44
  _anonymousCollection: AnonymousUserCollection                                                                     // 45
};                                                                                                                  //
                                                                                                                    //
if (Meteor.isClient) {                                                                                              // 48
  Comments.ui = (function () {                                                                                      // 49
    var config = {                                                                                                  // 50
      limit: 5,                                                                                                     // 51
      loadMoreCount: 10,                                                                                            // 52
      template: 'semantic-ui',                                                                                      // 53
      defaultAvatar: 'http://s3.amazonaws.com/37assets/svn/765-default-avatar.png',                                 // 54
      markdown: false                                                                                               // 55
    };                                                                                                              //
    Avatar.setOptions({                                                                                             // 57
      defaultImageUrl: 'http://s3.amazonaws.com/37assets/svn/765-default-avatar.png'                                // 58
    });                                                                                                             //
                                                                                                                    //
    return {                                                                                                        // 61
      config: function (newConfig) {                                                                                // 62
        if (!newConfig) {                                                                                           // 63
          return config;                                                                                            // 64
        }                                                                                                           //
                                                                                                                    //
        config = _.extend(config, newConfig);                                                                       // 67
      },                                                                                                            //
      setContent: function (content) {                                                                              // 69
        return Comments.session.set('content', content);                                                            //
      },                                                                                                            //
      callIfLoggedIn: function (action, cb) {                                                                       // 70
        if (!userService.getUserId()) {                                                                             // 71
          Comments.session.set('loginAction', action);                                                              // 72
        } else {                                                                                                    //
          return cb();                                                                                              // 74
        }                                                                                                           //
      }                                                                                                             //
    };                                                                                                              //
  })();                                                                                                             //
}                                                                                                                   //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arkham_comments-ui/lib/server/publish.js                                                                //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
/**                                                                                                                 //
 * Return user ids by the given comment.                                                                            //
 *                                                                                                                  //
 * @param {Object} comment                                                                                          //
 *                                                                                                                  //
 * @returns {Array}                                                                                                 //
 */                                                                                                                 //
function getUserIdsByComment(comment) {                                                                             // 8
  var ids = [];                                                                                                     // 9
                                                                                                                    //
  ids.push(comment.userId);                                                                                         // 11
                                                                                                                    //
  if (comment.replies) {                                                                                            // 13
    _.each(comment.replies, function (reply) {                                                                      // 14
      ids = _.union(ids, getUserIdsByComment(reply));                                                               // 15
    });                                                                                                             //
  }                                                                                                                 //
                                                                                                                    //
  return ids;                                                                                                       // 19
}                                                                                                                   //
                                                                                                                    //
Meteor.publish('comments/anonymous', function (data) {                                                              // 22
  check(data, {                                                                                                     // 23
    _id: String,                                                                                                    // 24
    salt: String                                                                                                    // 25
  });                                                                                                               //
                                                                                                                    //
  return AnonymousUserCollection.find(data);                                                                        // 28
});                                                                                                                 //
                                                                                                                    //
Meteor.publishComposite('comments/reference', function (id, limit) {                                                // 31
  var skip = arguments.length <= 2 || arguments[2] === undefined ? 0 : arguments[2];                                //
                                                                                                                    //
  check(id, String);                                                                                                // 32
  check(limit, Number);                                                                                             // 33
  check(skip, Number);                                                                                              // 34
                                                                                                                    //
  return {                                                                                                          // 36
    find: function () {                                                                                             // 37
      return Comments._collection.find({ referenceId: id }, { limit: limit, skip: skip, sort: { createdAt: -1 } });
    },                                                                                                              //
    children: [{                                                                                                    // 41
      find: function (comment) {                                                                                    // 42
        var userIds = getUserIdsByComment(comment);                                                                 // 43
                                                                                                                    //
        return Meteor.users.find({ _id: { $in: userIds } }, { fields: Comments.config().publishUserFields });       // 45
      }                                                                                                             //
    }, {                                                                                                            //
      find: function (comment) {                                                                                    // 51
        var userIds = getUserIdsByComment(comment);                                                                 // 52
                                                                                                                    //
        return AnonymousUserCollection.find({ _id: { $in: userIds } }, {                                            // 54
          fields: { salt: 0, email: 0 }                                                                             // 57
        });                                                                                                         //
      }                                                                                                             //
    }]                                                                                                              //
  };                                                                                                                //
});                                                                                                                 //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/arkham_comments-ui/lib/services/hashing.js                                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
hashingService = {                                                                                                  // 1
  /**                                                                                                               //
   * Hash the given data with a random secret.                                                                      //
   *                                                                                                                //
   * @param {Object} data                                                                                           //
   *                                                                                                                //
   * @returns {String}                                                                                              //
   */                                                                                                               //
  hash: function (data) {                                                                                           // 9
    return this.getHashFromData(data) + '+' + Random.secret(50);                                                    // 10
  },                                                                                                                //
  /**                                                                                                               //
   * Return a hash from the given data.                                                                             //
   *                                                                                                                //
   * @param {Object} data                                                                                           //
   *                                                                                                                //
   * @returns {String}                                                                                              //
   */                                                                                                               //
  getHashFromData: function (data) {                                                                                // 19
    var hashedSalt = '';                                                                                            // 20
    var anonSalt = Comments.config().anonymousSalt;                                                                 // 21
                                                                                                                    //
    _.times(20, function () {                                                                                       // 23
      hashedSalt += Random.choice(anonSalt) + Random.choice(data.username) + Random.choice(data.email);             // 24
    });                                                                                                             //
                                                                                                                    //
    return hashedSalt;                                                                                              // 27
  }                                                                                                                 //
};                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['arkham:comments-ui'] = {
  Comments: Comments
};

})();

//# sourceMappingURL=arkham_comments-ui.js.map
