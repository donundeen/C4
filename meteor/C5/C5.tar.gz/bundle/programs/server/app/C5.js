(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// C5.js                                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
Widgets = new Mongo.Collection("widgets");                             // 2
UserXtras = new Mongo.Collection("userxtras");                         // 3
                                                                       //
// set GLOBAL VARS                                                     //
//In the client side                                                   //
SERVER_NAME = "localhost";                                             // 7
SERVER_IP = "localhost";                                               // 8
                                                                       //
if (Meteor.isClient) {                                                 // 10
  Meteor.call('getServerName', function (err, results) {               // 11
    SERVER_NAME = results;                                             // 12
  });                                                                  //
  Meteor.call('getServerIP', function (err, results) {                 // 14
    SERVER_IP = results;                                               // 15
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 20
                                                                       //
  Meteor.methods({                                                     // 23
    getServerName: function () {                                       // 24
      SERVER_NAME = process.env.SERVER_NAME;                           // 25
      if (typeof SERVER_NAME === "undefined") {                        // 26
        SERVER_NAME = "localhost";                                     // 27
      }                                                                //
      return SERVER_NAME;                                              // 29
    },                                                                 //
    getServerIP: function () {                                         // 31
      SERVER_IP = process.env.SERVER_IP;                               // 32
      if (typeof SERVER_IP === "undefined") {                          // 33
        SERVER_IP = "localhost";                                       // 34
      }                                                                //
      return SERVER_IP;                                                // 36
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isClient) {                                                 // 41
                                                                       //
  Meteor.startup(function () {                                         // 44
    console.log("starting meteor");                                    // 45
    $(window).bind('beforeunload', function () {                       // 46
      $(".save").trigger("click");                                     // 47
    });                                                                //
  });                                                                  //
                                                                       //
  /// comments config                                                  //
  // On the Client                                                     //
  Comments.ui.config({                                                 // 57
    template: 'bootstrap' // or ionic, semantic-ui                     // 58
  });                                                                  //
                                                                       //
  ////// HELPERS                                                       //
  UI.registerHelper('shortIt', function (stringToShorten, maxCharsAmount) {
    if (stringToShorten.length > maxCharsAmount) {                     // 63
      return stringToShorten.substring(0, maxCharsAmount) + '...';     // 64
    }                                                                  //
    return stringToShorten;                                            // 66
  });                                                                  //
                                                                       //
  UI.registerHelper('encodeURIComponent', function (string) {          // 69
    return encodeURIComponent(string);                                 // 70
  });                                                                  //
                                                                       //
  UI.registerHelper('absoluteUrl', function () {                       // 73
    return Meteor.absoluteUrl();                                       // 74
  });                                                                  //
                                                                       //
  Accounts.ui.config({                                                 // 77
    passwordSignupFields: "USERNAME_AND_EMAIL"                         // 78
  });                                                                  //
                                                                       //
  Template.registerHelper("pageid", function () {                      // 81
    return pageinfo().pageid;                                          // 82
  });                                                                  //
                                                                       //
  Template.registerHelper("pageurl", function () {                     // 85
    return pageinfo().pageurl;                                         // 86
  });                                                                  //
  Template.registerHelper("pagetype", function () {                    // 88
    return pageinfo().pagetype;                                        // 89
  });                                                                  //
  Template.registerHelper("SERVER_NAME", function () {                 // 91
    return SERVER_NAME;                                                // 92
  });                                                                  //
  Template.registerHelper("SERVER_IP", function () {                   // 94
    return SERVER_IP;                                                  // 95
  });                                                                  //
  Template.body.helpers({                                              // 97
    widgets: function () {                                             // 98
      // Otherwise, return all of the tasks                            //
      var find = {                                                     // 100
        this_page_only: { $in: [false, null] },                        // 101
        pagetype: pageinfo().pagetype,                                 // 102
        $or: [{ visibility: "public" }, { $and: [{ visibility: "private" }, { "createdBy.userid": Meteor.userId() }] }, { visibility: null }]
      };                                                               //
                                                                       //
      return Widgets.find(find, { sort: { sort_order: 1, createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
    widgetTemplates: function () {                                     // 115
      // Otherwise, return all of the tasks                            //
      return Widgets.find({ isTemplate: true }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
    libraryWidgets: function () {                                      // 119
      // Otherwise, return all of the tasks                            //
      var find = { inLibrary: true };                                  // 121
      find["createdBy.userid"] = Meteor.userId();                      // 122
      return Widgets.find(find, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
    thisPageWidgets: function () {                                     // 125
      // Otherwise, return all of the tasks                            //
      var find = { this_page_only: true,                               // 127
        pagetype: pageinfo().pagetype,                                 // 128
        pageid: pageinfo().pageid };                                   // 129
      return Widgets.find(find, { sort: { sort_order: 1, createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
                                                                       //
    userXtras: function () {                                           // 133
      return getUserXtras();                                           // 134
    },                                                                 //
                                                                       //
    godmode: function () {                                             // 137
      return getUserXtras().godmode;                                   // 138
    }                                                                  //
                                                                       //
  });                                                                  //
  ////// END HELPERS                                                   //
                                                                       //
  ////// TEMPLATE ONRENDERED                                           //
  Template.body.onRendered(function () {                               // 147
    //$(".tooltip-right").tooltip({placement: "right"});               //
    //  $("[title]").tooltip({placement: "auto"});                     //
  });                                                                  //
  ////// END ONRENDERED                                                //
                                                                       //
  /////// EVENTS                                                       //
  Template.body.events({                                               // 156
                                                                       //
    "click .lockall": function () {                                    // 159
      $(".lock").trigger("click");                                     // 160
      $(".lockall").hide();                                            // 161
      $(".unlockall").show();                                          // 162
      giphy_modal("unlock", "Unlocking all widgets you have access to");
      return false;                                                    // 164
    },                                                                 //
    "click .unlockall": function () {                                  // 167
      $(".unlock").trigger("click");                                   // 168
      $(".lockall").show();                                            // 169
      $(".unlockall").hide();                                          // 170
      giphy_modal("lock", "Locking all Widgets");                      // 171
      return false;                                                    // 172
    },                                                                 //
                                                                       //
    "click .giphy": function (e, t) {                                  // 175
      $(e.target).hide();                                              // 176
    },                                                                 //
                                                                       //
    "click .godmode_check": function (e, t) {                          // 179
      console.log("clicked");                                          // 180
      console.log(e.target.checked);                                   // 181
      //      console.log(t);                                          //
      console.log("updating  " + Meteor.userId() + " to " + e.target.checked);
      UserXtras.update({ _id: Meteor.userId() }, { $set: { godmode: e.target.checked } });
    },                                                                 //
                                                                       //
    'click .copy_from_template': function () {                         // 188
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 192
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 194
        newWidget = { _id: results.data.url,                           // 195
          createdBy: { username: Meteor.user().username,               // 196
            userid: Meteor.userId() },                                 // 197
          isTemplate: false,                                           // 198
          html: results.data.html,                                     // 199
          javascript: results.data.javascript,                         // 200
          css: results.data.css,                                       // 201
          displayWidth: results.data.displayWidth,                     // 202
          displayHeight: results.data.displayHeight,                   // 203
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: results.data.widgetStyle,                       // 205
          name: "copy of " + template.name,                            // 206
          pagetype: pageinfo().pagetype,                               // 207
          pageurl: pageinfo().pageurl,                                 // 208
          pageid: pageinfo().pageid,                                   // 209
          url: results.data.url,                                       // 210
          createdAt: new Date(),                                       // 211
          visibility: "private",                                       // 212
          rand: Math.random() };                                       // 213
        Widgets.insert(newWidget);                                     // 214
      });                                                              //
                                                                       //
      giphy_modal("copy", "New Widget Copied From Template");          // 217
                                                                       //
      return false;                                                    // 220
    },                                                                 //
                                                                       //
    'click .deletetemplate': function () {                             // 223
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      template.isTemplate = false;                                     // 225
      Widgets.update(template._id, template);                          // 226
    },                                                                 //
                                                                       //
    'click .addwidget': function () {                                  // 229
      //add jsbin widget                                               //
                                                                       //
      var htmlstring = '<html>\n ' + '<head>\n ' + '<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>\n ' + '<script src="/c5libs/locallib.js"></script>\n ' + '   <script type="application/json" class="c5_data">{"data" : "data placed here gets passed along"}</script>\n ' + '</head>\n ' + '<body>\n ' + '  <div class="c5_html">\n ' + '  html placed here gets passed along\n ' + '  </div>\n ' + '</body>\n ' + '</html>\n';
      var csstring = "";                                               // 244
      var jsstring = "function doTheThings(data){\n" + "// everything you want to do should happen inside this function\n " + "// the data var will be populated with whatever you've requested from other widgets\n" + "// and this function will be call when all those widgets have complete \n" + "   c5_done(); // this message is required at the end of all the processing, so the system knows this widget is done \n " + "} \n" + "requireWidgetData( \n" + "// all requests to other widgets go here (automatically if you use the 'pull from' interface): \n" + "// c5_requires \n" + "{} \n" + "// end_c5_requires \n" + "// end other widget requests \n" + ", doTheThings)";
      var dataobj = { html: htmlstring, css: csstring, javascript: jsstring };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 260
      HTTP.post(url, options, function (error, results) {              // 261
        newWidget = { _id: results.data.url,                           // 262
          createdBy: { username: Meteor.user().username,               // 263
            userid: Meteor.userId() },                                 // 264
          isTemplate: false,                                           // 265
          name: results.data.url,                                      // 266
          description: "",                                             // 267
          html: results.data.html,                                     // 268
          javascript: results.data.javascript,                         // 269
          css: results.data.css,                                       // 270
          displayWidth: "",                                            // 271
          displayHeight: "",                                           // 272
          widgetStyle: "",                                             // 273
          pagetype: pageinfo().pagetype,                               // 274
          pageurl: pageinfo().pageurl,                                 // 275
          pageid: pageinfo().pageid,                                   // 276
          url: results.data.url,                                       // 277
          visibility: "private",                                       // 278
          createdAt: new Date(),                                       // 279
          rand: Math.random() };                                       // 280
        Widgets.insert(newWidget);                                     // 281
      });                                                              //
      return false;                                                    // 283
    },                                                                 //
                                                                       //
    'click .test': function () {                                       // 286
      return false;                                                    // 287
    }                                                                  //
  });                                                                  //
                                                                       //
  ///// END EVENTS                                                     //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 297
  Meteor.startup(function () {                                         // 298
    // code to run on server at startup                                //
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=C5.js.map
