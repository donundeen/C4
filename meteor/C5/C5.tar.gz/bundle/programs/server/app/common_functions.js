(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// common_functions.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
pageinfo = setWidgetDefaults = giphy_modal = getUserXtras = null;      // 1
                                                                       //
if (Meteor.isClient) {                                                 // 3
                                                                       //
  getUserXtras = function () {                                         // 5
    var userxtras = false;                                             // 6
    var user = Meteor.user();                                          // 7
    if (user) {                                                        // 8
      /*                                                               //
      console.log(user.username);                                      //
      console.log(user._id);                                           //
      console.log("getting for " + user._id);                          //
      */                                                               //
      var userxtras = UserXtras.findOne({ _id: user._id });            // 14
      if (!userxtras || !userxtras.foo) {                              // 15
        console.log("userxtras " + userxtras);                         // 16
        userxtras = { _id: user._id, admin: false, godmode: false, foo: "var" };
        if (user.username == "donundeen") {                            // 18
          userxtras.admin = true;                                      // 19
        }                                                              //
        console.log("saving for " + user._id);                         // 21
        UserXtras.upsert({ _id: user._id }, userxtras);                // 22
        var userxtras2 = UserXtras.findOne({ _id: user._id });         // 23
      }                                                                //
      console.log(userxtras);                                          // 25
    }                                                                  //
    return userxtras;                                                  // 27
  };                                                                   //
                                                                       //
  giphy_modal = function (term, text) {                                // 33
    $("#giphy_modal").modal('show');                                   // 34
    $(".giphy_modal_header").text(text);                               // 35
    var url = "/giphy_proxy/" + encodeURIComponent(term);              // 36
    $(".giphy_modal_image_div").empty();                               // 37
    var imgurl = url + "?" + new Date().getTime();                     // 38
    $(".giphy_modal_image_div").html("<img src='" + imgurl + "' width='200' class='giphy_modal_image_img'/>");
                                                                       //
    setTimeout(function () {                                           // 41
      $("#giphy_modal").modal('hide');                                 // 42
    }, 2000);                                                          //
  };                                                                   //
                                                                       //
  pageinfo = function () {                                             // 47
    var pagetype = "";                                                 // 48
    var pageid = "";                                                   // 49
    var pathname = window.location.pathname;                           // 50
    var split = pathname.split("/");                                   // 51
    split.shift();                                                     // 52
    var pageurl = split.join("/");                                     // 53
                                                                       //
    if (split.length > 0) {                                            // 55
      pagetype = split.shift();                                        // 56
    }                                                                  //
    if (split.length > 0) {                                            // 58
      pageid = split.shift();                                          // 59
    }                                                                  //
    pageid = pageid.replace(/:script/, "");                            // 61
    return { pageurl: pageurl,                                         // 62
      pagetype: pagetype,                                              // 63
      pageid: pageid };                                                // 64
  };                                                                   //
                                                                       //
  setWidgetDefaults = function (doc) {                                 // 68
    if (typeof doc.displayWidth === "undefined" || !doc.displayWidth || doc.displayWidth.trim() == "" || doc.displayWidth == "width" || doc.displayWidth == "default") {
      doc.displayWidth = "320px";                                      // 70
      doc.displayUsableWidth = "320px";                                // 71
    } else {                                                           //
      doc.displayUsableWidth = doc.displayWidth;                       // 73
    }                                                                  //
    if (typeof doc.displayHeight === "undefined" || !doc.displayHeight || doc.displayHeight.trim() == "" || doc.displayHeight == "height" || doc.displayHeight == "default") {
      doc.displayHeight = "400px";                                     // 76
      doc.displayUsableHeight = "400px";                               // 77
    } else {                                                           //
      doc.displayUsableHeight = doc.displayHeight;                     // 79
    }                                                                  //
    if (typeof doc.widgetStyle === "undefined" || !doc.widgetStyle || doc.widgetStyle.trim() == "" || doc.widgetStyle == "css" || doc.widgetStyle == "default") {
      doc.widgetStyle = "default";                                     // 82
      doc.usableWidgetStyle = "";                                      // 83
    } else {                                                           //
      doc.usableWidgetStyle = doc.widgetStyle;                         // 85
    }                                                                  //
    if (!doc.createdBy) {                                              // 87
      doc.createdBy = {};                                              // 88
    }                                                                  //
                                                                       //
    if (doc.displayUsableHeight.match(/px/)) {                         // 91
      var height = doc.displayUsableHeight.replace(/px/, "");          // 92
      doc.jsbinHeight = height - 20;                                   // 93
      doc.jsbinHeight += "px";                                         // 94
    } else {                                                           //
      doc.jsbinHeight = "";                                            // 96
    }                                                                  //
                                                                       //
    if (!doc.this_page_only) {                                         // 99
      doc.this_page_only = false;                                      // 100
    }                                                                  //
                                                                       //
    if (!doc.sort_order) {                                             // 103
      doc.sort_order = 0;                                              // 104
    }                                                                  //
                                                                       //
    if (!doc.visibility) {                                             // 107
      doc.visibility = "public";                                       // 108
    }                                                                  //
                                                                       //
    if (!doc.cacheConfig) {                                            // 111
      doc.cacheConfig = {};                                            // 112
    }                                                                  //
                                                                       //
    if (!doc.cacheConfig.ttl) {                                        // 115
      doc.cacheConfig.ttl = 60;                                        // 116
    }                                                                  //
                                                                       //
    return doc;                                                        // 120
  };                                                                   //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=common_functions.js.map
