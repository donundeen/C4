var require = meteorInstall({"server":{"smtp.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/smtp.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      //
Meteor.startup(function () {                                                                                          // 2
                                                                                                                      //
    Accounts.emailTemplates.siteName = "c5.boomhifive.com";                                                           // 4
    Accounts.emailTemplates.from = "C5 Admin <c5@boomhifive.com>";                                                    // 5
    Accounts.emailTemplates.enrollAccount.subject = function (user) {                                                 // 6
        return "Welcome to C5, " + user.profile.name;                                                                 // 7
    };                                                                                                                // 8
    Accounts.emailTemplates.resetPassword.from = function () {                                                        // 9
        // Overrides value set in Accounts.emailTemplates.from when resetting passwords                               // 10
        return "C5 Admin <c5@boomhifive.com>";                                                                        // 11
    };                                                                                                                // 12
    Accounts.emailTemplates.resetPassword.text = function (user, url) {                                               // 13
        var text = "Heard you need to reset your password. No biggie, it happens.";                                   // 14
        text += "\n Just open this url to reset your password: " + url;                                               // 15
        return text;                                                                                                  // 16
    };                                                                                                                // 17
});                                                                                                                   // 18
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"C5.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// C5.js                                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      //
Widgets = new Mongo.Collection("widgets");                                                                            // 2
UserXtras = new Mongo.Collection("userxtras");                                                                        // 3
                                                                                                                      //
// set GLOBAL VARS                                                                                                    // 5
//In the client side                                                                                                  // 6
SERVER_NAME = "localhost";                                                                                            // 7
SERVER_IP = "localhost";                                                                                              // 8
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 10
  Meteor.call('getServerName', function (err, results) {                                                              // 11
    SERVER_NAME = results;                                                                                            // 12
  });                                                                                                                 // 13
  Meteor.call('getServerIP', function (err, results) {                                                                // 14
    SERVER_IP = results;                                                                                              // 15
  });                                                                                                                 // 16
}                                                                                                                     // 17
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 20
                                                                                                                      //
  Meteor.startup(function () {                                                                                        // 22
    var to = "donundeen@gmail.com";                                                                                   // 23
    var from = "c5@boomhifive.com";                                                                                   // 24
    var subject = "C5 started";                                                                                       // 25
    var text = "notifying you that C5 started";                                                                       // 26
    console.log("sending email");                                                                                     // 27
    Email.send({                                                                                                      // 28
      to: to,                                                                                                         // 29
      from: from,                                                                                                     // 30
      subject: subject,                                                                                               // 31
      text: text                                                                                                      // 32
    });                                                                                                               // 28
  });                                                                                                                 // 34
                                                                                                                      //
  Meteor.methods({                                                                                                    // 37
    getServerName: function () {                                                                                      // 38
      function getServerName() {                                                                                      // 38
        SERVER_NAME = process.env.SERVER_NAME;                                                                        // 39
        if (typeof SERVER_NAME === "undefined") {                                                                     // 40
          SERVER_NAME = "localhost";                                                                                  // 41
        }                                                                                                             // 42
        return SERVER_NAME;                                                                                           // 43
      }                                                                                                               // 44
                                                                                                                      //
      return getServerName;                                                                                           // 38
    }(),                                                                                                              // 38
    getServerIP: function () {                                                                                        // 45
      function getServerIP() {                                                                                        // 45
        SERVER_IP = process.env.SERVER_IP;                                                                            // 46
        if (typeof SERVER_IP === "undefined") {                                                                       // 47
          SERVER_IP = "localhost";                                                                                    // 48
        }                                                                                                             // 49
        return SERVER_IP;                                                                                             // 50
      }                                                                                                               // 51
                                                                                                                      //
      return getServerIP;                                                                                             // 45
    }()                                                                                                               // 45
  });                                                                                                                 // 37
}                                                                                                                     // 53
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 55
                                                                                                                      //
  Meteor.startup(function () {                                                                                        // 58
    console.log("starting meteor");                                                                                   // 59
    $(window).bind('beforeunload', function () {                                                                      // 60
      $(".save").trigger("click");                                                                                    // 61
    });                                                                                                               // 62
  });                                                                                                                 // 64
                                                                                                                      //
  /// comments config                                                                                                 // 69
  // On the Client                                                                                                    // 70
  Comments.ui.config({                                                                                                // 71
    template: 'bootstrap' // or ionic, semantic-ui                                                                    // 72
  });                                                                                                                 // 71
                                                                                                                      //
  ////// HELPERS                                                                                                      // 75
  UI.registerHelper('shortIt', function (stringToShorten, maxCharsAmount) {                                           // 76
    if (stringToShorten.length > maxCharsAmount) {                                                                    // 77
      return stringToShorten.substring(0, maxCharsAmount) + '...';                                                    // 78
    }                                                                                                                 // 79
    return stringToShorten;                                                                                           // 80
  });                                                                                                                 // 81
                                                                                                                      //
  UI.registerHelper('encodeURIComponent', function (string) {                                                         // 83
    return encodeURIComponent(string);                                                                                // 84
  });                                                                                                                 // 85
                                                                                                                      //
  UI.registerHelper('absoluteUrl', function () {                                                                      // 87
    return Meteor.absoluteUrl();                                                                                      // 88
  });                                                                                                                 // 89
                                                                                                                      //
  Accounts.ui.config({                                                                                                // 91
    passwordSignupFields: "USERNAME_AND_EMAIL"                                                                        // 92
  });                                                                                                                 // 91
                                                                                                                      //
  Template.registerHelper("pageid", function () {                                                                     // 95
    return pageinfo().pageid;                                                                                         // 96
  });                                                                                                                 // 97
                                                                                                                      //
  Template.registerHelper("pageurl", function () {                                                                    // 99
    return pageinfo().pageurl;                                                                                        // 100
  });                                                                                                                 // 101
                                                                                                                      //
  Template.registerHelper("pagetype", function () {                                                                   // 104
    return pageinfo().pagetype;                                                                                       // 105
  });                                                                                                                 // 106
                                                                                                                      //
  Template.registerHelper("pageid_neverblank", function () {                                                          // 108
    return "_pi_" + pageinfo().pageid;                                                                                // 109
  });                                                                                                                 // 110
                                                                                                                      //
  Template.registerHelper("pageurl_neverblank", function () {                                                         // 112
    return "_pu_" + pageinfo().pageurl;                                                                               // 113
  });                                                                                                                 // 114
  Template.registerHelper("pagetype_neverblank", function () {                                                        // 115
    return "_pt_" + pageinfo().pagetype;                                                                              // 116
  });                                                                                                                 // 117
                                                                                                                      //
  Template.registerHelper("numComments", function (commentId) {                                                       // 119
                                                                                                                      //
    var instance = Template.instance;                                                                                 // 121
                                                                                                                      //
    if (!instance.commentCounters) {                                                                                  // 123
      instance.commentCounters = {};                                                                                  // 124
    }                                                                                                                 // 125
    if (!instance.commentCounters[commentId]) {                                                                       // 126
      instance.commentCounters[commentId] = new ReactiveVar();                                                        // 127
    }                                                                                                                 // 128
    Comments.getCount(commentId, function (error, count) {                                                            // 129
      instance.commentCounters[commentId].set(count);                                                                 // 130
    });                                                                                                               // 131
    return instance.commentCounters[commentId].get();                                                                 // 132
  });                                                                                                                 // 133
                                                                                                                      //
  Template.registerHelper("commentIcon", function (commentId) {                                                       // 135
                                                                                                                      //
    var instance = Template.instance;                                                                                 // 137
                                                                                                                      //
    var noComments = "zmdi-comment";                                                                                  // 139
    var hasComments = "zmdi-comment-alert";                                                                           // 140
                                                                                                                      //
    if (!instance.commentIcons) {                                                                                     // 142
      instance.commentIcons = {};                                                                                     // 143
    }                                                                                                                 // 144
    if (!instance.commentIcons[commentId]) {                                                                          // 145
      instance.commentIcons[commentId] = new ReactiveVar();                                                           // 146
    }                                                                                                                 // 147
    Comments.getCount(commentId, function (error, count) {                                                            // 148
      if (count > 0) {                                                                                                // 149
        console.log(commentId + " has comments");                                                                     // 150
        instance.commentCounters[commentId].set("zmdi-comment-alert");                                                // 151
      } else {                                                                                                        // 152
        console.log(commentId + " no comments");                                                                      // 153
        instance.commentIcons[commentId].set("zmdi-comment");                                                         // 154
      }                                                                                                               // 155
    });                                                                                                               // 156
    return instance.commentIcons[commentId].get();                                                                    // 157
  });                                                                                                                 // 158
                                                                                                                      //
  Template.registerHelper("SERVER_NAME", function () {                                                                // 162
    return SERVER_NAME;                                                                                               // 163
  });                                                                                                                 // 164
  Template.registerHelper("SERVER_IP", function () {                                                                  // 165
    return SERVER_IP;                                                                                                 // 166
  });                                                                                                                 // 167
  Template.gridwidgets.helpers({                                                                                      // 168
    widgets: function () {                                                                                            // 169
      function widgets() {                                                                                            // 169
        // Otherwise, return all of the tasks                                                                         // 170
        var find = {                                                                                                  // 171
          this_page_only: { $in: [false, null] },                                                                     // 172
          pagetype: pageinfo().pagetype,                                                                              // 173
          $or: [{ visibility: "public" }, { $and: [{ visibility: "private" }, { "createdBy.userid": Meteor.userId() }] }, { visibility: null }]
        };                                                                                                            // 171
                                                                                                                      //
        //        var results = Widgets.find(find, {sort: {sort_order : -1, createdAt: -1}}).map(setWidgetDefaults); 
        var results = Widgets.find(find, { sort: { sort_order: -1 } }).map(setWidgetDefaults);                        // 185
        return results;                                                                                               // 186
      }                                                                                                               // 187
                                                                                                                      //
      return widgets;                                                                                                 // 169
    }(),                                                                                                              // 169
    thisPageWidgets: function () {                                                                                    // 188
      function thisPageWidgets() {                                                                                    // 188
        // Otherwise, return all of the tasks                                                                         // 189
        var find = { this_page_only: true,                                                                            // 190
          pagetype: pageinfo().pagetype,                                                                              // 191
          pageid: pageinfo().pageid };                                                                                // 192
        var results = Widgets.find(find, { sort: { sort_order: -1, createdAt: -1 } }).map(setWidgetDefaults);         // 193
        return results;                                                                                               // 194
      }                                                                                                               // 195
                                                                                                                      //
      return thisPageWidgets;                                                                                         // 188
    }()                                                                                                               // 188
                                                                                                                      //
  });                                                                                                                 // 168
  Template.body.helpers({                                                                                             // 198
    widgets: function () {                                                                                            // 199
      function widgets() {                                                                                            // 199
        // Otherwise, return all of the tasks                                                                         // 200
        var find = {                                                                                                  // 201
          this_page_only: { $in: [false, null] },                                                                     // 202
          pagetype: pageinfo().pagetype,                                                                              // 203
          $or: [{ visibility: "public" }, { $and: [{ visibility: "private" }, { "createdBy.userid": Meteor.userId() }] }, { visibility: null }]
        };                                                                                                            // 201
                                                                                                                      //
        //        var results = Widgets.find(find, {sort: {sort_order : -1, createdAt: -1}}).map(setWidgetDefaults); 
        var results = Widgets.find(find, { sort: { sort_order: -1 } }).map(setWidgetDefaults);                        // 215
        return results;                                                                                               // 216
      }                                                                                                               // 217
                                                                                                                      //
      return widgets;                                                                                                 // 199
    }(),                                                                                                              // 199
    widgetTemplates: function () {                                                                                    // 218
      function widgetTemplates() {                                                                                    // 218
        // Otherwise, return all of the tasks                                                                         // 219
        var results = Widgets.find({ isTemplate: true }, { sort: { sort_order: -1, createdAt: -1 } }).map(setWidgetDefaults);
        return results;                                                                                               // 221
      }                                                                                                               // 222
                                                                                                                      //
      return widgetTemplates;                                                                                         // 218
    }(),                                                                                                              // 218
    libraryWidgets: function () {                                                                                     // 223
      function libraryWidgets() {                                                                                     // 223
        // Otherwise, return all of the tasks                                                                         // 224
        var find = { inLibrary: true };                                                                               // 225
        find["createdBy.userid"] = Meteor.userId();                                                                   // 226
        var results = Widgets.find(find, { sort: { sort_order: -1, createdAt: -1 } }).map(setWidgetDefaults);         // 227
        return results;                                                                                               // 228
      }                                                                                                               // 229
                                                                                                                      //
      return libraryWidgets;                                                                                          // 223
    }(),                                                                                                              // 223
    thisPageWidgets: function () {                                                                                    // 230
      function thisPageWidgets() {                                                                                    // 230
        // Otherwise, return all of the tasks                                                                         // 231
        var find = { this_page_only: true,                                                                            // 232
          pagetype: pageinfo().pagetype,                                                                              // 233
          pageid: pageinfo().pageid };                                                                                // 234
        var results = Widgets.find(find, { sort: { sort_order: -1, createdAt: -1 } }).map(setWidgetDefaults);         // 235
        return results;                                                                                               // 236
      }                                                                                                               // 237
                                                                                                                      //
      return thisPageWidgets;                                                                                         // 230
    }(),                                                                                                              // 230
                                                                                                                      //
    userXtras: function () {                                                                                          // 239
      function userXtras() {                                                                                          // 239
        return getUserXtras();                                                                                        // 240
      }                                                                                                               // 241
                                                                                                                      //
      return userXtras;                                                                                               // 239
    }(),                                                                                                              // 239
                                                                                                                      //
    godmode: function () {                                                                                            // 243
      function godmode() {                                                                                            // 243
        return getUserXtras().godmode;                                                                                // 244
      }                                                                                                               // 245
                                                                                                                      //
      return godmode;                                                                                                 // 243
    }()                                                                                                               // 243
                                                                                                                      //
  });                                                                                                                 // 198
  ////// END HELPERS                                                                                                  // 248
                                                                                                                      //
                                                                                                                      //
  ////// TEMPLATE ONRENDERED                                                                                          // 251
  Template.body.onRendered(function () {                                                                              // 252
    //$(".tooltip-right").tooltip({placement: "right"});                                                              // 253
    //  $("[title]").tooltip({placement: "auto"});                                                                    // 254
    console.log("555555555555C5 rendered");                                                                           // 255
  });                                                                                                                 // 256
  ////// END ONRENDERED                                                                                               // 257
                                                                                                                      //
                                                                                                                      //
  /////// EVENTS                                                                                                      // 261
  Template.body.events({                                                                                              // 262
                                                                                                                      //
    "click .lockall": function () {                                                                                   // 265
      function clickLockall() {                                                                                       // 265
        $(".lock").trigger("click");                                                                                  // 266
        $(".lockall").hide();                                                                                         // 267
        $(".unlockall").show();                                                                                       // 268
        giphy_modal("unlock", "Unlocking all widgets you have access to");                                            // 269
        return false;                                                                                                 // 270
      }                                                                                                               // 272
                                                                                                                      //
      return clickLockall;                                                                                            // 265
    }(),                                                                                                              // 265
    "click .unlockall": function () {                                                                                 // 273
      function clickUnlockall() {                                                                                     // 273
        $(".unlock").trigger("click");                                                                                // 274
        $(".lockall").show();                                                                                         // 275
        $(".unlockall").hide();                                                                                       // 276
        giphy_modal("lock", "Locking all Widgets");                                                                   // 277
        return false;                                                                                                 // 278
      }                                                                                                               // 279
                                                                                                                      //
      return clickUnlockall;                                                                                          // 273
    }(),                                                                                                              // 273
                                                                                                                      //
    "click .giphy": function () {                                                                                     // 281
      function clickGiphy(e, t) {                                                                                     // 281
        $(e.target).hide();                                                                                           // 282
      }                                                                                                               // 283
                                                                                                                      //
      return clickGiphy;                                                                                              // 281
    }(),                                                                                                              // 281
                                                                                                                      //
    "click .godmode_check": function () {                                                                             // 285
      function clickGodmode_check(e, t) {                                                                             // 285
        //      console.log(t);                                                                                       // 286
        UserXtras.update({ _id: Meteor.userId() }, { $set: { godmode: e.target.checked } });                          // 287
      }                                                                                                               // 288
                                                                                                                      //
      return clickGodmode_check;                                                                                      // 285
    }(),                                                                                                              // 285
                                                                                                                      //
    'click .copy_from_template': function () {                                                                        // 290
      function clickCopy_from_template() {                                                                            // 290
        copyWidgetToPage($(this).attr("target"), pageinfo().pagetype, pageinfo().pageurl, pageinfo().pageid);         // 291
        giphy_modal("copy", "New Widget Copied From Template");                                                       // 292
        return false;                                                                                                 // 293
      }                                                                                                               // 294
                                                                                                                      //
      return clickCopy_from_template;                                                                                 // 290
    }(),                                                                                                              // 290
                                                                                                                      //
    'click .deletetemplate': function () {                                                                            // 296
      function clickDeletetemplate() {                                                                                // 296
        var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                                 // 297
        template.isTemplate = false;                                                                                  // 298
        Widgets.update(template._id, template);                                                                       // 299
      }                                                                                                               // 300
                                                                                                                      //
      return clickDeletetemplate;                                                                                     // 296
    }(),                                                                                                              // 296
                                                                                                                      //
    'click .addwidget': function () {                                                                                 // 302
      function clickAddwidget() {                                                                                     // 302
        //add jsbin widget                                                                                            // 303
                                                                                                                      //
        var htmlstring = '<html>\n ' + '<head>\n ' + '<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>\n ' + '<script src="/c5libs/locallib.js"></script>\n ' + '   <script type="application/json" class="c5_data">{"data" : "data placed here gets passed along"}</script>\n ' + '</head>\n ' + '<body>\n ' + '  <div class="c5_html">\n ' + '  html placed here gets passed along\n ' + '  </div>\n ' + '</body>\n ' + '</html>\n';
        var csstring = "";                                                                                            // 317
        var jsstring = "function doTheThings(data){\n" + "// everything you want to do should happen inside this function\n " + "// the data var will be populated with whatever you've requested from other widgets\n" + "// and this function will be call when all those widgets have complete \n" + "   c5_done(); // this message is required at the end of all the processing, so the system knows this widget is done \n " + "} \n" + "requireWidgetData( \n" + "// all requests to other widgets go here (automatically if you use the 'pull from' interface): \n" + "// c5_requires \n" + "{} \n" + "// end_c5_requires \n" + "// end other widget requests \n" + ", doTheThings)";
        var dataobj = { html: htmlstring, css: csstring, javascript: jsstring };                                      // 331
        var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                                 // 332
        var options = { data: dataobj };                                                                              // 333
        HTTP.post(url, options, function (error, results) {                                                           // 334
          newWidget = { _id: results.data.url,                                                                        // 335
            createdBy: { username: Meteor.user().username,                                                            // 336
              userid: Meteor.userId() },                                                                              // 337
            isTemplate: false,                                                                                        // 338
            name: results.data.url,                                                                                   // 339
            description: "",                                                                                          // 340
            html: results.data.html,                                                                                  // 341
            javascript: results.data.javascript,                                                                      // 342
            css: results.data.css,                                                                                    // 343
            displayWidth: "",                                                                                         // 344
            displayHeight: "",                                                                                        // 345
            widgetStyle: "",                                                                                          // 346
            pagetype: pageinfo().pagetype,                                                                            // 347
            pageurl: pageinfo().pageurl,                                                                              // 348
            pageid: pageinfo().pageid,                                                                                // 349
            url: results.data.url,                                                                                    // 350
            visibility: "private",                                                                                    // 351
            createdAt: new Date(),                                                                                    // 352
            rand: Math.random() };                                                                                    // 353
          Widgets.insert(newWidget);                                                                                  // 354
        });                                                                                                           // 355
        return false;                                                                                                 // 356
      }                                                                                                               // 357
                                                                                                                      //
      return clickAddwidget;                                                                                          // 302
    }(),                                                                                                              // 302
                                                                                                                      //
    'click .test': function () {                                                                                      // 359
      function clickTest() {                                                                                          // 359
        return false;                                                                                                 // 360
      }                                                                                                               // 361
                                                                                                                      //
      return clickTest;                                                                                               // 359
    }()                                                                                                               // 359
  });                                                                                                                 // 262
                                                                                                                      //
  ///// END EVENTS                                                                                                    // 365
                                                                                                                      //
}                                                                                                                     // 368
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 370
  Meteor.startup(function () {                                                                                        // 371
    // code to run on server at startup                                                                               // 372
  });                                                                                                                 // 373
}                                                                                                                     // 374
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"common_functions.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// common_functions.js                                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
justaddedid = pageinfo = setWidgetDefaults = giphy_modal = getUserXtras = null;                                       // 1
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 3
                                                                                                                      //
  getUserXtras = function getUserXtras() {                                                                            // 5
    var userxtras = false;                                                                                            // 6
    var user = Meteor.user();                                                                                         // 7
    if (user) {                                                                                                       // 8
      /*                                                                                                              // 9
      console.log(user.username);                                                                                     //
      console.log(user._id);                                                                                          //
      console.log("getting for " + user._id);                                                                         //
      */                                                                                                              //
      userxtras = UserXtras.findOne({ _id: user._id });                                                               // 14
      if (!userxtras || !userxtras.foo) {                                                                             // 15
        console.log("userxtras " + userxtras);                                                                        // 16
        userxtras = { _id: user._id, admin: false, godmode: false, foo: "var" };                                      // 17
        if (user.username == "donundeen") {                                                                           // 18
          userxtras.admin = true;                                                                                     // 19
        }                                                                                                             // 20
        console.log("saving for " + user._id);                                                                        // 21
        UserXtras.upsert({ _id: user._id }, userxtras);                                                               // 22
        var userxtras2 = UserXtras.findOne({ _id: user._id });                                                        // 23
      }                                                                                                               // 24
    }                                                                                                                 // 25
    return userxtras;                                                                                                 // 26
  };                                                                                                                  // 28
                                                                                                                      //
  giphy_modal = function giphy_modal(term, text) {                                                                    // 32
    $("#giphy_modal").modal('show');                                                                                  // 33
    $(".giphy_modal_header").text(text);                                                                              // 34
    var url = "/giphy_proxy/" + encodeURIComponent(term);                                                             // 35
    $(".giphy_modal_image_div").empty();                                                                              // 36
    var imgurl = url + "?" + new Date().getTime();                                                                    // 37
    $(".giphy_modal_image_div").html("<img src='" + imgurl + "' width='200' class='giphy_modal_image_img'/>");        // 38
                                                                                                                      //
    setTimeout(function () {                                                                                          // 40
      $("#giphy_modal").modal('hide');                                                                                // 41
    }, 2000);                                                                                                         // 42
  };                                                                                                                  // 44
                                                                                                                      //
  pageinfo = function pageinfo() {                                                                                    // 46
    var pagetype = "";                                                                                                // 47
    var pageid = "";                                                                                                  // 48
    var pathname = window.location.pathname;                                                                          // 49
    var split = pathname.split("/");                                                                                  // 50
    split.shift();                                                                                                    // 51
    var pageurl = split.join("/");                                                                                    // 52
                                                                                                                      //
    if (split.length > 0) {                                                                                           // 54
      pagetype = split.shift();                                                                                       // 55
    }                                                                                                                 // 56
    if (split.length > 0) {                                                                                           // 57
      pageid = split.shift();                                                                                         // 58
    }                                                                                                                 // 59
    pageid = pageid.replace(/:script/, "");                                                                           // 60
    return { pageurl: pageurl,                                                                                        // 61
      pagetype: pagetype,                                                                                             // 62
      pageid: pageid };                                                                                               // 63
  };                                                                                                                  // 65
                                                                                                                      //
  copyWidgetToPage = function copyWidgetToPage(origID, pagetype, pageid, pageurl) {                                   // 68
    console.log("calling CopyWidgetToPage for " + origID);                                                            // 69
    var template = Widgets.findOne({ url: origID }); //.map(setWidgetDefaults);                                       // 70
    var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                        // 71
    var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                                     // 72
    var options = { data: dataobj };                                                                                  // 73
                                                                                                                      //
    HTTP.post(url, options, function (error, results) {                                                               // 75
      newWidget = { _id: results.data.url,                                                                            // 76
        createdBy: { username: Meteor.user().username,                                                                // 77
          userid: Meteor.userId() },                                                                                  // 78
        isTemplate: false,                                                                                            // 79
        html: results.data.html,                                                                                      // 80
        javascript: results.data.javascript,                                                                          // 81
        css: results.data.css,                                                                                        // 82
        displayWidth: results.data.displayWidth,                                                                      // 83
        displayHeight: results.data.displayHeight,                                                                    // 84
        description: "(copied from " + template.name + ") " + template.description,                                   // 85
        widgetStyle: results.data.widgetStyle,                                                                        // 86
        name: "copy of " + template.name,                                                                             // 87
        pagetype: pagetype,                                                                                           // 88
        pageurl: pageurl,                                                                                             // 89
        pageid: pageid,                                                                                               // 90
        url: results.data.url,                                                                                        // 91
        createdAt: new Date(),                                                                                        // 92
        visibility: "private",                                                                                        // 93
        rand: Math.random() };                                                                                        // 94
      justaddedid = Widgets.insert(newWidget);                                                                        // 95
      console.log("setting justaddedid " + justaddedid);                                                              // 96
                                                                                                                      //
      var grid = $(".grid-stack").data('gridstack');                                                                  // 98
      var widgetElement = $("#widgetContainer_" + results.data.url);                                                  // 99
                                                                                                                      //
      console.log("added ");                                                                                          // 101
      console.log(widgetElement);                                                                                     // 102
      /*                                                                                                              // 103
      var griditem = $(widgetElement).parent().parent();                                                              //
      $(griditem).data("gs-width", "12");                                                                             //
      $(griditem).data("gs-height", "5");                                                                             //
      $(griditem).data("gs-auto-position", "true");                                                                   //
      grid.makeWidget(griditem);                                                                                      //
      grid.resize(griditem, 12, 5);                                                                                   //
       var next = $(".grid-stack-item").get(0)  ;                                                                     //
      console.log("moving next" + $(next).data("widget-id"));                                                         //
      console.log(next);                                                                                              //
      grid.move(next, 0, 6);                                                                                          //
      */                                                                                                              //
    });                                                                                                               // 116
    giphy_modal("copy", "New Widget Copied From Template");                                                           // 117
  };                                                                                                                  // 119
                                                                                                                      //
  setWidgetDefaults = function setWidgetDefaults(doc) {                                                               // 122
    if (typeof doc.displayWidth === "undefined" || !doc.displayWidth || doc.displayWidth.trim() == "" || doc.displayWidth == "width" || doc.displayWidth == "default") {
      doc.displayWidth = "320px";                                                                                     // 124
      doc.displayUsableWidth = "320px";                                                                               // 125
    } else {                                                                                                          // 126
      doc.displayUsableWidth = doc.displayWidth;                                                                      // 127
    }                                                                                                                 // 128
    if (typeof doc.displayHeight === "undefined" || !doc.displayHeight || doc.displayHeight.trim() == "" || doc.displayHeight == "height" || doc.displayHeight == "default") {
      doc.displayHeight = "400px";                                                                                    // 130
      doc.displayUsableHeight = "400px";                                                                              // 131
    } else {                                                                                                          // 132
      doc.displayUsableHeight = doc.displayHeight;                                                                    // 133
    }                                                                                                                 // 134
    if (typeof doc.widgetStyle === "undefined" || !doc.widgetStyle || doc.widgetStyle.trim() == "" || doc.widgetStyle == "css" || doc.widgetStyle == "default") {
      doc.widgetStyle = "default";                                                                                    // 136
      doc.usableWidgetStyle = "";                                                                                     // 137
    } else {                                                                                                          // 138
      doc.usableWidgetStyle = doc.widgetStyle;                                                                        // 139
    }                                                                                                                 // 140
    if (!doc.createdBy) {                                                                                             // 141
      doc.createdBy = {};                                                                                             // 142
    }                                                                                                                 // 143
                                                                                                                      //
    if (doc.displayUsableHeight.match(/px/)) {                                                                        // 145
      var height = doc.displayUsableHeight.replace(/px/, "");                                                         // 146
      doc.jsbinHeight = height - 20;                                                                                  // 147
      doc.jsbinHeight += "px";                                                                                        // 148
    } else {                                                                                                          // 149
      doc.jsbinHeight = "";                                                                                           // 150
    }                                                                                                                 // 151
                                                                                                                      //
    if (!doc.this_page_only) {                                                                                        // 153
      doc.this_page_only = false;                                                                                     // 154
    }                                                                                                                 // 155
                                                                                                                      //
    if (!doc.sort_order) {                                                                                            // 157
      doc.sort_order = 0;                                                                                             // 158
    }                                                                                                                 // 159
                                                                                                                      //
    if (!doc.visibility) {                                                                                            // 161
      doc.visibility = "public";                                                                                      // 162
    }                                                                                                                 // 163
                                                                                                                      //
    if (!doc.cacheConfig) {                                                                                           // 165
      doc.cacheConfig = {};                                                                                           // 166
    }                                                                                                                 // 167
                                                                                                                      //
    if (!doc.cacheConfig.ttl) {                                                                                       // 169
      doc.cacheConfig.ttl = 60;                                                                                       // 170
    }                                                                                                                 // 171
                                                                                                                      //
    if (typeof doc.width_in_cells == "undefined") {                                                                   // 173
      doc.width_in_cells = 12;                                                                                        // 174
    }                                                                                                                 // 175
    if (typeof doc.height_in_cells == "undefined") {                                                                  // 176
      doc.height_in_cells = 5;                                                                                        // 177
    }                                                                                                                 // 178
    if (doc.width_in_cells == 0) {                                                                                    // 179
      doc.width_in_cells = 1;                                                                                         // 180
    }                                                                                                                 // 181
    if (doc.height_in_cells == 0) {                                                                                   // 182
      doc.height_in_cells = 1;                                                                                        // 183
    }                                                                                                                 // 184
    if (typeof doc.width_in_px == "undefined") {                                                                      // 185
      doc.width_in_px = 640;                                                                                          // 186
    }                                                                                                                 // 187
    if (typeof doc.height_in_px == "undefined") {                                                                     // 188
      doc.height_in_px = 320;                                                                                         // 189
    }                                                                                                                 // 190
    if (doc.width_in_px == 0) {                                                                                       // 191
      doc.width_in_px = 640;                                                                                          // 192
    }                                                                                                                 // 193
    if (doc.height_in_px == 0) {                                                                                      // 194
      doc.height_in_px = 320;                                                                                         // 195
    }                                                                                                                 // 196
                                                                                                                      //
    return doc;                                                                                                       // 199
  };                                                                                                                  // 200
}                                                                                                                     // 201
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"widget.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// widget.js                                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 2
  var dix;                                                                                                            // 2
                                                                                                                      //
  (function () {                                                                                                      // 2
    var setDisplayModeOn = function setDisplayModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin, widgetid, isnew) {
      var grid = $(".grid-stack").data("gridstack");                                                                  // 8
      var griditem = $(widgetElement).parent().parent();                                                              // 9
      var result = grid.resize(griditem, widgetData.width_in_cells, widgetData.height_in_cells);                      // 10
                                                                                                                      //
      // get the size of the navbar, subtract from height of iframe                                                   // 12
                                                                                                                      //
      dix++;                                                                                                          // 14
      var di = dix;                                                                                                   // 15
      var newbintop = 0;                                                                                              // 16
      $(menu).hide();                                                                                                 // 17
                                                                                                                      //
      $(".editmodeonly", widgetElement).hide();                                                                       // 19
      $(".displaymodeonly", widgetElement).show();                                                                    // 20
      iframeElement.oldbintop = $(bin).css("top");                                                                    // 21
      $(bin).css("top", newbintop);                                                                                   // 22
      $(widgetElement).attr("style", widgetData.usableWidgetStyle);                                                   // 23
                                                                                                                      //
      $(widgetElement).css("border-radius", "10px");                                                                  // 25
      $(".widgetDisplayHeader", widgetElement).hide();                                                                // 26
                                                                                                                      //
      if (jsbin && jsbin.panels) {                                                                                    // 28
        jsbin.panels.hide("html");                                                                                    // 29
        jsbin.panels.hide("javascript");                                                                              // 30
        jsbin.panels.hide("css");                                                                                     // 31
        jsbin.panels.hide("console");                                                                                 // 32
      }                                                                                                               // 33
      $(".lock", widgetElement).show();                                                                               // 34
      $(".unlock", widgetElement).hide();                                                                             // 35
      $(widgetElement).data("mode", "display");                                                                       // 36
      $(iframeElement).css("border-radius", "10px");                                                                  // 37
                                                                                                                      //
      var initialH = $(griditem).height();                                                                            // 39
      var finalh = initialH;                                                                                          // 40
      var initialW = $(griditem).width();                                                                             // 41
      var finalw = initialW;                                                                                          // 42
      $(widgetElement).width(finalw - 35);                                                                            // 43
      $(widgetElement).height(finalh - 15);                                                                           // 44
                                                                                                                      //
      $(iframeElement).css("max-height", "");                                                                         // 46
      $(iframeElement).css("max-width", "");                                                                          // 47
      $(iframeElement).css("min-height", "");                                                                         // 48
      $(iframeElement).css("min-width", "");                                                                          // 49
                                                                                                                      //
      $(iframeElement).width(finalw - 35);                                                                            // 51
      $(iframeElement).css("max-width", finalw - 35);                                                                 // 52
      $(iframeElement).height(finalh - 25);                                                                           // 53
      $(iframeElement).css("max-height", finalh - 25);                                                                // 54
      $(iframeElement).css("min-height", finalh - 25);                                                                // 55
    };                                                                                                                // 57
                                                                                                                      //
    var setEditModeOn = function setEditModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin) {          // 2
      var grid = $(".grid-stack").data("gridstack");                                                                  // 61
      var griditem = $(widgetElement).parent().parent();                                                              // 62
      if (jsbin) {                                                                                                    // 63
        jsbin.panels.show("html");                                                                                    // 64
        jsbin.panels.show("javascript");                                                                              // 65
      }                                                                                                               // 66
      $(".lock", widgetElement).hide();                                                                               // 67
      $(".unlock", widgetElement).show();                                                                             // 68
      //      editors.panels.show("css");                                                                             // 69
                                                                                                                      //
      var newbintop = 0;                                                                                              // 71
                                                                                                                      //
      grid.resize(griditem, 12, 6);                                                                                   // 73
                                                                                                                      //
      // put it in EDIT MODE                                                                                          // 75
      $(menu).show();                                                                                                 // 76
      $(".editmodeonly", widgetElement).show();                                                                       // 77
      $(".displaymodeonly", widgetElement).hide();                                                                    // 78
      $(bin).css("top", iframeElement.oldbintop);                                                                     // 79
      $(widgetElement).css("border-radius", "10px");                                                                  // 80
      $(iframeElement).css("border-radius", "10px");                                                                  // 81
                                                                                                                      //
      // ".navbar-collapse"                                                                                           // 83
      var height_adjust = $(".navbar-collapse", widgetElement).height() - 20;                                         // 84
      // adjust for height of menu                                                                                    // 85
                                                                                                                      //
                                                                                                                      //
      var initialH = $(griditem).height();                                                                            // 88
      var finalh = initialH;                                                                                          // 89
      var initialW = $(griditem).width();                                                                             // 90
      var finalw = initialW;                                                                                          // 91
      $(widgetElement).width(finalw - 25);                                                                            // 92
      $(widgetElement).height(finalh - 15);                                                                           // 93
                                                                                                                      //
      $(iframeElement).css("max-height", "");                                                                         // 95
      $(iframeElement).css("max-width", "");                                                                          // 96
      $(iframeElement).css("min-height", "");                                                                         // 97
      $(iframeElement).css("min-width", "");                                                                          // 98
                                                                                                                      //
      $(iframeElement).width(finalw - 25);                                                                            // 100
      $(iframeElement).css("max-width", finalw - 25);                                                                 // 101
      $(iframeElement).height(finalh - 25 - height_adjust);                                                           // 102
      $(iframeElement).css("max-height", finalh - 25);                                                                // 103
      $(iframeElement).css("min-height", finalh - 25);                                                                // 104
    };                                                                                                                // 106
    /////// END FUNCTION DEFS                                                                                         // 107
                                                                                                                      //
                                                                                                                      //
    /////////// END WIDGET ONRENDERED                                                                                 // 345
                                                                                                                      //
                                                                                                                      //
    //////////// EVENTS                                                                                               // 349
                                                                                                                      //
    var insert_code = function insert_code(jsbin_id, codeString, codeStringRe, comments) {                            // 2
                                                                                                                      //
      var editors = document.getElementById(jsbin_id).contentWindow.editors;                                          // 353
                                                                                                                      //
      if (!editors) {                                                                                                 // 355
        return true;                                                                                                  // 356
      }                                                                                                               // 357
      var code = editors.javascript.getCode();                                                                        // 358
      var line = editors.javascript.editor.getCursor().line;                                                          // 359
      var charpos = editors.javascript.editor.getCursor().ch;                                                         // 360
      // make sure it's not already in there:                                                                         // 361
      var codeRe = new RegExp("\/\/ *c[45]_requires[\\s\\S]*\\[[\\s\\S]*" + codeStringRe + "[\\s\\S]*\\] *,[\\s\\S]*\/\/ *end_c[45]_requires");
      var codeMatch = code.match(codeRe);                                                                             // 363
      if (!codeMatch) {                                                                                               // 364
        // match to empty array                                                                                       // 365
        var match = /(\/\/ *c[45]_requires[\s\S]*\[)\s*(\] *,[\s\S]*\/\/ *end_c[45]_requires)/;                       // 366
        var results = code.match(match);                                                                              // 367
        newcode = code.replace(match, "$1\n" + codeString + " // " + comments + "\n$2");                              // 368
                                                                                                                      //
        if (newcode == code) {                                                                                        // 370
          // match to non-empty array                                                                                 // 371
          var match = /(\/\/ *c[45]_requires[\s\S]*\[)([^\]]*\] *,[\s\S]*\/\/ *end_c[45]_requires)/;                  // 372
          var results = code.match(match);                                                                            // 373
          newcode = code.replace(match, "$1\n" + codeString + ", // " + comments + "$2");                             // 374
        }                                                                                                             // 375
        code = newcode;                                                                                               // 376
        var state = { line: editors.javascript.editor.currentLine(),                                                  // 377
          character: editors.javascript.editor.getCursor().ch,                                                        // 378
          add: 0                                                                                                      // 379
        };                                                                                                            // 377
                                                                                                                      //
        editors.javascript.setCode(code);                                                                             // 382
        editors.javascript.editor.setCursor({ line: state.line + state.add, ch: state.character });                   // 383
      }                                                                                                               // 384
    };                                                                                                                // 385
                                                                                                                      //
    /////// FUNCTION DEFS                                                                                             // 4
    dix = 0;                                                                                                          // 5
    Template.gridwidgets.onRendered(function () {                                                                     // 111
      // set whatever gridStack options you want                                                                      // 112
      var options = {                                                                                                 // 113
        width: 12,                                                                                                    // 114
        auto: false,                                                                                                  // 115
        cellHeight: 60,                                                                                               // 116
        cellWidth: 60,                                                                                                // 117
        alwaysShowResizeHandle: /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),
        resizable: {                                                                                                  // 119
          handles: 'e, se, s, sw, w'                                                                                  // 120
        }                                                                                                             // 119
      };                                                                                                              // 113
      var $gridstack = this.$('.grid-stack');                                                                         // 123
      // initialise gridstack                                                                                         // 124
      $gridstack.gridstack(options);                                                                                  // 125
                                                                                                                      //
      $(window).resize(function (evt) {                                                                               // 127
        if (evt.target == window) {                                                                                   // 128
          var grid = $(".grid-stack").data("gridstack");                                                              // 129
          $(".grid-stack-item").each(function (index) {                                                               // 130
            var element = this;                                                                                       // 131
            var initialH = $(element).height();                                                                       // 132
            var finalh = initialH;                                                                                    // 133
            var initialW = $(element).width();                                                                        // 134
            var finalw = initialW;                                                                                    // 135
            var cellw = grid.cellWidth();                                                                             // 136
            var cellh = grid.cellHeight();                                                                            // 137
            var cells_wide = $(element).data("gs-width");                                                             // 138
            var cells_high = $(element).data('gs-height');                                                            // 139
                                                                                                                      //
            var widgetElement = $(".widgetContainer", element);                                                       // 141
            var iframeElement = $(".jsbin-embed", element);                                                           // 142
                                                                                                                      //
            $(widgetElement).width(finalw - 25);                                                                      // 144
            $(widgetElement).height(finalh - 15);                                                                     // 145
                                                                                                                      //
            $(iframeElement).css("max-height", "");                                                                   // 147
            $(iframeElement).css("max-width", "");                                                                    // 148
            $(iframeElement).css("min-height", "");                                                                   // 149
            $(iframeElement).css("min-width", "");                                                                    // 150
                                                                                                                      //
            $(iframeElement).width(finalw - 35);                                                                      // 152
            $(iframeElement).css("max-width", finalw - 35);                                                           // 153
            $(iframeElement).height(finalh - 25);                                                                     // 154
            $(iframeElement).css("max-height", finalh - 25);                                                          // 155
          });                                                                                                         // 157
        }                                                                                                             // 158
      });                                                                                                             // 159
                                                                                                                      //
      $('.grid-stack').on('dragstop', function (event, ui) {                                                          // 163
        // for some reason the moved grid-item doesn't have access to the widgetId data attribute, so get it here and hang onto it.
        var target_url = $(event.target).data("widget-id");                                                           // 165
        // save new order when items are moved.                                                                       // 166
        var grid = $(this).data('gridstack');                                                                         // 167
        var nodes = grid.grid.nodes;                                                                                  // 168
        for (var i = 0; i < nodes.length; i++) {                                                                      // 169
          var node = nodes[i];                                                                                        // 170
          var id = $(node.el).data('widgetId');                                                                       // 171
          // get widget code, update sort-order                                                                       // 172
          if (typeof id == "undefined") {                                                                             // 173
            id = target_url;                                                                                          // 174
          }                                                                                                           // 175
          if (typeof id != "undefined") {                                                                             // 176
            (function (_id) {                                                                                         // 177
              var widget = Widgets.findOne({ url: _id }); //.map(setWidgetDefaults);                                  // 178
              widget.sort_order = i;                                                                                  // 179
              Widgets.update(widget._id, widget, {}, function (arg1, arg2) {});                                       // 180
            })(id);                                                                                                   // 182
          } else {                                                                                                    // 183
            //            console.log(node);                                                                          // 184
          }                                                                                                           // 185
        }                                                                                                             // 186
      });                                                                                                             // 187
                                                                                                                      //
      $('.grid-stack').on('resizestop', function (event, items) {                                                     // 189
        var grid = this;                                                                                              // 190
        var element = event.target;                                                                                   // 191
        var widgetElement = $(".widgetContainer", element);                                                           // 192
        var iframeElement = $(".jsbin-embed", element);                                                               // 193
        // need to wait just a bit for the size to quantize to the grid...                                            // 194
        setTimeout(function () {                                                                                      // 195
          var initialH = $(element).height();                                                                         // 196
          var finalh = initialH;                                                                                      // 197
          var initialW = $(element).width();                                                                          // 198
          var finalw = initialW;                                                                                      // 199
          var widgetID = $(widgetElement).data("url");                                                                // 200
          var widget = Widgets.findOne({ url: widgetID }); //.map(setWidgetDefaults);                                 // 201
          $(widgetElement).width(finalw - 35);                                                                        // 202
          $(widgetElement).height(finalh - 15);                                                                       // 203
                                                                                                                      //
          $(iframeElement).css("max-height", "");                                                                     // 205
          $(iframeElement).css("max-width", "");                                                                      // 206
          $(iframeElement).css("min-height", "");                                                                     // 207
          $(iframeElement).css("min-width", "");                                                                      // 208
                                                                                                                      //
          $(iframeElement).width(finalw - 35);                                                                        // 210
          $(iframeElement).css("max-width", finalw - 35);                                                             // 211
          $(iframeElement).height(finalh - 25);                                                                       // 212
          $(iframeElement).css("max-height", finalh - 25);                                                            // 213
                                                                                                                      //
          var cellw = $(grid).data("gridstack").opts.cellWidth;                                                       // 215
          var cellh = $(grid).data("gridstack").opts.cellHeight;                                                      // 216
          var cells_wide = $(element).data("gs-width");                                                               // 217
          var cells_high = $(element).data('gs-height');                                                              // 218
                                                                                                                      //
          widget.width_in_cells = cells_wide;                                                                         // 220
          widget.height_in_cells = cells_high;                                                                        // 221
          widget.width_in_px = finalw;                                                                                // 222
          widget.height_in_px = finalh;                                                                               // 223
          Widgets.update(widget._id, widget);                                                                         // 224
        }, 350);                                                                                                      // 225
      });                                                                                                             // 227
                                                                                                                      //
      $('.grid-stack').data("inited", true);                                                                          // 229
    });                                                                                                               // 231
                                                                                                                      //
    /////// WIDGET ONRENDERED                                                                                         // 233
    // In the client code, below everything else                                                                      // 234
    Template.widget.onRendered(function () {                                                                          // 235
      var thisisnew = false;                                                                                          // 236
                                                                                                                      //
      if (justaddedid == this.data._id) {                                                                             // 238
        thisisnew = true; // this node was just added.                                                                // 239
      }                                                                                                               // 240
      var context = Template.currentData();                                                                           // 241
      var firstNode = this.firstNode;                                                                                 // 242
      var firstNodeId = $(firstNode).data("widget-id");                                                               // 243
      var lastNode = this.lastNode;                                                                                   // 244
      var lastNodeId = $(lastNode).data("widget-id");                                                                 // 245
                                                                                                                      //
      var grid = $(".grid-stack").data('gridstack');                                                                  // 247
      var widgetElement = $("#widgetContainer_" + this.data._id);                                                     // 248
      var griditem = $(widgetElement).parent().parent();                                                              // 249
                                                                                                                      //
      if (!thisisnew && grid) {                                                                                       // 251
        grid.addWidget(this.$('.grid-stack-item'));                                                                   // 252
      } else {                                                                                                        // 253
        console.log("no grid?");                                                                                      // 254
      }                                                                                                               // 255
      // find out if the widget has been added to the grid.                                                           // 256
                                                                                                                      //
      if (thisisnew) {                                                                                                // 258
        grid.makeWidget(griditem);                                                                                    // 259
        grid.move(griditem, 0, 0);                                                                                    // 260
        var node = grid.grid.getNodeDataByDOMEl(griditem);                                                            // 261
        //  grid.grid._fixCollisions(griditem);                                                                       // 262
      }                                                                                                               // 263
      if (!$('.grid-stack').data("inited")) {}                                                                        // 264
      // end resizable grid setup                                                                                     // 267
                                                                                                                      //
                                                                                                                      //
      (function (widget, isnew) {                                                                                     // 271
        var thisid = widget.data._id;                                                                                 // 272
        var element = document.getElementById('jsbin_' + thisid);                                                     // 273
        var thiselement = document.getElementById('widgetContainer_' + thisid);                                       // 274
        $(".widgetDisplayHeader", thiselement).hide();                                                                // 275
                                                                                                                      //
        // maybe already exists?                                                                                      // 277
        var theElement = document.getElementById('jsbin_' + thisid);                                                  // 278
        if (theElement && theElement.contentWindow && theElement.contentWindow.document) {                            // 279
          $(theElement).load(function () {                                                                            // 280
            var widgetElement = document.getElementById('widgetContainer_' + thisid);                                 // 281
            var editors = jsbin = menu = bin = null;                                                                  // 282
            if (theElement) {                                                                                         // 283
              editors = theElement.contentWindow.editors;                                                             // 284
              jsbin = theElement.contentWindow.jsbin;                                                                 // 285
              menu = theElement.contentWindow.document.getElementById("control");                                     // 286
              bin = theElement.contentWindow.document.getElementById("bin");                                          // 287
              var thiselement = document.getElementById('widgetContainer_' + thisid);                                 // 288
              if (jsbin && jsbin.panels) {                                                                            // 289
                jsbin.panels.saveOnExit = true;                                                                       // 290
              }                                                                                                       // 291
              setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, thisid, isnew);                    // 292
            } else {                                                                                                  // 293
              console.log("no element found for jsbin_" + thisid);                                                    // 294
            }                                                                                                         // 295
          });                                                                                                         // 296
        }                                                                                                             // 297
        // this part here happens when the JSBIN stuff is loaded.                                                     // 298
        (function (this_id, isnew) {                                                                                  // 299
          if (isnew) {                                                                                                // 300
            var widgetElement = document.getElementById('widgetContainer_' + this_id);                                // 301
            var editors = jsbin = menu = bin = null;                                                                  // 302
            var theElement = document.getElementById('jsbin_' + this_id);                                             // 303
            if (theElement) {                                                                                         // 304
              editors = theElement.contentWindow.editors;                                                             // 305
              jsbin = theElement.contentWindow.jsbin;                                                                 // 306
              menu = theElement.contentWindow.document.getElementById("control");                                     // 307
              bin = theElement.contentWindow.document.getElementById("bin");                                          // 308
              if (jsbin && jsbin.panels) {                                                                            // 309
                jsbin.panels.saveOnExit = true;                                                                       // 310
              }                                                                                                       // 311
              setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, this_id, isnew);                   // 312
            } else {                                                                                                  // 313
              console.log("no element found for jsbin_" + this_id);                                                   // 314
            }                                                                                                         // 315
          }                                                                                                           // 316
                                                                                                                      //
          document.addEventListener("DOMNodeInserted", function (evt, item) {                                         // 319
            (function (_evt, _this_id, isnew) {                                                                       // 320
              if ($(_evt.target)[0].tagName == "IFRAME" && $(_evt.target)[0].id.replace("jsbin_", "") == _this_id) {  // 321
                $(_evt.target).load(function () {                                                                     // 322
                  var widgetElement = document.getElementById('widgetContainer_' + _this_id);                         // 323
                  var editors = jsbin = menu = bin = null;                                                            // 324
                  var theElement = document.getElementById('jsbin_' + _this_id);                                      // 325
                  if (theElement) {                                                                                   // 326
                    editors = theElement.contentWindow.editors;                                                       // 327
                    jsbin = theElement.contentWindow.jsbin;                                                           // 328
                    menu = theElement.contentWindow.document.getElementById("control");                               // 329
                    bin = theElement.contentWindow.document.getElementById("bin");                                    // 330
                    if (jsbin && jsbin.panels) {                                                                      // 331
                      jsbin.panels.saveOnExit = true;                                                                 // 332
                    }                                                                                                 // 333
                    setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, _this_id, isnew);            // 334
                  } else {                                                                                            // 335
                    console.log("no element found for jsbin_" + _this_id);                                            // 336
                  }                                                                                                   // 337
                });                                                                                                   // 338
              }                                                                                                       // 339
            })(evt, this_id, isnew);                                                                                  // 340
          });                                                                                                         // 341
        })(thisid, isnew);                                                                                            // 342
      })(this, thisisnew);                                                                                            // 343
    });                                                                                                               // 344
                                                                                                                      //
    Template.help.events({                                                                                            // 388
      "click .giphy": function () {                                                                                   // 389
        function clickGiphy(e, t) {                                                                                   // 389
          $(e.target).hide();                                                                                         // 390
        }                                                                                                             // 391
                                                                                                                      //
        return clickGiphy;                                                                                            // 389
      }()                                                                                                             // 389
    });                                                                                                               // 388
                                                                                                                      //
    Template.widget.events({                                                                                          // 394
                                                                                                                      //
      "click .giphy": function () {                                                                                   // 396
        function clickGiphy(e, t) {                                                                                   // 396
          $(e.target).hide();                                                                                         // 397
        }                                                                                                             // 398
                                                                                                                      //
        return clickGiphy;                                                                                            // 396
      }(),                                                                                                            // 396
                                                                                                                      //
      "click .delete": function () {                                                                                  // 400
        function clickDelete() {                                                                                      // 400
                                                                                                                      //
          var grid = $(".grid-stack").data("gridstack");                                                              // 402
                                                                                                                      //
          var widgetElement = $("#widgetContainer_" + this._id);                                                      // 404
          var griditem = $(widgetElement).parent().parent();                                                          // 405
                                                                                                                      //
          grid.removeWidget(griditem, true);                                                                          // 407
                                                                                                                      //
          if (this.isTemplate) {                                                                                      // 409
            this.pagetype = "template";                                                                               // 410
            Widgets.update(this._id, this);                                                                           // 411
          } else {                                                                                                    // 412
            Widgets.remove(this._id);                                                                                 // 413
          }                                                                                                           // 414
          giphy_modal("erase", "Widget Deleted");                                                                     // 415
          return false;                                                                                               // 416
        }                                                                                                             // 417
                                                                                                                      //
        return clickDelete;                                                                                           // 400
      }(),                                                                                                            // 400
                                                                                                                      //
      "click .save": function () {                                                                                    // 419
        function clickSave() {                                                                                        // 419
          var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                           // 420
          var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                               // 421
          var revision = jsbin.state.revision;                                                                        // 422
                                                                                                                      //
          this.html = editors.html.getCode();                                                                         // 424
          this.javascript = editors.javascript.getCode();                                                             // 425
          this.css = editors.css.getCode();                                                                           // 426
          jsbin.saveDisabled = false;                                                                                 // 427
          jsbin.panels.save();                                                                                        // 428
          jsbin.panels.savecontent();                                                                                 // 429
          Widgets.update(this._id, this);                                                                             // 430
                                                                                                                      //
          // also trigger the jsbin save                                                                              // 432
          var dataobj = { html: this.html, css: this.css, javascript: this.javascript };                              // 433
          var url = "/api/" + this.url + "/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,              // 434
          var options = { data: dataobj };                                                                            // 435
          HTTP.post(url, options, function (error, results) {});                                                      // 436
                                                                                                                      //
          giphy_modal("saved", "Widget Content Saved");                                                               // 439
                                                                                                                      //
          return false;                                                                                               // 441
        }                                                                                                             // 442
                                                                                                                      //
        return clickSave;                                                                                             // 419
      }(),                                                                                                            // 419
                                                                                                                      //
      "click .call_webservice_url": function () {                                                                     // 445
        function clickCall_webservice_url(evt, template) {                                                            // 445
          $("#webservice_insert_modal").modal('show');                                                                // 446
                                                                                                                      //
          $("#webservice_insert_modal_submit").click(function () {                                                    // 448
            var jsbin_id = 'jsbin_' + template.data.url;                                                              // 449
                                                                                                                      //
            var url = $("#webservice_insert_url").val().trim();                                                       // 452
            var name = $("#webservice_insert_name").val().trim();                                                     // 453
            var auth_token = $("#webservice_insert_auth_token").val().trim();                                         // 454
            var return_type = $("input[name=webservice_insert_return_type]:checked").val().trim();                    // 455
                                                                                                                      //
            url = url.replace("||PAGEID||", "'+pageId()+'");                                                          // 457
            url = url.replace("||PAGETYPE||", "'+pageType()+'");                                                      // 458
                                                                                                                      //
            var token_string;                                                                                         // 460
            if (auth_token) {                                                                                         // 461
              token_string = " \n authentication_token : '" + auth_token + "',";                                      // 462
            }                                                                                                         // 463
                                                                                                                      //
            var codeString = "{\n id:'" + name + "', \n type: 'webservice', " + token_string + " \n return_type: '" + return_type + "', \n url: '" + url + "' \n}";
            var codeStringRe = "\\{\n id:'" + name + "', \n type: 'webservice', \n return_type: '" + return_type + "', \n url: '" + url + "' \n\\}";
            var comments = " this will hold a " + return_type + " object";                                            // 467
                                                                                                                      //
            insert_code(jsbin_id, codeString, codeStringRe, comments);                                                // 469
          });                                                                                                         // 471
        }                                                                                                             // 474
                                                                                                                      //
        return clickCall_webservice_url;                                                                              // 445
      }(),                                                                                                            // 445
                                                                                                                      //
      "click .add_code": function () {                                                                                // 476
        function clickAdd_code(evt, template) {                                                                       // 476
                                                                                                                      //
          var pullfrom = evt.currentTarget.dataset.pullfrom;                                                          // 478
          var pulltype = evt.currentTarget.dataset.pulltype;                                                          // 479
                                                                                                                      //
          if (this.url == template.data.url) {                                                                        // 481
            return false;                                                                                             // 482
          }                                                                                                           // 483
                                                                                                                      //
          var type;                                                                                                   // 485
          var comments = "";                                                                                          // 486
          if (pulltype == "data") {                                                                                   // 487
            type = "data";                                                                                            // 488
            comments = " This will hold a JSON object";                                                               // 489
          }                                                                                                           // 490
          if (pulltype == "html") {                                                                                   // 491
            type = "html";                                                                                            // 492
            comments = " This will hold a jQuery object";                                                             // 493
          }                                                                                                           // 494
          var codeString = "{from: '" + pullfrom + "', type : '" + pulltype + "'}";                                   // 495
          var codeStringRe = "\\{from: '" + pullfrom + "', type : '" + pulltype + "'\\}";                             // 496
                                                                                                                      //
          var jsbin_id = 'jsbin_' + template.data.url;                                                                // 498
                                                                                                                      //
          insert_code(jsbin_id, codeString, codeStringRe, comments);                                                  // 500
                                                                                                                      //
          return true;                                                                                                // 502
        }                                                                                                             // 503
                                                                                                                      //
        return clickAdd_code;                                                                                         // 476
      }(),                                                                                                            // 476
                                                                                                                      //
      "click .test": function () {                                                                                    // 507
        function clickTest() {                                                                                        // 507
          var thiselement = document.getElementById('widgetContainer_' + this._id);                                   // 508
          var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                           // 509
          var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                               // 510
          var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");   // 511
          var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");        // 512
                                                                                                                      //
          var newbintop = 0;                                                                                          // 514
          this.maxed = !this.maxed;                                                                                   // 515
          if (this.maxed) {                                                                                           // 516
            $(menu).hide();                                                                                           // 517
            $(".editmodeonly", thiselement).hide();                                                                   // 518
            this.oldbintop = $(bin).css("top");                                                                       // 519
            $(bin).css("top", newbintop);                                                                             // 520
          } else {                                                                                                    // 521
            $(menu).show();                                                                                           // 522
            $(".editmodeonly", thiselement).show();                                                                   // 523
            $(bin).css("top", this.oldbintop);                                                                        // 524
          }                                                                                                           // 525
          return false;                                                                                               // 526
        }                                                                                                             // 527
                                                                                                                      //
        return clickTest;                                                                                             // 507
      }(),                                                                                                            // 507
      /*                                                                                                              // 528
      panel ids: html, css, javascript, console, live                                                                 //
      */                                                                                                              //
                                                                                                                      //
      // this sets it to EDIT mode                                                                                    // 532
      "click .widgetUnlock": function () {                                                                            // 533
        function clickWidgetUnlock() {                                                                                // 533
                                                                                                                      //
          var widgetElement = document.getElementById('widgetContainer_' + this._id);                                 // 535
          var iframeElement = document.getElementById('jsbin_' + this._id);                                           // 536
                                                                                                                      //
          var editors = iframeElement.contentWindow.editors;                                                          // 538
          var jsbin = iframeElement.contentWindow.jsbin;                                                              // 539
          var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");   // 540
          var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");        // 541
                                                                                                                      //
          setEditModeOn(this, iframeElement, widgetElement, menu, bin, jsbin);                                        // 543
                                                                                                                      //
          return false;                                                                                               // 545
        }                                                                                                             // 546
                                                                                                                      //
        return clickWidgetUnlock;                                                                                     // 533
      }(),                                                                                                            // 533
                                                                                                                      //
      // this sets it to DISPLAY mode                                                                                 // 549
      "click .widgetLock": function () {                                                                              // 550
        function clickWidgetLock() {                                                                                  // 550
                                                                                                                      //
          var widgetElement = document.getElementById('widgetContainer_' + this._id);                                 // 552
          var iframeElement = document.getElementById('jsbin_' + this._id);                                           // 553
                                                                                                                      //
          var editors = iframeElement.contentWindow.editors;                                                          // 555
          var jsbin = iframeElement.contentWindow.jsbin;                                                              // 556
          var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");   // 557
          var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");        // 558
          setDisplayModeOn(this, iframeElement, widgetElement, menu, bin, jsbin, this._id, false);                    // 559
                                                                                                                      //
          return false;                                                                                               // 561
        }                                                                                                             // 562
                                                                                                                      //
        return clickWidgetLock;                                                                                       // 550
      }(),                                                                                                            // 550
                                                                                                                      //
      // setting visibility on widgets (public or private)                                                            // 565
      "click .setpublic": function () {                                                                               // 566
        function clickSetpublic() {                                                                                   // 566
          this.visibility = "public";                                                                                 // 567
          Widgets.update(this._id, this);                                                                             // 568
          return false;                                                                                               // 569
        }                                                                                                             // 570
                                                                                                                      //
        return clickSetpublic;                                                                                        // 566
      }(),                                                                                                            // 566
      "click .setprivate": function () {                                                                              // 571
        function clickSetprivate() {                                                                                  // 571
          this.visibility = "private";                                                                                // 572
          Widgets.update(this._id, this);                                                                             // 573
          return false;                                                                                               // 574
        }                                                                                                             // 575
                                                                                                                      //
        return clickSetprivate;                                                                                       // 571
      }(),                                                                                                            // 571
                                                                                                                      //
      "click .order_up": function () {                                                                                // 577
        function clickOrder_up() {                                                                                    // 577
          this.sort_order--;                                                                                          // 578
          Widgets.update(this._id, this);                                                                             // 579
          return false;                                                                                               // 580
        }                                                                                                             // 581
                                                                                                                      //
        return clickOrder_up;                                                                                         // 577
      }(),                                                                                                            // 577
                                                                                                                      //
      "click .order_down": function () {                                                                              // 583
        function clickOrder_down() {                                                                                  // 583
          this.sort_order++;                                                                                          // 584
          Widgets.update(this._id, this);                                                                             // 585
          return false;                                                                                               // 586
        }                                                                                                             // 587
                                                                                                                      //
        return clickOrder_down;                                                                                       // 583
      }(),                                                                                                            // 583
                                                                                                                      //
      "click .nonclickable": function () {                                                                            // 589
        function clickNonclickable() {                                                                                // 589
          return false;                                                                                               // 590
        }                                                                                                             // 591
                                                                                                                      //
        return clickNonclickable;                                                                                     // 589
      }(),                                                                                                            // 589
                                                                                                                      //
      'click .copy': function () {                                                                                    // 594
        function clickCopy() {                                                                                        // 594
          var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                               // 595
          var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                  // 596
          var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                               // 597
          var options = { data: dataobj };                                                                            // 598
                                                                                                                      //
          HTTP.post(url, options, function (error, results) {                                                         // 600
            newWidget = { _id: results.data.url,                                                                      // 601
              createdBy: { username: Meteor.user().username,                                                          // 602
                userid: Meteor.userId() },                                                                            // 603
              isTemplate: false,                                                                                      // 604
              html: results.data.html,                                                                                // 605
              javascript: results.data.javascript,                                                                    // 606
              css: results.data.css,                                                                                  // 607
              displayWidth: template.displayWidth,                                                                    // 608
              displayHeight: template.displayHeight,                                                                  // 609
              description: "(copied from " + template.name + ") " + template.description,                             // 610
              widgetStyle: template.widgetStyle,                                                                      // 611
              name: "copy of " + template.name,                                                                       // 612
              pagetype: pageinfo().pagetype,                                                                          // 613
              pageurl: pageinfo().pageurl,                                                                            // 614
              pageid: pageinfo().pageid,                                                                              // 615
              url: results.data.url,                                                                                  // 616
              createdAt: new Date(),                                                                                  // 617
              visibility: "private",                                                                                  // 618
              rand: Math.random() };                                                                                  // 619
            Widgets.insert(newWidget);                                                                                // 620
          });                                                                                                         // 621
                                                                                                                      //
          giphy_modal("copy", "widget copied");                                                                       // 623
                                                                                                                      //
          return false;                                                                                               // 625
        }                                                                                                             // 626
                                                                                                                      //
        return clickCopy;                                                                                             // 594
      }(),                                                                                                            // 594
                                                                                                                      //
      "click .save_template": function () {                                                                           // 629
        function clickSave_template() {                                                                               // 629
          this.isTemplate = !this.isTemplate;                                                                         // 630
          Widgets.update(this._id, this);                                                                             // 631
          var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                           // 632
          var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                               // 633
                                                                                                                      //
          giphy_modal("promotion", "widget saved as a template");                                                     // 635
                                                                                                                      //
          return false;                                                                                               // 637
        }                                                                                                             // 638
                                                                                                                      //
        return clickSave_template;                                                                                    // 629
      }(),                                                                                                            // 629
                                                                                                                      //
      "click .save_to_library": function () {                                                                         // 640
        function clickSave_to_library() {                                                                             // 640
          this.isTemplate = !this.isTemplate;                                                                         // 641
          //      Widgets.update(this._id, this);                                                                     // 642
                                                                                                                      //
          var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                               // 644
          var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                  // 645
          var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                               // 646
          var options = { data: dataobj };                                                                            // 647
                                                                                                                      //
          var newpagetype = "user_libs";                                                                              // 649
          var newpageid = Meteor.user().username;                                                                     // 650
          var newpageurl = newpagetype + "/" + newpageurl;                                                            // 651
                                                                                                                      //
          HTTP.post(url, options, function (error, results) {                                                         // 653
            newWidget = { _id: results.data.url,                                                                      // 654
              createdBy: { username: Meteor.user().username,                                                          // 655
                userid: Meteor.userId() },                                                                            // 656
              inLibrary: true,                                                                                        // 657
              html: results.data.html,                                                                                // 658
              javascript: results.data.javascript,                                                                    // 659
              css: results.data.css,                                                                                  // 660
              displayWidth: template.displayWidth,                                                                    // 661
              displayHeight: template.displayHeight,                                                                  // 662
              description: "(copied from " + template.name + ") " + template.description,                             // 663
              widgetStyle: template.widgetStyle,                                                                      // 664
              name: "copy of " + template.name,                                                                       // 665
              pagetype: newpagetype,                                                                                  // 666
              pageurl: newpageurl,                                                                                    // 667
              pageid: newpageid,                                                                                      // 668
              this_page_only: true,                                                                                   // 669
              url: results.data.url,                                                                                  // 670
              createdAt: new Date(),                                                                                  // 671
              visibility: "private",                                                                                  // 672
              rand: Math.random() };                                                                                  // 673
            Widgets.insert(newWidget);                                                                                // 674
          });                                                                                                         // 675
                                                                                                                      //
          giphy_modal("library", "widget added to your library");                                                     // 677
                                                                                                                      //
          return false;                                                                                               // 679
        }                                                                                                             // 680
                                                                                                                      //
        return clickSave_to_library;                                                                                  // 640
      }(),                                                                                                            // 640
                                                                                                                      //
      "click .openinfo": function () {                                                                                // 682
        function clickOpeninfo() {                                                                                    // 682
          var thiselement = document.getElementById('widgetContainer_' + this._id);                                   // 683
          var mode = $(thiselement).data("mode");                                                                     // 684
          if (!mode || mode == "display") {                                                                           // 685
            //      $(".widgetMouseOverTarget", thiselement ).css("background", "red");                               // 686
            $(".widgetDisplayHeader", thiselement).show();                                                            // 687
            $(".widgetMouseOverTarget", thiselement).css("z-index", 5);                                               // 688
            $(".widgetDisplayHeader", thiselement).css("z-index", 10);                                                // 689
          }                                                                                                           // 690
        }                                                                                                             // 691
                                                                                                                      //
        return clickOpeninfo;                                                                                         // 682
      }(),                                                                                                            // 682
                                                                                                                      //
      "mouseleave .widgetDisplayHeader": function () {                                                                // 694
        function mouseleaveWidgetDisplayHeader() {                                                                    // 694
          var thiselement = document.getElementById('widgetContainer_' + this._id);                                   // 695
          $(".widgetMouseOverTarget", thiselement).css("background", "transparent");                                  // 696
          $(".widgetDisplayHeader", thiselement).hide();                                                              // 697
          $(".widgetMouseOverTarget", thiselement).css("z-index", 10);                                                // 698
          $(".widgetDisplayHeader", thiselement).css("z-index", 5);                                                   // 699
        }                                                                                                             // 700
                                                                                                                      //
        return mouseleaveWidgetDisplayHeader;                                                                         // 694
      }()                                                                                                             // 694
                                                                                                                      //
    });                                                                                                               // 394
    ////// END EVENTS                                                                                                 // 704
                                                                                                                      //
                                                                                                                      //
    ////// HELPERS                                                                                                    // 707
                                                                                                                      //
    widgetIncrement = 0;                                                                                              // 709
    Template.widget.helpers({                                                                                         // 710
      otherwidgets: function () {                                                                                     // 711
        function otherwidgets() {                                                                                     // 711
          // Otherwise, return all of the tasks                                                                       // 712
          return Widgets.find({ pagetype: pageinfo().pagetype, _id: { $ne: this._id } }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
        }                                                                                                             // 714
                                                                                                                      //
        return otherwidgets;                                                                                          // 711
      }(),                                                                                                            // 711
                                                                                                                      //
      isPublic: function () {                                                                                         // 716
        function isPublic() {                                                                                         // 716
          if (this.visibility == "public") {                                                                          // 717
            return true;                                                                                              // 718
          }                                                                                                           // 719
          return false;                                                                                               // 720
        }                                                                                                             // 721
                                                                                                                      //
        return isPublic;                                                                                              // 716
      }(),                                                                                                            // 716
                                                                                                                      //
      pageTypeAndUrl: function () {                                                                                   // 723
        function pageTypeAndUrl() {                                                                                   // 723
                                                                                                                      //
          return "_pt_" + this.pagetype + "/" + this.url;                                                             // 725
        }                                                                                                             // 726
                                                                                                                      //
        return pageTypeAndUrl;                                                                                        // 723
      }(),                                                                                                            // 723
                                                                                                                      //
      pageUrlAndUrl: function () {                                                                                    // 728
        function pageUrlAndUrl() {                                                                                    // 728
          return "_pu_" + pageinfo().pageurl + "/" + this.url;                                                        // 729
        }                                                                                                             // 730
                                                                                                                      //
        return pageUrlAndUrl;                                                                                         // 728
      }(),                                                                                                            // 728
                                                                                                                      //
      commentsCount: function () {                                                                                    // 732
        function commentsCount(id) {                                                                                  // 732
          var value = "";                                                                                             // 733
          return value;                                                                                               // 734
        }                                                                                                             // 735
                                                                                                                      //
        return commentsCount;                                                                                         // 732
      }(),                                                                                                            // 732
                                                                                                                      //
      isMyWidget: function () {                                                                                       // 737
        function isMyWidget() {                                                                                       // 737
          // is this a widget I created?                                                                              // 738
          if (getUserXtras().godmode) {                                                                               // 739
            return true;                                                                                              // 740
          }                                                                                                           // 741
          if (this.createdBy && Meteor.user()) {                                                                      // 742
            return this.createdBy.username == Meteor.user().username;                                                 // 743
          } else {                                                                                                    // 744
            return false;                                                                                             // 745
          }                                                                                                           // 746
        }                                                                                                             // 747
                                                                                                                      //
        return isMyWidget;                                                                                            // 737
      }(),                                                                                                            // 737
                                                                                                                      //
      widgetIncrement: function (_widgetIncrement) {                                                                  // 749
        function widgetIncrement() {                                                                                  // 749
          return _widgetIncrement.apply(this, arguments);                                                             // 749
        }                                                                                                             // 749
                                                                                                                      //
        widgetIncrement.toString = function () {                                                                      // 749
          return _widgetIncrement.toString();                                                                         // 749
        };                                                                                                            // 749
                                                                                                                      //
        return widgetIncrement;                                                                                       // 749
      }(function () {                                                                                                 // 749
        var ret = widgetIncrement;                                                                                    // 750
        if (typeof this.widgetIncrement == "undefined") {                                                             // 751
          this.widgetIncrement = widgetIncrement;                                                                     // 752
          widgetIncrement++;                                                                                          // 753
        } else {                                                                                                      // 754
          ret = this.widgetIncrement;                                                                                 // 755
        }                                                                                                             // 756
        return ret;                                                                                                   // 757
      }),                                                                                                             // 758
                                                                                                                      //
      userXtras: function () {                                                                                        // 760
        function userXtras() {                                                                                        // 760
          return getUserXtras();                                                                                      // 761
        }                                                                                                             // 762
                                                                                                                      //
        return userXtras;                                                                                             // 760
      }(),                                                                                                            // 760
                                                                                                                      //
      godmode: function () {                                                                                          // 764
        function godmode() {                                                                                          // 764
          return getUserXtras().godmode;                                                                              // 765
        }                                                                                                             // 767
                                                                                                                      //
        return godmode;                                                                                               // 764
      }()                                                                                                             // 764
    });                                                                                                               // 710
                                                                                                                      //
    Template.allWidgetsLoaded.onRendered(function () {                                                                // 772
      console.log("aaaaaall widgets loaded");                                                                         // 773
    });                                                                                                               // 774
    //////// END HELPERS                                                                                              // 775
  })();                                                                                                               // 2
}                                                                                                                     // 776
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{"extensions":[".js",".json"]});
require("./server/smtp.js");
require("./C5.js");
require("./common_functions.js");
require("./widget.js");
//# sourceMappingURL=app.js.map
