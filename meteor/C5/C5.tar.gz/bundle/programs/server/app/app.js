var require = meteorInstall({"server":{"smtp.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/smtp.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     //
Meteor.startup(function () {                                                                                         // 2
                                                                                                                     //
    Accounts.emailTemplates.siteName = "c5.boomhifive.com";                                                          // 4
    Accounts.emailTemplates.from = "C5 Admin <c5@boomhifive.com>";                                                   // 5
    Accounts.emailTemplates.enrollAccount.subject = function (user) {                                                // 6
        return "Welcome to C5, " + user.profile.name;                                                                // 7
    };                                                                                                               // 8
    Accounts.emailTemplates.resetPassword.from = function () {                                                       // 9
        // Overrides value set in Accounts.emailTemplates.from when resetting passwords                              //
        return "C5 Admin <c5@boomhifive.com>";                                                                       // 11
    };                                                                                                               // 12
    Accounts.emailTemplates.resetPassword.text = function (user, url) {                                              // 13
        var text = "Heard you need to reset your password. No biggie, it happens.";                                  // 14
        text += "\n Just open this url to reset your password: " + url;                                              // 15
        return text;                                                                                                 // 16
    };                                                                                                               // 17
                                                                                                                     //
    process.env.MAIL_URL = 'smtp://c5@boomhifive.com:Un1c0rn5@smtp.sendgrid.net:587';                                // 19
});                                                                                                                  // 20
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"C5.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// C5.js                                                                                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     //
Widgets = new Mongo.Collection("widgets");                                                                           // 2
UserXtras = new Mongo.Collection("userxtras");                                                                       // 3
                                                                                                                     //
// set GLOBAL VARS                                                                                                   //
//In the client side                                                                                                 //
SERVER_NAME = "localhost";                                                                                           // 7
SERVER_IP = "localhost";                                                                                             // 8
                                                                                                                     //
if (Meteor.isClient) {                                                                                               // 10
  Meteor.call('getServerName', function (err, results) {                                                             // 11
    SERVER_NAME = results;                                                                                           // 12
  });                                                                                                                // 13
  Meteor.call('getServerIP', function (err, results) {                                                               // 14
    SERVER_IP = results;                                                                                             // 15
  });                                                                                                                // 16
}                                                                                                                    // 17
                                                                                                                     //
if (Meteor.isServer) {                                                                                               // 20
                                                                                                                     //
  Meteor.startup(function () {                                                                                       // 23
    var to = "donundeen@gmail.com";                                                                                  // 24
    var from = "c5@boomhifive.com";                                                                                  // 25
    var subject = "C5 started";                                                                                      // 26
    var text = "notifying you that C5 started";                                                                      // 27
    console.log("sending email");                                                                                    // 28
    Email.send({                                                                                                     // 29
      to: to,                                                                                                        // 30
      from: from,                                                                                                    // 31
      subject: subject,                                                                                              // 32
      text: text                                                                                                     // 33
    });                                                                                                              // 29
  });                                                                                                                // 35
                                                                                                                     //
  Meteor.methods({                                                                                                   // 38
    getServerName: function getServerName() {                                                                        // 39
      SERVER_NAME = process.env.SERVER_NAME;                                                                         // 40
      if (typeof SERVER_NAME === "undefined") {                                                                      // 41
        SERVER_NAME = "localhost";                                                                                   // 42
      }                                                                                                              // 43
      return SERVER_NAME;                                                                                            // 44
    },                                                                                                               // 45
    getServerIP: function getServerIP() {                                                                            // 46
      SERVER_IP = process.env.SERVER_IP;                                                                             // 47
      if (typeof SERVER_IP === "undefined") {                                                                        // 48
        SERVER_IP = "localhost";                                                                                     // 49
      }                                                                                                              // 50
      return SERVER_IP;                                                                                              // 51
    }                                                                                                                // 52
  });                                                                                                                // 38
}                                                                                                                    // 54
                                                                                                                     //
if (Meteor.isClient) {                                                                                               // 56
                                                                                                                     //
  Meteor.startup(function () {                                                                                       // 59
    console.log("starting meteor");                                                                                  // 60
    $(window).bind('beforeunload', function () {                                                                     // 61
      $(".save").trigger("click");                                                                                   // 62
    });                                                                                                              // 63
  });                                                                                                                // 65
                                                                                                                     //
  /// comments config                                                                                                //
  // On the Client                                                                                                   //
  Comments.ui.config({                                                                                               // 72
    template: 'bootstrap' // or ionic, semantic-ui                                                                   // 73
  });                                                                                                                // 72
                                                                                                                     //
  ////// HELPERS                                                                                                     //
  UI.registerHelper('shortIt', function (stringToShorten, maxCharsAmount) {                                          // 77
    if (stringToShorten.length > maxCharsAmount) {                                                                   // 78
      return stringToShorten.substring(0, maxCharsAmount) + '...';                                                   // 79
    }                                                                                                                // 80
    return stringToShorten;                                                                                          // 81
  });                                                                                                                // 82
                                                                                                                     //
  UI.registerHelper('encodeURIComponent', function (string) {                                                        // 84
    return encodeURIComponent(string);                                                                               // 85
  });                                                                                                                // 86
                                                                                                                     //
  UI.registerHelper('absoluteUrl', function () {                                                                     // 88
    return Meteor.absoluteUrl();                                                                                     // 89
  });                                                                                                                // 90
                                                                                                                     //
  Accounts.ui.config({                                                                                               // 92
    passwordSignupFields: "USERNAME_AND_EMAIL"                                                                       // 93
  });                                                                                                                // 92
                                                                                                                     //
  Template.registerHelper("pageid", function () {                                                                    // 96
    return pageinfo().pageid;                                                                                        // 97
  });                                                                                                                // 98
                                                                                                                     //
  Template.registerHelper("pageurl", function () {                                                                   // 100
    return pageinfo().pageurl;                                                                                       // 101
  });                                                                                                                // 102
                                                                                                                     //
  Template.registerHelper("pagetype", function () {                                                                  // 105
    return pageinfo().pagetype;                                                                                      // 106
  });                                                                                                                // 107
                                                                                                                     //
  Template.registerHelper("pageid_neverblank", function () {                                                         // 109
    return "_pi_" + pageinfo().pageid;                                                                               // 110
  });                                                                                                                // 111
                                                                                                                     //
  Template.registerHelper("pageurl_neverblank", function () {                                                        // 113
    return "_pu_" + pageinfo().pageurl;                                                                              // 114
  });                                                                                                                // 115
  Template.registerHelper("pagetype_neverblank", function () {                                                       // 116
    return "_pt_" + pageinfo().pagetype;                                                                             // 117
  });                                                                                                                // 118
                                                                                                                     //
  Template.registerHelper("numComments", function (commentId) {                                                      // 120
                                                                                                                     //
    var instance = Template.instance;                                                                                // 122
                                                                                                                     //
    if (!instance.commentCounters) {                                                                                 // 124
      instance.commentCounters = {};                                                                                 // 125
    }                                                                                                                // 126
    if (!instance.commentCounters[commentId]) {                                                                      // 127
      instance.commentCounters[commentId] = new ReactiveVar();                                                       // 128
    }                                                                                                                // 129
    Comments.getCount(commentId, function (error, count) {                                                           // 130
      instance.commentCounters[commentId].set(count);                                                                // 131
    });                                                                                                              // 132
    return instance.commentCounters[commentId].get();                                                                // 133
  });                                                                                                                // 134
                                                                                                                     //
  Template.registerHelper("commentIcon", function (commentId) {                                                      // 136
                                                                                                                     //
    var instance = Template.instance;                                                                                // 138
                                                                                                                     //
    var noComments = "zmdi-comment";                                                                                 // 140
    var hasComments = "zmdi-comment-alert";                                                                          // 141
                                                                                                                     //
    if (!instance.commentIcons) {                                                                                    // 143
      instance.commentIcons = {};                                                                                    // 144
    }                                                                                                                // 145
    if (!instance.commentIcons[commentId]) {                                                                         // 146
      instance.commentIcons[commentId] = new ReactiveVar();                                                          // 147
    }                                                                                                                // 148
    Comments.getCount(commentId, function (error, count) {                                                           // 149
      if (count > 0) {                                                                                               // 150
        console.log(commentId + " has comments");                                                                    // 151
        instance.commentCounters[commentId].set("zmdi-comment-alert");                                               // 152
      } else {                                                                                                       // 153
        console.log(commentId + " no comments");                                                                     // 154
        instance.commentIcons[commentId].set("zmdi-comment");                                                        // 155
      }                                                                                                              // 156
    });                                                                                                              // 157
    return instance.commentIcons[commentId].get();                                                                   // 158
  });                                                                                                                // 159
                                                                                                                     //
  Template.registerHelper("SERVER_NAME", function () {                                                               // 163
    return SERVER_NAME;                                                                                              // 164
  });                                                                                                                // 165
  Template.registerHelper("SERVER_IP", function () {                                                                 // 166
    return SERVER_IP;                                                                                                // 167
  });                                                                                                                // 168
  Template.body.helpers({                                                                                            // 169
    widgets: function widgets() {                                                                                    // 170
      // Otherwise, return all of the tasks                                                                          //
      var find = {                                                                                                   // 172
        this_page_only: { $in: [false, null] },                                                                      // 173
        pagetype: pageinfo().pagetype,                                                                               // 174
        $or: [{ visibility: "public" }, { $and: [{ visibility: "private" }, { "createdBy.userid": Meteor.userId() }] }, { visibility: null }]
      };                                                                                                             // 172
                                                                                                                     //
      return Widgets.find(find, { sort: { sort_order: 1, createdAt: -1 } }).map(setWidgetDefaults);                  // 185
    },                                                                                                               // 186
    widgetTemplates: function widgetTemplates() {                                                                    // 187
      // Otherwise, return all of the tasks                                                                          //
      return Widgets.find({ isTemplate: true }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);                 // 189
    },                                                                                                               // 190
    libraryWidgets: function libraryWidgets() {                                                                      // 191
      // Otherwise, return all of the tasks                                                                          //
      var find = { inLibrary: true };                                                                                // 193
      find["createdBy.userid"] = Meteor.userId();                                                                    // 194
      return Widgets.find(find, { sort: { createdAt: -1 } }).map(setWidgetDefaults);                                 // 195
    },                                                                                                               // 196
    thisPageWidgets: function thisPageWidgets() {                                                                    // 197
      // Otherwise, return all of the tasks                                                                          //
      var find = { this_page_only: true,                                                                             // 199
        pagetype: pageinfo().pagetype,                                                                               // 200
        pageid: pageinfo().pageid };                                                                                 // 201
      return Widgets.find(find, { sort: { sort_order: 1, createdAt: -1 } }).map(setWidgetDefaults);                  // 202
    },                                                                                                               // 203
                                                                                                                     //
    userXtras: function userXtras() {                                                                                // 205
      return getUserXtras();                                                                                         // 206
    },                                                                                                               // 207
                                                                                                                     //
    godmode: function godmode() {                                                                                    // 209
      return getUserXtras().godmode;                                                                                 // 210
    }                                                                                                                // 212
                                                                                                                     //
  });                                                                                                                // 169
  ////// END HELPERS                                                                                                 //
                                                                                                                     //
  ////// TEMPLATE ONRENDERED                                                                                         //
  Template.body.onRendered(function () {                                                                             // 219
    //$(".tooltip-right").tooltip({placement: "right"});                                                             //
    //  $("[title]").tooltip({placement: "auto"});                                                                   //
  });                                                                                                                // 222
  ////// END ONRENDERED                                                                                              //
                                                                                                                     //
  /////// EVENTS                                                                                                     //
  Template.body.events({                                                                                             // 228
                                                                                                                     //
    "click .lockall": function clickLockall() {                                                                      // 231
      $(".lock").trigger("click");                                                                                   // 232
      $(".lockall").hide();                                                                                          // 233
      $(".unlockall").show();                                                                                        // 234
      giphy_modal("unlock", "Unlocking all widgets you have access to");                                             // 235
      return false;                                                                                                  // 236
    },                                                                                                               // 238
    "click .unlockall": function clickUnlockall() {                                                                  // 239
      $(".unlock").trigger("click");                                                                                 // 240
      $(".lockall").show();                                                                                          // 241
      $(".unlockall").hide();                                                                                        // 242
      giphy_modal("lock", "Locking all Widgets");                                                                    // 243
      return false;                                                                                                  // 244
    },                                                                                                               // 245
                                                                                                                     //
    "click .giphy": function clickGiphy(e, t) {                                                                      // 247
      $(e.target).hide();                                                                                            // 248
    },                                                                                                               // 249
                                                                                                                     //
    "click .godmode_check": function clickGodmode_check(e, t) {                                                      // 251
      console.log("clicked");                                                                                        // 252
      console.log(e.target.checked);                                                                                 // 253
      //      console.log(t);                                                                                        //
      console.log("updating  " + Meteor.userId() + " to " + e.target.checked);                                       // 255
      UserXtras.update({ _id: Meteor.userId() }, { $set: { godmode: e.target.checked } });                           // 256
    },                                                                                                               // 258
                                                                                                                     //
    'click .copy_from_template': function clickCopy_from_template() {                                                // 260
      copyWidgetToPage($(this).attr("target"), pageinfo().pagetype, pageinfo().pageurl, pageinfo().pageid);          // 261
      giphy_modal("copy", "New Widget Copied From Template");                                                        // 262
      return false;                                                                                                  // 263
    },                                                                                                               // 264
                                                                                                                     //
    'click .deletetemplate': function clickDeletetemplate() {                                                        // 266
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                                  // 267
      template.isTemplate = false;                                                                                   // 268
      Widgets.update(template._id, template);                                                                        // 269
    },                                                                                                               // 270
                                                                                                                     //
    'click .addwidget': function clickAddwidget() {                                                                  // 272
      //add jsbin widget                                                                                             //
                                                                                                                     //
      var htmlstring = '<html>\n ' + '<head>\n ' + '<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>\n ' + '<script src="/c5libs/locallib.js"></script>\n ' + '   <script type="application/json" class="c5_data">{"data" : "data placed here gets passed along"}</script>\n ' + '</head>\n ' + '<body>\n ' + '  <div class="c5_html">\n ' + '  html placed here gets passed along\n ' + '  </div>\n ' + '</body>\n ' + '</html>\n';
      var csstring = "";                                                                                             // 287
      var jsstring = "function doTheThings(data){\n" + "// everything you want to do should happen inside this function\n " + "// the data var will be populated with whatever you've requested from other widgets\n" + "// and this function will be call when all those widgets have complete \n" + "   c5_done(); // this message is required at the end of all the processing, so the system knows this widget is done \n " + "} \n" + "requireWidgetData( \n" + "// all requests to other widgets go here (automatically if you use the 'pull from' interface): \n" + "// c5_requires \n" + "{} \n" + "// end_c5_requires \n" + "// end other widget requests \n" + ", doTheThings)";
      var dataobj = { html: htmlstring, css: csstring, javascript: jsstring };                                       // 301
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                                  // 302
      var options = { data: dataobj };                                                                               // 303
      HTTP.post(url, options, function (error, results) {                                                            // 304
        newWidget = { _id: results.data.url,                                                                         // 305
          createdBy: { username: Meteor.user().username,                                                             // 306
            userid: Meteor.userId() },                                                                               // 307
          isTemplate: false,                                                                                         // 308
          name: results.data.url,                                                                                    // 309
          description: "",                                                                                           // 310
          html: results.data.html,                                                                                   // 311
          javascript: results.data.javascript,                                                                       // 312
          css: results.data.css,                                                                                     // 313
          displayWidth: "",                                                                                          // 314
          displayHeight: "",                                                                                         // 315
          widgetStyle: "",                                                                                           // 316
          pagetype: pageinfo().pagetype,                                                                             // 317
          pageurl: pageinfo().pageurl,                                                                               // 318
          pageid: pageinfo().pageid,                                                                                 // 319
          url: results.data.url,                                                                                     // 320
          visibility: "private",                                                                                     // 321
          createdAt: new Date(),                                                                                     // 322
          rand: Math.random() };                                                                                     // 323
        Widgets.insert(newWidget);                                                                                   // 324
      });                                                                                                            // 325
      return false;                                                                                                  // 326
    },                                                                                                               // 327
                                                                                                                     //
    'click .test': function clickTest() {                                                                            // 329
      return false;                                                                                                  // 330
    }                                                                                                                // 331
  });                                                                                                                // 228
                                                                                                                     //
  ///// END EVENTS                                                                                                   //
}                                                                                                                    // 338
                                                                                                                     //
if (Meteor.isServer) {                                                                                               // 340
  Meteor.startup(function () {                                                                                       // 341
    // code to run on server at startup                                                                              //
  });                                                                                                                // 343
}                                                                                                                    // 344
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"common_functions.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// common_functions.js                                                                                               //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
pageinfo = setWidgetDefaults = giphy_modal = getUserXtras = null;                                                    // 1
                                                                                                                     //
if (Meteor.isClient) {                                                                                               // 3
                                                                                                                     //
  getUserXtras = function getUserXtras() {                                                                           // 5
    var userxtras = false;                                                                                           // 6
    var user = Meteor.user();                                                                                        // 7
    if (user) {                                                                                                      // 8
      /*                                                                                                             //
      console.log(user.username);                                                                                    //
      console.log(user._id);                                                                                         //
      console.log("getting for " + user._id);                                                                        //
      */                                                                                                             //
      userxtras = UserXtras.findOne({ _id: user._id });                                                              // 14
      if (!userxtras || !userxtras.foo) {                                                                            // 15
        console.log("userxtras " + userxtras);                                                                       // 16
        userxtras = { _id: user._id, admin: false, godmode: false, foo: "var" };                                     // 17
        if (user.username == "donundeen") {                                                                          // 18
          userxtras.admin = true;                                                                                    // 19
        }                                                                                                            // 20
        console.log("saving for " + user._id);                                                                       // 21
        UserXtras.upsert({ _id: user._id }, userxtras);                                                              // 22
        var userxtras2 = UserXtras.findOne({ _id: user._id });                                                       // 23
      }                                                                                                              // 24
    }                                                                                                                // 25
    return userxtras;                                                                                                // 26
  };                                                                                                                 // 28
                                                                                                                     //
  giphy_modal = function giphy_modal(term, text) {                                                                   // 32
    $("#giphy_modal").modal('show');                                                                                 // 33
    $(".giphy_modal_header").text(text);                                                                             // 34
    var url = "/giphy_proxy/" + encodeURIComponent(term);                                                            // 35
    $(".giphy_modal_image_div").empty();                                                                             // 36
    var imgurl = url + "?" + new Date().getTime();                                                                   // 37
    $(".giphy_modal_image_div").html("<img src='" + imgurl + "' width='200' class='giphy_modal_image_img'/>");       // 38
                                                                                                                     //
    setTimeout(function () {                                                                                         // 40
      $("#giphy_modal").modal('hide');                                                                               // 41
    }, 2000);                                                                                                        // 42
  };                                                                                                                 // 44
                                                                                                                     //
  pageinfo = function pageinfo() {                                                                                   // 46
    var pagetype = "";                                                                                               // 47
    var pageid = "";                                                                                                 // 48
    var pathname = window.location.pathname;                                                                         // 49
    var split = pathname.split("/");                                                                                 // 50
    split.shift();                                                                                                   // 51
    var pageurl = split.join("/");                                                                                   // 52
                                                                                                                     //
    if (split.length > 0) {                                                                                          // 54
      pagetype = split.shift();                                                                                      // 55
    }                                                                                                                // 56
    if (split.length > 0) {                                                                                          // 57
      pageid = split.shift();                                                                                        // 58
    }                                                                                                                // 59
    pageid = pageid.replace(/:script/, "");                                                                          // 60
    return { pageurl: pageurl,                                                                                       // 61
      pagetype: pagetype,                                                                                            // 62
      pageid: pageid };                                                                                              // 63
  };                                                                                                                 // 65
                                                                                                                     //
  copyWidgetToPage = function copyWidgetToPage(origID, pagetype, pageid, pageurl) {                                  // 68
    console.log("calling CopyWidgetToPage for " + origID);                                                           // 69
    var template = Widgets.findOne({ url: origID }); //.map(setWidgetDefaults);                                      // 70
    var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                       // 71
    var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                                    // 72
    var options = { data: dataobj };                                                                                 // 73
                                                                                                                     //
    HTTP.post(url, options, function (error, results) {                                                              // 75
      newWidget = { _id: results.data.url,                                                                           // 76
        createdBy: { username: Meteor.user().username,                                                               // 77
          userid: Meteor.userId() },                                                                                 // 78
        isTemplate: false,                                                                                           // 79
        html: results.data.html,                                                                                     // 80
        javascript: results.data.javascript,                                                                         // 81
        css: results.data.css,                                                                                       // 82
        displayWidth: results.data.displayWidth,                                                                     // 83
        displayHeight: results.data.displayHeight,                                                                   // 84
        description: "(copied from " + template.name + ") " + template.description,                                  // 85
        widgetStyle: results.data.widgetStyle,                                                                       // 86
        name: "copy of " + template.name,                                                                            // 87
        pagetype: pagetype,                                                                                          // 88
        pageurl: pageurl,                                                                                            // 89
        pageid: pageid,                                                                                              // 90
        url: results.data.url,                                                                                       // 91
        createdAt: new Date(),                                                                                       // 92
        visibility: "private",                                                                                       // 93
        rand: Math.random() };                                                                                       // 94
      Widgets.insert(newWidget);                                                                                     // 95
    });                                                                                                              // 96
    giphy_modal("copy", "New Widget Copied From Template");                                                          // 97
  };                                                                                                                 // 99
                                                                                                                     //
  setWidgetDefaults = function setWidgetDefaults(doc) {                                                              // 102
    if (typeof doc.displayWidth === "undefined" || !doc.displayWidth || doc.displayWidth.trim() == "" || doc.displayWidth == "width" || doc.displayWidth == "default") {
      doc.displayWidth = "320px";                                                                                    // 104
      doc.displayUsableWidth = "320px";                                                                              // 105
    } else {                                                                                                         // 106
      doc.displayUsableWidth = doc.displayWidth;                                                                     // 107
    }                                                                                                                // 108
    if (typeof doc.displayHeight === "undefined" || !doc.displayHeight || doc.displayHeight.trim() == "" || doc.displayHeight == "height" || doc.displayHeight == "default") {
      doc.displayHeight = "400px";                                                                                   // 110
      doc.displayUsableHeight = "400px";                                                                             // 111
    } else {                                                                                                         // 112
      doc.displayUsableHeight = doc.displayHeight;                                                                   // 113
    }                                                                                                                // 114
    if (typeof doc.widgetStyle === "undefined" || !doc.widgetStyle || doc.widgetStyle.trim() == "" || doc.widgetStyle == "css" || doc.widgetStyle == "default") {
      doc.widgetStyle = "default";                                                                                   // 116
      doc.usableWidgetStyle = "";                                                                                    // 117
    } else {                                                                                                         // 118
      doc.usableWidgetStyle = doc.widgetStyle;                                                                       // 119
    }                                                                                                                // 120
    if (!doc.createdBy) {                                                                                            // 121
      doc.createdBy = {};                                                                                            // 122
    }                                                                                                                // 123
                                                                                                                     //
    if (doc.displayUsableHeight.match(/px/)) {                                                                       // 125
      var height = doc.displayUsableHeight.replace(/px/, "");                                                        // 126
      doc.jsbinHeight = height - 20;                                                                                 // 127
      doc.jsbinHeight += "px";                                                                                       // 128
    } else {                                                                                                         // 129
      doc.jsbinHeight = "";                                                                                          // 130
    }                                                                                                                // 131
                                                                                                                     //
    if (!doc.this_page_only) {                                                                                       // 133
      doc.this_page_only = false;                                                                                    // 134
    }                                                                                                                // 135
                                                                                                                     //
    if (!doc.sort_order) {                                                                                           // 137
      doc.sort_order = 0;                                                                                            // 138
    }                                                                                                                // 139
                                                                                                                     //
    if (!doc.visibility) {                                                                                           // 141
      doc.visibility = "public";                                                                                     // 142
    }                                                                                                                // 143
                                                                                                                     //
    if (!doc.cacheConfig) {                                                                                          // 145
      doc.cacheConfig = {};                                                                                          // 146
    }                                                                                                                // 147
                                                                                                                     //
    if (!doc.cacheConfig.ttl) {                                                                                      // 149
      doc.cacheConfig.ttl = 60;                                                                                      // 150
    }                                                                                                                // 151
                                                                                                                     //
    return doc;                                                                                                      // 154
  };                                                                                                                 // 155
}                                                                                                                    // 156
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"widget.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// widget.js                                                                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
                                                                                                                     //
if (Meteor.isClient) {                                                                                               // 2
  var dix;                                                                                                           // 2
                                                                                                                     //
  (function () {                                                                                                     // 2
    var setDisplayModeOn = function setDisplayModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin, widgetid) {
                                                                                                                     //
      console.log("setting display mode on");                                                                        // 8
      dix++;                                                                                                         // 9
      var di = dix;                                                                                                  // 10
      var newbintop = 0;                                                                                             // 11
      $(menu).hide();                                                                                                // 12
                                                                                                                     //
      if (!widgetData.displayUsableWidth || widgetData.displayUsableWidth.trim() == "") {                            // 14
        widgetData.displayUsableWidth = "50%";                                                                       // 15
      }                                                                                                              // 16
                                                                                                                     //
      $(".editmodeonly", widgetElement).hide();                                                                      // 18
      $(".displaymodeonly", widgetElement).show();                                                                   // 19
      iframeElement.oldbintop = $(bin).css("top");                                                                   // 20
      $(bin).css("top", newbintop);                                                                                  // 21
      $(widgetElement).attr("style", widgetData.usableWidgetStyle);                                                  // 22
      $(widgetElement).width(widgetData.displayUsableWidth);                                                         // 23
      $(widgetElement).height(widgetData.displayUsableHeight);                                                       // 24
      $(widgetElement).css("border-radius", "10px");                                                                 // 25
      $(".widgetDisplayHeader", widgetElement).hide();                                                               // 26
                                                                                                                     //
      if (jsbin && jsbin.panels) {                                                                                   // 28
        jsbin.panels.hide("html");                                                                                   // 29
        jsbin.panels.hide("javascript");                                                                             // 30
        jsbin.panels.hide("css");                                                                                    // 31
        jsbin.panels.hide("console");                                                                                // 32
      }                                                                                                              // 33
      $(".lock", widgetElement).show();                                                                              // 34
      $(".unlock", widgetElement).hide();                                                                            // 35
      $(widgetElement).data("mode", "display");                                                                      // 36
                                                                                                                     //
      console.log("setting display mode");                                                                           // 38
                                                                                                                     //
      $(iframeElement).css("max-height", "");                                                                        // 40
      $(iframeElement).css("max-width", "");                                                                         // 41
      $(iframeElement).width($(widgetElement).width());                                                              // 42
      $(iframeElement).height($(widgetElement).height() - 10);                                                       // 43
      $(iframeElement).css("border-radius", "10px");                                                                 // 44
      $(iframeElement).css("max-height", $(widgetElement).height() - 10);                                            // 45
                                                                                                                     //
      (function (wn, wd, ifr) {                                                                                      // 47
        $(wn).resize(function () {                                                                                   // 48
          console.log("display mode resizing");                                                                      // 49
          $(ifr).width($(wd).width());                                                                               // 50
          $(ifr).height($(wd).height() - 10);                                                                        // 51
        });                                                                                                          // 52
      })(window, widgetElement, iframeElement);                                                                      // 53
                                                                                                                     //
      console.log($(widgetElement).width() + ", " + $(widgetElement).height());                                      // 55
      console.log($(iframeElement).width() + ", " + $(iframeElement).height());                                      // 56
    };                                                                                                               // 58
                                                                                                                     //
    var setEditModeOn = function setEditModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin) {         // 2
                                                                                                                     //
      if (jsbin) {                                                                                                   // 63
        jsbin.panels.show("html");                                                                                   // 64
        jsbin.panels.show("javascript");                                                                             // 65
      }                                                                                                              // 66
      $(".lock", widgetElement).hide();                                                                              // 67
      $(".unlock", widgetElement).show();                                                                            // 68
      //      editors.panels.show("css");                                                                            //
                                                                                                                     //
      var newbintop = 0;                                                                                             // 71
                                                                                                                     //
      // put it in EDIT MODE                                                                                         //
      $(menu).show();                                                                                                // 74
      $(".editmodeonly", widgetElement).show();                                                                      // 75
      $(".displaymodeonly", widgetElement).hide();                                                                   // 76
      $(bin).css("top", iframeElement.oldbintop);                                                                    // 77
      $(widgetElement).width($(window).width());                                                                     // 78
      $(widgetElement).height($(window).height());                                                                   // 79
      $(widgetElement).css("border-radius", "10px");                                                                 // 80
                                                                                                                     //
      console.log("setting edit mode");                                                                              // 82
                                                                                                                     //
      $(iframeElement).css("max-height", "");                                                                        // 84
      $(iframeElement).width($(widgetElement).width());                                                              // 85
      $(iframeElement).height($(widgetElement).height() - 80);                                                       // 86
      $(iframeElement).css("border-radius", "10px");                                                                 // 87
                                                                                                                     //
      (function (wn, wd, ifr) {                                                                                      // 89
        $(wn).resize(function () {                                                                                   // 90
          console.log("edit mode resizing");                                                                         // 91
                                                                                                                     //
          $(ifr).width($(wd).width());                                                                               // 93
          $(ifr).height($(wd).height());                                                                             // 94
        });                                                                                                          // 95
      })(window, widgetElement, iframeElement);                                                                      // 96
    };                                                                                                               // 99
    /////// END FUNCTION DEFS                                                                                        //
                                                                                                                     //
    /////// WIDGET ONRENDERED                                                                                        //
    // In the client code, below everything else                                                                     //
                                                                                                                     //
                                                                                                                     //
    /////////// END WIDGET ONRENDERED                                                                                //
                                                                                                                     //
    //////////// EVENTS                                                                                              //
                                                                                                                     //
    var insert_code = function insert_code(jsbin_id, codeString, codeStringRe, comments) {                           // 2
                                                                                                                     //
      var editors = document.getElementById(jsbin_id).contentWindow.editors;                                         // 174
                                                                                                                     //
      if (!editors) {                                                                                                // 176
        return true;                                                                                                 // 177
      }                                                                                                              // 178
      var code = editors.javascript.getCode();                                                                       // 179
      var line = editors.javascript.editor.getCursor().line;                                                         // 180
      var charpos = editors.javascript.editor.getCursor().ch;                                                        // 181
      // make sure it's not already in there:                                                                        //
      var codeRe = new RegExp("\/\/ *c[45]_requires[\\s\\S]*\\[[\\s\\S]*" + codeStringRe + "[\\s\\S]*\\] *,[\\s\\S]*\/\/ *end_c[45]_requires");
      var codeMatch = code.match(codeRe);                                                                            // 184
      if (!codeMatch) {                                                                                              // 185
        // match to empty array                                                                                      //
        var match = /(\/\/ *c[45]_requires[\s\S]*\[)\s*(\] *,[\s\S]*\/\/ *end_c[45]_requires)/;                      // 187
        var results = code.match(match);                                                                             // 188
        newcode = code.replace(match, "$1\n" + codeString + " // " + comments + "\n$2");                             // 189
                                                                                                                     //
        if (newcode == code) {                                                                                       // 191
          // match to non-empty array                                                                                //
          var match = /(\/\/ *c[45]_requires[\s\S]*\[)([^\]]*\] *,[\s\S]*\/\/ *end_c[45]_requires)/;                 // 193
          var results = code.match(match);                                                                           // 194
          newcode = code.replace(match, "$1\n" + codeString + ", // " + comments + "$2");                            // 195
        }                                                                                                            // 196
        code = newcode;                                                                                              // 197
        var state = { line: editors.javascript.editor.currentLine(),                                                 // 198
          character: editors.javascript.editor.getCursor().ch,                                                       // 199
          add: 0                                                                                                     // 200
        };                                                                                                           // 198
                                                                                                                     //
        editors.javascript.setCode(code);                                                                            // 203
        editors.javascript.editor.setCursor({ line: state.line + state.add, ch: state.character });                  // 204
      }                                                                                                              // 205
    };                                                                                                               // 206
                                                                                                                     //
    /////// FUNCTION DEFS                                                                                            //
    dix = 0;                                                                                                         // 5
    Template.widget.onRendered(function () {                                                                         // 106
                                                                                                                     //
      (function (widget) {                                                                                           // 108
        var thisid = widget.data._id;                                                                                // 109
        var element = document.getElementById('jsbin_' + thisid);                                                    // 110
        var thiselement = document.getElementById('widgetContainer_' + thisid);                                      // 111
        $(".widgetDisplayHeader", thiselement).hide();                                                               // 112
                                                                                                                     //
        // maybe already exists?                                                                                     //
        var theElement = document.getElementById('jsbin_' + thisid);                                                 // 115
        if (theElement && theElement.contentWindow && theElement.contentWindow.document) {                           // 116
          $(theElement).load(function () {                                                                           // 117
            var widgetElement = document.getElementById('widgetContainer_' + thisid);                                // 118
            var editors = jsbin = menu = bin = null;                                                                 // 119
            if (theElement) {                                                                                        // 120
              editors = theElement.contentWindow.editors;                                                            // 121
              jsbin = theElement.contentWindow.jsbin;                                                                // 122
              menu = theElement.contentWindow.document.getElementById("control");                                    // 123
              bin = theElement.contentWindow.document.getElementById("bin");                                         // 124
              var thiselement = document.getElementById('widgetContainer_' + thisid);                                // 125
              if (jsbin && jsbin.panels) {                                                                           // 126
                jsbin.panels.saveOnExit = true;                                                                      // 127
              }                                                                                                      // 128
              setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, thisid);                          // 129
            } else {                                                                                                 // 130
              console.log("no element found for jsbin_" + thisid);                                                   // 131
            }                                                                                                        // 132
          });                                                                                                        // 133
        }                                                                                                            // 134
        // this part here happens when the JSBIN stuff is loaded.                                                    //
        (function (this_id) {                                                                                        // 136
          document.addEventListener("DOMNodeInserted", function (evt, item) {                                        // 137
            (function (_evt, _this_id) {                                                                             // 138
              if ($(_evt.target)[0].tagName == "IFRAME" && $(_evt.target)[0].id.replace("jsbin_", "") == _this_id) {
                $(_evt.target).load(function () {                                                                    // 140
                  var widgetElement = document.getElementById('widgetContainer_' + _this_id);                        // 141
                  var editors = jsbin = menu = bin = null;                                                           // 142
                  var theElement = document.getElementById('jsbin_' + _this_id);                                     // 143
                  if (theElement) {                                                                                  // 144
                    editors = theElement.contentWindow.editors;                                                      // 145
                    console.log(editors.live.el);                                                                    // 146
                    jsbin = theElement.contentWindow.jsbin;                                                          // 147
                    console.log(jsbin);                                                                              // 148
                    menu = theElement.contentWindow.document.getElementById("control");                              // 149
                    bin = theElement.contentWindow.document.getElementById("bin");                                   // 150
                    console.log(bin);                                                                                // 151
                  } else {                                                                                           // 152
                    console.log("no element found for jsbin_" + _this_id);                                           // 153
                  }                                                                                                  // 154
                  if (jsbin && jsbin.panels) {                                                                       // 155
                    jsbin.panels.saveOnExit = true;                                                                  // 156
                  }                                                                                                  // 157
                  setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, _this_id);                    // 158
                });                                                                                                  // 159
              }                                                                                                      // 160
            })(evt, this_id);                                                                                        // 161
          });                                                                                                        // 162
        })(thisid);                                                                                                  // 163
      })(this);                                                                                                      // 164
    });                                                                                                              // 165
                                                                                                                     //
    Template.help.events({                                                                                           // 209
      "click .giphy": function clickGiphy(e, t) {                                                                    // 210
        $(e.target).hide();                                                                                          // 211
      }                                                                                                              // 212
    });                                                                                                              // 209
                                                                                                                     //
    Template.widget.events({                                                                                         // 215
                                                                                                                     //
      "click .giphy": function clickGiphy(e, t) {                                                                    // 217
        $(e.target).hide();                                                                                          // 218
      },                                                                                                             // 219
                                                                                                                     //
      "click .delete": function clickDelete() {                                                                      // 221
        if (this.isTemplate) {                                                                                       // 222
          this.pagetype = "template";                                                                                // 223
          Widgets.update(this._id, this);                                                                            // 224
        } else {                                                                                                     // 225
          Widgets.remove(this._id);                                                                                  // 226
        }                                                                                                            // 227
        giphy_modal("erase", "Widget Deleted");                                                                      // 228
        return false;                                                                                                // 229
      },                                                                                                             // 230
                                                                                                                     //
      "click .save": function clickSave() {                                                                          // 232
        var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                            // 233
        var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                                // 234
        var revision = jsbin.state.revision;                                                                         // 235
                                                                                                                     //
        this.html = editors.html.getCode();                                                                          // 237
        this.javascript = editors.javascript.getCode();                                                              // 238
        this.css = editors.css.getCode();                                                                            // 239
        jsbin.saveDisabled = false;                                                                                  // 240
        jsbin.panels.save();                                                                                         // 241
        jsbin.panels.savecontent();                                                                                  // 242
        Widgets.update(this._id, this);                                                                              // 243
                                                                                                                     //
        // also trigger the jsbin save                                                                               //
        var dataobj = { html: this.html, css: this.css, javascript: this.javascript };                               // 246
        var url = "/api/" + this.url + "/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,               // 247
        var options = { data: dataobj };                                                                             // 248
        HTTP.post(url, options, function (error, results) {});                                                       // 249
                                                                                                                     //
        giphy_modal("saved", "Widget Content Saved");                                                                // 252
                                                                                                                     //
        return false;                                                                                                // 254
      },                                                                                                             // 255
                                                                                                                     //
      "click .call_webservice_url": function clickCall_webservice_url(evt, template) {                               // 258
        $("#webservice_insert_modal").modal('show');                                                                 // 259
                                                                                                                     //
        $("#webservice_insert_modal_submit").click(function () {                                                     // 261
          var jsbin_id = 'jsbin_' + template.data.url;                                                               // 262
                                                                                                                     //
          var url = $("#webservice_insert_url").val().trim();                                                        // 265
          var name = $("#webservice_insert_name").val().trim();                                                      // 266
          var auth_token = $("#webservice_insert_auth_token").val().trim();                                          // 267
          var return_type = $("input[name=webservice_insert_return_type]:checked").val().trim();                     // 268
                                                                                                                     //
          url = url.replace("||PAGEID||", "'+pageId()+'");                                                           // 270
          url = url.replace("||PAGETYPE||", "'+pageType()+'");                                                       // 271
                                                                                                                     //
          var token_string;                                                                                          // 273
          if (auth_token) {                                                                                          // 274
            token_string = " \n authentication_token : '" + auth_token + "',";                                       // 275
          }                                                                                                          // 276
                                                                                                                     //
          var codeString = "{\n id:'" + name + "', \n type: 'webservice', " + token_string + " \n return_type: '" + return_type + "', \n url: '" + url + "' \n}";
          var codeStringRe = "\\{\n id:'" + name + "', \n type: 'webservice', \n return_type: '" + return_type + "', \n url: '" + url + "' \n\\}";
          var comments = " this will hold a " + return_type + " object";                                             // 280
                                                                                                                     //
          insert_code(jsbin_id, codeString, codeStringRe, comments);                                                 // 282
        });                                                                                                          // 284
      },                                                                                                             // 287
                                                                                                                     //
      "click .add_code": function clickAdd_code(evt, template) {                                                     // 289
                                                                                                                     //
        var pullfrom = evt.currentTarget.dataset.pullfrom;                                                           // 291
        var pulltype = evt.currentTarget.dataset.pulltype;                                                           // 292
                                                                                                                     //
        if (this.url == template.data.url) {                                                                         // 294
          return false;                                                                                              // 295
        }                                                                                                            // 296
                                                                                                                     //
        var type;                                                                                                    // 298
        var comments = "";                                                                                           // 299
        if (pulltype == "data") {                                                                                    // 300
          type = "data";                                                                                             // 301
          comments = " This will hold a JSON object";                                                                // 302
        }                                                                                                            // 303
        if (pulltype == "html") {                                                                                    // 304
          type = "html";                                                                                             // 305
          comments = " This will hold a jQuery object";                                                              // 306
        }                                                                                                            // 307
        var codeString = "{from: '" + pullfrom + "', type : '" + pulltype + "'}";                                    // 308
        var codeStringRe = "\\{from: '" + pullfrom + "', type : '" + pulltype + "'\\}";                              // 309
                                                                                                                     //
        var jsbin_id = 'jsbin_' + template.data.url;                                                                 // 311
                                                                                                                     //
        insert_code(jsbin_id, codeString, codeStringRe, comments);                                                   // 313
                                                                                                                     //
        return true;                                                                                                 // 315
      },                                                                                                             // 316
                                                                                                                     //
      "click .test": function clickTest() {                                                                          // 320
        var thiselement = document.getElementById('widgetContainer_' + this._id);                                    // 321
        var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                            // 322
        var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                                // 323
        var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");    // 324
        var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");         // 325
                                                                                                                     //
        var newbintop = 0;                                                                                           // 327
        this.maxed = !this.maxed;                                                                                    // 328
        if (this.maxed) {                                                                                            // 329
          $(menu).hide();                                                                                            // 330
          $(".editmodeonly", thiselement).hide();                                                                    // 331
          this.oldbintop = $(bin).css("top");                                                                        // 332
          $(bin).css("top", newbintop);                                                                              // 333
        } else {                                                                                                     // 334
          $(menu).show();                                                                                            // 335
          $(".editmodeonly", thiselement).show();                                                                    // 336
          $(bin).css("top", this.oldbintop);                                                                         // 337
        }                                                                                                            // 338
        return false;                                                                                                // 339
      },                                                                                                             // 340
      /*                                                                                                             //
      panel ids: html, css, javascript, console, live                                                                //
      */                                                                                                             //
                                                                                                                     //
      // this sets it to EDIT mode                                                                                   //
      "click .widgetUnlock": function clickWidgetUnlock() {                                                          // 346
                                                                                                                     //
        var widgetElement = document.getElementById('widgetContainer_' + this._id);                                  // 348
        var iframeElement = document.getElementById('jsbin_' + this._id);                                            // 349
                                                                                                                     //
        var editors = iframeElement.contentWindow.editors;                                                           // 351
        var jsbin = iframeElement.contentWindow.jsbin;                                                               // 352
        var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");    // 353
        var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");         // 354
                                                                                                                     //
        setEditModeOn(this, iframeElement, widgetElement, menu, bin, jsbin);                                         // 356
                                                                                                                     //
        return false;                                                                                                // 358
      },                                                                                                             // 359
                                                                                                                     //
      // this sets it to DISPLAY mode                                                                                //
      "click .widgetLock": function clickWidgetLock() {                                                              // 363
                                                                                                                     //
        var widgetElement = document.getElementById('widgetContainer_' + this._id);                                  // 365
        var iframeElement = document.getElementById('jsbin_' + this._id);                                            // 366
                                                                                                                     //
        var editors = iframeElement.contentWindow.editors;                                                           // 368
        var jsbin = iframeElement.contentWindow.jsbin;                                                               // 369
        var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");    // 370
        var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");         // 371
        setDisplayModeOn(this, iframeElement, widgetElement, menu, bin, jsbin, this._id);                            // 372
                                                                                                                     //
        return false;                                                                                                // 374
      },                                                                                                             // 375
                                                                                                                     //
      // setting visibility on widgets (public or private)                                                           //
      "click .setpublic": function clickSetpublic() {                                                                // 379
        console.log("setpublic");                                                                                    // 380
        this.visibility = "public";                                                                                  // 381
        Widgets.update(this._id, this);                                                                              // 382
        return false;                                                                                                // 383
      },                                                                                                             // 384
      "click .setprivate": function clickSetprivate() {                                                              // 385
        console.log("setprivate");                                                                                   // 386
        this.visibility = "private";                                                                                 // 387
        Widgets.update(this._id, this);                                                                              // 388
        return false;                                                                                                // 389
      },                                                                                                             // 390
                                                                                                                     //
      "click .order_up": function clickOrder_up() {                                                                  // 392
        this.sort_order--;                                                                                           // 393
        Widgets.update(this._id, this);                                                                              // 394
        return false;                                                                                                // 395
      },                                                                                                             // 396
                                                                                                                     //
      "click .order_down": function clickOrder_down() {                                                              // 398
        this.sort_order++;                                                                                           // 399
        Widgets.update(this._id, this);                                                                              // 400
        return false;                                                                                                // 401
      },                                                                                                             // 402
                                                                                                                     //
      "click .nonclickable": function clickNonclickable() {                                                          // 404
        return false;                                                                                                // 405
      },                                                                                                             // 406
                                                                                                                     //
      'click .copy': function clickCopy() {                                                                          // 409
        var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                                // 410
        var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                   // 411
        var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                                // 412
        var options = { data: dataobj };                                                                             // 413
                                                                                                                     //
        HTTP.post(url, options, function (error, results) {                                                          // 415
          newWidget = { _id: results.data.url,                                                                       // 416
            createdBy: { username: Meteor.user().username,                                                           // 417
              userid: Meteor.userId() },                                                                             // 418
            isTemplate: false,                                                                                       // 419
            html: results.data.html,                                                                                 // 420
            javascript: results.data.javascript,                                                                     // 421
            css: results.data.css,                                                                                   // 422
            displayWidth: template.displayWidth,                                                                     // 423
            displayHeight: template.displayHeight,                                                                   // 424
            description: "(copied from " + template.name + ") " + template.description,                              // 425
            widgetStyle: template.widgetStyle,                                                                       // 426
            name: "copy of " + template.name,                                                                        // 427
            pagetype: pageinfo().pagetype,                                                                           // 428
            pageurl: pageinfo().pageurl,                                                                             // 429
            pageid: pageinfo().pageid,                                                                               // 430
            url: results.data.url,                                                                                   // 431
            createdAt: new Date(),                                                                                   // 432
            visibility: "private",                                                                                   // 433
            rand: Math.random() };                                                                                   // 434
          Widgets.insert(newWidget);                                                                                 // 435
        });                                                                                                          // 436
                                                                                                                     //
        giphy_modal("copy", "widget copied");                                                                        // 438
                                                                                                                     //
        return false;                                                                                                // 440
      },                                                                                                             // 441
                                                                                                                     //
      "click .save_template": function clickSave_template() {                                                        // 444
        this.isTemplate = !this.isTemplate;                                                                          // 445
        Widgets.update(this._id, this);                                                                              // 446
        var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                            // 447
        var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                                // 448
                                                                                                                     //
        giphy_modal("promotion", "widget saved as a template");                                                      // 450
                                                                                                                     //
        return false;                                                                                                // 452
      },                                                                                                             // 453
                                                                                                                     //
      "click .save_to_library": function clickSave_to_library() {                                                    // 455
        this.isTemplate = !this.isTemplate;                                                                          // 456
        //      Widgets.update(this._id, this);                                                                      //
                                                                                                                     //
        var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                                // 459
        var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                   // 460
        var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                                // 461
        var options = { data: dataobj };                                                                             // 462
                                                                                                                     //
        var newpagetype = "user_libs";                                                                               // 464
        var newpageid = Meteor.user().username;                                                                      // 465
        var newpageurl = newpagetype + "/" + newpageurl;                                                             // 466
                                                                                                                     //
        HTTP.post(url, options, function (error, results) {                                                          // 468
          newWidget = { _id: results.data.url,                                                                       // 469
            createdBy: { username: Meteor.user().username,                                                           // 470
              userid: Meteor.userId() },                                                                             // 471
            inLibrary: true,                                                                                         // 472
            html: results.data.html,                                                                                 // 473
            javascript: results.data.javascript,                                                                     // 474
            css: results.data.css,                                                                                   // 475
            displayWidth: template.displayWidth,                                                                     // 476
            displayHeight: template.displayHeight,                                                                   // 477
            description: "(copied from " + template.name + ") " + template.description,                              // 478
            widgetStyle: template.widgetStyle,                                                                       // 479
            name: "copy of " + template.name,                                                                        // 480
            pagetype: newpagetype,                                                                                   // 481
            pageurl: newpageurl,                                                                                     // 482
            pageid: newpageid,                                                                                       // 483
            this_page_only: true,                                                                                    // 484
            url: results.data.url,                                                                                   // 485
            createdAt: new Date(),                                                                                   // 486
            visibility: "private",                                                                                   // 487
            rand: Math.random() };                                                                                   // 488
          Widgets.insert(newWidget);                                                                                 // 489
        });                                                                                                          // 490
                                                                                                                     //
        giphy_modal("library", "widget added to your library");                                                      // 492
                                                                                                                     //
        return false;                                                                                                // 494
      },                                                                                                             // 495
                                                                                                                     //
      "click .openinfo": function clickOpeninfo() {                                                                  // 497
        var thiselement = document.getElementById('widgetContainer_' + this._id);                                    // 498
        var mode = $(thiselement).data("mode");                                                                      // 499
        if (!mode || mode == "display") {                                                                            // 500
          //      $(".widgetMouseOverTarget", thiselement ).css("background", "red");                                //
          $(".widgetDisplayHeader", thiselement).show();                                                             // 502
          $(".widgetMouseOverTarget", thiselement).css("z-index", 5);                                                // 503
          $(".widgetDisplayHeader", thiselement).css("z-index", 10);                                                 // 504
        }                                                                                                            // 505
      },                                                                                                             // 506
                                                                                                                     //
      "mouseleave .widgetDisplayHeader": function mouseleaveWidgetDisplayHeader() {                                  // 509
        var thiselement = document.getElementById('widgetContainer_' + this._id);                                    // 510
        $(".widgetMouseOverTarget", thiselement).css("background", "transparent");                                   // 511
        $(".widgetDisplayHeader", thiselement).hide();                                                               // 512
        $(".widgetMouseOverTarget", thiselement).css("z-index", 10);                                                 // 513
        $(".widgetDisplayHeader", thiselement).css("z-index", 5);                                                    // 514
      }                                                                                                              // 515
                                                                                                                     //
    });                                                                                                              // 215
    ////// END EVENTS                                                                                                //
                                                                                                                     //
    ////// HELPERS                                                                                                   //
                                                                                                                     //
    Template.widget.helpers({                                                                                        // 524
      otherwidgets: function otherwidgets() {                                                                        // 525
        // Otherwise, return all of the tasks                                                                        //
        return Widgets.find({ pagetype: pageinfo().pagetype, _id: { $ne: this._id } }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
      },                                                                                                             // 528
                                                                                                                     //
      isPublic: function isPublic() {                                                                                // 530
        if (this.visibility == "public") {                                                                           // 531
          return true;                                                                                               // 532
        }                                                                                                            // 533
        return false;                                                                                                // 534
      },                                                                                                             // 535
                                                                                                                     //
      pageTypeAndUrl: function pageTypeAndUrl() {                                                                    // 537
                                                                                                                     //
        return "_pt_" + this.pagetype + "/" + this.url;                                                              // 539
      },                                                                                                             // 540
                                                                                                                     //
      pageUrlAndUrl: function pageUrlAndUrl() {                                                                      // 542
        return "_pu_" + pageinfo().pageurl + "/" + this.url;                                                         // 543
      },                                                                                                             // 544
                                                                                                                     //
      commentsCount: function commentsCount(id) {                                                                    // 546
        console.log("in commentsCount " + id);                                                                       // 547
        var value = "";                                                                                              // 548
        console.log("value is " + value);                                                                            // 549
        return value;                                                                                                // 550
      },                                                                                                             // 551
                                                                                                                     //
      isMyWidget: function isMyWidget() {                                                                            // 553
        // is this a widget I created?                                                                               //
        if (getUserXtras().godmode) {                                                                                // 555
          return true;                                                                                               // 556
        }                                                                                                            // 557
        if (this.createdBy && Meteor.user()) {                                                                       // 558
          return this.createdBy.username == Meteor.user().username;                                                  // 559
        } else {                                                                                                     // 560
          return false;                                                                                              // 561
        }                                                                                                            // 562
      },                                                                                                             // 563
                                                                                                                     //
      userXtras: function userXtras() {                                                                              // 565
        return getUserXtras();                                                                                       // 566
      },                                                                                                             // 567
                                                                                                                     //
      godmode: function godmode() {                                                                                  // 569
        return getUserXtras().godmode;                                                                               // 570
      }                                                                                                              // 572
    });                                                                                                              // 524
    //////// END HELPERS                                                                                             //
  })();                                                                                                              // 2
}                                                                                                                    // 575
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{"extensions":[".js",".json"]});
require("./server/smtp.js");
require("./C5.js");
require("./common_functions.js");
require("./widget.js");
//# sourceMappingURL=app.js.map
