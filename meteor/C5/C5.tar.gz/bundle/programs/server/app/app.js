var require = meteorInstall({"server":{"smtp.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/smtp.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      //
Meteor.startup(function () {                                                                                          // 2
                                                                                                                      //
    Accounts.emailTemplates.siteName = "c5.boomhifive.com";                                                           // 4
    Accounts.emailTemplates.from = "C5 Admin <c5@boomhifive.com>";                                                    // 5
    Accounts.emailTemplates.enrollAccount.subject = function (user) {                                                 // 6
        return "Welcome to C5, " + user.profile.name;                                                                 // 7
    };                                                                                                                // 8
    Accounts.emailTemplates.resetPassword.from = function () {                                                        // 9
        // Overrides value set in Accounts.emailTemplates.from when resetting passwords                               // 10
        return "C5 Admin <c5@boomhifive.com>";                                                                        // 11
    };                                                                                                                // 12
    Accounts.emailTemplates.resetPassword.text = function (user, url) {                                               // 13
        var text = "Heard you need to reset your password. No biggie, it happens.";                                   // 14
        text += "\n Just open this url to reset your password: " + url;                                               // 15
        return text;                                                                                                  // 16
    };                                                                                                                // 17
});                                                                                                                   // 18
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"C5.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// C5.js                                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      //
Widgets = new Mongo.Collection("widgets");                                                                            // 2
UserXtras = new Mongo.Collection("userxtras");                                                                        // 3
                                                                                                                      //
// set GLOBAL VARS                                                                                                    // 5
//In the client side                                                                                                  // 6
SERVER_NAME = "localhost";                                                                                            // 7
SERVER_IP = "localhost";                                                                                              // 8
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 10
  Meteor.call('getServerName', function (err, results) {                                                              // 11
    SERVER_NAME = results;                                                                                            // 12
  });                                                                                                                 // 13
  Meteor.call('getServerIP', function (err, results) {                                                                // 14
    SERVER_IP = results;                                                                                              // 15
  });                                                                                                                 // 16
}                                                                                                                     // 17
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 20
                                                                                                                      //
  Meteor.startup(function () {                                                                                        // 22
    /*                                                                                                                // 23
    var to ="donundeen@gmail.com";                                                                                    //
    var from = "c5@boomhifive.com";                                                                                   //
    var subject = "C5 started";                                                                                       //
    var text = "notifying you that C5 started";                                                                       //
    console.log("sending email");                                                                                     //
    Email.send({                                                                                                      //
      to: to,                                                                                                         //
      from: from,                                                                                                     //
      subject: subject,                                                                                               //
      text: text                                                                                                      //
    });                                                                                                               //
    */                                                                                                                //
  });                                                                                                                 // 36
                                                                                                                      //
  Meteor.methods({                                                                                                    // 39
    getServerName: function () {                                                                                      // 40
      function getServerName() {                                                                                      // 40
        SERVER_NAME = process.env.SERVER_NAME;                                                                        // 41
        if (typeof SERVER_NAME === "undefined") {                                                                     // 42
          SERVER_NAME = "localhost";                                                                                  // 43
        }                                                                                                             // 44
        return SERVER_NAME;                                                                                           // 45
      }                                                                                                               // 46
                                                                                                                      //
      return getServerName;                                                                                           // 40
    }(),                                                                                                              // 40
    getServerIP: function () {                                                                                        // 47
      function getServerIP() {                                                                                        // 47
        SERVER_IP = process.env.SERVER_IP;                                                                            // 48
        if (typeof SERVER_IP === "undefined") {                                                                       // 49
          SERVER_IP = "localhost";                                                                                    // 50
        }                                                                                                             // 51
        return SERVER_IP;                                                                                             // 52
      }                                                                                                               // 53
                                                                                                                      //
      return getServerIP;                                                                                             // 47
    }()                                                                                                               // 47
  });                                                                                                                 // 39
}                                                                                                                     // 55
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 57
                                                                                                                      //
  Meteor.startup(function () {                                                                                        // 60
    console.log("starting meteor");                                                                                   // 61
    $(window).bind('beforeunload', function () {                                                                      // 62
      $(".save").trigger("click");                                                                                    // 63
    });                                                                                                               // 64
  });                                                                                                                 // 66
                                                                                                                      //
  /// comments config                                                                                                 // 71
  // On the Client                                                                                                    // 72
  Comments.ui.config({                                                                                                // 73
    template: 'bootstrap' // or ionic, semantic-ui                                                                    // 74
  });                                                                                                                 // 73
                                                                                                                      //
  ////// HELPERS                                                                                                      // 77
  UI.registerHelper('shortIt', function (stringToShorten, maxCharsAmount) {                                           // 78
    if (stringToShorten.length > maxCharsAmount) {                                                                    // 79
      return stringToShorten.substring(0, maxCharsAmount) + '...';                                                    // 80
    }                                                                                                                 // 81
    return stringToShorten;                                                                                           // 82
  });                                                                                                                 // 83
                                                                                                                      //
  UI.registerHelper('encodeURIComponent', function (string) {                                                         // 85
    return encodeURIComponent(string);                                                                                // 86
  });                                                                                                                 // 87
                                                                                                                      //
  UI.registerHelper('absoluteUrl', function () {                                                                      // 89
    return Meteor.absoluteUrl();                                                                                      // 90
  });                                                                                                                 // 91
                                                                                                                      //
  Accounts.ui.config({                                                                                                // 93
    passwordSignupFields: "USERNAME_AND_EMAIL"                                                                        // 94
  });                                                                                                                 // 93
                                                                                                                      //
  Template.registerHelper("pageid", function () {                                                                     // 97
    return pageinfo().pageid;                                                                                         // 98
  });                                                                                                                 // 99
                                                                                                                      //
  Template.registerHelper("pageurl", function () {                                                                    // 101
    return pageinfo().pageurl;                                                                                        // 102
  });                                                                                                                 // 103
                                                                                                                      //
  Template.registerHelper("pagetype", function () {                                                                   // 106
    return pageinfo().pagetype;                                                                                       // 107
  });                                                                                                                 // 108
                                                                                                                      //
  Template.registerHelper("pageid_neverblank", function () {                                                          // 110
    return "_pi_" + pageinfo().pageid;                                                                                // 111
  });                                                                                                                 // 112
                                                                                                                      //
  Template.registerHelper("pageurl_neverblank", function () {                                                         // 114
    return "_pu_" + pageinfo().pageurl;                                                                               // 115
  });                                                                                                                 // 116
  Template.registerHelper("pagetype_neverblank", function () {                                                        // 117
    return "_pt_" + pageinfo().pagetype;                                                                              // 118
  });                                                                                                                 // 119
                                                                                                                      //
  Template.registerHelper("numComments", function (commentId) {                                                       // 121
                                                                                                                      //
    var instance = Template.instance;                                                                                 // 123
                                                                                                                      //
    if (!instance.commentCounters) {                                                                                  // 125
      instance.commentCounters = {};                                                                                  // 126
    }                                                                                                                 // 127
    if (!instance.commentCounters[commentId]) {                                                                       // 128
      instance.commentCounters[commentId] = new ReactiveVar();                                                        // 129
    }                                                                                                                 // 130
    Comments.getCount(commentId, function (error, count) {                                                            // 131
      instance.commentCounters[commentId].set(count);                                                                 // 132
    });                                                                                                               // 133
    return instance.commentCounters[commentId].get();                                                                 // 134
  });                                                                                                                 // 135
                                                                                                                      //
  Template.registerHelper("commentIcon", function (commentId) {                                                       // 137
                                                                                                                      //
    var instance = Template.instance;                                                                                 // 139
                                                                                                                      //
    var noComments = "zmdi-comment";                                                                                  // 141
    var hasComments = "zmdi-comment-alert";                                                                           // 142
                                                                                                                      //
    if (!instance.commentIcons) {                                                                                     // 144
      instance.commentIcons = {};                                                                                     // 145
    }                                                                                                                 // 146
    if (!instance.commentIcons[commentId]) {                                                                          // 147
      instance.commentIcons[commentId] = new ReactiveVar();                                                           // 148
    }                                                                                                                 // 149
    Comments.getCount(commentId, function (error, count) {                                                            // 150
      if (count > 0) {                                                                                                // 151
        console.log(commentId + " has comments");                                                                     // 152
        instance.commentCounters[commentId].set("zmdi-comment-alert");                                                // 153
      } else {                                                                                                        // 154
        console.log(commentId + " no comments");                                                                      // 155
        instance.commentIcons[commentId].set("zmdi-comment");                                                         // 156
      }                                                                                                               // 157
    });                                                                                                               // 158
    return instance.commentIcons[commentId].get();                                                                    // 159
  });                                                                                                                 // 160
                                                                                                                      //
  Template.registerHelper("SERVER_NAME", function () {                                                                // 164
    return SERVER_NAME;                                                                                               // 165
  });                                                                                                                 // 166
  Template.registerHelper("SERVER_IP", function () {                                                                  // 167
    return SERVER_IP;                                                                                                 // 168
  });                                                                                                                 // 169
  Template.gridwidgets.helpers({                                                                                      // 170
    widgets: function () {                                                                                            // 171
      function widgets() {                                                                                            // 171
        // Otherwise, return all of the tasks                                                                         // 172
        var find = {                                                                                                  // 173
          this_page_only: { $in: [false, null] },                                                                     // 174
          pagetype: pageinfo().pagetype,                                                                              // 175
          $or: [{ visibility: "public" }, { $and: [{ visibility: "private" }, { "createdBy.userid": Meteor.userId() }] }, { visibility: null }]
        };                                                                                                            // 173
                                                                                                                      //
        //        var results = Widgets.find(find, {sort: {sort_order : -1, createdAt: -1}}).map(setWidgetDefaults); 
        var results = Widgets.find(find, { sort: { sort_order: 1 } }).map(setWidgetDefaults);                         // 187
        return results;                                                                                               // 188
      }                                                                                                               // 189
                                                                                                                      //
      return widgets;                                                                                                 // 171
    }(),                                                                                                              // 171
    thisPageWidgets: function () {                                                                                    // 190
      function thisPageWidgets() {                                                                                    // 190
        // Otherwise, return all of the tasks                                                                         // 191
        var find = { this_page_only: true,                                                                            // 192
          pagetype: pageinfo().pagetype,                                                                              // 193
          pageid: pageinfo().pageid };                                                                                // 194
        var results = Widgets.find(find, { sort: { sort_order: 1, createdAt: -1 } }).map(setWidgetDefaults);          // 195
        return results;                                                                                               // 196
      }                                                                                                               // 197
                                                                                                                      //
      return thisPageWidgets;                                                                                         // 190
    }()                                                                                                               // 190
                                                                                                                      //
  });                                                                                                                 // 170
  Template.body.helpers({                                                                                             // 200
    widgets: function () {                                                                                            // 201
      function widgets() {                                                                                            // 201
        // Otherwise, return all of the tasks                                                                         // 202
        var find = {                                                                                                  // 203
          this_page_only: { $in: [false, null] },                                                                     // 204
          pagetype: pageinfo().pagetype,                                                                              // 205
          $or: [{ visibility: "public" }, { $and: [{ visibility: "private" }, { "createdBy.userid": Meteor.userId() }] }, { visibility: null }]
        };                                                                                                            // 203
                                                                                                                      //
        //        var results = Widgets.find(find, {sort: {sort_order : -1, createdAt: -1}}).map(setWidgetDefaults); 
        var results = Widgets.find(find, { sort: { sort_order: 1 } }).map(setWidgetDefaults);                         // 217
        return results;                                                                                               // 218
      }                                                                                                               // 219
                                                                                                                      //
      return widgets;                                                                                                 // 201
    }(),                                                                                                              // 201
    widgetTemplates: function () {                                                                                    // 220
      function widgetTemplates() {                                                                                    // 220
        // Otherwise, return all of the tasks                                                                         // 221
        var results = Widgets.find({ isTemplate: true }, { sort: { sort_order: -1, createdAt: -1 } }).map(setWidgetDefaults);
        return results;                                                                                               // 223
      }                                                                                                               // 224
                                                                                                                      //
      return widgetTemplates;                                                                                         // 220
    }(),                                                                                                              // 220
    libraryWidgets: function () {                                                                                     // 225
      function libraryWidgets() {                                                                                     // 225
        // Otherwise, return all of the tasks                                                                         // 226
        var find = { inLibrary: true };                                                                               // 227
        find["createdBy.userid"] = Meteor.userId();                                                                   // 228
        var results = Widgets.find(find, { sort: { sort_order: -1, createdAt: -1 } }).map(setWidgetDefaults);         // 229
        return results;                                                                                               // 230
      }                                                                                                               // 231
                                                                                                                      //
      return libraryWidgets;                                                                                          // 225
    }(),                                                                                                              // 225
    thisPageWidgets: function () {                                                                                    // 232
      function thisPageWidgets() {                                                                                    // 232
        // Otherwise, return all of the tasks                                                                         // 233
        var find = { this_page_only: true,                                                                            // 234
          pagetype: pageinfo().pagetype,                                                                              // 235
          pageid: pageinfo().pageid };                                                                                // 236
        var results = Widgets.find(find, { sort: { sort_order: -1, createdAt: -1 } }).map(setWidgetDefaults);         // 237
        return results;                                                                                               // 238
      }                                                                                                               // 239
                                                                                                                      //
      return thisPageWidgets;                                                                                         // 232
    }(),                                                                                                              // 232
                                                                                                                      //
    userXtras: function () {                                                                                          // 241
      function userXtras() {                                                                                          // 241
        return getUserXtras();                                                                                        // 242
      }                                                                                                               // 243
                                                                                                                      //
      return userXtras;                                                                                               // 241
    }(),                                                                                                              // 241
                                                                                                                      //
    godmode: function () {                                                                                            // 245
      function godmode() {                                                                                            // 245
        return getUserXtras().godmode;                                                                                // 246
      }                                                                                                               // 247
                                                                                                                      //
      return godmode;                                                                                                 // 245
    }()                                                                                                               // 245
                                                                                                                      //
  });                                                                                                                 // 200
  ////// END HELPERS                                                                                                  // 250
                                                                                                                      //
                                                                                                                      //
  ////// TEMPLATE ONRENDERED                                                                                          // 253
  Template.body.onRendered(function () {                                                                              // 254
    //$(".tooltip-right").tooltip({placement: "right"});                                                              // 255
    //  $("[title]").tooltip({placement: "auto"});                                                                    // 256
    console.log("555555555555C5 rendered");                                                                           // 257
  });                                                                                                                 // 258
  ////// END ONRENDERED                                                                                               // 259
                                                                                                                      //
                                                                                                                      //
  /////// EVENTS                                                                                                      // 263
  Template.body.events({                                                                                              // 264
                                                                                                                      //
    "click .lockall": function () {                                                                                   // 267
      function clickLockall() {                                                                                       // 267
        $(".lock").trigger("click");                                                                                  // 268
        $(".lockall").hide();                                                                                         // 269
        $(".unlockall").show();                                                                                       // 270
        giphy_modal("unlock", "Unlocking all widgets you have access to");                                            // 271
        return false;                                                                                                 // 272
      }                                                                                                               // 274
                                                                                                                      //
      return clickLockall;                                                                                            // 267
    }(),                                                                                                              // 267
    "click .unlockall": function () {                                                                                 // 275
      function clickUnlockall() {                                                                                     // 275
        $(".unlock").trigger("click");                                                                                // 276
        $(".lockall").show();                                                                                         // 277
        $(".unlockall").hide();                                                                                       // 278
        giphy_modal("lock", "Locking all Widgets");                                                                   // 279
        return false;                                                                                                 // 280
      }                                                                                                               // 281
                                                                                                                      //
      return clickUnlockall;                                                                                          // 275
    }(),                                                                                                              // 275
                                                                                                                      //
    "click .giphy": function () {                                                                                     // 283
      function clickGiphy(e, t) {                                                                                     // 283
        $(e.target).hide();                                                                                           // 284
      }                                                                                                               // 285
                                                                                                                      //
      return clickGiphy;                                                                                              // 283
    }(),                                                                                                              // 283
                                                                                                                      //
    "click .godmode_check": function () {                                                                             // 287
      function clickGodmode_check(e, t) {                                                                             // 287
        //      console.log(t);                                                                                       // 288
        UserXtras.update({ _id: Meteor.userId() }, { $set: { godmode: e.target.checked } });                          // 289
      }                                                                                                               // 290
                                                                                                                      //
      return clickGodmode_check;                                                                                      // 287
    }(),                                                                                                              // 287
                                                                                                                      //
    'click .copy_from_template': function () {                                                                        // 292
      function clickCopy_from_template() {                                                                            // 292
        copyWidgetToPage($(this).attr("target"), pageinfo().pagetype, pageinfo().pageurl, pageinfo().pageid);         // 293
        giphy_modal("copy", "New Widget Copied From Template");                                                       // 294
        return false;                                                                                                 // 295
      }                                                                                                               // 296
                                                                                                                      //
      return clickCopy_from_template;                                                                                 // 292
    }(),                                                                                                              // 292
                                                                                                                      //
    'click .deletetemplate': function () {                                                                            // 298
      function clickDeletetemplate() {                                                                                // 298
        var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                                 // 299
        template.isTemplate = false;                                                                                  // 300
        Widgets.update(template._id, template);                                                                       // 301
      }                                                                                                               // 302
                                                                                                                      //
      return clickDeletetemplate;                                                                                     // 298
    }(),                                                                                                              // 298
                                                                                                                      //
    'click .addwidget': function () {                                                                                 // 304
      function clickAddwidget() {                                                                                     // 304
        //add jsbin widget                                                                                            // 305
                                                                                                                      //
        var htmlstring = '<html>\n ' + '<head>\n ' + '<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>\n ' + '<script src="/c5libs/locallib.js"></script>\n ' + '   <script type="application/json" class="c5_data">{"data" : "data placed here gets passed along"}</script>\n ' + '</head>\n ' + '<body>\n ' + '  <div class="c5_html">\n ' + '  html placed here gets passed along\n ' + '  </div>\n ' + '</body>\n ' + '</html>\n';
        var csstring = "";                                                                                            // 319
        var jsstring = "function doTheThings(data){\n" + "// everything you want to do should happen inside this function\n " + "// the data var will be populated with whatever you've requested from other widgets\n" + "// and this function will be call when all those widgets have complete \n" + "   c5_done(); // this message is required at the end of all the processing, so the system knows this widget is done \n " + "} \n" + "requireWidgetData( \n" + "// all requests to other widgets go here (automatically if you use the 'pull from' interface): \n" + "// c5_requires \n" + "{} \n" + "// end_c5_requires \n" + "// end other widget requests \n" + ", doTheThings)";
        var dataobj = { html: htmlstring, css: csstring, javascript: jsstring };                                      // 333
        var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                                 // 334
        var options = { data: dataobj };                                                                              // 335
        HTTP.post(url, options, function (error, results) {                                                           // 336
          newWidget = { _id: results.data.url,                                                                        // 337
            createdBy: { username: Meteor.user().username,                                                            // 338
              userid: Meteor.userId() },                                                                              // 339
            isTemplate: false,                                                                                        // 340
            name: results.data.url,                                                                                   // 341
            description: "",                                                                                          // 342
            html: results.data.html,                                                                                  // 343
            javascript: results.data.javascript,                                                                      // 344
            css: results.data.css,                                                                                    // 345
            displayWidth: "",                                                                                         // 346
            displayHeight: "",                                                                                        // 347
            widgetStyle: "",                                                                                          // 348
            pagetype: pageinfo().pagetype,                                                                            // 349
            pageurl: pageinfo().pageurl,                                                                              // 350
            pageid: pageinfo().pageid,                                                                                // 351
            url: results.data.url,                                                                                    // 352
            visibility: "private",                                                                                    // 353
            createdAt: new Date(),                                                                                    // 354
            rand: Math.random() };                                                                                    // 355
          Widgets.insert(newWidget);                                                                                  // 356
        });                                                                                                           // 357
        return false;                                                                                                 // 358
      }                                                                                                               // 359
                                                                                                                      //
      return clickAddwidget;                                                                                          // 304
    }(),                                                                                                              // 304
                                                                                                                      //
    'click .test': function () {                                                                                      // 361
      function clickTest() {                                                                                          // 361
        return false;                                                                                                 // 362
      }                                                                                                               // 363
                                                                                                                      //
      return clickTest;                                                                                               // 361
    }()                                                                                                               // 361
  });                                                                                                                 // 264
                                                                                                                      //
  ///// END EVENTS                                                                                                    // 367
                                                                                                                      //
}                                                                                                                     // 370
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 372
  Meteor.startup(function () {                                                                                        // 373
    // code to run on server at startup                                                                               // 374
  });                                                                                                                 // 375
}                                                                                                                     // 376
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"common_functions.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// common_functions.js                                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
justaddedid = pageinfo = setWidgetDefaults = giphy_modal = getUserXtras = null;                                       // 1
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 3
                                                                                                                      //
  getUserXtras = function getUserXtras() {                                                                            // 5
    var userxtras = false;                                                                                            // 6
    var user = Meteor.user();                                                                                         // 7
    if (user) {                                                                                                       // 8
      /*                                                                                                              // 9
      console.log(user.username);                                                                                     //
      console.log(user._id);                                                                                          //
      console.log("getting for " + user._id);                                                                         //
      */                                                                                                              //
      userxtras = UserXtras.findOne({ _id: user._id });                                                               // 14
      if (!userxtras || !userxtras.foo) {                                                                             // 15
        console.log("userxtras " + userxtras);                                                                        // 16
        userxtras = { _id: user._id, admin: false, godmode: false, foo: "var" };                                      // 17
        if (user.username == "donundeen") {                                                                           // 18
          userxtras.admin = true;                                                                                     // 19
        }                                                                                                             // 20
        console.log("saving for " + user._id);                                                                        // 21
        UserXtras.upsert({ _id: user._id }, userxtras);                                                               // 22
        var userxtras2 = UserXtras.findOne({ _id: user._id });                                                        // 23
      }                                                                                                               // 24
    }                                                                                                                 // 25
    return userxtras;                                                                                                 // 26
  };                                                                                                                  // 28
                                                                                                                      //
  giphy_modal = function giphy_modal(term, text) {                                                                    // 32
    $("#giphy_modal").modal('show');                                                                                  // 33
    $(".giphy_modal_header").text(text);                                                                              // 34
    var url = "/giphy_proxy/" + encodeURIComponent(term);                                                             // 35
    $(".giphy_modal_image_div").empty();                                                                              // 36
    var imgurl = url + "?" + new Date().getTime();                                                                    // 37
    $(".giphy_modal_image_div").html("<img src='" + imgurl + "' width='200' class='giphy_modal_image_img'/>");        // 38
                                                                                                                      //
    setTimeout(function () {                                                                                          // 40
      $("#giphy_modal").modal('hide');                                                                                // 41
    }, 2000);                                                                                                         // 42
  };                                                                                                                  // 44
                                                                                                                      //
  pageinfo = function pageinfo() {                                                                                    // 46
    var pagetype = "";                                                                                                // 47
    var pageid = "";                                                                                                  // 48
    var pathname = window.location.pathname;                                                                          // 49
    var split = pathname.split("/");                                                                                  // 50
    split.shift();                                                                                                    // 51
    var pageurl = split.join("/");                                                                                    // 52
                                                                                                                      //
    if (split.length > 0) {                                                                                           // 54
      pagetype = split.shift();                                                                                       // 55
    }                                                                                                                 // 56
    if (split.length > 0) {                                                                                           // 57
      pageid = split.shift();                                                                                         // 58
    }                                                                                                                 // 59
    pageid = pageid.replace(/:script/, "");                                                                           // 60
    return { pageurl: pageurl,                                                                                        // 61
      pagetype: pagetype,                                                                                             // 62
      pageid: pageid };                                                                                               // 63
  };                                                                                                                  // 65
                                                                                                                      //
  copyWidgetToPage = function copyWidgetToPage(origID, pagetype, pageid, pageurl) {                                   // 68
    console.log("calling CopyWidgetToPage for " + origID);                                                            // 69
    var template = Widgets.findOne({ url: origID }); //.map(setWidgetDefaults);                                       // 70
    var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                        // 71
    var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                                     // 72
    var options = { data: dataobj };                                                                                  // 73
                                                                                                                      //
    HTTP.post(url, options, function (error, results) {                                                               // 75
      newWidget = { _id: results.data.url,                                                                            // 76
        createdBy: { username: Meteor.user().username,                                                                // 77
          userid: Meteor.userId() },                                                                                  // 78
        isTemplate: false,                                                                                            // 79
        html: results.data.html,                                                                                      // 80
        javascript: results.data.javascript,                                                                          // 81
        css: results.data.css,                                                                                        // 82
        displayWidth: results.data.displayWidth,                                                                      // 83
        displayHeight: results.data.displayHeight,                                                                    // 84
        description: "(copied from " + template.name + ") " + template.description,                                   // 85
        widgetStyle: results.data.widgetStyle,                                                                        // 86
        name: "copy of " + template.name,                                                                             // 87
        pagetype: pagetype,                                                                                           // 88
        pageurl: pageurl,                                                                                             // 89
        pageid: pageid,                                                                                               // 90
        url: results.data.url,                                                                                        // 91
        createdAt: new Date(),                                                                                        // 92
        visibility: "private",                                                                                        // 93
        rand: Math.random() };                                                                                        // 94
      justaddedid = Widgets.insert(newWidget);                                                                        // 95
      console.log("setting justaddedid " + justaddedid);                                                              // 96
                                                                                                                      //
      var grid = $(".grid-stack").data('gridstack');                                                                  // 98
      var widgetElement = $("#widgetContainer_" + results.data.url);                                                  // 99
                                                                                                                      //
      console.log("added ");                                                                                          // 101
      console.log(widgetElement);                                                                                     // 102
      /*                                                                                                              // 103
      var griditem = $(widgetElement).parent().parent();                                                              //
      $(griditem).data("gs-width", "12");                                                                             //
      $(griditem).data("gs-height", "5");                                                                             //
      $(griditem).data("gs-auto-position", "true");                                                                   //
      grid.makeWidget(griditem);                                                                                      //
      grid.resize(griditem, 12, 5);                                                                                   //
       var next = $(".grid-stack-item").get(0)  ;                                                                     //
      console.log("moving next" + $(next).data("widget-id"));                                                         //
      console.log(next);                                                                                              //
      grid.move(next, 0, 6);                                                                                          //
      */                                                                                                              //
    });                                                                                                               // 116
    giphy_modal("copy", "New Widget Copied From Template");                                                           // 117
  };                                                                                                                  // 119
                                                                                                                      //
  setWidgetDefaults = function setWidgetDefaults(doc) {                                                               // 122
    if (typeof doc.displayWidth === "undefined" || !doc.displayWidth || doc.displayWidth.trim() == "" || doc.displayWidth == "width" || doc.displayWidth == "default") {
      doc.displayWidth = "320px";                                                                                     // 124
      doc.displayUsableWidth = "320px";                                                                               // 125
    } else {                                                                                                          // 126
      doc.displayUsableWidth = doc.displayWidth;                                                                      // 127
    }                                                                                                                 // 128
    if (typeof doc.displayHeight === "undefined" || !doc.displayHeight || doc.displayHeight.trim() == "" || doc.displayHeight == "height" || doc.displayHeight == "default") {
      doc.displayHeight = "400px";                                                                                    // 130
      doc.displayUsableHeight = "400px";                                                                              // 131
    } else {                                                                                                          // 132
      doc.displayUsableHeight = doc.displayHeight;                                                                    // 133
    }                                                                                                                 // 134
    if (typeof doc.widgetStyle === "undefined" || !doc.widgetStyle || doc.widgetStyle.trim() == "" || doc.widgetStyle == "css" || doc.widgetStyle == "default") {
      doc.widgetStyle = "default";                                                                                    // 136
      doc.usableWidgetStyle = "";                                                                                     // 137
    } else {                                                                                                          // 138
      doc.usableWidgetStyle = doc.widgetStyle;                                                                        // 139
    }                                                                                                                 // 140
    if (!doc.createdBy) {                                                                                             // 141
      doc.createdBy = {};                                                                                             // 142
    }                                                                                                                 // 143
                                                                                                                      //
    if (doc.displayUsableHeight.match(/px/)) {                                                                        // 145
      var height = doc.displayUsableHeight.replace(/px/, "");                                                         // 146
      doc.jsbinHeight = height - 20;                                                                                  // 147
      doc.jsbinHeight += "px";                                                                                        // 148
    } else {                                                                                                          // 149
      doc.jsbinHeight = "";                                                                                           // 150
    }                                                                                                                 // 151
                                                                                                                      //
    if (!doc.this_page_only) {                                                                                        // 153
      doc.this_page_only = false;                                                                                     // 154
    }                                                                                                                 // 155
                                                                                                                      //
    if (!doc.sort_order) {                                                                                            // 157
      doc.sort_order = 0;                                                                                             // 158
    }                                                                                                                 // 159
                                                                                                                      //
    if (!doc.visibility) {                                                                                            // 161
      doc.visibility = "public";                                                                                      // 162
    }                                                                                                                 // 163
                                                                                                                      //
    if (!doc.cacheConfig) {                                                                                           // 165
      doc.cacheConfig = {};                                                                                           // 166
    }                                                                                                                 // 167
                                                                                                                      //
    if (!doc.cacheConfig.ttl) {                                                                                       // 169
      doc.cacheConfig.ttl = 60;                                                                                       // 170
    }                                                                                                                 // 171
                                                                                                                      //
    if (typeof doc.width_in_cells == "undefined") {                                                                   // 173
      doc.width_in_cells = 12;                                                                                        // 174
    }                                                                                                                 // 175
    if (typeof doc.height_in_cells == "undefined") {                                                                  // 176
      doc.height_in_cells = 5;                                                                                        // 177
    }                                                                                                                 // 178
    if (doc.width_in_cells == 0) {                                                                                    // 179
      doc.width_in_cells = 1;                                                                                         // 180
    }                                                                                                                 // 181
    if (doc.height_in_cells == 0) {                                                                                   // 182
      doc.height_in_cells = 1;                                                                                        // 183
    }                                                                                                                 // 184
    if (typeof doc.width_in_px == "undefined") {                                                                      // 185
      doc.width_in_px = 640;                                                                                          // 186
    }                                                                                                                 // 187
    if (typeof doc.height_in_px == "undefined") {                                                                     // 188
      doc.height_in_px = 320;                                                                                         // 189
    }                                                                                                                 // 190
    if (doc.width_in_px == 0) {                                                                                       // 191
      doc.width_in_px = 640;                                                                                          // 192
    }                                                                                                                 // 193
    if (doc.height_in_px == 0) {                                                                                      // 194
      doc.height_in_px = 320;                                                                                         // 195
    }                                                                                                                 // 196
                                                                                                                      //
    return doc;                                                                                                       // 199
  };                                                                                                                  // 200
}                                                                                                                     // 201
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"widget.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// widget.js                                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 2
  var dix;                                                                                                            // 2
                                                                                                                      //
  (function () {                                                                                                      // 2
    var setDisplayModeOn = function setDisplayModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin, widgetid, isnew) {
      var grid = $(".grid-stack").data("gridstack");                                                                  // 8
      var griditem = $(widgetElement).parent().parent();                                                              // 9
      var result = grid.resize(griditem, widgetData.width_in_cells, widgetData.height_in_cells);                      // 10
                                                                                                                      //
      // get the size of the navbar, subtract from height of iframe                                                   // 12
                                                                                                                      //
      dix++;                                                                                                          // 14
      var di = dix;                                                                                                   // 15
      var newbintop = 0;                                                                                              // 16
      $(menu).hide();                                                                                                 // 17
                                                                                                                      //
      $(".editmodeonly", widgetElement).hide();                                                                       // 19
      $(".displaymodeonly", widgetElement).show();                                                                    // 20
      iframeElement.oldbintop = $(bin).css("top");                                                                    // 21
      $(bin).css("top", newbintop);                                                                                   // 22
      $(widgetElement).attr("style", widgetData.usableWidgetStyle);                                                   // 23
                                                                                                                      //
      $(widgetElement).css("border-radius", "10px");                                                                  // 25
      $(".widgetDisplayHeader", widgetElement).hide();                                                                // 26
                                                                                                                      //
      if (jsbin && jsbin.panels) {                                                                                    // 28
        jsbin.panels.hide("html");                                                                                    // 29
        jsbin.panels.hide("javascript");                                                                              // 30
        jsbin.panels.hide("css");                                                                                     // 31
        jsbin.panels.hide("console");                                                                                 // 32
      }                                                                                                               // 33
      $(".lock", widgetElement).show();                                                                               // 34
      $(".unlock", widgetElement).hide();                                                                             // 35
      $(widgetElement).data("mode", "display");                                                                       // 36
      $(iframeElement).css("border-radius", "10px");                                                                  // 37
                                                                                                                      //
      var initialH = $(griditem).height();                                                                            // 39
      var finalh = initialH;                                                                                          // 40
      var initialW = $(griditem).width();                                                                             // 41
      var finalw = initialW;                                                                                          // 42
      $(widgetElement).width(finalw - 35);                                                                            // 43
      $(widgetElement).height(finalh - 15);                                                                           // 44
                                                                                                                      //
      $(iframeElement).css("max-height", "");                                                                         // 46
      $(iframeElement).css("max-width", "");                                                                          // 47
      $(iframeElement).css("min-height", "");                                                                         // 48
      $(iframeElement).css("min-width", "");                                                                          // 49
                                                                                                                      //
      $(iframeElement).width(finalw - 35);                                                                            // 51
      $(iframeElement).css("max-width", finalw - 35);                                                                 // 52
      $(iframeElement).height(finalh - 25);                                                                           // 53
      $(iframeElement).css("max-height", finalh - 25);                                                                // 54
      $(iframeElement).css("min-height", finalh - 25);                                                                // 55
    };                                                                                                                // 57
                                                                                                                      //
    var setEditModeOn = function setEditModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin) {          // 2
      var grid = $(".grid-stack").data("gridstack");                                                                  // 61
      var griditem = $(widgetElement).parent().parent();                                                              // 62
      if (jsbin) {                                                                                                    // 63
        jsbin.panels.show("html");                                                                                    // 64
        jsbin.panels.show("javascript");                                                                              // 65
      }                                                                                                               // 66
      $(".lock", widgetElement).hide();                                                                               // 67
      $(".unlock", widgetElement).show();                                                                             // 68
      //      editors.panels.show("css");                                                                             // 69
                                                                                                                      //
      var newbintop = 0;                                                                                              // 71
                                                                                                                      //
      grid.resize(griditem, 12, 6);                                                                                   // 73
                                                                                                                      //
      // put it in EDIT MODE                                                                                          // 75
      $(menu).show();                                                                                                 // 76
      $(".editmodeonly", widgetElement).show();                                                                       // 77
      $(".displaymodeonly", widgetElement).hide();                                                                    // 78
      $(bin).css("top", iframeElement.oldbintop);                                                                     // 79
      $(widgetElement).css("border-radius", "10px");                                                                  // 80
      $(iframeElement).css("border-radius", "10px");                                                                  // 81
                                                                                                                      //
      // ".navbar-collapse"                                                                                           // 83
      var height_adjust = $(".navbar-collapse", widgetElement).height() - 20;                                         // 84
      // adjust for height of menu                                                                                    // 85
                                                                                                                      //
                                                                                                                      //
      var initialH = $(griditem).height();                                                                            // 88
      var finalh = initialH;                                                                                          // 89
      var initialW = $(griditem).width();                                                                             // 90
      var finalw = initialW;                                                                                          // 91
      $(widgetElement).width(finalw - 25);                                                                            // 92
      $(widgetElement).height(finalh - 15);                                                                           // 93
                                                                                                                      //
      $(iframeElement).css("max-height", "");                                                                         // 95
      $(iframeElement).css("max-width", "");                                                                          // 96
      $(iframeElement).css("min-height", "");                                                                         // 97
      $(iframeElement).css("min-width", "");                                                                          // 98
                                                                                                                      //
      $(iframeElement).width(finalw - 25);                                                                            // 100
      $(iframeElement).css("max-width", finalw - 25);                                                                 // 101
      $(iframeElement).height(finalh - 25 - height_adjust);                                                           // 102
      $(iframeElement).css("max-height", finalh - 25);                                                                // 103
      $(iframeElement).css("min-height", finalh - 25);                                                                // 104
    };                                                                                                                // 106
    /////// END FUNCTION DEFS                                                                                         // 107
                                                                                                                      //
                                                                                                                      //
    /////////// END WIDGET ONRENDERED                                                                                 // 348
                                                                                                                      //
                                                                                                                      //
    //////////// EVENTS                                                                                               // 352
                                                                                                                      //
    var insert_code = function insert_code(jsbin_id, codeString, codeStringRe, comments) {                            // 2
                                                                                                                      //
      var editors = document.getElementById(jsbin_id).contentWindow.editors;                                          // 356
                                                                                                                      //
      if (!editors) {                                                                                                 // 358
        return true;                                                                                                  // 359
      }                                                                                                               // 360
      var code = editors.javascript.getCode();                                                                        // 361
      var line = editors.javascript.editor.getCursor().line;                                                          // 362
      var charpos = editors.javascript.editor.getCursor().ch;                                                         // 363
      // make sure it's not already in there:                                                                         // 364
      var codeRe = new RegExp("\/\/ *c[45]_requires[\\s\\S]*\\[[\\s\\S]*" + codeStringRe + "[\\s\\S]*\\] *,[\\s\\S]*\/\/ *end_c[45]_requires");
      var codeMatch = code.match(codeRe);                                                                             // 366
      if (!codeMatch) {                                                                                               // 367
        // match to empty array                                                                                       // 368
        var match = /(\/\/ *c[45]_requires[\s\S]*\[)\s*(\] *,[\s\S]*\/\/ *end_c[45]_requires)/;                       // 369
        var results = code.match(match);                                                                              // 370
        newcode = code.replace(match, "$1\n" + codeString + " // " + comments + "\n$2");                              // 371
                                                                                                                      //
        if (newcode == code) {                                                                                        // 373
          // match to non-empty array                                                                                 // 374
          var match = /(\/\/ *c[45]_requires[\s\S]*\[)([^\]]*\] *,[\s\S]*\/\/ *end_c[45]_requires)/;                  // 375
          var results = code.match(match);                                                                            // 376
          newcode = code.replace(match, "$1\n" + codeString + ", // " + comments + "$2");                             // 377
        }                                                                                                             // 378
        code = newcode;                                                                                               // 379
        var state = { line: editors.javascript.editor.currentLine(),                                                  // 380
          character: editors.javascript.editor.getCursor().ch,                                                        // 381
          add: 0                                                                                                      // 382
        };                                                                                                            // 380
                                                                                                                      //
        editors.javascript.setCode(code);                                                                             // 385
        editors.javascript.editor.setCursor({ line: state.line + state.add, ch: state.character });                   // 386
      }                                                                                                               // 387
    };                                                                                                                // 388
                                                                                                                      //
    /////// FUNCTION DEFS                                                                                             // 4
    dix = 0;                                                                                                          // 5
    Template.gridwidgets.onRendered(function () {                                                                     // 111
      // set whatever gridStack options you want                                                                      // 112
      var options = {                                                                                                 // 113
        width: 12,                                                                                                    // 114
        auto: false,                                                                                                  // 115
        cellHeight: 60,                                                                                               // 116
        cellWidth: 60,                                                                                                // 117
        alwaysShowResizeHandle: /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),
        resizable: {                                                                                                  // 119
          handles: 'e, se, s, sw, w'                                                                                  // 120
        }                                                                                                             // 119
      };                                                                                                              // 113
      var $gridstack = this.$('.grid-stack');                                                                         // 123
      // initialise gridstack                                                                                         // 124
      $gridstack.gridstack(options);                                                                                  // 125
                                                                                                                      //
      $(window).resize(function (evt) {                                                                               // 127
        if (evt.target == window) {                                                                                   // 128
          var grid = $(".grid-stack").data("gridstack");                                                              // 129
          $(".grid-stack-item").each(function (index) {                                                               // 130
            var element = this;                                                                                       // 131
            var initialH = $(element).height();                                                                       // 132
            var finalh = initialH;                                                                                    // 133
            var initialW = $(element).width();                                                                        // 134
            var finalw = initialW;                                                                                    // 135
            var cellw = grid.cellWidth();                                                                             // 136
            var cellh = grid.cellHeight();                                                                            // 137
            var cells_wide = $(element).data("gs-width");                                                             // 138
            var cells_high = $(element).data('gs-height');                                                            // 139
                                                                                                                      //
            var widgetElement = $(".widgetContainer", element);                                                       // 141
            var iframeElement = $(".jsbin-embed", element);                                                           // 142
                                                                                                                      //
            $(widgetElement).width(finalw - 25);                                                                      // 144
            $(widgetElement).height(finalh - 15);                                                                     // 145
                                                                                                                      //
            $(iframeElement).css("max-height", "");                                                                   // 147
            $(iframeElement).css("max-width", "");                                                                    // 148
            $(iframeElement).css("min-height", "");                                                                   // 149
            $(iframeElement).css("min-width", "");                                                                    // 150
                                                                                                                      //
            $(iframeElement).width(finalw - 35);                                                                      // 152
            $(iframeElement).css("max-width", finalw - 35);                                                           // 153
            $(iframeElement).height(finalh - 25);                                                                     // 154
            $(iframeElement).css("max-height", finalh - 25);                                                          // 155
          });                                                                                                         // 157
        }                                                                                                             // 158
      });                                                                                                             // 159
                                                                                                                      //
      $('.grid-stack').on('dragstop', function (event, ui) {                                                          // 163
        // for some reason the moved grid-item doesn't have access to the widgetId data attribute, so get it here and hang onto it.
        var target_url = $(event.target).data("widget-id");                                                           // 165
        // save new order when items are moved.                                                                       // 166
        var grid = $(this).data('gridstack');                                                                         // 167
        var nodes = grid.grid.nodes;                                                                                  // 168
        for (var i = 0; i < nodes.length; i++) {                                                                      // 169
          var node = nodes[i];                                                                                        // 170
          var id = $(node.el).data('widgetId');                                                                       // 171
          // get widget code, update sort-order                                                                       // 172
          if (typeof id == "undefined") {                                                                             // 173
            id = target_url;                                                                                          // 174
          }                                                                                                           // 175
          if (typeof id != "undefined") {                                                                             // 176
            (function (_id) {                                                                                         // 177
              var widget = Widgets.findOne({ url: _id }); //.map(setWidgetDefaults);                                  // 178
              widget.sort_order = i;                                                                                  // 179
              Widgets.update(widget._id, widget, {}, function (arg1, arg2) {});                                       // 180
            })(id);                                                                                                   // 182
          } else {                                                                                                    // 183
            //            console.log(node);                                                                          // 184
          }                                                                                                           // 185
        }                                                                                                             // 186
      });                                                                                                             // 187
                                                                                                                      //
      $('.grid-stack').on('resizestop', function (event, items) {                                                     // 189
        var grid = this;                                                                                              // 190
        var element = event.target;                                                                                   // 191
        var widgetElement = $(".widgetContainer", element);                                                           // 192
        var iframeElement = $(".jsbin-embed", element);                                                               // 193
        // need to wait just a bit for the size to quantize to the grid...                                            // 194
        setTimeout(function () {                                                                                      // 195
          var initialH = $(element).height();                                                                         // 196
          var finalh = initialH;                                                                                      // 197
          var initialW = $(element).width();                                                                          // 198
          var finalw = initialW;                                                                                      // 199
          var widgetID = $(widgetElement).data("url");                                                                // 200
          var widget = Widgets.findOne({ url: widgetID }); //.map(setWidgetDefaults);                                 // 201
          $(widgetElement).width(finalw - 35);                                                                        // 202
          $(widgetElement).height(finalh - 15);                                                                       // 203
                                                                                                                      //
          $(iframeElement).css("max-height", "");                                                                     // 205
          $(iframeElement).css("max-width", "");                                                                      // 206
          $(iframeElement).css("min-height", "");                                                                     // 207
          $(iframeElement).css("min-width", "");                                                                      // 208
                                                                                                                      //
          $(iframeElement).width(finalw - 35);                                                                        // 210
          $(iframeElement).css("max-width", finalw - 35);                                                             // 211
          $(iframeElement).height(finalh - 25);                                                                       // 212
          $(iframeElement).css("max-height", finalh - 25);                                                            // 213
                                                                                                                      //
          var cellw = $(grid).data("gridstack").opts.cellWidth;                                                       // 215
          var cellh = $(grid).data("gridstack").opts.cellHeight;                                                      // 216
          var cells_wide = $(element).data("gs-width");                                                               // 217
          var cells_high = $(element).data('gs-height');                                                              // 218
                                                                                                                      //
          widget.width_in_cells = cells_wide;                                                                         // 220
          widget.height_in_cells = cells_high;                                                                        // 221
          widget.width_in_px = finalw;                                                                                // 222
          widget.height_in_px = finalh;                                                                               // 223
          Widgets.update(widget._id, widget);                                                                         // 224
        }, 350);                                                                                                      // 225
      });                                                                                                             // 227
                                                                                                                      //
      $('.grid-stack').data("inited", true);                                                                          // 229
    });                                                                                                               // 231
                                                                                                                      //
    /////// WIDGET ONRENDERED                                                                                         // 233
    // In the client code, below everything else                                                                      // 234
    Template.widget.onRendered(function () {                                                                          // 235
      var thisisnew = false;                                                                                          // 236
                                                                                                                      //
      if (justaddedid == this.data._id) {                                                                             // 238
        thisisnew = true; // this node was just added.                                                                // 239
      }                                                                                                               // 240
      var context = Template.currentData();                                                                           // 241
      var firstNode = this.firstNode;                                                                                 // 242
      var firstNodeId = $(firstNode).data("widget-id");                                                               // 243
      var lastNode = this.lastNode;                                                                                   // 244
      var lastNodeId = $(lastNode).data("widget-id");                                                                 // 245
                                                                                                                      //
      var grid = $(".grid-stack").data('gridstack');                                                                  // 247
      var widgetElement = $("#widgetContainer_" + this.data._id);                                                     // 248
      var griditem = $(widgetElement).parent().parent();                                                              // 249
                                                                                                                      //
      if (!thisisnew && grid) {                                                                                       // 251
        console.log("widget Rendered");                                                                               // 252
        console.log(this.data._id);                                                                                   // 253
        console.log(this.data.sort_order);                                                                            // 254
        grid.addWidget(this.$('.grid-stack-item'));                                                                   // 255
      } else {                                                                                                        // 256
        console.log("no grid?");                                                                                      // 257
      }                                                                                                               // 258
      // find out if the widget has been added to the grid.                                                           // 259
                                                                                                                      //
      if (thisisnew) {                                                                                                // 261
        grid.makeWidget(griditem);                                                                                    // 262
        grid.move(griditem, 0, 0);                                                                                    // 263
        var node = grid.grid.getNodeDataByDOMEl(griditem);                                                            // 264
        //  grid.grid._fixCollisions(griditem);                                                                       // 265
      }                                                                                                               // 266
      if (!$('.grid-stack').data("inited")) {}                                                                        // 267
      // end resizable grid setup                                                                                     // 270
                                                                                                                      //
                                                                                                                      //
      (function (widget, isnew) {                                                                                     // 274
        var thisid = widget.data._id;                                                                                 // 275
        var element = document.getElementById('jsbin_' + thisid);                                                     // 276
        var thiselement = document.getElementById('widgetContainer_' + thisid);                                       // 277
        $(".widgetDisplayHeader", thiselement).hide();                                                                // 278
                                                                                                                      //
        // maybe already exists?                                                                                      // 280
        var theElement = document.getElementById('jsbin_' + thisid);                                                  // 281
        if (theElement && theElement.contentWindow && theElement.contentWindow.document) {                            // 282
          $(theElement).load(function () {                                                                            // 283
            var widgetElement = document.getElementById('widgetContainer_' + thisid);                                 // 284
            var editors = jsbin = menu = bin = null;                                                                  // 285
            if (theElement) {                                                                                         // 286
              editors = theElement.contentWindow.editors;                                                             // 287
              jsbin = theElement.contentWindow.jsbin;                                                                 // 288
              menu = theElement.contentWindow.document.getElementById("control");                                     // 289
              bin = theElement.contentWindow.document.getElementById("bin");                                          // 290
              var thiselement = document.getElementById('widgetContainer_' + thisid);                                 // 291
              if (jsbin && jsbin.panels) {                                                                            // 292
                jsbin.panels.saveOnExit = true;                                                                       // 293
              }                                                                                                       // 294
              setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, thisid, isnew);                    // 295
            } else {                                                                                                  // 296
              console.log("no element found for jsbin_" + thisid);                                                    // 297
            }                                                                                                         // 298
          });                                                                                                         // 299
        }                                                                                                             // 300
        // this part here happens when the JSBIN stuff is loaded.                                                     // 301
        (function (this_id, isnew) {                                                                                  // 302
          if (isnew) {                                                                                                // 303
            var widgetElement = document.getElementById('widgetContainer_' + this_id);                                // 304
            var editors = jsbin = menu = bin = null;                                                                  // 305
            var theElement = document.getElementById('jsbin_' + this_id);                                             // 306
            if (theElement) {                                                                                         // 307
              editors = theElement.contentWindow.editors;                                                             // 308
              jsbin = theElement.contentWindow.jsbin;                                                                 // 309
              menu = theElement.contentWindow.document.getElementById("control");                                     // 310
              bin = theElement.contentWindow.document.getElementById("bin");                                          // 311
              if (jsbin && jsbin.panels) {                                                                            // 312
                jsbin.panels.saveOnExit = true;                                                                       // 313
              }                                                                                                       // 314
              setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, this_id, isnew);                   // 315
            } else {                                                                                                  // 316
              console.log("no element found for jsbin_" + this_id);                                                   // 317
            }                                                                                                         // 318
          }                                                                                                           // 319
                                                                                                                      //
          document.addEventListener("DOMNodeInserted", function (evt, item) {                                         // 322
            (function (_evt, _this_id, isnew) {                                                                       // 323
              if ($(_evt.target)[0].tagName == "IFRAME" && $(_evt.target)[0].id.replace("jsbin_", "") == _this_id) {  // 324
                $(_evt.target).load(function () {                                                                     // 325
                  var widgetElement = document.getElementById('widgetContainer_' + _this_id);                         // 326
                  var editors = jsbin = menu = bin = null;                                                            // 327
                  var theElement = document.getElementById('jsbin_' + _this_id);                                      // 328
                  if (theElement) {                                                                                   // 329
                    editors = theElement.contentWindow.editors;                                                       // 330
                    jsbin = theElement.contentWindow.jsbin;                                                           // 331
                    menu = theElement.contentWindow.document.getElementById("control");                               // 332
                    bin = theElement.contentWindow.document.getElementById("bin");                                    // 333
                    if (jsbin && jsbin.panels) {                                                                      // 334
                      jsbin.panels.saveOnExit = true;                                                                 // 335
                    }                                                                                                 // 336
                    setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, _this_id, isnew);            // 337
                  } else {                                                                                            // 338
                    console.log("no element found for jsbin_" + _this_id);                                            // 339
                  }                                                                                                   // 340
                });                                                                                                   // 341
              }                                                                                                       // 342
            })(evt, this_id, isnew);                                                                                  // 343
          });                                                                                                         // 344
        })(thisid, isnew);                                                                                            // 345
      })(this, thisisnew);                                                                                            // 346
    });                                                                                                               // 347
                                                                                                                      //
    Template.help.events({                                                                                            // 391
      "click .giphy": function () {                                                                                   // 392
        function clickGiphy(e, t) {                                                                                   // 392
          $(e.target).hide();                                                                                         // 393
        }                                                                                                             // 394
                                                                                                                      //
        return clickGiphy;                                                                                            // 392
      }()                                                                                                             // 392
    });                                                                                                               // 391
                                                                                                                      //
    Template.widget.events({                                                                                          // 397
                                                                                                                      //
      "click .giphy": function () {                                                                                   // 399
        function clickGiphy(e, t) {                                                                                   // 399
          $(e.target).hide();                                                                                         // 400
        }                                                                                                             // 401
                                                                                                                      //
        return clickGiphy;                                                                                            // 399
      }(),                                                                                                            // 399
                                                                                                                      //
      "click .delete": function () {                                                                                  // 403
        function clickDelete() {                                                                                      // 403
                                                                                                                      //
          var grid = $(".grid-stack").data("gridstack");                                                              // 405
                                                                                                                      //
          var widgetElement = $("#widgetContainer_" + this._id);                                                      // 407
          var griditem = $(widgetElement).parent().parent();                                                          // 408
                                                                                                                      //
          grid.removeWidget(griditem, true);                                                                          // 410
                                                                                                                      //
          if (this.isTemplate) {                                                                                      // 412
            this.pagetype = "template";                                                                               // 413
            Widgets.update(this._id, this);                                                                           // 414
          } else {                                                                                                    // 415
            Widgets.remove(this._id);                                                                                 // 416
          }                                                                                                           // 417
          giphy_modal("erase", "Widget Deleted");                                                                     // 418
          return false;                                                                                               // 419
        }                                                                                                             // 420
                                                                                                                      //
        return clickDelete;                                                                                           // 403
      }(),                                                                                                            // 403
                                                                                                                      //
      "click .save": function () {                                                                                    // 422
        function clickSave() {                                                                                        // 422
          var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                           // 423
          var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                               // 424
          var revision = jsbin.state.revision;                                                                        // 425
                                                                                                                      //
          this.html = editors.html.getCode();                                                                         // 427
          this.javascript = editors.javascript.getCode();                                                             // 428
          this.css = editors.css.getCode();                                                                           // 429
          jsbin.saveDisabled = false;                                                                                 // 430
          jsbin.panels.save();                                                                                        // 431
          jsbin.panels.savecontent();                                                                                 // 432
          Widgets.update(this._id, this);                                                                             // 433
                                                                                                                      //
          // also trigger the jsbin save                                                                              // 435
          var dataobj = { html: this.html, css: this.css, javascript: this.javascript };                              // 436
          var url = "/api/" + this.url + "/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,              // 437
          var options = { data: dataobj };                                                                            // 438
          HTTP.post(url, options, function (error, results) {});                                                      // 439
                                                                                                                      //
          giphy_modal("saved", "Widget Content Saved");                                                               // 442
                                                                                                                      //
          return false;                                                                                               // 444
        }                                                                                                             // 445
                                                                                                                      //
        return clickSave;                                                                                             // 422
      }(),                                                                                                            // 422
                                                                                                                      //
      "click .call_webservice_url": function () {                                                                     // 448
        function clickCall_webservice_url(evt, template) {                                                            // 448
          $("#webservice_insert_modal").modal('show');                                                                // 449
                                                                                                                      //
          $("#webservice_insert_modal_submit").click(function () {                                                    // 451
            var jsbin_id = 'jsbin_' + template.data.url;                                                              // 452
                                                                                                                      //
            var url = $("#webservice_insert_url").val().trim();                                                       // 455
            var name = $("#webservice_insert_name").val().trim();                                                     // 456
            var auth_token = $("#webservice_insert_auth_token").val().trim();                                         // 457
            var return_type = $("input[name=webservice_insert_return_type]:checked").val().trim();                    // 458
                                                                                                                      //
            url = url.replace("||PAGEID||", "'+pageId()+'");                                                          // 460
            url = url.replace("||PAGETYPE||", "'+pageType()+'");                                                      // 461
                                                                                                                      //
            var token_string;                                                                                         // 463
            if (auth_token) {                                                                                         // 464
              token_string = " \n authentication_token : '" + auth_token + "',";                                      // 465
            }                                                                                                         // 466
                                                                                                                      //
            var codeString = "{\n id:'" + name + "', \n type: 'webservice', " + token_string + " \n return_type: '" + return_type + "', \n url: '" + url + "' \n}";
            var codeStringRe = "\\{\n id:'" + name + "', \n type: 'webservice', \n return_type: '" + return_type + "', \n url: '" + url + "' \n\\}";
            var comments = " this will hold a " + return_type + " object";                                            // 470
                                                                                                                      //
            insert_code(jsbin_id, codeString, codeStringRe, comments);                                                // 472
          });                                                                                                         // 474
        }                                                                                                             // 477
                                                                                                                      //
        return clickCall_webservice_url;                                                                              // 448
      }(),                                                                                                            // 448
                                                                                                                      //
      "click .add_code": function () {                                                                                // 479
        function clickAdd_code(evt, template) {                                                                       // 479
                                                                                                                      //
          var pullfrom = evt.currentTarget.dataset.pullfrom;                                                          // 481
          var pulltype = evt.currentTarget.dataset.pulltype;                                                          // 482
                                                                                                                      //
          if (this.url == template.data.url) {                                                                        // 484
            return false;                                                                                             // 485
          }                                                                                                           // 486
                                                                                                                      //
          var type;                                                                                                   // 488
          var comments = "";                                                                                          // 489
          if (pulltype == "data") {                                                                                   // 490
            type = "data";                                                                                            // 491
            comments = " This will hold a JSON object";                                                               // 492
          }                                                                                                           // 493
          if (pulltype == "html") {                                                                                   // 494
            type = "html";                                                                                            // 495
            comments = " This will hold a jQuery object";                                                             // 496
          }                                                                                                           // 497
          var codeString = "{from: '" + pullfrom + "', type : '" + pulltype + "'}";                                   // 498
          var codeStringRe = "\\{from: '" + pullfrom + "', type : '" + pulltype + "'\\}";                             // 499
                                                                                                                      //
          var jsbin_id = 'jsbin_' + template.data.url;                                                                // 501
                                                                                                                      //
          insert_code(jsbin_id, codeString, codeStringRe, comments);                                                  // 503
                                                                                                                      //
          return true;                                                                                                // 505
        }                                                                                                             // 506
                                                                                                                      //
        return clickAdd_code;                                                                                         // 479
      }(),                                                                                                            // 479
                                                                                                                      //
      "click .test": function () {                                                                                    // 510
        function clickTest() {                                                                                        // 510
          var thiselement = document.getElementById('widgetContainer_' + this._id);                                   // 511
          var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                           // 512
          var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                               // 513
          var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");   // 514
          var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");        // 515
                                                                                                                      //
          var newbintop = 0;                                                                                          // 517
          this.maxed = !this.maxed;                                                                                   // 518
          if (this.maxed) {                                                                                           // 519
            $(menu).hide();                                                                                           // 520
            $(".editmodeonly", thiselement).hide();                                                                   // 521
            this.oldbintop = $(bin).css("top");                                                                       // 522
            $(bin).css("top", newbintop);                                                                             // 523
          } else {                                                                                                    // 524
            $(menu).show();                                                                                           // 525
            $(".editmodeonly", thiselement).show();                                                                   // 526
            $(bin).css("top", this.oldbintop);                                                                        // 527
          }                                                                                                           // 528
          return false;                                                                                               // 529
        }                                                                                                             // 530
                                                                                                                      //
        return clickTest;                                                                                             // 510
      }(),                                                                                                            // 510
      /*                                                                                                              // 531
      panel ids: html, css, javascript, console, live                                                                 //
      */                                                                                                              //
                                                                                                                      //
      // this sets it to EDIT mode                                                                                    // 535
      "click .widgetUnlock": function () {                                                                            // 536
        function clickWidgetUnlock() {                                                                                // 536
                                                                                                                      //
          var widgetElement = document.getElementById('widgetContainer_' + this._id);                                 // 538
          var iframeElement = document.getElementById('jsbin_' + this._id);                                           // 539
                                                                                                                      //
          var editors = iframeElement.contentWindow.editors;                                                          // 541
          var jsbin = iframeElement.contentWindow.jsbin;                                                              // 542
          var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");   // 543
          var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");        // 544
                                                                                                                      //
          setEditModeOn(this, iframeElement, widgetElement, menu, bin, jsbin);                                        // 546
                                                                                                                      //
          return false;                                                                                               // 548
        }                                                                                                             // 549
                                                                                                                      //
        return clickWidgetUnlock;                                                                                     // 536
      }(),                                                                                                            // 536
                                                                                                                      //
      // this sets it to DISPLAY mode                                                                                 // 552
      "click .widgetLock": function () {                                                                              // 553
        function clickWidgetLock() {                                                                                  // 553
                                                                                                                      //
          var widgetElement = document.getElementById('widgetContainer_' + this._id);                                 // 555
          var iframeElement = document.getElementById('jsbin_' + this._id);                                           // 556
                                                                                                                      //
          var editors = iframeElement.contentWindow.editors;                                                          // 558
          var jsbin = iframeElement.contentWindow.jsbin;                                                              // 559
          var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");   // 560
          var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");        // 561
          setDisplayModeOn(this, iframeElement, widgetElement, menu, bin, jsbin, this._id, false);                    // 562
                                                                                                                      //
          return false;                                                                                               // 564
        }                                                                                                             // 565
                                                                                                                      //
        return clickWidgetLock;                                                                                       // 553
      }(),                                                                                                            // 553
                                                                                                                      //
      // setting visibility on widgets (public or private)                                                            // 568
      "click .setpublic": function () {                                                                               // 569
        function clickSetpublic() {                                                                                   // 569
          this.visibility = "public";                                                                                 // 570
          Widgets.update(this._id, this);                                                                             // 571
          return false;                                                                                               // 572
        }                                                                                                             // 573
                                                                                                                      //
        return clickSetpublic;                                                                                        // 569
      }(),                                                                                                            // 569
      "click .setprivate": function () {                                                                              // 574
        function clickSetprivate() {                                                                                  // 574
          this.visibility = "private";                                                                                // 575
          Widgets.update(this._id, this);                                                                             // 576
          return false;                                                                                               // 577
        }                                                                                                             // 578
                                                                                                                      //
        return clickSetprivate;                                                                                       // 574
      }(),                                                                                                            // 574
                                                                                                                      //
      "click .order_up": function () {                                                                                // 580
        function clickOrder_up() {                                                                                    // 580
          this.sort_order--;                                                                                          // 581
          Widgets.update(this._id, this);                                                                             // 582
          return false;                                                                                               // 583
        }                                                                                                             // 584
                                                                                                                      //
        return clickOrder_up;                                                                                         // 580
      }(),                                                                                                            // 580
                                                                                                                      //
      "click .order_down": function () {                                                                              // 586
        function clickOrder_down() {                                                                                  // 586
          this.sort_order++;                                                                                          // 587
          Widgets.update(this._id, this);                                                                             // 588
          return false;                                                                                               // 589
        }                                                                                                             // 590
                                                                                                                      //
        return clickOrder_down;                                                                                       // 586
      }(),                                                                                                            // 586
                                                                                                                      //
      "click .nonclickable": function () {                                                                            // 592
        function clickNonclickable() {                                                                                // 592
          return false;                                                                                               // 593
        }                                                                                                             // 594
                                                                                                                      //
        return clickNonclickable;                                                                                     // 592
      }(),                                                                                                            // 592
                                                                                                                      //
      'click .copy': function () {                                                                                    // 597
        function clickCopy() {                                                                                        // 597
          var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                               // 598
          var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                  // 599
          var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                               // 600
          var options = { data: dataobj };                                                                            // 601
                                                                                                                      //
          HTTP.post(url, options, function (error, results) {                                                         // 603
            newWidget = { _id: results.data.url,                                                                      // 604
              createdBy: { username: Meteor.user().username,                                                          // 605
                userid: Meteor.userId() },                                                                            // 606
              isTemplate: false,                                                                                      // 607
              html: results.data.html,                                                                                // 608
              javascript: results.data.javascript,                                                                    // 609
              css: results.data.css,                                                                                  // 610
              displayWidth: template.displayWidth,                                                                    // 611
              displayHeight: template.displayHeight,                                                                  // 612
              description: "(copied from " + template.name + ") " + template.description,                             // 613
              widgetStyle: template.widgetStyle,                                                                      // 614
              name: "copy of " + template.name,                                                                       // 615
              pagetype: pageinfo().pagetype,                                                                          // 616
              pageurl: pageinfo().pageurl,                                                                            // 617
              pageid: pageinfo().pageid,                                                                              // 618
              url: results.data.url,                                                                                  // 619
              createdAt: new Date(),                                                                                  // 620
              visibility: "private",                                                                                  // 621
              rand: Math.random() };                                                                                  // 622
            Widgets.insert(newWidget);                                                                                // 623
          });                                                                                                         // 624
                                                                                                                      //
          giphy_modal("copy", "widget copied");                                                                       // 626
                                                                                                                      //
          return false;                                                                                               // 628
        }                                                                                                             // 629
                                                                                                                      //
        return clickCopy;                                                                                             // 597
      }(),                                                                                                            // 597
                                                                                                                      //
      "click .save_template": function () {                                                                           // 632
        function clickSave_template() {                                                                               // 632
          this.isTemplate = !this.isTemplate;                                                                         // 633
          Widgets.update(this._id, this);                                                                             // 634
          var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                           // 635
          var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                               // 636
                                                                                                                      //
          giphy_modal("promotion", "widget saved as a template");                                                     // 638
                                                                                                                      //
          return false;                                                                                               // 640
        }                                                                                                             // 641
                                                                                                                      //
        return clickSave_template;                                                                                    // 632
      }(),                                                                                                            // 632
                                                                                                                      //
      "click .save_to_library": function () {                                                                         // 643
        function clickSave_to_library() {                                                                             // 643
          this.isTemplate = !this.isTemplate;                                                                         // 644
          //      Widgets.update(this._id, this);                                                                     // 645
                                                                                                                      //
          var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                               // 647
          var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                  // 648
          var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                               // 649
          var options = { data: dataobj };                                                                            // 650
                                                                                                                      //
          var newpagetype = "user_libs";                                                                              // 652
          var newpageid = Meteor.user().username;                                                                     // 653
          var newpageurl = newpagetype + "/" + newpageurl;                                                            // 654
                                                                                                                      //
          HTTP.post(url, options, function (error, results) {                                                         // 656
            newWidget = { _id: results.data.url,                                                                      // 657
              createdBy: { username: Meteor.user().username,                                                          // 658
                userid: Meteor.userId() },                                                                            // 659
              inLibrary: true,                                                                                        // 660
              html: results.data.html,                                                                                // 661
              javascript: results.data.javascript,                                                                    // 662
              css: results.data.css,                                                                                  // 663
              displayWidth: template.displayWidth,                                                                    // 664
              displayHeight: template.displayHeight,                                                                  // 665
              description: "(copied from " + template.name + ") " + template.description,                             // 666
              widgetStyle: template.widgetStyle,                                                                      // 667
              name: "copy of " + template.name,                                                                       // 668
              pagetype: newpagetype,                                                                                  // 669
              pageurl: newpageurl,                                                                                    // 670
              pageid: newpageid,                                                                                      // 671
              this_page_only: true,                                                                                   // 672
              url: results.data.url,                                                                                  // 673
              createdAt: new Date(),                                                                                  // 674
              visibility: "private",                                                                                  // 675
              rand: Math.random() };                                                                                  // 676
            Widgets.insert(newWidget);                                                                                // 677
          });                                                                                                         // 678
                                                                                                                      //
          giphy_modal("library", "widget added to your library");                                                     // 680
                                                                                                                      //
          return false;                                                                                               // 682
        }                                                                                                             // 683
                                                                                                                      //
        return clickSave_to_library;                                                                                  // 643
      }(),                                                                                                            // 643
                                                                                                                      //
      "click .openinfo": function () {                                                                                // 685
        function clickOpeninfo() {                                                                                    // 685
          var thiselement = document.getElementById('widgetContainer_' + this._id);                                   // 686
          var mode = $(thiselement).data("mode");                                                                     // 687
          if (!mode || mode == "display") {                                                                           // 688
            //      $(".widgetMouseOverTarget", thiselement ).css("background", "red");                               // 689
            $(".widgetDisplayHeader", thiselement).show();                                                            // 690
            $(".widgetMouseOverTarget", thiselement).css("z-index", 5);                                               // 691
            $(".widgetDisplayHeader", thiselement).css("z-index", 10);                                                // 692
          }                                                                                                           // 693
        }                                                                                                             // 694
                                                                                                                      //
        return clickOpeninfo;                                                                                         // 685
      }(),                                                                                                            // 685
                                                                                                                      //
      "mouseleave .widgetDisplayHeader": function () {                                                                // 697
        function mouseleaveWidgetDisplayHeader() {                                                                    // 697
          var thiselement = document.getElementById('widgetContainer_' + this._id);                                   // 698
          $(".widgetMouseOverTarget", thiselement).css("background", "transparent");                                  // 699
          $(".widgetDisplayHeader", thiselement).hide();                                                              // 700
          $(".widgetMouseOverTarget", thiselement).css("z-index", 10);                                                // 701
          $(".widgetDisplayHeader", thiselement).css("z-index", 5);                                                   // 702
        }                                                                                                             // 703
                                                                                                                      //
        return mouseleaveWidgetDisplayHeader;                                                                         // 697
      }()                                                                                                             // 697
                                                                                                                      //
    });                                                                                                               // 397
    ////// END EVENTS                                                                                                 // 707
                                                                                                                      //
                                                                                                                      //
    ////// HELPERS                                                                                                    // 710
                                                                                                                      //
    widgetIncrement = 0;                                                                                              // 712
    Template.widget.helpers({                                                                                         // 713
      otherwidgets: function () {                                                                                     // 714
        function otherwidgets() {                                                                                     // 714
          // Otherwise, return all of the tasks                                                                       // 715
          return Widgets.find({ pagetype: pageinfo().pagetype, _id: { $ne: this._id } }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
        }                                                                                                             // 717
                                                                                                                      //
        return otherwidgets;                                                                                          // 714
      }(),                                                                                                            // 714
                                                                                                                      //
      isPublic: function () {                                                                                         // 719
        function isPublic() {                                                                                         // 719
          if (this.visibility == "public") {                                                                          // 720
            return true;                                                                                              // 721
          }                                                                                                           // 722
          return false;                                                                                               // 723
        }                                                                                                             // 724
                                                                                                                      //
        return isPublic;                                                                                              // 719
      }(),                                                                                                            // 719
                                                                                                                      //
      pageTypeAndUrl: function () {                                                                                   // 726
        function pageTypeAndUrl() {                                                                                   // 726
                                                                                                                      //
          return "_pt_" + this.pagetype + "/" + this.url;                                                             // 728
        }                                                                                                             // 729
                                                                                                                      //
        return pageTypeAndUrl;                                                                                        // 726
      }(),                                                                                                            // 726
                                                                                                                      //
      pageUrlAndUrl: function () {                                                                                    // 731
        function pageUrlAndUrl() {                                                                                    // 731
          return "_pu_" + pageinfo().pageurl + "/" + this.url;                                                        // 732
        }                                                                                                             // 733
                                                                                                                      //
        return pageUrlAndUrl;                                                                                         // 731
      }(),                                                                                                            // 731
                                                                                                                      //
      commentsCount: function () {                                                                                    // 735
        function commentsCount(id) {                                                                                  // 735
          var value = "";                                                                                             // 736
          return value;                                                                                               // 737
        }                                                                                                             // 738
                                                                                                                      //
        return commentsCount;                                                                                         // 735
      }(),                                                                                                            // 735
                                                                                                                      //
      isMyWidget: function () {                                                                                       // 740
        function isMyWidget() {                                                                                       // 740
          // is this a widget I created?                                                                              // 741
          if (getUserXtras().godmode) {                                                                               // 742
            return true;                                                                                              // 743
          }                                                                                                           // 744
          if (this.createdBy && Meteor.user()) {                                                                      // 745
            return this.createdBy.username == Meteor.user().username;                                                 // 746
          } else {                                                                                                    // 747
            return false;                                                                                             // 748
          }                                                                                                           // 749
        }                                                                                                             // 750
                                                                                                                      //
        return isMyWidget;                                                                                            // 740
      }(),                                                                                                            // 740
                                                                                                                      //
      widgetIncrement: function (_widgetIncrement) {                                                                  // 752
        function widgetIncrement() {                                                                                  // 752
          return _widgetIncrement.apply(this, arguments);                                                             // 752
        }                                                                                                             // 752
                                                                                                                      //
        widgetIncrement.toString = function () {                                                                      // 752
          return _widgetIncrement.toString();                                                                         // 752
        };                                                                                                            // 752
                                                                                                                      //
        return widgetIncrement;                                                                                       // 752
      }(function () {                                                                                                 // 752
        var ret = widgetIncrement;                                                                                    // 753
        if (typeof this.widgetIncrement == "undefined") {                                                             // 754
          this.widgetIncrement = widgetIncrement;                                                                     // 755
          widgetIncrement++;                                                                                          // 756
        } else {                                                                                                      // 757
          ret = this.widgetIncrement;                                                                                 // 758
        }                                                                                                             // 759
        return ret;                                                                                                   // 760
      }),                                                                                                             // 761
                                                                                                                      //
      userXtras: function () {                                                                                        // 763
        function userXtras() {                                                                                        // 763
          return getUserXtras();                                                                                      // 764
        }                                                                                                             // 765
                                                                                                                      //
        return userXtras;                                                                                             // 763
      }(),                                                                                                            // 763
                                                                                                                      //
      godmode: function () {                                                                                          // 767
        function godmode() {                                                                                          // 767
          return getUserXtras().godmode;                                                                              // 768
        }                                                                                                             // 770
                                                                                                                      //
        return godmode;                                                                                               // 767
      }()                                                                                                             // 767
    });                                                                                                               // 713
                                                                                                                      //
    Template.allWidgetsLoaded.onRendered(function () {                                                                // 775
      console.log("aaaaaall widgets loaded");                                                                         // 776
    });                                                                                                               // 777
    //////// END HELPERS                                                                                              // 778
  })();                                                                                                               // 2
}                                                                                                                     // 779
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{"extensions":[".js",".json"]});
require("./server/smtp.js");
require("./C5.js");
require("./common_functions.js");
require("./widget.js");
//# sourceMappingURL=app.js.map
