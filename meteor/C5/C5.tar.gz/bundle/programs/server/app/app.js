var require = meteorInstall({"server":{"smtp.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/smtp.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      //
Meteor.startup(function () {                                                                                          // 2
                                                                                                                      //
    Accounts.emailTemplates.siteName = "c5.boomhifive.com";                                                           // 4
    Accounts.emailTemplates.from = "C5 Admin <c5@boomhifive.com>";                                                    // 5
    Accounts.emailTemplates.enrollAccount.subject = function (user) {                                                 // 6
        return "Welcome to C5, " + user.profile.name;                                                                 // 7
    };                                                                                                                // 8
    Accounts.emailTemplates.resetPassword.from = function () {                                                        // 9
        // Overrides value set in Accounts.emailTemplates.from when resetting passwords                               // 10
        return "C5 Admin <c5@boomhifive.com>";                                                                        // 11
    };                                                                                                                // 12
    Accounts.emailTemplates.resetPassword.text = function (user, url) {                                               // 13
        var text = "Heard you need to reset your password. No biggie, it happens.";                                   // 14
        text += "\n Just open this url to reset your password: " + url;                                               // 15
        return text;                                                                                                  // 16
    };                                                                                                                // 17
});                                                                                                                   // 18
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"C5.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// C5.js                                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      //
Widgets = new Mongo.Collection("widgets");                                                                            // 2
UserXtras = new Mongo.Collection("userxtras");                                                                        // 3
                                                                                                                      //
// set GLOBAL VARS                                                                                                    // 5
//In the client side                                                                                                  // 6
SERVER_NAME = "localhost";                                                                                            // 7
SERVER_IP = "localhost";                                                                                              // 8
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 10
  Meteor.call('getServerName', function (err, results) {                                                              // 11
    SERVER_NAME = results;                                                                                            // 12
  });                                                                                                                 // 13
  Meteor.call('getServerIP', function (err, results) {                                                                // 14
    SERVER_IP = results;                                                                                              // 15
  });                                                                                                                 // 16
}                                                                                                                     // 17
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 20
                                                                                                                      //
  Meteor.startup(function () {                                                                                        // 22
    /*                                                                                                                // 23
    var to ="donundeen@gmail.com";                                                                                    //
    var from = "c5@boomhifive.com";                                                                                   //
    var subject = "C5 started";                                                                                       //
    var text = "notifying you that C5 started";                                                                       //
    console.log("sending email");                                                                                     //
    Email.send({                                                                                                      //
      to: to,                                                                                                         //
      from: from,                                                                                                     //
      subject: subject,                                                                                               //
      text: text                                                                                                      //
    });                                                                                                               //
    */                                                                                                                //
  });                                                                                                                 // 36
                                                                                                                      //
  Meteor.methods({                                                                                                    // 39
    getServerName: function () {                                                                                      // 40
      function getServerName() {                                                                                      // 40
        SERVER_NAME = process.env.SERVER_NAME;                                                                        // 41
        if (typeof SERVER_NAME === "undefined") {                                                                     // 42
          SERVER_NAME = "localhost";                                                                                  // 43
        }                                                                                                             // 44
        return SERVER_NAME;                                                                                           // 45
      }                                                                                                               // 46
                                                                                                                      //
      return getServerName;                                                                                           // 40
    }(),                                                                                                              // 40
    getServerIP: function () {                                                                                        // 47
      function getServerIP() {                                                                                        // 47
        SERVER_IP = process.env.SERVER_IP;                                                                            // 48
        if (typeof SERVER_IP === "undefined") {                                                                       // 49
          SERVER_IP = "localhost";                                                                                    // 50
        }                                                                                                             // 51
        return SERVER_IP;                                                                                             // 52
      }                                                                                                               // 53
                                                                                                                      //
      return getServerIP;                                                                                             // 47
    }()                                                                                                               // 47
  });                                                                                                                 // 39
}                                                                                                                     // 55
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 57
                                                                                                                      //
  Meteor.startup(function () {                                                                                        // 60
    console.log("starting meteor");                                                                                   // 61
    $(window).bind('beforeunload', function () {                                                                      // 62
      $(".save").trigger("click");                                                                                    // 63
    });                                                                                                               // 64
  });                                                                                                                 // 66
                                                                                                                      //
  /// comments config                                                                                                 // 71
  // On the Client                                                                                                    // 72
  Comments.ui.config({                                                                                                // 73
    template: 'bootstrap' // or ionic, semantic-ui                                                                    // 74
  });                                                                                                                 // 73
                                                                                                                      //
  ////// HELPERS                                                                                                      // 77
  UI.registerHelper('shortIt', function (stringToShorten, maxCharsAmount) {                                           // 78
    if (stringToShorten.length > maxCharsAmount) {                                                                    // 79
      return stringToShorten.substring(0, maxCharsAmount) + '...';                                                    // 80
    }                                                                                                                 // 81
    return stringToShorten;                                                                                           // 82
  });                                                                                                                 // 83
                                                                                                                      //
  UI.registerHelper('encodeURIComponent', function (string) {                                                         // 85
    return encodeURIComponent(string);                                                                                // 86
  });                                                                                                                 // 87
                                                                                                                      //
  UI.registerHelper('absoluteUrl', function () {                                                                      // 89
    return Meteor.absoluteUrl();                                                                                      // 90
  });                                                                                                                 // 91
                                                                                                                      //
  Accounts.ui.config({                                                                                                // 93
    passwordSignupFields: "USERNAME_AND_EMAIL"                                                                        // 94
  });                                                                                                                 // 93
                                                                                                                      //
  Template.registerHelper("pageid", function () {                                                                     // 97
    return pageinfo().pageid;                                                                                         // 98
  });                                                                                                                 // 99
                                                                                                                      //
  Template.registerHelper("pageurl", function () {                                                                    // 101
    return pageinfo().pageurl;                                                                                        // 102
  });                                                                                                                 // 103
                                                                                                                      //
  Template.registerHelper("pagetype", function () {                                                                   // 106
    return pageinfo().pagetype;                                                                                       // 107
  });                                                                                                                 // 108
                                                                                                                      //
  Template.registerHelper("pageid_neverblank", function () {                                                          // 110
    return "_pi_" + pageinfo().pageid;                                                                                // 111
  });                                                                                                                 // 112
                                                                                                                      //
  Template.registerHelper("pageurl_neverblank", function () {                                                         // 114
    return "_pu_" + pageinfo().pageurl;                                                                               // 115
  });                                                                                                                 // 116
  Template.registerHelper("pagetype_neverblank", function () {                                                        // 117
    return "_pt_" + pageinfo().pagetype;                                                                              // 118
  });                                                                                                                 // 119
                                                                                                                      //
  Template.registerHelper("numComments", function (commentId) {                                                       // 121
                                                                                                                      //
    var instance = Template.instance;                                                                                 // 123
                                                                                                                      //
    if (!instance.commentCounters) {                                                                                  // 125
      instance.commentCounters = {};                                                                                  // 126
    }                                                                                                                 // 127
    if (!instance.commentCounters[commentId]) {                                                                       // 128
      instance.commentCounters[commentId] = new ReactiveVar();                                                        // 129
    }                                                                                                                 // 130
    Comments.getCount(commentId, function (error, count) {                                                            // 131
      instance.commentCounters[commentId].set(count);                                                                 // 132
    });                                                                                                               // 133
    return instance.commentCounters[commentId].get();                                                                 // 134
  });                                                                                                                 // 135
                                                                                                                      //
  Template.registerHelper("commentIcon", function (commentId) {                                                       // 137
                                                                                                                      //
    var instance = Template.instance;                                                                                 // 139
                                                                                                                      //
    var noComments = "zmdi-comment";                                                                                  // 141
    var hasComments = "zmdi-comment-alert";                                                                           // 142
                                                                                                                      //
    if (!instance.commentIcons) {                                                                                     // 144
      instance.commentIcons = {};                                                                                     // 145
    }                                                                                                                 // 146
    if (!instance.commentIcons[commentId]) {                                                                          // 147
      instance.commentIcons[commentId] = new ReactiveVar();                                                           // 148
    }                                                                                                                 // 149
    Comments.getCount(commentId, function (error, count) {                                                            // 150
      if (count > 0) {                                                                                                // 151
        console.log(commentId + " has comments");                                                                     // 152
        instance.commentCounters[commentId].set("zmdi-comment-alert");                                                // 153
      } else {                                                                                                        // 154
        console.log(commentId + " no comments");                                                                      // 155
        instance.commentIcons[commentId].set("zmdi-comment");                                                         // 156
      }                                                                                                               // 157
    });                                                                                                               // 158
    return instance.commentIcons[commentId].get();                                                                    // 159
  });                                                                                                                 // 160
                                                                                                                      //
  Template.registerHelper("SERVER_NAME", function () {                                                                // 164
    return SERVER_NAME;                                                                                               // 165
  });                                                                                                                 // 166
  Template.registerHelper("SERVER_IP", function () {                                                                  // 167
    return SERVER_IP;                                                                                                 // 168
  });                                                                                                                 // 169
  Template.gridwidgets.helpers({                                                                                      // 170
    widgets: function () {                                                                                            // 171
      function widgets() {                                                                                            // 171
        // Otherwise, return all of the tasks                                                                         // 172
        var find = {                                                                                                  // 173
          this_page_only: { $in: [false, null] },                                                                     // 174
          pagetype: pageinfo().pagetype,                                                                              // 175
          $or: [{ visibility: "public" }, { $and: [{ visibility: "private" }, { "createdBy.userid": Meteor.userId() }] }, { visibility: null }]
        };                                                                                                            // 173
                                                                                                                      //
        //        var results = Widgets.find(find, {sort: {sort_order : -1, createdAt: -1}}).map(setWidgetDefaults); 
        var results = Widgets.find(find, { sort: { sort_order: 1 } }).map(setWidgetDefaults);                         // 187
        console.log("got results");                                                                                   // 188
        console.log(results);                                                                                         // 189
                                                                                                                      //
        return results;                                                                                               // 191
      }                                                                                                               // 192
                                                                                                                      //
      return widgets;                                                                                                 // 171
    }(),                                                                                                              // 171
    thisPageWidgets: function () {                                                                                    // 193
      function thisPageWidgets() {                                                                                    // 193
        // Otherwise, return all of the tasks                                                                         // 194
        var find = { this_page_only: true,                                                                            // 195
          pagetype: pageinfo().pagetype,                                                                              // 196
          pageid: pageinfo().pageid };                                                                                // 197
        var results = Widgets.find(find, { sort: { sort_order: 1, createdAt: -1 } }).map(setWidgetDefaults);          // 198
        return results;                                                                                               // 199
      }                                                                                                               // 200
                                                                                                                      //
      return thisPageWidgets;                                                                                         // 193
    }()                                                                                                               // 193
                                                                                                                      //
  });                                                                                                                 // 170
  Template.body.helpers({                                                                                             // 203
    widgets: function () {                                                                                            // 204
      function widgets() {                                                                                            // 204
        // Otherwise, return all of the tasks                                                                         // 205
        var find = {                                                                                                  // 206
          this_page_only: { $in: [false, null] },                                                                     // 207
          pagetype: pageinfo().pagetype,                                                                              // 208
          $or: [{ visibility: "public" }, { $and: [{ visibility: "private" }, { "createdBy.userid": Meteor.userId() }] }, { visibility: null }]
        };                                                                                                            // 206
                                                                                                                      //
        //        var results = Widgets.find(find, {sort: {sort_order : -1, createdAt: -1}}).map(setWidgetDefaults); 
        var results = Widgets.find(find, { sort: { sort_order: 1 } }).map(setWidgetDefaults);                         // 220
                                                                                                                      //
        console.log(results);                                                                                         // 222
        return results;                                                                                               // 223
      }                                                                                                               // 224
                                                                                                                      //
      return widgets;                                                                                                 // 204
    }(),                                                                                                              // 204
    widgetTemplates: function () {                                                                                    // 225
      function widgetTemplates() {                                                                                    // 225
        // Otherwise, return all of the tasks                                                                         // 226
        var results = Widgets.find({ isTemplate: true }, { sort: { sort_order: -1, createdAt: -1 } }).map(setWidgetDefaults);
        return results;                                                                                               // 228
      }                                                                                                               // 229
                                                                                                                      //
      return widgetTemplates;                                                                                         // 225
    }(),                                                                                                              // 225
    libraryWidgets: function () {                                                                                     // 230
      function libraryWidgets() {                                                                                     // 230
        // Otherwise, return all of the tasks                                                                         // 231
        var find = { inLibrary: true };                                                                               // 232
        find["createdBy.userid"] = Meteor.userId();                                                                   // 233
        var results = Widgets.find(find, { sort: { sort_order: -1, createdAt: -1 } }).map(setWidgetDefaults);         // 234
        return results;                                                                                               // 235
      }                                                                                                               // 236
                                                                                                                      //
      return libraryWidgets;                                                                                          // 230
    }(),                                                                                                              // 230
    thisPageWidgets: function () {                                                                                    // 237
      function thisPageWidgets() {                                                                                    // 237
        // Otherwise, return all of the tasks                                                                         // 238
        var find = { this_page_only: true,                                                                            // 239
          pagetype: pageinfo().pagetype,                                                                              // 240
          pageid: pageinfo().pageid };                                                                                // 241
        var results = Widgets.find(find, { sort: { sort_order: -1, createdAt: -1 } }).map(setWidgetDefaults);         // 242
        return results;                                                                                               // 243
      }                                                                                                               // 244
                                                                                                                      //
      return thisPageWidgets;                                                                                         // 237
    }(),                                                                                                              // 237
                                                                                                                      //
    userXtras: function () {                                                                                          // 246
      function userXtras() {                                                                                          // 246
        return getUserXtras();                                                                                        // 247
      }                                                                                                               // 248
                                                                                                                      //
      return userXtras;                                                                                               // 246
    }(),                                                                                                              // 246
                                                                                                                      //
    godmode: function () {                                                                                            // 250
      function godmode() {                                                                                            // 250
        return getUserXtras().godmode;                                                                                // 251
      }                                                                                                               // 252
                                                                                                                      //
      return godmode;                                                                                                 // 250
    }()                                                                                                               // 250
                                                                                                                      //
  });                                                                                                                 // 203
  ////// END HELPERS                                                                                                  // 255
                                                                                                                      //
                                                                                                                      //
  ////// TEMPLATE ONRENDERED                                                                                          // 258
  Template.body.onRendered(function () {                                                                              // 259
    //$(".tooltip-right").tooltip({placement: "right"});                                                              // 260
    //  $("[title]").tooltip({placement: "auto"});                                                                    // 261
    console.log("555555555555C5 rendered");                                                                           // 262
  });                                                                                                                 // 263
  ////// END ONRENDERED                                                                                               // 264
                                                                                                                      //
                                                                                                                      //
  /////// EVENTS                                                                                                      // 268
  Template.body.events({                                                                                              // 269
                                                                                                                      //
    "click .lockall": function () {                                                                                   // 272
      function clickLockall() {                                                                                       // 272
        $(".lock").trigger("click");                                                                                  // 273
        $(".lockall").hide();                                                                                         // 274
        $(".unlockall").show();                                                                                       // 275
        giphy_modal("unlock", "Unlocking all widgets you have access to");                                            // 276
        return false;                                                                                                 // 277
      }                                                                                                               // 279
                                                                                                                      //
      return clickLockall;                                                                                            // 272
    }(),                                                                                                              // 272
    "click .unlockall": function () {                                                                                 // 280
      function clickUnlockall() {                                                                                     // 280
        $(".unlock").trigger("click");                                                                                // 281
        $(".lockall").show();                                                                                         // 282
        $(".unlockall").hide();                                                                                       // 283
        giphy_modal("lock", "Locking all Widgets");                                                                   // 284
        return false;                                                                                                 // 285
      }                                                                                                               // 286
                                                                                                                      //
      return clickUnlockall;                                                                                          // 280
    }(),                                                                                                              // 280
                                                                                                                      //
    "click .giphy": function () {                                                                                     // 288
      function clickGiphy(e, t) {                                                                                     // 288
        $(e.target).hide();                                                                                           // 289
      }                                                                                                               // 290
                                                                                                                      //
      return clickGiphy;                                                                                              // 288
    }(),                                                                                                              // 288
                                                                                                                      //
    "click .godmode_check": function () {                                                                             // 292
      function clickGodmode_check(e, t) {                                                                             // 292
        //      console.log(t);                                                                                       // 293
        UserXtras.update({ _id: Meteor.userId() }, { $set: { godmode: e.target.checked } });                          // 294
      }                                                                                                               // 295
                                                                                                                      //
      return clickGodmode_check;                                                                                      // 292
    }(),                                                                                                              // 292
                                                                                                                      //
    'click .copy_from_template': function () {                                                                        // 297
      function clickCopy_from_template() {                                                                            // 297
        copyWidgetToPage($(this).attr("target"), pageinfo().pagetype, pageinfo().pageurl, pageinfo().pageid);         // 298
        giphy_modal("copy", "New Widget Copied From Template");                                                       // 299
        return false;                                                                                                 // 300
      }                                                                                                               // 301
                                                                                                                      //
      return clickCopy_from_template;                                                                                 // 297
    }(),                                                                                                              // 297
                                                                                                                      //
    'click .deletetemplate': function () {                                                                            // 303
      function clickDeletetemplate() {                                                                                // 303
        var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                                 // 304
        template.isTemplate = false;                                                                                  // 305
        Widgets.update(template._id, template);                                                                       // 306
      }                                                                                                               // 307
                                                                                                                      //
      return clickDeletetemplate;                                                                                     // 303
    }(),                                                                                                              // 303
                                                                                                                      //
    'click .addwidget': function () {                                                                                 // 309
      function clickAddwidget() {                                                                                     // 309
        //add jsbin widget                                                                                            // 310
                                                                                                                      //
        var htmlstring = '<html>\n ' + '<head>\n ' + '<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>\n ' + '<script src="/c5libs/locallib.js"></script>\n ' + '   <script type="application/json" class="c5_data">{"data" : "data placed here gets passed along"}</script>\n ' + '</head>\n ' + '<body>\n ' + '  <div class="c5_html">\n ' + '  html placed here gets passed along\n ' + '  </div>\n ' + '</body>\n ' + '</html>\n';
        var csstring = "";                                                                                            // 324
        var jsstring = "function doTheThings(data){\n" + "// everything you want to do should happen inside this function\n " + "// the data var will be populated with whatever you've requested from other widgets\n" + "// and this function will be call when all those widgets have complete \n" + "   c5_done(); // this message is required at the end of all the processing, so the system knows this widget is done \n " + "} \n" + "requireWidgetData( \n" + "// all requests to other widgets go here (automatically if you use the 'pull from' interface): \n" + "// c5_requires \n" + "{} \n" + "// end_c5_requires \n" + "// end other widget requests \n" + ", doTheThings)";
        var dataobj = { html: htmlstring, css: csstring, javascript: jsstring };                                      // 338
        var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                                 // 339
        var options = { data: dataobj };                                                                              // 340
        HTTP.post(url, options, function (error, results) {                                                           // 341
          newWidget = { _id: results.data.url,                                                                        // 342
            createdBy: { username: Meteor.user().username,                                                            // 343
              userid: Meteor.userId() },                                                                              // 344
            isTemplate: false,                                                                                        // 345
            name: results.data.url,                                                                                   // 346
            description: "",                                                                                          // 347
            html: results.data.html,                                                                                  // 348
            javascript: results.data.javascript,                                                                      // 349
            css: results.data.css,                                                                                    // 350
            displayWidth: "",                                                                                         // 351
            displayHeight: "",                                                                                        // 352
            widgetStyle: "",                                                                                          // 353
            pagetype: pageinfo().pagetype,                                                                            // 354
            pageurl: pageinfo().pageurl,                                                                              // 355
            pageid: pageinfo().pageid,                                                                                // 356
            url: results.data.url,                                                                                    // 357
            visibility: "private",                                                                                    // 358
            createdAt: new Date(),                                                                                    // 359
            rand: Math.random() };                                                                                    // 360
          Widgets.insert(newWidget);                                                                                  // 361
        });                                                                                                           // 362
        return false;                                                                                                 // 363
      }                                                                                                               // 364
                                                                                                                      //
      return clickAddwidget;                                                                                          // 309
    }(),                                                                                                              // 309
                                                                                                                      //
    'click .test': function () {                                                                                      // 366
      function clickTest() {                                                                                          // 366
        return false;                                                                                                 // 367
      }                                                                                                               // 368
                                                                                                                      //
      return clickTest;                                                                                               // 366
    }()                                                                                                               // 366
  });                                                                                                                 // 269
                                                                                                                      //
  ///// END EVENTS                                                                                                    // 372
                                                                                                                      //
}                                                                                                                     // 375
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 377
  Meteor.startup(function () {                                                                                        // 378
    // code to run on server at startup                                                                               // 379
  });                                                                                                                 // 380
}                                                                                                                     // 381
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"common_functions.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// common_functions.js                                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
justaddedid = pageinfo = setWidgetDefaults = giphy_modal = getUserXtras = null;                                       // 1
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 3
                                                                                                                      //
  getUserXtras = function getUserXtras() {                                                                            // 5
    var userxtras = false;                                                                                            // 6
    var user = Meteor.user();                                                                                         // 7
    if (user) {                                                                                                       // 8
      /*                                                                                                              // 9
      console.log(user.username);                                                                                     //
      console.log(user._id);                                                                                          //
      console.log("getting for " + user._id);                                                                         //
      */                                                                                                              //
      userxtras = UserXtras.findOne({ _id: user._id });                                                               // 14
      if (!userxtras || !userxtras.foo) {                                                                             // 15
        console.log("userxtras " + userxtras);                                                                        // 16
        userxtras = { _id: user._id, admin: false, godmode: false, foo: "var" };                                      // 17
        if (user.username == "donundeen") {                                                                           // 18
          userxtras.admin = true;                                                                                     // 19
        }                                                                                                             // 20
        console.log("saving for " + user._id);                                                                        // 21
        UserXtras.upsert({ _id: user._id }, userxtras);                                                               // 22
        var userxtras2 = UserXtras.findOne({ _id: user._id });                                                        // 23
      }                                                                                                               // 24
    }                                                                                                                 // 25
    return userxtras;                                                                                                 // 26
  };                                                                                                                  // 28
                                                                                                                      //
  giphy_modal = function giphy_modal(term, text) {                                                                    // 32
    $("#giphy_modal").modal('show');                                                                                  // 33
    $(".giphy_modal_header").text(text);                                                                              // 34
    var url = "/giphy_proxy/" + encodeURIComponent(term);                                                             // 35
    $(".giphy_modal_image_div").empty();                                                                              // 36
    var imgurl = url + "?" + new Date().getTime();                                                                    // 37
    $(".giphy_modal_image_div").html("<img src='" + imgurl + "' width='200' class='giphy_modal_image_img'/>");        // 38
                                                                                                                      //
    setTimeout(function () {                                                                                          // 40
      $("#giphy_modal").modal('hide');                                                                                // 41
    }, 2000);                                                                                                         // 42
  };                                                                                                                  // 44
                                                                                                                      //
  pageinfo = function pageinfo() {                                                                                    // 46
    var pagetype = "";                                                                                                // 47
    var pageid = "";                                                                                                  // 48
    var pathname = window.location.pathname;                                                                          // 49
    var split = pathname.split("/");                                                                                  // 50
    split.shift();                                                                                                    // 51
    var pageurl = split.join("/");                                                                                    // 52
                                                                                                                      //
    if (split.length > 0) {                                                                                           // 54
      pagetype = split.shift();                                                                                       // 55
    }                                                                                                                 // 56
    if (split.length > 0) {                                                                                           // 57
      pageid = split.shift();                                                                                         // 58
    }                                                                                                                 // 59
    pageid = pageid.replace(/:script/, "");                                                                           // 60
    return { pageurl: pageurl,                                                                                        // 61
      pagetype: pagetype,                                                                                             // 62
      pageid: pageid };                                                                                               // 63
  };                                                                                                                  // 65
                                                                                                                      //
  copyWidgetToPage = function copyWidgetToPage(origID, pagetype, pageid, pageurl) {                                   // 68
    console.log("calling CopyWidgetToPage for " + origID);                                                            // 69
    var template = Widgets.findOne({ url: origID }); //.map(setWidgetDefaults);                                       // 70
    var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                        // 71
    var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                                     // 72
    var options = { data: dataobj };                                                                                  // 73
                                                                                                                      //
    HTTP.post(url, options, function (error, results) {                                                               // 75
      newWidget = { _id: results.data.url,                                                                            // 76
        createdBy: { username: Meteor.user().username,                                                                // 77
          userid: Meteor.userId() },                                                                                  // 78
        isTemplate: false,                                                                                            // 79
        html: results.data.html,                                                                                      // 80
        javascript: results.data.javascript,                                                                          // 81
        css: results.data.css,                                                                                        // 82
        displayWidth: results.data.displayWidth,                                                                      // 83
        displayHeight: results.data.displayHeight,                                                                    // 84
        description: "(copied from " + template.name + ") " + template.description,                                   // 85
        widgetStyle: results.data.widgetStyle,                                                                        // 86
        name: "copy of " + template.name,                                                                             // 87
        pagetype: pagetype,                                                                                           // 88
        pageurl: pageurl,                                                                                             // 89
        pageid: pageid,                                                                                               // 90
        url: results.data.url,                                                                                        // 91
        createdAt: new Date(),                                                                                        // 92
        visibility: "private",                                                                                        // 93
        rand: Math.random() };                                                                                        // 94
      justaddedid = Widgets.insert(newWidget);                                                                        // 95
      console.log("setting justaddedid " + justaddedid);                                                              // 96
                                                                                                                      //
      var grid = $(".grid-stack").data('gridstack');                                                                  // 98
      var widgetElement = $("#widgetContainer_" + results.data.url);                                                  // 99
                                                                                                                      //
      console.log("added ");                                                                                          // 101
      console.log(widgetElement);                                                                                     // 102
      /*                                                                                                              // 103
      var griditem = $(widgetElement).parent().parent();                                                              //
      $(griditem).data("gs-width", "12");                                                                             //
      $(griditem).data("gs-height", "5");                                                                             //
      $(griditem).data("gs-auto-position", "true");                                                                   //
      grid.makeWidget(griditem);                                                                                      //
      grid.resize(griditem, 12, 5);                                                                                   //
       var next = $(".grid-stack-item").get(0)  ;                                                                     //
      console.log("moving next" + $(next).data("widget-id"));                                                         //
      console.log(next);                                                                                              //
      grid.move(next, 0, 6);                                                                                          //
      */                                                                                                              //
    });                                                                                                               // 116
    giphy_modal("copy", "New Widget Copied From Template");                                                           // 117
  };                                                                                                                  // 119
                                                                                                                      //
  setWidgetDefaults = function setWidgetDefaults(doc) {                                                               // 122
    if (typeof doc.displayWidth === "undefined" || !doc.displayWidth || doc.displayWidth.trim() == "" || doc.displayWidth == "width" || doc.displayWidth == "default") {
      doc.displayWidth = "320px";                                                                                     // 124
      doc.displayUsableWidth = "320px";                                                                               // 125
    } else {                                                                                                          // 126
      doc.displayUsableWidth = doc.displayWidth;                                                                      // 127
    }                                                                                                                 // 128
    if (typeof doc.displayHeight === "undefined" || !doc.displayHeight || doc.displayHeight.trim() == "" || doc.displayHeight == "height" || doc.displayHeight == "default") {
      doc.displayHeight = "400px";                                                                                    // 130
      doc.displayUsableHeight = "400px";                                                                              // 131
    } else {                                                                                                          // 132
      doc.displayUsableHeight = doc.displayHeight;                                                                    // 133
    }                                                                                                                 // 134
    if (typeof doc.widgetStyle === "undefined" || !doc.widgetStyle || doc.widgetStyle.trim() == "" || doc.widgetStyle == "css" || doc.widgetStyle == "default") {
      doc.widgetStyle = "default";                                                                                    // 136
      doc.usableWidgetStyle = "";                                                                                     // 137
    } else {                                                                                                          // 138
      doc.usableWidgetStyle = doc.widgetStyle;                                                                        // 139
    }                                                                                                                 // 140
    if (!doc.createdBy) {                                                                                             // 141
      doc.createdBy = {};                                                                                             // 142
    }                                                                                                                 // 143
                                                                                                                      //
    if (doc.displayUsableHeight.match(/px/)) {                                                                        // 145
      var height = doc.displayUsableHeight.replace(/px/, "");                                                         // 146
      doc.jsbinHeight = height - 20;                                                                                  // 147
      doc.jsbinHeight += "px";                                                                                        // 148
    } else {                                                                                                          // 149
      doc.jsbinHeight = "";                                                                                           // 150
    }                                                                                                                 // 151
                                                                                                                      //
    if (!doc.this_page_only) {                                                                                        // 153
      doc.this_page_only = false;                                                                                     // 154
    }                                                                                                                 // 155
                                                                                                                      //
    if (!doc.sort_order) {                                                                                            // 157
      doc.sort_order = 0;                                                                                             // 158
    }                                                                                                                 // 159
                                                                                                                      //
    if (!doc.visibility) {                                                                                            // 161
      doc.visibility = "public";                                                                                      // 162
    }                                                                                                                 // 163
                                                                                                                      //
    if (!doc.cacheConfig) {                                                                                           // 165
      doc.cacheConfig = {};                                                                                           // 166
    }                                                                                                                 // 167
                                                                                                                      //
    if (!doc.cacheConfig.ttl) {                                                                                       // 169
      doc.cacheConfig.ttl = 60;                                                                                       // 170
    }                                                                                                                 // 171
                                                                                                                      //
    if (typeof doc.width_in_cells == "undefined") {                                                                   // 173
      doc.width_in_cells = 12;                                                                                        // 174
    }                                                                                                                 // 175
    if (typeof doc.height_in_cells == "undefined") {                                                                  // 176
      doc.height_in_cells = 5;                                                                                        // 177
    }                                                                                                                 // 178
    if (doc.width_in_cells == 0) {                                                                                    // 179
      doc.width_in_cells = 1;                                                                                         // 180
    }                                                                                                                 // 181
    if (doc.height_in_cells == 0) {                                                                                   // 182
      doc.height_in_cells = 1;                                                                                        // 183
    }                                                                                                                 // 184
    if (typeof doc.width_in_px == "undefined") {                                                                      // 185
      doc.width_in_px = 640;                                                                                          // 186
    }                                                                                                                 // 187
    if (typeof doc.height_in_px == "undefined") {                                                                     // 188
      doc.height_in_px = 320;                                                                                         // 189
    }                                                                                                                 // 190
    if (doc.width_in_px == 0) {                                                                                       // 191
      doc.width_in_px = 640;                                                                                          // 192
    }                                                                                                                 // 193
    if (doc.height_in_px == 0) {                                                                                      // 194
      doc.height_in_px = 320;                                                                                         // 195
    }                                                                                                                 // 196
                                                                                                                      //
    return doc;                                                                                                       // 199
  };                                                                                                                  // 200
}                                                                                                                     // 201
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"widget.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// widget.js                                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 2
  var dix;                                                                                                            // 2
                                                                                                                      //
  (function () {                                                                                                      // 2
    var setDisplayModeOn = function setDisplayModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin, widgetid, isnew) {
      var grid = $(".grid-stack").data("gridstack");                                                                  // 8
      var griditem = $(widgetElement).parent().parent();                                                              // 9
      var result = grid.resize(griditem, widgetData.width_in_cells, widgetData.height_in_cells);                      // 10
                                                                                                                      //
      // get the size of the navbar, subtract from height of iframe                                                   // 12
                                                                                                                      //
      dix++;                                                                                                          // 14
      var di = dix;                                                                                                   // 15
      var newbintop = 0;                                                                                              // 16
      $(menu).hide();                                                                                                 // 17
                                                                                                                      //
      $(".editmodeonly", widgetElement).hide();                                                                       // 19
      $(".displaymodeonly", widgetElement).show();                                                                    // 20
      iframeElement.oldbintop = $(bin).css("top");                                                                    // 21
      $(bin).css("top", newbintop);                                                                                   // 22
      $(widgetElement).attr("style", widgetData.usableWidgetStyle);                                                   // 23
                                                                                                                      //
      $(widgetElement).css("border-radius", "10px");                                                                  // 25
      $(".widgetDisplayHeader", widgetElement).hide();                                                                // 26
                                                                                                                      //
      if (jsbin && jsbin.panels) {                                                                                    // 28
        jsbin.panels.hide("html");                                                                                    // 29
        jsbin.panels.hide("javascript");                                                                              // 30
        jsbin.panels.hide("css");                                                                                     // 31
        jsbin.panels.hide("console");                                                                                 // 32
      }                                                                                                               // 33
      $(".lock", widgetElement).show();                                                                               // 34
      $(".unlock", widgetElement).hide();                                                                             // 35
      $(widgetElement).data("mode", "display");                                                                       // 36
      $(iframeElement).css("border-radius", "10px");                                                                  // 37
                                                                                                                      //
      var initialH = $(griditem).height();                                                                            // 39
      var finalh = initialH;                                                                                          // 40
      var initialW = $(griditem).width();                                                                             // 41
      var finalw = initialW;                                                                                          // 42
      $(widgetElement).width(finalw - 35);                                                                            // 43
      $(widgetElement).height(finalh - 15);                                                                           // 44
                                                                                                                      //
      $(iframeElement).css("max-height", "");                                                                         // 46
      $(iframeElement).css("max-width", "");                                                                          // 47
      $(iframeElement).css("min-height", "");                                                                         // 48
      $(iframeElement).css("min-width", "");                                                                          // 49
                                                                                                                      //
      $(iframeElement).width(finalw - 35);                                                                            // 51
      $(iframeElement).css("max-width", finalw - 35);                                                                 // 52
      $(iframeElement).height(finalh - 25);                                                                           // 53
      $(iframeElement).css("max-height", finalh - 25);                                                                // 54
      $(iframeElement).css("min-height", finalh - 25);                                                                // 55
    };                                                                                                                // 57
                                                                                                                      //
    var setEditModeOn = function setEditModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin) {          // 2
      var grid = $(".grid-stack").data("gridstack");                                                                  // 61
      var griditem = $(widgetElement).parent().parent();                                                              // 62
      if (jsbin) {                                                                                                    // 63
        jsbin.panels.show("html");                                                                                    // 64
        jsbin.panels.show("javascript");                                                                              // 65
      }                                                                                                               // 66
      $(".lock", widgetElement).hide();                                                                               // 67
      $(".unlock", widgetElement).show();                                                                             // 68
      //      editors.panels.show("css");                                                                             // 69
                                                                                                                      //
      var newbintop = 0;                                                                                              // 71
                                                                                                                      //
      grid.resize(griditem, 12, 6);                                                                                   // 73
                                                                                                                      //
      // put it in EDIT MODE                                                                                          // 75
      $(menu).show();                                                                                                 // 76
      $(".editmodeonly", widgetElement).show();                                                                       // 77
      $(".displaymodeonly", widgetElement).hide();                                                                    // 78
      $(bin).css("top", iframeElement.oldbintop);                                                                     // 79
      $(widgetElement).css("border-radius", "10px");                                                                  // 80
      $(iframeElement).css("border-radius", "10px");                                                                  // 81
                                                                                                                      //
      // ".navbar-collapse"                                                                                           // 83
      var height_adjust = $(".navbar-collapse", widgetElement).height() - 20;                                         // 84
      // adjust for height of menu                                                                                    // 85
                                                                                                                      //
                                                                                                                      //
      var initialH = $(griditem).height();                                                                            // 88
      var finalh = initialH;                                                                                          // 89
      var initialW = $(griditem).width();                                                                             // 90
      var finalw = initialW;                                                                                          // 91
      $(widgetElement).width(finalw - 25);                                                                            // 92
      $(widgetElement).height(finalh - 15);                                                                           // 93
                                                                                                                      //
      $(iframeElement).css("max-height", "");                                                                         // 95
      $(iframeElement).css("max-width", "");                                                                          // 96
      $(iframeElement).css("min-height", "");                                                                         // 97
      $(iframeElement).css("min-width", "");                                                                          // 98
                                                                                                                      //
      $(iframeElement).width(finalw - 25);                                                                            // 100
      $(iframeElement).css("max-width", finalw - 25);                                                                 // 101
      $(iframeElement).height(finalh - 25 - height_adjust);                                                           // 102
      $(iframeElement).css("max-height", finalh - 25);                                                                // 103
      $(iframeElement).css("min-height", finalh - 25);                                                                // 104
    };                                                                                                                // 106
    /////// END FUNCTION DEFS                                                                                         // 107
                                                                                                                      //
                                                                                                                      //
    /////////// END WIDGET ONRENDERED                                                                                 // 360
                                                                                                                      //
                                                                                                                      //
    //////////// EVENTS                                                                                               // 364
                                                                                                                      //
    var insert_code = function insert_code(jsbin_id, codeString, codeStringRe, comments) {                            // 2
                                                                                                                      //
      var editors = document.getElementById(jsbin_id).contentWindow.editors;                                          // 368
                                                                                                                      //
      if (!editors) {                                                                                                 // 370
        return true;                                                                                                  // 371
      }                                                                                                               // 372
      var code = editors.javascript.getCode();                                                                        // 373
      var line = editors.javascript.editor.getCursor().line;                                                          // 374
      var charpos = editors.javascript.editor.getCursor().ch;                                                         // 375
      // make sure it's not already in there:                                                                         // 376
      var codeRe = new RegExp("\/\/ *c[45]_requires[\\s\\S]*\\[[\\s\\S]*" + codeStringRe + "[\\s\\S]*\\] *,[\\s\\S]*\/\/ *end_c[45]_requires");
      var codeMatch = code.match(codeRe);                                                                             // 378
      if (!codeMatch) {                                                                                               // 379
        // match to empty array                                                                                       // 380
        var match = /(\/\/ *c[45]_requires[\s\S]*\[)\s*(\] *,[\s\S]*\/\/ *end_c[45]_requires)/;                       // 381
        var results = code.match(match);                                                                              // 382
        newcode = code.replace(match, "$1\n" + codeString + " // " + comments + "\n$2");                              // 383
                                                                                                                      //
        if (newcode == code) {                                                                                        // 385
          // match to non-empty array                                                                                 // 386
          var match = /(\/\/ *c[45]_requires[\s\S]*\[)([^\]]*\] *,[\s\S]*\/\/ *end_c[45]_requires)/;                  // 387
          var results = code.match(match);                                                                            // 388
          newcode = code.replace(match, "$1\n" + codeString + ", // " + comments + "$2");                             // 389
        }                                                                                                             // 390
        code = newcode;                                                                                               // 391
        var state = { line: editors.javascript.editor.currentLine(),                                                  // 392
          character: editors.javascript.editor.getCursor().ch,                                                        // 393
          add: 0                                                                                                      // 394
        };                                                                                                            // 392
                                                                                                                      //
        editors.javascript.setCode(code);                                                                             // 397
        editors.javascript.editor.setCursor({ line: state.line + state.add, ch: state.character });                   // 398
      }                                                                                                               // 399
    };                                                                                                                // 400
                                                                                                                      //
    /////// FUNCTION DEFS                                                                                             // 4
    dix = 0;                                                                                                          // 5
    Template.gridwidgets.onRendered(function () {                                                                     // 111
      // set whatever gridStack options you want                                                                      // 112
      var options = {                                                                                                 // 113
        width: 12,                                                                                                    // 114
        auto: false,                                                                                                  // 115
        cellHeight: 60,                                                                                               // 116
        cellWidth: 60,                                                                                                // 117
        alwaysShowResizeHandle: /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),
        resizable: {                                                                                                  // 119
          handles: 'e, se, s, sw, w'                                                                                  // 120
        }                                                                                                             // 119
      };                                                                                                              // 113
      var $gridstack = this.$('.grid-stack');                                                                         // 123
      // initialise gridstack                                                                                         // 124
      $gridstack.gridstack(options);                                                                                  // 125
                                                                                                                      //
      $(window).resize(function (evt) {                                                                               // 127
        if (evt.target == window) {                                                                                   // 128
          var grid = $(".grid-stack").data("gridstack");                                                              // 129
          $(".grid-stack-item").each(function (index) {                                                               // 130
            var element = this;                                                                                       // 131
            var initialH = $(element).height();                                                                       // 132
            var finalh = initialH;                                                                                    // 133
            var initialW = $(element).width();                                                                        // 134
            var finalw = initialW;                                                                                    // 135
            var cellw = grid.cellWidth();                                                                             // 136
            var cellh = grid.cellHeight();                                                                            // 137
            var cells_wide = $(element).data("gs-width");                                                             // 138
            var cells_high = $(element).data('gs-height');                                                            // 139
                                                                                                                      //
            var widgetElement = $(".widgetContainer", element);                                                       // 141
            var iframeElement = $(".jsbin-embed", element);                                                           // 142
                                                                                                                      //
            $(widgetElement).width(finalw - 25);                                                                      // 144
            $(widgetElement).height(finalh - 15);                                                                     // 145
                                                                                                                      //
            $(iframeElement).css("max-height", "");                                                                   // 147
            $(iframeElement).css("max-width", "");                                                                    // 148
            $(iframeElement).css("min-height", "");                                                                   // 149
            $(iframeElement).css("min-width", "");                                                                    // 150
                                                                                                                      //
            $(iframeElement).width(finalw - 35);                                                                      // 152
            $(iframeElement).css("max-width", finalw - 35);                                                           // 153
            $(iframeElement).height(finalh - 25);                                                                     // 154
            $(iframeElement).css("max-height", finalh - 25);                                                          // 155
          });                                                                                                         // 157
        }                                                                                                             // 158
      });                                                                                                             // 159
                                                                                                                      //
      $('.grid-stack').on('dragstop', function (event, ui) {                                                          // 163
        // for some reason the moved grid-item doesn't have access to the widgetId data attribute, so get it here and hang onto it.
        var target_url = $(event.target).data("widget-id");                                                           // 165
        // save new order when items are moved.                                                                       // 166
        var grid = $(this).data('gridstack');                                                                         // 167
        var nodes = grid.grid.nodes;                                                                                  // 168
        for (var i = 0; i < nodes.length; i++) {                                                                      // 169
          var node = nodes[i];                                                                                        // 170
          var id = $(node.el).data('widgetId');                                                                       // 171
          // get widget code, update sort-order                                                                       // 172
          if (typeof id == "undefined") {                                                                             // 173
            id = target_url;                                                                                          // 174
          }                                                                                                           // 175
          if (typeof id != "undefined") {                                                                             // 176
            (function (_id) {                                                                                         // 177
              var widget = Widgets.findOne({ url: _id }); //.map(setWidgetDefaults);                                  // 178
              widget.sort_order = i;                                                                                  // 179
              Widgets.update(widget._id, widget, {}, function (arg1, arg2) {});                                       // 180
            })(id);                                                                                                   // 182
          } else {                                                                                                    // 183
            //            console.log(node);                                                                          // 184
          }                                                                                                           // 185
        }                                                                                                             // 186
      });                                                                                                             // 187
                                                                                                                      //
      $('.grid-stack').on('resizestop', function (event, items) {                                                     // 189
        var grid = this;                                                                                              // 190
        var element = event.target;                                                                                   // 191
        var widgetElement = $(".widgetContainer", element);                                                           // 192
        var iframeElement = $(".jsbin-embed", element);                                                               // 193
        // need to wait just a bit for the size to quantize to the grid...                                            // 194
        setTimeout(function () {                                                                                      // 195
          var initialH = $(element).height();                                                                         // 196
          var finalh = initialH;                                                                                      // 197
          var initialW = $(element).width();                                                                          // 198
          var finalw = initialW;                                                                                      // 199
          var widgetID = $(widgetElement).data("url");                                                                // 200
          var widget = Widgets.findOne({ url: widgetID }); //.map(setWidgetDefaults);                                 // 201
          $(widgetElement).width(finalw - 35);                                                                        // 202
          $(widgetElement).height(finalh - 15);                                                                       // 203
                                                                                                                      //
          $(iframeElement).css("max-height", "");                                                                     // 205
          $(iframeElement).css("max-width", "");                                                                      // 206
          $(iframeElement).css("min-height", "");                                                                     // 207
          $(iframeElement).css("min-width", "");                                                                      // 208
                                                                                                                      //
          $(iframeElement).width(finalw - 35);                                                                        // 210
          $(iframeElement).css("max-width", finalw - 35);                                                             // 211
          $(iframeElement).height(finalh - 25);                                                                       // 212
          $(iframeElement).css("max-height", finalh - 25);                                                            // 213
                                                                                                                      //
          var cellw = $(grid).data("gridstack").opts.cellWidth;                                                       // 215
          var cellh = $(grid).data("gridstack").opts.cellHeight;                                                      // 216
          var cells_wide = $(element).data("gs-width");                                                               // 217
          var cells_high = $(element).data('gs-height');                                                              // 218
                                                                                                                      //
          widget.width_in_cells = cells_wide;                                                                         // 220
          widget.height_in_cells = cells_high;                                                                        // 221
          widget.width_in_px = finalw;                                                                                // 222
          widget.height_in_px = finalh;                                                                               // 223
          Widgets.update(widget._id, widget);                                                                         // 224
        }, 350);                                                                                                      // 225
      });                                                                                                             // 227
                                                                                                                      //
      $('.grid-stack').data("inited", true);                                                                          // 229
    });                                                                                                               // 231
                                                                                                                      //
    Template.widget.onCreated(function () {                                                                           // 235
      var sortorder = this.data.sort_order;                                                                           // 236
      var id = this.data._id;                                                                                         // 237
      console.log("created");                                                                                         // 238
      console.log(id + " , " + sortorder);                                                                            // 239
    });                                                                                                               // 240
                                                                                                                      //
    /////// WIDGET ONRENDERED                                                                                         // 242
    // In the client code, below everything else                                                                      // 243
    Template.widget.onRendered(function () {                                                                          // 244
      var thisisnew = false;                                                                                          // 245
                                                                                                                      //
      if (justaddedid == this.data._id) {                                                                             // 247
        thisisnew = true; // this node was just added.                                                                // 248
      }                                                                                                               // 249
                                                                                                                      //
      var sortorder = this.data.sort_order;                                                                           // 251
                                                                                                                      //
      var context = Template.currentData();                                                                           // 253
      var firstNode = this.firstNode;                                                                                 // 254
      var firstNodeId = $(firstNode).data("widget-id");                                                               // 255
      var lastNode = this.lastNode;                                                                                   // 256
      var lastNodeId = $(lastNode).data("widget-id");                                                                 // 257
                                                                                                                      //
      var grid = $(".grid-stack").data('gridstack');                                                                  // 259
      var widgetElement = $("#widgetContainer_" + this.data._id);                                                     // 260
      var griditem = $(widgetElement).parent().parent();                                                              // 261
                                                                                                                      //
      if (!thisisnew && grid) {                                                                                       // 263
        console.log("widget Rendered");                                                                               // 264
        console.log(this.data._id);                                                                                   // 265
        console.log(this.data.sort_order);                                                                            // 266
        grid.addWidget(this.$('.grid-stack-item'));                                                                   // 267
      } else {                                                                                                        // 268
        console.log("no grid?");                                                                                      // 269
      }                                                                                                               // 270
      // find out if the widget has been added to the grid.                                                           // 271
                                                                                                                      //
      if (thisisnew) {                                                                                                // 273
        grid.makeWidget(griditem);                                                                                    // 274
        grid.move(griditem, 0, 0);                                                                                    // 275
        var node = grid.grid.getNodeDataByDOMEl(griditem);                                                            // 276
        //  grid.grid._fixCollisions(griditem);                                                                       // 277
      }                                                                                                               // 278
      if (!$('.grid-stack').data("inited")) {}                                                                        // 279
      // end resizable grid setup                                                                                     // 282
                                                                                                                      //
                                                                                                                      //
      (function (widget, isnew) {                                                                                     // 286
        var thisid = widget.data._id;                                                                                 // 287
        var element = document.getElementById('jsbin_' + thisid);                                                     // 288
        var thiselement = document.getElementById('widgetContainer_' + thisid);                                       // 289
        $(".widgetDisplayHeader", thiselement).hide();                                                                // 290
                                                                                                                      //
        // maybe already exists?                                                                                      // 292
        var theElement = document.getElementById('jsbin_' + thisid);                                                  // 293
        if (theElement && theElement.contentWindow && theElement.contentWindow.document) {                            // 294
          $(theElement).load(function () {                                                                            // 295
            var widgetElement = document.getElementById('widgetContainer_' + thisid);                                 // 296
            var editors = jsbin = menu = bin = null;                                                                  // 297
            if (theElement) {                                                                                         // 298
              editors = theElement.contentWindow.editors;                                                             // 299
              jsbin = theElement.contentWindow.jsbin;                                                                 // 300
              menu = theElement.contentWindow.document.getElementById("control");                                     // 301
              bin = theElement.contentWindow.document.getElementById("bin");                                          // 302
              var thiselement = document.getElementById('widgetContainer_' + thisid);                                 // 303
              if (jsbin && jsbin.panels) {                                                                            // 304
                jsbin.panels.saveOnExit = true;                                                                       // 305
              }                                                                                                       // 306
              setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, thisid, isnew);                    // 307
            } else {                                                                                                  // 308
              console.log("no element found for jsbin_" + thisid);                                                    // 309
            }                                                                                                         // 310
          });                                                                                                         // 311
        }                                                                                                             // 312
        // this part here happens when the JSBIN stuff is loaded.                                                     // 313
        (function (this_id, isnew) {                                                                                  // 314
          if (isnew) {                                                                                                // 315
            var widgetElement = document.getElementById('widgetContainer_' + this_id);                                // 316
            var editors = jsbin = menu = bin = null;                                                                  // 317
            var theElement = document.getElementById('jsbin_' + this_id);                                             // 318
            if (theElement) {                                                                                         // 319
              editors = theElement.contentWindow.editors;                                                             // 320
              jsbin = theElement.contentWindow.jsbin;                                                                 // 321
              menu = theElement.contentWindow.document.getElementById("control");                                     // 322
              bin = theElement.contentWindow.document.getElementById("bin");                                          // 323
              if (jsbin && jsbin.panels) {                                                                            // 324
                jsbin.panels.saveOnExit = true;                                                                       // 325
              }                                                                                                       // 326
              setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, this_id, isnew);                   // 327
            } else {                                                                                                  // 328
              console.log("no element found for jsbin_" + this_id);                                                   // 329
            }                                                                                                         // 330
          }                                                                                                           // 331
                                                                                                                      //
          document.addEventListener("DOMNodeInserted", function (evt, item) {                                         // 334
            (function (_evt, _this_id, isnew) {                                                                       // 335
              if ($(_evt.target)[0].tagName == "IFRAME" && $(_evt.target)[0].id.replace("jsbin_", "") == _this_id) {  // 336
                $(_evt.target).load(function () {                                                                     // 337
                  var widgetElement = document.getElementById('widgetContainer_' + _this_id);                         // 338
                  var editors = jsbin = menu = bin = null;                                                            // 339
                  var theElement = document.getElementById('jsbin_' + _this_id);                                      // 340
                  if (theElement) {                                                                                   // 341
                    editors = theElement.contentWindow.editors;                                                       // 342
                    jsbin = theElement.contentWindow.jsbin;                                                           // 343
                    menu = theElement.contentWindow.document.getElementById("control");                               // 344
                    bin = theElement.contentWindow.document.getElementById("bin");                                    // 345
                    if (jsbin && jsbin.panels) {                                                                      // 346
                      jsbin.panels.saveOnExit = true;                                                                 // 347
                    }                                                                                                 // 348
                    setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, _this_id, isnew);            // 349
                  } else {                                                                                            // 350
                    console.log("no element found for jsbin_" + _this_id);                                            // 351
                  }                                                                                                   // 352
                });                                                                                                   // 353
              }                                                                                                       // 354
            })(evt, this_id, isnew);                                                                                  // 355
          });                                                                                                         // 356
        })(thisid, isnew);                                                                                            // 357
      })(this, thisisnew);                                                                                            // 358
    });                                                                                                               // 359
                                                                                                                      //
    Template.help.events({                                                                                            // 403
      "click .giphy": function () {                                                                                   // 404
        function clickGiphy(e, t) {                                                                                   // 404
          $(e.target).hide();                                                                                         // 405
        }                                                                                                             // 406
                                                                                                                      //
        return clickGiphy;                                                                                            // 404
      }()                                                                                                             // 404
    });                                                                                                               // 403
                                                                                                                      //
    Template.widget.events({                                                                                          // 409
                                                                                                                      //
      "click .giphy": function () {                                                                                   // 411
        function clickGiphy(e, t) {                                                                                   // 411
          $(e.target).hide();                                                                                         // 412
        }                                                                                                             // 413
                                                                                                                      //
        return clickGiphy;                                                                                            // 411
      }(),                                                                                                            // 411
                                                                                                                      //
      "click .delete": function () {                                                                                  // 415
        function clickDelete() {                                                                                      // 415
                                                                                                                      //
          var grid = $(".grid-stack").data("gridstack");                                                              // 417
                                                                                                                      //
          var widgetElement = $("#widgetContainer_" + this._id);                                                      // 419
          var griditem = $(widgetElement).parent().parent();                                                          // 420
                                                                                                                      //
          grid.removeWidget(griditem, true);                                                                          // 422
                                                                                                                      //
          if (this.isTemplate) {                                                                                      // 424
            this.pagetype = "template";                                                                               // 425
            Widgets.update(this._id, this);                                                                           // 426
          } else {                                                                                                    // 427
            Widgets.remove(this._id);                                                                                 // 428
          }                                                                                                           // 429
          giphy_modal("erase", "Widget Deleted");                                                                     // 430
          return false;                                                                                               // 431
        }                                                                                                             // 432
                                                                                                                      //
        return clickDelete;                                                                                           // 415
      }(),                                                                                                            // 415
                                                                                                                      //
      "click .save": function () {                                                                                    // 434
        function clickSave() {                                                                                        // 434
          var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                           // 435
          var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                               // 436
          var revision = jsbin.state.revision;                                                                        // 437
                                                                                                                      //
          this.html = editors.html.getCode();                                                                         // 439
          this.javascript = editors.javascript.getCode();                                                             // 440
          this.css = editors.css.getCode();                                                                           // 441
          jsbin.saveDisabled = false;                                                                                 // 442
          jsbin.panels.save();                                                                                        // 443
          jsbin.panels.savecontent();                                                                                 // 444
          Widgets.update(this._id, this);                                                                             // 445
                                                                                                                      //
          // also trigger the jsbin save                                                                              // 447
          var dataobj = { html: this.html, css: this.css, javascript: this.javascript };                              // 448
          var url = "/api/" + this.url + "/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,              // 449
          var options = { data: dataobj };                                                                            // 450
          HTTP.post(url, options, function (error, results) {});                                                      // 451
                                                                                                                      //
          giphy_modal("saved", "Widget Content Saved");                                                               // 454
                                                                                                                      //
          return false;                                                                                               // 456
        }                                                                                                             // 457
                                                                                                                      //
        return clickSave;                                                                                             // 434
      }(),                                                                                                            // 434
                                                                                                                      //
      "click .call_webservice_url": function () {                                                                     // 460
        function clickCall_webservice_url(evt, template) {                                                            // 460
          $("#webservice_insert_modal").modal('show');                                                                // 461
                                                                                                                      //
          $("#webservice_insert_modal_submit").click(function () {                                                    // 463
            var jsbin_id = 'jsbin_' + template.data.url;                                                              // 464
                                                                                                                      //
            var url = $("#webservice_insert_url").val().trim();                                                       // 467
            var name = $("#webservice_insert_name").val().trim();                                                     // 468
            var auth_token = $("#webservice_insert_auth_token").val().trim();                                         // 469
            var return_type = $("input[name=webservice_insert_return_type]:checked").val().trim();                    // 470
                                                                                                                      //
            url = url.replace("||PAGEID||", "'+pageId()+'");                                                          // 472
            url = url.replace("||PAGETYPE||", "'+pageType()+'");                                                      // 473
                                                                                                                      //
            var token_string;                                                                                         // 475
            if (auth_token) {                                                                                         // 476
              token_string = " \n authentication_token : '" + auth_token + "',";                                      // 477
            }                                                                                                         // 478
                                                                                                                      //
            var codeString = "{\n id:'" + name + "', \n type: 'webservice', " + token_string + " \n return_type: '" + return_type + "', \n url: '" + url + "' \n}";
            var codeStringRe = "\\{\n id:'" + name + "', \n type: 'webservice', \n return_type: '" + return_type + "', \n url: '" + url + "' \n\\}";
            var comments = " this will hold a " + return_type + " object";                                            // 482
                                                                                                                      //
            insert_code(jsbin_id, codeString, codeStringRe, comments);                                                // 484
          });                                                                                                         // 486
        }                                                                                                             // 489
                                                                                                                      //
        return clickCall_webservice_url;                                                                              // 460
      }(),                                                                                                            // 460
                                                                                                                      //
      "click .add_code": function () {                                                                                // 491
        function clickAdd_code(evt, template) {                                                                       // 491
                                                                                                                      //
          var pullfrom = evt.currentTarget.dataset.pullfrom;                                                          // 493
          var pulltype = evt.currentTarget.dataset.pulltype;                                                          // 494
                                                                                                                      //
          if (this.url == template.data.url) {                                                                        // 496
            return false;                                                                                             // 497
          }                                                                                                           // 498
                                                                                                                      //
          var type;                                                                                                   // 500
          var comments = "";                                                                                          // 501
          if (pulltype == "data") {                                                                                   // 502
            type = "data";                                                                                            // 503
            comments = " This will hold a JSON object";                                                               // 504
          }                                                                                                           // 505
          if (pulltype == "html") {                                                                                   // 506
            type = "html";                                                                                            // 507
            comments = " This will hold a jQuery object";                                                             // 508
          }                                                                                                           // 509
          var codeString = "{from: '" + pullfrom + "', type : '" + pulltype + "'}";                                   // 510
          var codeStringRe = "\\{from: '" + pullfrom + "', type : '" + pulltype + "'\\}";                             // 511
                                                                                                                      //
          var jsbin_id = 'jsbin_' + template.data.url;                                                                // 513
                                                                                                                      //
          insert_code(jsbin_id, codeString, codeStringRe, comments);                                                  // 515
                                                                                                                      //
          return true;                                                                                                // 517
        }                                                                                                             // 518
                                                                                                                      //
        return clickAdd_code;                                                                                         // 491
      }(),                                                                                                            // 491
                                                                                                                      //
      "click .test": function () {                                                                                    // 522
        function clickTest() {                                                                                        // 522
          var thiselement = document.getElementById('widgetContainer_' + this._id);                                   // 523
          var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                           // 524
          var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                               // 525
          var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");   // 526
          var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");        // 527
                                                                                                                      //
          var newbintop = 0;                                                                                          // 529
          this.maxed = !this.maxed;                                                                                   // 530
          if (this.maxed) {                                                                                           // 531
            $(menu).hide();                                                                                           // 532
            $(".editmodeonly", thiselement).hide();                                                                   // 533
            this.oldbintop = $(bin).css("top");                                                                       // 534
            $(bin).css("top", newbintop);                                                                             // 535
          } else {                                                                                                    // 536
            $(menu).show();                                                                                           // 537
            $(".editmodeonly", thiselement).show();                                                                   // 538
            $(bin).css("top", this.oldbintop);                                                                        // 539
          }                                                                                                           // 540
          return false;                                                                                               // 541
        }                                                                                                             // 542
                                                                                                                      //
        return clickTest;                                                                                             // 522
      }(),                                                                                                            // 522
      /*                                                                                                              // 543
      panel ids: html, css, javascript, console, live                                                                 //
      */                                                                                                              //
                                                                                                                      //
      // this sets it to EDIT mode                                                                                    // 547
      "click .widgetUnlock": function () {                                                                            // 548
        function clickWidgetUnlock() {                                                                                // 548
                                                                                                                      //
          var widgetElement = document.getElementById('widgetContainer_' + this._id);                                 // 550
          var iframeElement = document.getElementById('jsbin_' + this._id);                                           // 551
                                                                                                                      //
          var editors = iframeElement.contentWindow.editors;                                                          // 553
          var jsbin = iframeElement.contentWindow.jsbin;                                                              // 554
          var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");   // 555
          var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");        // 556
                                                                                                                      //
          setEditModeOn(this, iframeElement, widgetElement, menu, bin, jsbin);                                        // 558
                                                                                                                      //
          return false;                                                                                               // 560
        }                                                                                                             // 561
                                                                                                                      //
        return clickWidgetUnlock;                                                                                     // 548
      }(),                                                                                                            // 548
                                                                                                                      //
      // this sets it to DISPLAY mode                                                                                 // 564
      "click .widgetLock": function () {                                                                              // 565
        function clickWidgetLock() {                                                                                  // 565
                                                                                                                      //
          var widgetElement = document.getElementById('widgetContainer_' + this._id);                                 // 567
          var iframeElement = document.getElementById('jsbin_' + this._id);                                           // 568
                                                                                                                      //
          var editors = iframeElement.contentWindow.editors;                                                          // 570
          var jsbin = iframeElement.contentWindow.jsbin;                                                              // 571
          var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");   // 572
          var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");        // 573
          setDisplayModeOn(this, iframeElement, widgetElement, menu, bin, jsbin, this._id, false);                    // 574
                                                                                                                      //
          return false;                                                                                               // 576
        }                                                                                                             // 577
                                                                                                                      //
        return clickWidgetLock;                                                                                       // 565
      }(),                                                                                                            // 565
                                                                                                                      //
      // setting visibility on widgets (public or private)                                                            // 580
      "click .setpublic": function () {                                                                               // 581
        function clickSetpublic() {                                                                                   // 581
          this.visibility = "public";                                                                                 // 582
          Widgets.update(this._id, this);                                                                             // 583
          return false;                                                                                               // 584
        }                                                                                                             // 585
                                                                                                                      //
        return clickSetpublic;                                                                                        // 581
      }(),                                                                                                            // 581
      "click .setprivate": function () {                                                                              // 586
        function clickSetprivate() {                                                                                  // 586
          this.visibility = "private";                                                                                // 587
          Widgets.update(this._id, this);                                                                             // 588
          return false;                                                                                               // 589
        }                                                                                                             // 590
                                                                                                                      //
        return clickSetprivate;                                                                                       // 586
      }(),                                                                                                            // 586
                                                                                                                      //
      "click .order_up": function () {                                                                                // 592
        function clickOrder_up() {                                                                                    // 592
          this.sort_order--;                                                                                          // 593
          Widgets.update(this._id, this);                                                                             // 594
          return false;                                                                                               // 595
        }                                                                                                             // 596
                                                                                                                      //
        return clickOrder_up;                                                                                         // 592
      }(),                                                                                                            // 592
                                                                                                                      //
      "click .order_down": function () {                                                                              // 598
        function clickOrder_down() {                                                                                  // 598
          this.sort_order++;                                                                                          // 599
          Widgets.update(this._id, this);                                                                             // 600
          return false;                                                                                               // 601
        }                                                                                                             // 602
                                                                                                                      //
        return clickOrder_down;                                                                                       // 598
      }(),                                                                                                            // 598
                                                                                                                      //
      "click .nonclickable": function () {                                                                            // 604
        function clickNonclickable() {                                                                                // 604
          return false;                                                                                               // 605
        }                                                                                                             // 606
                                                                                                                      //
        return clickNonclickable;                                                                                     // 604
      }(),                                                                                                            // 604
                                                                                                                      //
      'click .copy': function () {                                                                                    // 609
        function clickCopy() {                                                                                        // 609
          var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                               // 610
          var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                  // 611
          var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                               // 612
          var options = { data: dataobj };                                                                            // 613
                                                                                                                      //
          HTTP.post(url, options, function (error, results) {                                                         // 615
            newWidget = { _id: results.data.url,                                                                      // 616
              createdBy: { username: Meteor.user().username,                                                          // 617
                userid: Meteor.userId() },                                                                            // 618
              isTemplate: false,                                                                                      // 619
              html: results.data.html,                                                                                // 620
              javascript: results.data.javascript,                                                                    // 621
              css: results.data.css,                                                                                  // 622
              displayWidth: template.displayWidth,                                                                    // 623
              displayHeight: template.displayHeight,                                                                  // 624
              description: "(copied from " + template.name + ") " + template.description,                             // 625
              widgetStyle: template.widgetStyle,                                                                      // 626
              name: "copy of " + template.name,                                                                       // 627
              pagetype: pageinfo().pagetype,                                                                          // 628
              pageurl: pageinfo().pageurl,                                                                            // 629
              pageid: pageinfo().pageid,                                                                              // 630
              url: results.data.url,                                                                                  // 631
              createdAt: new Date(),                                                                                  // 632
              visibility: "private",                                                                                  // 633
              rand: Math.random() };                                                                                  // 634
            Widgets.insert(newWidget);                                                                                // 635
          });                                                                                                         // 636
                                                                                                                      //
          giphy_modal("copy", "widget copied");                                                                       // 638
                                                                                                                      //
          return false;                                                                                               // 640
        }                                                                                                             // 641
                                                                                                                      //
        return clickCopy;                                                                                             // 609
      }(),                                                                                                            // 609
                                                                                                                      //
      "click .save_template": function () {                                                                           // 644
        function clickSave_template() {                                                                               // 644
          this.isTemplate = !this.isTemplate;                                                                         // 645
          Widgets.update(this._id, this);                                                                             // 646
          var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                           // 647
          var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                               // 648
                                                                                                                      //
          giphy_modal("promotion", "widget saved as a template");                                                     // 650
                                                                                                                      //
          return false;                                                                                               // 652
        }                                                                                                             // 653
                                                                                                                      //
        return clickSave_template;                                                                                    // 644
      }(),                                                                                                            // 644
                                                                                                                      //
      "click .save_to_library": function () {                                                                         // 655
        function clickSave_to_library() {                                                                             // 655
          this.isTemplate = !this.isTemplate;                                                                         // 656
          //      Widgets.update(this._id, this);                                                                     // 657
                                                                                                                      //
          var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                               // 659
          var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                  // 660
          var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                               // 661
          var options = { data: dataobj };                                                                            // 662
                                                                                                                      //
          var newpagetype = "user_libs";                                                                              // 664
          var newpageid = Meteor.user().username;                                                                     // 665
          var newpageurl = newpagetype + "/" + newpageurl;                                                            // 666
                                                                                                                      //
          HTTP.post(url, options, function (error, results) {                                                         // 668
            newWidget = { _id: results.data.url,                                                                      // 669
              createdBy: { username: Meteor.user().username,                                                          // 670
                userid: Meteor.userId() },                                                                            // 671
              inLibrary: true,                                                                                        // 672
              html: results.data.html,                                                                                // 673
              javascript: results.data.javascript,                                                                    // 674
              css: results.data.css,                                                                                  // 675
              displayWidth: template.displayWidth,                                                                    // 676
              displayHeight: template.displayHeight,                                                                  // 677
              description: "(copied from " + template.name + ") " + template.description,                             // 678
              widgetStyle: template.widgetStyle,                                                                      // 679
              name: "copy of " + template.name,                                                                       // 680
              pagetype: newpagetype,                                                                                  // 681
              pageurl: newpageurl,                                                                                    // 682
              pageid: newpageid,                                                                                      // 683
              this_page_only: true,                                                                                   // 684
              url: results.data.url,                                                                                  // 685
              createdAt: new Date(),                                                                                  // 686
              visibility: "private",                                                                                  // 687
              rand: Math.random() };                                                                                  // 688
            Widgets.insert(newWidget);                                                                                // 689
          });                                                                                                         // 690
                                                                                                                      //
          giphy_modal("library", "widget added to your library");                                                     // 692
                                                                                                                      //
          return false;                                                                                               // 694
        }                                                                                                             // 695
                                                                                                                      //
        return clickSave_to_library;                                                                                  // 655
      }(),                                                                                                            // 655
                                                                                                                      //
      "click .openinfo": function () {                                                                                // 697
        function clickOpeninfo() {                                                                                    // 697
          var thiselement = document.getElementById('widgetContainer_' + this._id);                                   // 698
          var mode = $(thiselement).data("mode");                                                                     // 699
          if (!mode || mode == "display") {                                                                           // 700
            //      $(".widgetMouseOverTarget", thiselement ).css("background", "red");                               // 701
            $(".widgetDisplayHeader", thiselement).show();                                                            // 702
            $(".widgetMouseOverTarget", thiselement).css("z-index", 5);                                               // 703
            $(".widgetDisplayHeader", thiselement).css("z-index", 10);                                                // 704
          }                                                                                                           // 705
        }                                                                                                             // 706
                                                                                                                      //
        return clickOpeninfo;                                                                                         // 697
      }(),                                                                                                            // 697
                                                                                                                      //
      "mouseleave .widgetDisplayHeader": function () {                                                                // 709
        function mouseleaveWidgetDisplayHeader() {                                                                    // 709
          var thiselement = document.getElementById('widgetContainer_' + this._id);                                   // 710
          $(".widgetMouseOverTarget", thiselement).css("background", "transparent");                                  // 711
          $(".widgetDisplayHeader", thiselement).hide();                                                              // 712
          $(".widgetMouseOverTarget", thiselement).css("z-index", 10);                                                // 713
          $(".widgetDisplayHeader", thiselement).css("z-index", 5);                                                   // 714
        }                                                                                                             // 715
                                                                                                                      //
        return mouseleaveWidgetDisplayHeader;                                                                         // 709
      }()                                                                                                             // 709
                                                                                                                      //
    });                                                                                                               // 409
    ////// END EVENTS                                                                                                 // 719
                                                                                                                      //
                                                                                                                      //
    ////// HELPERS                                                                                                    // 722
                                                                                                                      //
    widgetIncrement = 0;                                                                                              // 724
    Template.widget.helpers({                                                                                         // 725
      otherwidgets: function () {                                                                                     // 726
        function otherwidgets() {                                                                                     // 726
          // Otherwise, return all of the tasks                                                                       // 727
          return Widgets.find({ pagetype: pageinfo().pagetype, _id: { $ne: this._id } }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
        }                                                                                                             // 729
                                                                                                                      //
        return otherwidgets;                                                                                          // 726
      }(),                                                                                                            // 726
                                                                                                                      //
      isPublic: function () {                                                                                         // 731
        function isPublic() {                                                                                         // 731
          if (this.visibility == "public") {                                                                          // 732
            return true;                                                                                              // 733
          }                                                                                                           // 734
          return false;                                                                                               // 735
        }                                                                                                             // 736
                                                                                                                      //
        return isPublic;                                                                                              // 731
      }(),                                                                                                            // 731
                                                                                                                      //
      pageTypeAndUrl: function () {                                                                                   // 738
        function pageTypeAndUrl() {                                                                                   // 738
                                                                                                                      //
          return "_pt_" + this.pagetype + "/" + this.url;                                                             // 740
        }                                                                                                             // 741
                                                                                                                      //
        return pageTypeAndUrl;                                                                                        // 738
      }(),                                                                                                            // 738
                                                                                                                      //
      pageUrlAndUrl: function () {                                                                                    // 743
        function pageUrlAndUrl() {                                                                                    // 743
          return "_pu_" + pageinfo().pageurl + "/" + this.url;                                                        // 744
        }                                                                                                             // 745
                                                                                                                      //
        return pageUrlAndUrl;                                                                                         // 743
      }(),                                                                                                            // 743
                                                                                                                      //
      commentsCount: function () {                                                                                    // 747
        function commentsCount(id) {                                                                                  // 747
          var value = "";                                                                                             // 748
          return value;                                                                                               // 749
        }                                                                                                             // 750
                                                                                                                      //
        return commentsCount;                                                                                         // 747
      }(),                                                                                                            // 747
                                                                                                                      //
      isMyWidget: function () {                                                                                       // 752
        function isMyWidget() {                                                                                       // 752
          // is this a widget I created?                                                                              // 753
          if (getUserXtras().godmode) {                                                                               // 754
            return true;                                                                                              // 755
          }                                                                                                           // 756
          if (this.createdBy && Meteor.user()) {                                                                      // 757
            return this.createdBy.username == Meteor.user().username;                                                 // 758
          } else {                                                                                                    // 759
            return false;                                                                                             // 760
          }                                                                                                           // 761
        }                                                                                                             // 762
                                                                                                                      //
        return isMyWidget;                                                                                            // 752
      }(),                                                                                                            // 752
                                                                                                                      //
      widgetIncrement: function (_widgetIncrement) {                                                                  // 764
        function widgetIncrement() {                                                                                  // 764
          return _widgetIncrement.apply(this, arguments);                                                             // 764
        }                                                                                                             // 764
                                                                                                                      //
        widgetIncrement.toString = function () {                                                                      // 764
          return _widgetIncrement.toString();                                                                         // 764
        };                                                                                                            // 764
                                                                                                                      //
        return widgetIncrement;                                                                                       // 764
      }(function () {                                                                                                 // 764
        var ret = widgetIncrement;                                                                                    // 765
        if (typeof this.widgetIncrement == "undefined") {                                                             // 766
          this.widgetIncrement = widgetIncrement;                                                                     // 767
          widgetIncrement++;                                                                                          // 768
        } else {                                                                                                      // 769
          ret = this.widgetIncrement;                                                                                 // 770
        }                                                                                                             // 771
        return ret;                                                                                                   // 772
      }),                                                                                                             // 773
                                                                                                                      //
      userXtras: function () {                                                                                        // 775
        function userXtras() {                                                                                        // 775
          return getUserXtras();                                                                                      // 776
        }                                                                                                             // 777
                                                                                                                      //
        return userXtras;                                                                                             // 775
      }(),                                                                                                            // 775
                                                                                                                      //
      godmode: function () {                                                                                          // 779
        function godmode() {                                                                                          // 779
          return getUserXtras().godmode;                                                                              // 780
        }                                                                                                             // 782
                                                                                                                      //
        return godmode;                                                                                               // 779
      }()                                                                                                             // 779
    });                                                                                                               // 725
                                                                                                                      //
    Template.allWidgetsLoaded.onRendered(function () {                                                                // 787
      console.log("aaaaaall widgets loaded");                                                                         // 788
    });                                                                                                               // 789
    //////// END HELPERS                                                                                              // 790
  })();                                                                                                               // 2
}                                                                                                                     // 791
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{"extensions":[".js",".json"]});
require("./server/smtp.js");
require("./C5.js");
require("./common_functions.js");
require("./widget.js");
//# sourceMappingURL=app.js.map
