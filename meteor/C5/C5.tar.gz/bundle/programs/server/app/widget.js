(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// widget.js                                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
if (Meteor.isClient) {                                                 // 2
                                                                       //
  /////// FUNCTION DEFS                                                //
  var dix = 0;                                                         // 5
  function setDisplayModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin, widgetid) {
                                                                       //
    console.log("setting display mode on");                            // 8
    dix++;                                                             // 9
    var di = dix;                                                      // 10
    var newbintop = 0;                                                 // 11
    $(menu).hide();                                                    // 12
                                                                       //
    if (!widgetData.displayUsableWidth || widgetData.displayUsableWidth.trim() == "") {
      widgetData.displayUsableWidth = "50%";                           // 15
    }                                                                  //
                                                                       //
    $(".editmodeonly", widgetElement).hide();                          // 18
    $(".displaymodeonly", widgetElement).show();                       // 19
    iframeElement.oldbintop = $(bin).css("top");                       // 20
    $(bin).css("top", newbintop);                                      // 21
    $(widgetElement).attr("style", widgetData.usableWidgetStyle);      // 22
    $(widgetElement).width(widgetData.displayUsableWidth);             // 23
    $(widgetElement).height(widgetData.displayUsableHeight);           // 24
    $(widgetElement).css("border-radius", "10px");                     // 25
    $(".widgetDisplayHeader", widgetElement).hide();                   // 26
                                                                       //
    if (jsbin && jsbin.panels) {                                       // 28
      jsbin.panels.hide("html");                                       // 29
      jsbin.panels.hide("javascript");                                 // 30
      jsbin.panels.hide("css");                                        // 31
      jsbin.panels.hide("console");                                    // 32
    }                                                                  //
    $(".lock", widgetElement).show();                                  // 34
    $(".unlock", widgetElement).hide();                                // 35
    $(widgetElement).data("mode", "display");                          // 36
                                                                       //
    console.log("setting display mode");                               // 38
                                                                       //
    $(iframeElement).css("max-height", "");                            // 40
    $(iframeElement).css("max-width", "");                             // 41
    $(iframeElement).width($(widgetElement).width());                  // 42
    $(iframeElement).height($(widgetElement).height() - 10);           // 43
    $(iframeElement).css("border-radius", "10px");                     // 44
    $(iframeElement).css("max-height", $(widgetElement).height() - 10);
                                                                       //
    (function (wn, wd, ifr) {                                          // 47
      $(wn).resize(function () {                                       // 48
        console.log("display mode resizing");                          // 49
        $(ifr).width($(wd).width());                                   // 50
        $(ifr).height($(wd).height() - 10);                            // 51
      });                                                              //
    })(window, widgetElement, iframeElement);                          //
                                                                       //
    console.log($(widgetElement).width() + ", " + $(widgetElement).height());
    console.log($(iframeElement).width() + ", " + $(iframeElement).height());
  }                                                                    //
                                                                       //
  function setEditModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin) {
                                                                       //
    if (jsbin) {                                                       // 62
      jsbin.panels.show("html");                                       // 63
      jsbin.panels.show("javascript");                                 // 64
    }                                                                  //
    $(".lock", widgetElement).hide();                                  // 66
    $(".unlock", widgetElement).show();                                // 67
    //      editors.panels.show("css");                                //
                                                                       //
    var newbintop = 0;                                                 // 70
                                                                       //
    // put it in EDIT MODE                                             //
    $(menu).show();                                                    // 73
    $(".editmodeonly", widgetElement).show();                          // 74
    $(".displaymodeonly", widgetElement).hide();                       // 75
    $(bin).css("top", iframeElement.oldbintop);                        // 76
    $(widgetElement).width($(window).width());                         // 77
    $(widgetElement).height($(window).height());                       // 78
    $(widgetElement).css("border-radius", "10px");                     // 79
                                                                       //
    console.log("setting edit mode");                                  // 81
                                                                       //
    $(iframeElement).css("max-height", "");                            // 83
    $(iframeElement).width($(widgetElement).width());                  // 84
    $(iframeElement).height($(widgetElement).height() - 80);           // 85
    $(iframeElement).css("border-radius", "10px");                     // 86
                                                                       //
    (function (wn, wd, ifr) {                                          // 88
      $(wn).resize(function () {                                       // 89
        console.log("edit mode resizing");                             // 90
                                                                       //
        $(ifr).width($(wd).width());                                   // 92
        $(ifr).height($(wd).height());                                 // 93
      });                                                              //
    })(window, widgetElement, iframeElement);                          //
  }                                                                    //
  /////// END FUNCTION DEFS                                            //
                                                                       //
  /////// WIDGET ONRENDERED                                            //
  // In the client code, below everything else                         //
  Template.widget.onRendered(function () {                             // 105
                                                                       //
    (function (widget) {                                               // 107
      var thisid = widget.data._id;                                    // 108
      var element = document.getElementById('jsbin_' + thisid);        // 109
      var thiselement = document.getElementById('widgetContainer_' + thisid);
      $(".widgetDisplayHeader", thiselement).hide();                   // 111
                                                                       //
      // maybe already exists?                                         //
      var theElement = document.getElementById('jsbin_' + thisid);     // 114
      if (theElement && theElement.contentWindow && theElement.contentWindow.document) {
        $(theElement).load(function () {                               // 116
          var widgetElement = document.getElementById('widgetContainer_' + thisid);
          var editors = jsbin = menu = bin = null;                     // 118
          if (theElement) {                                            // 119
            editors = theElement.contentWindow.editors;                // 120
            jsbin = theElement.contentWindow.jsbin;                    // 121
            menu = theElement.contentWindow.document.getElementById("control");
            bin = theElement.contentWindow.document.getElementById("bin");
            var thiselement = document.getElementById('widgetContainer_' + thisid);
            if (jsbin && jsbin.panels) {                               // 125
              jsbin.panels.saveOnExit = true;                          // 126
            }                                                          //
            setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, thisid);
          } else {                                                     //
            console.log("no element found for jsbin_" + thisid);       // 130
          }                                                            //
        });                                                            //
      }                                                                //
      // this part here happens when the JSBIN stuff is loaded.        //
      (function (this_id) {                                            // 135
        document.addEventListener("DOMNodeInserted", function (evt, item) {
          (function (_evt, _this_id) {                                 // 137
            if ($(_evt.target)[0].tagName == "IFRAME" && $(_evt.target)[0].id.replace("jsbin_", "") == _this_id) {
              $(_evt.target).load(function () {                        // 139
                var widgetElement = document.getElementById('widgetContainer_' + _this_id);
                var editors = jsbin = menu = bin = null;               // 141
                var theElement = document.getElementById('jsbin_' + _this_id);
                if (theElement) {                                      // 143
                  editors = theElement.contentWindow.editors;          // 144
                  console.log(editors.live.el);                        // 145
                  jsbin = theElement.contentWindow.jsbin;              // 146
                  console.log(jsbin);                                  // 147
                  menu = theElement.contentWindow.document.getElementById("control");
                  bin = theElement.contentWindow.document.getElementById("bin");
                  console.log(bin);                                    // 150
                } else {                                               //
                  console.log("no element found for jsbin_" + _this_id);
                }                                                      //
                if (jsbin && jsbin.panels) {                           // 154
                  jsbin.panels.saveOnExit = true;                      // 155
                }                                                      //
                setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, _this_id);
              });                                                      //
            }                                                          //
          })(evt, this_id);                                            //
        });                                                            //
      })(thisid);                                                      //
    })(this);                                                          //
  });                                                                  //
  /////////// END WIDGET ONRENDERED                                    //
                                                                       //
  //////////// EVENTS                                                  //
                                                                       //
  function insert_code(jsbin_id, codeString, codeStringRe, comments) {
                                                                       //
    var editors = document.getElementById(jsbin_id).contentWindow.editors;
                                                                       //
    if (!editors) {                                                    // 175
      return true;                                                     // 176
    }                                                                  //
    var code = editors.javascript.getCode();                           // 178
    var line = editors.javascript.editor.getCursor().line;             // 179
    var charpos = editors.javascript.editor.getCursor().ch;            // 180
    // make sure it's not already in there:                            //
    var codeRe = new RegExp("\/\/ *c[45]_requires[\\s\\S]*\\[[\\s\\S]*" + codeStringRe + "[\\s\\S]*\\] *,[\\s\\S]*\/\/ *end_c[45]_requires");
    var codeMatch = code.match(codeRe);                                // 183
    if (!codeMatch) {                                                  // 184
      // match to empty array                                          //
      var match = /(\/\/ *c[45]_requires[\s\S]*\[)\s*(\] *,[\s\S]*\/\/ *end_c[45]_requires)/;
      var results = code.match(match);                                 // 187
      newcode = code.replace(match, "$1\n" + codeString + " // " + comments + "\n$2");
                                                                       //
      if (newcode == code) {                                           // 190
        // match to non-empty array                                    //
        var match = /(\/\/ *c[45]_requires[\s\S]*\[)([^\]]*\] *,[\s\S]*\/\/ *end_c[45]_requires)/;
        var results = code.match(match);                               // 193
        newcode = code.replace(match, "$1\n" + codeString + ", // " + comments + "$2");
      }                                                                //
      code = newcode;                                                  // 196
      var state = { line: editors.javascript.editor.currentLine(),     // 197
        character: editors.javascript.editor.getCursor().ch,           // 198
        add: 0                                                         // 199
      };                                                               //
                                                                       //
      editors.javascript.setCode(code);                                // 202
      editors.javascript.editor.setCursor({ line: state.line + state.add, ch: state.character });
    }                                                                  //
  }                                                                    //
                                                                       //
  Template.help.events({                                               // 208
    "click .giphy": function (e, t) {                                  // 209
      $(e.target).hide();                                              // 210
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.widget.events({                                             // 214
                                                                       //
    "click .giphy": function (e, t) {                                  // 216
      $(e.target).hide();                                              // 217
    },                                                                 //
                                                                       //
    "click .delete": function () {                                     // 220
      if (this.isTemplate) {                                           // 221
        this.pagetype = "template";                                    // 222
        Widgets.update(this._id, this);                                // 223
      } else {                                                         //
        Widgets.remove(this._id);                                      // 225
      }                                                                //
      giphy_modal("erase", "Widget Deleted");                          // 227
      return false;                                                    // 228
    },                                                                 //
                                                                       //
    "click .save": function () {                                       // 231
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
      var revision = jsbin.state.revision;                             // 234
                                                                       //
      this.html = editors.html.getCode();                              // 236
      this.javascript = editors.javascript.getCode();                  // 237
      this.css = editors.css.getCode();                                // 238
      jsbin.saveDisabled = false;                                      // 239
      jsbin.panels.save();                                             // 240
      jsbin.panels.savecontent();                                      // 241
      Widgets.update(this._id, this);                                  // 242
                                                                       //
      // also trigger the jsbin save                                   //
      var dataobj = { html: this.html, css: this.css, javascript: this.javascript };
      var url = "/api/" + this.url + "/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 247
      HTTP.post(url, options, function (error, results) {});           // 248
                                                                       //
      giphy_modal("saved", "Widget Content Saved");                    // 251
                                                                       //
      return false;                                                    // 253
    },                                                                 //
                                                                       //
    "click .call_webservice_url": function (evt, template) {           // 257
      $("#webservice_insert_modal").modal('show');                     // 258
                                                                       //
      $("#webservice_insert_modal_submit").click(function () {         // 260
        var jsbin_id = 'jsbin_' + template.data.url;                   // 261
                                                                       //
        var url = $("#webservice_insert_url").val().trim();            // 264
        var name = $("#webservice_insert_name").val().trim();          // 265
        var auth_token = $("#webservice_insert_auth_token").val().trim();
        var return_type = $("input[name=webservice_insert_return_type]:checked").val().trim();
                                                                       //
        url = url.replace("||PAGEID||", "'+pageId()+'");               // 269
        url = url.replace("||PAGETYPE||", "'+pageType()+'");           // 270
                                                                       //
        var token_string;                                              // 272
        if (auth_token) {                                              // 273
          token_string = " \n authentication_token : '" + auth_token + "',";
        }                                                              //
                                                                       //
        var codeString = "{\n id:'" + name + "', \n type: 'webservice', " + token_string + " \n return_type: '" + return_type + "', \n url: '" + url + "' \n}";
        var codeStringRe = "\\{\n id:'" + name + "', \n type: 'webservice', \n return_type: '" + return_type + "', \n url: '" + url + "' \n\\}";
        var comments = " this will hold a " + return_type + " object";
                                                                       //
        insert_code(jsbin_id, codeString, codeStringRe, comments);     // 281
      });                                                              //
    },                                                                 //
                                                                       //
    "click .add_code": function (evt, template) {                      // 288
                                                                       //
      var pullfrom = evt.currentTarget.dataset.pullfrom;               // 290
      var pulltype = evt.currentTarget.dataset.pulltype;               // 291
                                                                       //
      if (this.url == template.data.url) {                             // 293
        return false;                                                  // 294
      }                                                                //
                                                                       //
      var type;                                                        // 297
      var comments = "";                                               // 298
      if (pulltype == "data") {                                        // 299
        type = "data";                                                 // 300
        comments = " This will hold a JSON object";                    // 301
      }                                                                //
      if (pulltype == "html") {                                        // 303
        type = "html";                                                 // 304
        comments = " This will hold a jQuery object";                  // 305
      }                                                                //
      var codeString = "{from: '" + pullfrom + "', type : '" + pulltype + "'}";
      var codeStringRe = "\\{from: '" + pullfrom + "', type : '" + pulltype + "'\\}";
                                                                       //
      var jsbin_id = 'jsbin_' + template.data.url;                     // 310
                                                                       //
      insert_code(jsbin_id, codeString, codeStringRe, comments);       // 312
                                                                       //
      return true;                                                     // 314
    },                                                                 //
                                                                       //
    "click .test": function () {                                       // 319
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
                                                                       //
      var newbintop = 0;                                               // 326
      this.maxed = !this.maxed;                                        // 327
      if (this.maxed) {                                                // 328
        $(menu).hide();                                                // 329
        $(".editmodeonly", thiselement).hide();                        // 330
        this.oldbintop = $(bin).css("top");                            // 331
        $(bin).css("top", newbintop);                                  // 332
      } else {                                                         //
        $(menu).show();                                                // 334
        $(".editmodeonly", thiselement).show();                        // 335
        $(bin).css("top", this.oldbintop);                             // 336
      }                                                                //
      return false;                                                    // 338
    },                                                                 //
    /*                                                                 //
    panel ids: html, css, javascript, console, live                    //
    */                                                                 //
                                                                       //
    // this sets it to EDIT mode                                       //
    "click .lock": function () {                                       // 345
                                                                       //
      var widgetElement = document.getElementById('widgetContainer_' + this._id);
      var iframeElement = document.getElementById('jsbin_' + this._id);
                                                                       //
      var editors = iframeElement.contentWindow.editors;               // 350
      var jsbin = iframeElement.contentWindow.jsbin;                   // 351
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
                                                                       //
      setEditModeOn(this, iframeElement, widgetElement, menu, bin, jsbin);
                                                                       //
      return false;                                                    // 357
    },                                                                 //
                                                                       //
    // this sets it to DISPLAY mode                                    //
    "click .unlock": function () {                                     // 362
                                                                       //
      var widgetElement = document.getElementById('widgetContainer_' + this._id);
      var iframeElement = document.getElementById('jsbin_' + this._id);
                                                                       //
      var editors = iframeElement.contentWindow.editors;               // 367
      var jsbin = iframeElement.contentWindow.jsbin;                   // 368
      var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");
      var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");
      setDisplayModeOn(this, iframeElement, widgetElement, menu, bin, jsbin, this._id);
                                                                       //
      return false;                                                    // 373
    },                                                                 //
                                                                       //
    // setting visibility on widgets (public or private)               //
    "click .setpublic": function () {                                  // 378
      console.log("setpublic");                                        // 379
      this.visibility = "public";                                      // 380
      Widgets.update(this._id, this);                                  // 381
      return false;                                                    // 382
    },                                                                 //
    "click .setprivate": function () {                                 // 384
      console.log("setprivate");                                       // 385
      this.visibility = "private";                                     // 386
      Widgets.update(this._id, this);                                  // 387
      return false;                                                    // 388
    },                                                                 //
                                                                       //
    "click .order_up": function () {                                   // 391
      this.sort_order--;                                               // 392
      Widgets.update(this._id, this);                                  // 393
      return false;                                                    // 394
    },                                                                 //
                                                                       //
    "click .order_down": function () {                                 // 397
      this.sort_order++;                                               // 398
      Widgets.update(this._id, this);                                  // 399
      return false;                                                    // 400
    },                                                                 //
                                                                       //
    "click .nonclickable": function () {                               // 403
      return false;                                                    // 404
    },                                                                 //
                                                                       //
    'click .copy': function () {                                       // 408
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 412
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 414
        newWidget = { _id: results.data.url,                           // 415
          createdBy: { username: Meteor.user().username,               // 416
            userid: Meteor.userId() },                                 // 417
          isTemplate: false,                                           // 418
          html: results.data.html,                                     // 419
          javascript: results.data.javascript,                         // 420
          css: results.data.css,                                       // 421
          displayWidth: template.displayWidth,                         // 422
          displayHeight: template.displayHeight,                       // 423
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: template.widgetStyle,                           // 425
          name: "copy of " + template.name,                            // 426
          pagetype: pageinfo().pagetype,                               // 427
          pageurl: pageinfo().pageurl,                                 // 428
          pageid: pageinfo().pageid,                                   // 429
          url: results.data.url,                                       // 430
          createdAt: new Date(),                                       // 431
          visibility: "private",                                       // 432
          rand: Math.random() };                                       // 433
        Widgets.insert(newWidget);                                     // 434
      });                                                              //
                                                                       //
      giphy_modal("copy", "widget copied");                            // 437
                                                                       //
      return false;                                                    // 439
    },                                                                 //
                                                                       //
    "click .save_template": function () {                              // 443
      this.isTemplate = !this.isTemplate;                              // 444
      Widgets.update(this._id, this);                                  // 445
      var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;
      var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;
                                                                       //
      giphy_modal("promotion", "widget saved as a template");          // 449
                                                                       //
      return false;                                                    // 451
    },                                                                 //
                                                                       //
    "click .save_to_library": function () {                            // 454
      this.isTemplate = !this.isTemplate;                              // 455
      //      Widgets.update(this._id, this);                          //
                                                                       //
      var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);
      var dataobj = { html: template.html, css: template.css, javascript: template.javascript };
      var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,
      var options = { data: dataobj };                                 // 461
                                                                       //
      var newpagetype = "user_libs";                                   // 463
      var newpageid = Meteor.user().username;                          // 464
      var newpageurl = newpagetype + "/" + newpageurl;                 // 465
                                                                       //
      HTTP.post(url, options, function (error, results) {              // 467
        newWidget = { _id: results.data.url,                           // 468
          createdBy: { username: Meteor.user().username,               // 469
            userid: Meteor.userId() },                                 // 470
          inLibrary: true,                                             // 471
          html: results.data.html,                                     // 472
          javascript: results.data.javascript,                         // 473
          css: results.data.css,                                       // 474
          displayWidth: template.displayWidth,                         // 475
          displayHeight: template.displayHeight,                       // 476
          description: "(copied from " + template.name + ") " + template.description,
          widgetStyle: template.widgetStyle,                           // 478
          name: "copy of " + template.name,                            // 479
          pagetype: newpagetype,                                       // 480
          pageurl: newpageurl,                                         // 481
          pageid: newpageid,                                           // 482
          this_page_only: true,                                        // 483
          url: results.data.url,                                       // 484
          createdAt: new Date(),                                       // 485
          visibility: "private",                                       // 486
          rand: Math.random() };                                       // 487
        Widgets.insert(newWidget);                                     // 488
      });                                                              //
                                                                       //
      giphy_modal("library", "widget added to your library");          // 491
                                                                       //
      return false;                                                    // 493
    },                                                                 //
                                                                       //
    "click .openinfo": function () {                                   // 496
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      var mode = $(thiselement).data("mode");                          // 498
      if (!mode || mode == "display") {                                // 499
        //      $(".widgetMouseOverTarget", thiselement ).css("background", "red");
        $(".widgetDisplayHeader", thiselement).show();                 // 501
        $(".widgetMouseOverTarget", thiselement).css("z-index", 5);    // 502
        $(".widgetDisplayHeader", thiselement).css("z-index", 10);     // 503
      }                                                                //
    },                                                                 //
                                                                       //
    "mouseleave .widgetDisplayHeader": function () {                   // 508
      var thiselement = document.getElementById('widgetContainer_' + this._id);
      $(".widgetMouseOverTarget", thiselement).css("background", "transparent");
      $(".widgetDisplayHeader", thiselement).hide();                   // 511
      $(".widgetMouseOverTarget", thiselement).css("z-index", 10);     // 512
      $(".widgetDisplayHeader", thiselement).css("z-index", 5);        // 513
    }                                                                  //
                                                                       //
  });                                                                  //
  ////// END EVENTS                                                    //
                                                                       //
  ////// HELPERS                                                       //
                                                                       //
  Template.widget.helpers({                                            // 523
    otherwidgets: function () {                                        // 524
      // Otherwise, return all of the tasks                            //
      return Widgets.find({ pagetype: pageinfo().pagetype, _id: { $ne: this._id } }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
    },                                                                 //
                                                                       //
    isPublic: function () {                                            // 529
      if (this.visibility == "public") {                               // 530
        return true;                                                   // 531
      }                                                                //
      return false;                                                    // 533
    },                                                                 //
                                                                       //
    pageTypeAndUrl: function () {                                      // 536
                                                                       //
      return this.pagetype + "/" + this.url;                           // 538
    },                                                                 //
                                                                       //
    pageUrlAndUrl: function () {                                       // 541
      return pageinfo().pageurl + "/" + this.url;                      // 542
    },                                                                 //
                                                                       //
    commentsCount: function (id) {                                     // 545
      console.log("in commentsCount " + id);                           // 546
      var value = "";                                                  // 547
      console.log("value is " + value);                                // 548
      return value;                                                    // 549
    },                                                                 //
                                                                       //
    isMyWidget: function () {                                          // 552
      // is this a widget I created?                                   //
      if (getUserXtras().godmode) {                                    // 554
        return true;                                                   // 555
      }                                                                //
      if (this.createdBy && Meteor.user()) {                           // 557
        return this.createdBy.username == Meteor.user().username;      // 558
      } else {                                                         //
        return false;                                                  // 560
      }                                                                //
    },                                                                 //
                                                                       //
    userXtras: function () {                                           // 564
      return getUserXtras();                                           // 565
    },                                                                 //
                                                                       //
    godmode: function () {                                             // 568
      return getUserXtras().godmode;                                   // 569
    }                                                                  //
  });                                                                  //
  //////// END HELPERS                                                 //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=widget.js.map
