(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Accounts = Package['accounts-base'].Accounts;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var Random = Package.random.Random;
var Showdown = Package.markdown.Showdown;
var ReactiveDict = Package['reactive-dict'].ReactiveDict;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var moment = Package['momentjs:moment'].moment;
var Avatar = Package['utilities:avatar'].Avatar;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

/* Package-scope variables */
var AnonymousUserCollection, CommentsCollection, Comments;

var require = meteorInstall({"node_modules":{"meteor":{"arkham:comments-ui":{"lib":{"collections":{"anonymous-user.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/collections/anonymous-user.js                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
AnonymousUserCollection = new Mongo.Collection('commentsui-anonymoususer');                                           // 1
                                                                                                                      //
AnonymousUserCollection.allow({                                                                                       // 3
  insert: function insert() {                                                                                         // 4
    return false;                                                                                                     // 4
  },                                                                                                                  // 4
  update: function update() {                                                                                         // 5
    return false;                                                                                                     // 5
  },                                                                                                                  // 5
  remove: function remove() {                                                                                         // 6
    return false;                                                                                                     // 6
  }                                                                                                                   // 6
});                                                                                                                   // 3
                                                                                                                      //
AnonymousUserCollection.attachSchema(new SimpleSchema({                                                               // 9
  username: {                                                                                                         // 10
    type: String,                                                                                                     // 11
    optional: true                                                                                                    // 12
  },                                                                                                                  // 10
  email: {                                                                                                            // 14
    type: String,                                                                                                     // 15
    optional: true                                                                                                    // 16
  },                                                                                                                  // 14
  anonIp: {                                                                                                           // 18
    type: String                                                                                                      // 19
  },                                                                                                                  // 18
  salt: {                                                                                                             // 21
    type: String                                                                                                      // 22
  },                                                                                                                  // 21
  createdAt: {                                                                                                        // 24
    type: Date,                                                                                                       // 25
    autoValue: function autoValue() {                                                                                 // 26
      if (this.isInsert) {                                                                                            // 27
        return new Date();                                                                                            // 28
      } else if (this.isUpsert) {                                                                                     // 29
        return { $setOnInsert: new Date() };                                                                          // 30
      } else {                                                                                                        // 31
        this.unset();                                                                                                 // 32
      }                                                                                                               // 33
    }                                                                                                                 // 34
  }                                                                                                                   // 24
}));                                                                                                                  // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":["babel-runtime/helpers/extends","../services/time-tick","../services/user","linkifyjs/string",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/collections/comments.js                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _extends2 = require('babel-runtime/helpers/extends');                                                             //
                                                                                                                      //
var _extends3 = _interopRequireDefault(_extends2);                                                                    //
                                                                                                                      //
var _timeTick = require('../services/time-tick');                                                                     // 1
                                                                                                                      //
var _timeTick2 = _interopRequireDefault(_timeTick);                                                                   //
                                                                                                                      //
var _user = require('../services/user');                                                                              // 2
                                                                                                                      //
var _user2 = _interopRequireDefault(_user);                                                                           //
                                                                                                                      //
var _string = require('linkifyjs/string');                                                                            // 3
                                                                                                                      //
var _string2 = _interopRequireDefault(_string);                                                                       //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                     //
                                                                                                                      //
CommentsCollection = new Mongo.Collection('comments');                                                                // 5
                                                                                                                      //
CommentsCollection.schemas = {};                                                                                      // 7
                                                                                                                      //
CommentsCollection.schemas.StarRatingSchema = new SimpleSchema({                                                      // 9
  userId: {                                                                                                           // 10
    type: String                                                                                                      // 11
  },                                                                                                                  // 10
  rating: {                                                                                                           // 13
    type: Number                                                                                                      // 14
  }                                                                                                                   // 13
});                                                                                                                   // 9
                                                                                                                      //
/**                                                                                                                   //
 * Return a comment schema enhanced with the given schema config.                                                     //
 *                                                                                                                    //
 * @param additionalSchemaConfig                                                                                      //
 *                                                                                                                    //
 * @returns {Object}                                                                                                  //
 */                                                                                                                   //
function getCommonCommentSchema() {                                                                                   // 25
  var additionalSchemaConfig = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];               // 25
                                                                                                                      //
  return (0, _extends3['default'])({                                                                                  // 26
    userId: {                                                                                                         // 27
      type: String                                                                                                    // 28
    },                                                                                                                // 27
    isAnonymous: {                                                                                                    // 30
      type: Boolean,                                                                                                  // 31
      autoValue: function autoValue() {                                                                               // 32
        if (this.isInsert) {                                                                                          // 33
          return false;                                                                                               // 34
        }                                                                                                             // 35
      }                                                                                                               // 36
    },                                                                                                                // 30
    'media.type': {                                                                                                   // 38
      type: String,                                                                                                   // 39
      optional: true                                                                                                  // 40
    },                                                                                                                // 38
    'media.content': {                                                                                                // 42
      type: String,                                                                                                   // 43
      optional: true                                                                                                  // 44
    },                                                                                                                // 42
    content: {                                                                                                        // 46
      type: String,                                                                                                   // 47
      min: 1,                                                                                                         // 48
      max: 10000                                                                                                      // 49
    },                                                                                                                // 46
    replies: {                                                                                                        // 51
      type: [Object],                                                                                                 // 52
      autoValue: function autoValue() {                                                                               // 53
        if (this.isInsert) {                                                                                          // 54
          return [];                                                                                                  // 55
        }                                                                                                             // 56
      },                                                                                                              // 57
      optional: true                                                                                                  // 58
    },                                                                                                                // 51
    likes: {                                                                                                          // 60
      type: [String],                                                                                                 // 61
      autoValue: function autoValue() {                                                                               // 62
        if (this.isInsert) {                                                                                          // 63
          return [];                                                                                                  // 64
        }                                                                                                             // 65
      },                                                                                                              // 66
      optional: true                                                                                                  // 67
    },                                                                                                                // 60
    starRatings: {                                                                                                    // 69
      type: [CommentsCollection.schemas.StarRatingSchema],                                                            // 70
      autoValue: function autoValue() {                                                                               // 71
        if (this.isInsert) {                                                                                          // 72
          return [];                                                                                                  // 73
        }                                                                                                             // 74
      },                                                                                                              // 75
      optional: true                                                                                                  // 76
    },                                                                                                                // 69
    // general rating number that is used for sorting                                                                 //
    ratingScore: {                                                                                                    // 79
      type: Number,                                                                                                   // 80
      decimal: true,                                                                                                  // 81
      autoValue: function autoValue() {                                                                               // 82
        if (this.isInsert) {                                                                                          // 83
          return 0;                                                                                                   // 84
        }                                                                                                             // 85
      }                                                                                                               // 86
    },                                                                                                                // 79
    createdAt: {                                                                                                      // 88
      type: Date,                                                                                                     // 89
      autoValue: function autoValue() {                                                                               // 90
        if (this.isInsert) {                                                                                          // 91
          return new Date();                                                                                          // 92
        } else if (this.isUpsert) {                                                                                   // 93
          return { $setOnInsert: new Date() };                                                                        // 94
        } else {                                                                                                      // 95
          this.unset();                                                                                               // 96
        }                                                                                                             // 97
      }                                                                                                               // 98
    },                                                                                                                // 88
    lastUpdatedAt: {                                                                                                  // 100
      type: Date,                                                                                                     // 101
      autoValue: function autoValue() {                                                                               // 102
        if (this.isUpdate) {                                                                                          // 103
          return new Date();                                                                                          // 104
        }                                                                                                             // 105
      },                                                                                                              // 106
      denyInsert: true,                                                                                               // 107
      optional: true                                                                                                  // 108
    }                                                                                                                 // 100
  }, additionalSchemaConfig);                                                                                         // 26
}                                                                                                                     // 112
                                                                                                                      //
/**                                                                                                                   //
 * Enhance nested replies with correct data.                                                                          //
 *                                                                                                                    //
 * @param {Object} scope                                                                                              //
 * @param {Array} position                                                                                            //
 *                                                                                                                    //
 * @returns {Array}                                                                                                   //
 */                                                                                                                   //
function enhanceReplies(scope, position) {                                                                            // 122
  if (!position) {                                                                                                    // 123
    position = [];                                                                                                    // 124
  }                                                                                                                   // 125
                                                                                                                      //
  return _.map(scope.replies, function (reply, index) {                                                               // 127
    position.push(index);                                                                                             // 128
                                                                                                                      //
    reply = Object.assign(reply, {                                                                                    // 130
      position: position.slice(0),                                                                                    // 131
      documentId: scope._id,                                                                                          // 132
      user: scope.user.bind(reply),                                                                                   // 133
      likesCount: scope.likesCount.bind(reply),                                                                       // 134
      createdAgo: scope.createdAgo.bind(reply),                                                                       // 135
      getStarRating: scope.getStarRating.bind(reply),                                                                 // 136
      enhancedContent: scope.enhancedContent.bind(reply)                                                              // 137
    });                                                                                                               // 130
                                                                                                                      //
    if (reply.replies) {                                                                                              // 140
      // recursive!                                                                                                   //
      reply.enhancedReplies = _.bind(enhanceReplies, null, _.extend(_.clone(scope), { replies: reply.replies }), position)();
    }                                                                                                                 // 148
                                                                                                                      //
    position.pop();                                                                                                   // 150
                                                                                                                      //
    return reply;                                                                                                     // 152
  });                                                                                                                 // 153
}                                                                                                                     // 154
                                                                                                                      //
CommentsCollection.schemas.ReplySchema = new SimpleSchema(getCommonCommentSchema({                                    // 156
  replyId: {                                                                                                          // 157
    type: String                                                                                                      // 158
  }                                                                                                                   // 157
}));                                                                                                                  // 156
                                                                                                                      //
CommentsCollection.schemas.CommentSchema = new SimpleSchema(getCommonCommentSchema({                                  // 162
  referenceId: {                                                                                                      // 163
    type: String                                                                                                      // 164
  }                                                                                                                   // 163
}));                                                                                                                  // 162
                                                                                                                      //
CommentsCollection.attachSchema(CommentsCollection.schemas.CommentSchema);                                            // 168
                                                                                                                      //
// Is handled with Meteor.methods                                                                                     //
CommentsCollection.allow({                                                                                            // 171
  insert: function insert() {                                                                                         // 172
    return false;                                                                                                     // 172
  },                                                                                                                  // 172
  update: function update() {                                                                                         // 173
    return false;                                                                                                     // 173
  },                                                                                                                  // 173
  remove: function remove() {                                                                                         // 174
    return false;                                                                                                     // 174
  }                                                                                                                   // 174
});                                                                                                                   // 171
                                                                                                                      //
var calculateAverageRating = function calculateAverageRating(ratings) {                                               // 177
  return _.reduce(ratings, function (averageRating, rating) {                                                         // 177
    return averageRating + rating.rating / ratings.length;                                                            // 179
  }, 0);                                                                                                              // 179
};                                                                                                                    // 177
                                                                                                                      //
CommentsCollection._calculateAverageRating = calculateAverageRating;                                                  // 183
                                                                                                                      //
CommentsCollection.helpers({                                                                                          // 185
  likesCount: function likesCount() {                                                                                 // 186
    if (this.likes && this.likes.length) {                                                                            // 187
      return this.likes.length;                                                                                       // 188
    }                                                                                                                 // 189
                                                                                                                      //
    return 0;                                                                                                         // 191
  },                                                                                                                  // 192
  user: function user() {                                                                                             // 193
    return _user2['default'].getUserById(this.userId);                                                                // 194
  },                                                                                                                  // 195
  createdAgo: function createdAgo() {                                                                                 // 196
    return _timeTick2['default'].fromNowReactive(moment(this.createdAt));                                             // 197
  },                                                                                                                  // 198
  enhancedReplies: function enhancedReplies(position) {                                                               // 199
    return enhanceReplies(this, position);                                                                            // 200
  },                                                                                                                  // 201
  enhancedContent: function enhancedContent() {                                                                       // 202
    return (0, _string2['default'])(this.content);                                                                    // 203
  },                                                                                                                  // 204
  getStarRating: function getStarRating() {                                                                           // 205
    if (_.isArray(this.starRatings)) {                                                                                // 206
      var ownRating = _.find(this.starRatings, function (rating) {                                                    // 207
        return rating.userId === Meteor.userId();                                                                     // 207
      });                                                                                                             // 207
                                                                                                                      //
      if (ownRating) {                                                                                                // 209
        return {                                                                                                      // 210
          type: 'user',                                                                                               // 211
          rating: ownRating.rating                                                                                    // 212
        };                                                                                                            // 210
      }                                                                                                               // 214
                                                                                                                      //
      return {                                                                                                        // 216
        type: 'average',                                                                                              // 217
        rating: calculateAverageRating(this.starRatings)                                                              // 218
      };                                                                                                              // 216
    }                                                                                                                 // 220
                                                                                                                      //
    return {                                                                                                          // 222
      type: 'average',                                                                                                // 223
      rating: 0                                                                                                       // 224
    };                                                                                                                // 222
  }                                                                                                                   // 226
});                                                                                                                   // 185
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods":{"anonymous-user.js":["../../services/hashing",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/collections/methods/anonymous-user.js                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _hashing = require('../../services/hashing');                                                                     // 1
                                                                                                                      //
var _hashing2 = _interopRequireDefault(_hashing);                                                                     //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                     //
                                                                                                                      //
Meteor.methods({                                                                                                      // 3
  'commentsUiAnonymousUser/add': function commentsUiAnonymousUserAdd(data) {                                          // 4
    check(data, {                                                                                                     // 5
      username: String,                                                                                               // 6
      email: String                                                                                                   // 7
    });                                                                                                               // 5
                                                                                                                      //
    if (Meteor.isServer) {                                                                                            // 10
      data.salt = _hashing2['default'].hash(data);                                                                    // 11
      data.anonIp = this.connection.clientAddress;                                                                    // 12
    } else {                                                                                                          // 13
      data.salt = 'fake';                                                                                             // 14
      data.anonIp = 'fake';                                                                                           // 15
    }                                                                                                                 // 16
                                                                                                                      //
    if (AnonymousUserCollection.find({ anonIp: data.anonIp, createdAt: { $gte: moment().subtract(10, 'days').toDate() } }).count() >= 5) {
      throw new Meteor.Error('More than 5 anonymous accounts with the same IP');                                      // 19
    }                                                                                                                 // 20
                                                                                                                      //
    return {                                                                                                          // 22
      _id: AnonymousUserCollection.insert(data),                                                                      // 23
      salt: data.salt                                                                                                 // 24
    };                                                                                                                // 22
  },                                                                                                                  // 26
  'commentsUiAnonymousUser/update': function commentsUiAnonymousUserUpdate(_id, salt, data) {                         // 27
    check(_id, String);                                                                                               // 28
    check(salt, String);                                                                                              // 29
    check(data, {                                                                                                     // 30
      username: Match.Optional(String),                                                                               // 31
      email: Match.Optional(String)                                                                                   // 32
    });                                                                                                               // 30
                                                                                                                      //
    return AnonymousUserCollection.update({ _id: _id, salt: salt }, { $set: data });                                  // 35
  }                                                                                                                   // 36
});                                                                                                                   // 3
                                                                                                                      //
AnonymousUserCollection.methods = {                                                                                   // 39
  add: function add(data, cb) {                                                                                       // 40
    return Meteor.call('commentsUiAnonymousUser/add', data, cb);                                                      // 40
  },                                                                                                                  // 40
  update: function update(id, salt, data, cb) {                                                                       // 41
    return Meteor.call('commentsUiAnonymousUser/update', id, salt, data, cb);                                         // 41
  }                                                                                                                   // 41
};                                                                                                                    // 39
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"comments.js":["../../services/media","../../services/user",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/collections/methods/comments.js                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _media = require('../../services/media');                                                                         // 1
                                                                                                                      //
var _media2 = _interopRequireDefault(_media);                                                                         //
                                                                                                                      //
var _user = require('../../services/user');                                                                           // 2
                                                                                                                      //
var _user2 = _interopRequireDefault(_user);                                                                           //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                     //
                                                                                                                      //
var noOptOptions = {                                                                                                  // 4
  validate: false,                                                                                                    // 5
  filter: false,                                                                                                      // 6
  getAutoValues: false,                                                                                               // 7
  removeEmptyStrings: false                                                                                           // 8
};                                                                                                                    // 4
                                                                                                                      //
/**                                                                                                                   //
 * Modify replies with a callback in a nested array.                                                                  //
 *                                                                                                                    //
 * @param {Array} nestedArray                                                                                         //
 * @param {Array} position Array of numbers with indexes throughout the reply tree.                                   //
 * @param {Function} callback                                                                                         //
 */                                                                                                                   //
function modifyNestedReplies(nestedArray, position, callback) {                                                       // 18
  var currentPos = position.shift();                                                                                  // 19
                                                                                                                      //
  if (nestedArray[currentPos]) {                                                                                      // 21
    if (position.length && nestedArray[currentPos] && nestedArray[currentPos].replies) {                              // 22
      modifyNestedReplies(nestedArray[currentPos].replies, position, callback);                                       // 23
    } else {                                                                                                          // 24
      callback(nestedArray, currentPos);                                                                              // 25
    }                                                                                                                 // 26
  }                                                                                                                   // 27
}                                                                                                                     // 28
                                                                                                                      //
/**                                                                                                                   //
 * Call a meteor method with anonymous user id if there is as the last argument.                                      //
 *                                                                                                                    //
 * @param {String} methodName                                                                                         //
 * @param {Array} methodArgs                                                                                          //
 */                                                                                                                   //
function callWithAnonUserData(methodName) {                                                                           // 36
  var anonUserData = _user2['default'].isAnonymous() ? _user2['default'].getUserData() : {};                          // 37
                                                                                                                      //
  for (var _len = arguments.length, methodArgs = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {     // 36
    methodArgs[_key - 1] = arguments[_key];                                                                           // 36
  }                                                                                                                   // 36
                                                                                                                      //
  Meteor.apply(methodName, [].concat(methodArgs, [anonUserData]));                                                    // 38
}                                                                                                                     // 39
                                                                                                                      //
/**                                                                                                                   //
 * Return a mongodb style field descriptor                                                                            //
 *                                                                                                                    //
 * e.g "replies.0.replies.1" which points at the second reply of the first reply.                                     //
 *                                                                                                                    //
 * @param {undefined|Array} position                                                                                  //
 *                                                                                                                    //
 * @return {String}                                                                                                   //
 */                                                                                                                   //
function getMongoReplyFieldDescriptor(position) {                                                                     // 50
  if (!position) {                                                                                                    // 51
    return '';                                                                                                        // 52
  }                                                                                                                   // 53
                                                                                                                      //
  var descriptorWithLeadingDot = _.reduce(position, function (descriptor, positionNumber) {                           // 55
    return descriptor + 'replies.' + positionNumber + '.';                                                            // 56
  }, '');                                                                                                             // 57
                                                                                                                      //
  return descriptorWithLeadingDot.substr(0, descriptorWithLeadingDot.length - 1);                                     // 59
}                                                                                                                     // 60
                                                                                                                      //
var triggerEvent = function triggerEvent(name, action, payload) {                                                     // 62
  var func = Comments.config().onEvent;                                                                               // 63
                                                                                                                      //
  if (_.isFunction(func)) {                                                                                           // 65
    func(name, action, payload);                                                                                      // 66
  }                                                                                                                   // 67
};                                                                                                                    // 68
                                                                                                                      //
var getRatingScore = function getRatingScore(doc) {                                                                   // 70
  var score = CommentsCollection._calculateAverageRating(doc.starRatings);                                            // 71
                                                                                                                      //
  if (score === 0) {                                                                                                  // 73
    score = doc.likes.length;                                                                                         // 74
  }                                                                                                                   // 75
                                                                                                                      //
  return score;                                                                                                       // 77
};                                                                                                                    // 78
                                                                                                                      //
var updateRatingScoreOnDoc = function updateRatingScoreOnDoc(_id) {                                                   // 80
  CommentsCollection.update({ _id: _id }, {                                                                           // 81
    $set: { ratingScore: getRatingScore(CommentsCollection.findOne(_id)) }                                            // 82
  });                                                                                                                 // 81
};                                                                                                                    // 84
                                                                                                                      //
// TODO: add unit tests + good user testing (bootstrap, ionic and so on)!                                             //
                                                                                                                      //
Meteor.methods({                                                                                                      // 88
  'comments/add': function commentsAdd(referenceId, content, anonUserData) {                                          // 89
    check(referenceId, String);                                                                                       // 90
    check(content, String);                                                                                           // 91
                                                                                                                      //
    _user2['default'].verifyAnonUserData(anonUserData);                                                               // 93
    var userId = this.userId || anonUserData._id;                                                                     // 94
                                                                                                                      //
    content = content.trim();                                                                                         // 96
                                                                                                                      //
    if (userId && content) {                                                                                          // 98
      var doc = {                                                                                                     // 99
        referenceId: referenceId,                                                                                     // 100
        content: content,                                                                                             // 101
        userId: userId,                                                                                               // 102
        createdAt: new Date(),                                                                                        // 103
        likes: [],                                                                                                    // 104
        replies: [],                                                                                                  // 105
        isAnonymous: !!anonUserData._id,                                                                              // 106
        media: _media2['default'].getMediaFromContent(content)                                                        // 107
      };                                                                                                              // 99
                                                                                                                      //
      var docId = CommentsCollection.insert(doc);                                                                     // 110
                                                                                                                      //
      triggerEvent('comment', 'add', Object.assign({}, doc, { _id: docId }));                                         // 112
    }                                                                                                                 // 113
  },                                                                                                                  // 114
  'comments/edit': function commentsEdit(documentId, newContent, anonUserData) {                                      // 115
    check(documentId, String);                                                                                        // 116
    check(newContent, String);                                                                                        // 117
                                                                                                                      //
    _user2['default'].verifyAnonUserData(anonUserData);                                                               // 119
    var userId = this.userId || anonUserData._id;                                                                     // 120
                                                                                                                      //
    newContent = newContent.trim();                                                                                   // 122
                                                                                                                      //
    if (!userId || !newContent) {                                                                                     // 124
      return;                                                                                                         // 125
    }                                                                                                                 // 126
                                                                                                                      //
    var setDoc = { content: newContent, likes: [], media: _media2['default'].getMediaFromContent(newContent), ratingScore: 0 };
    var findSelector = { _id: documentId, userId: userId };                                                           // 129
                                                                                                                      //
    CommentsCollection.update(findSelector, { $set: setDoc });                                                        // 131
                                                                                                                      //
    triggerEvent('comment', 'edit', Object.assign({}, setDoc, findSelector));                                         // 136
  },                                                                                                                  // 137
  'comments/remove': function commentsRemove(documentId, anonUserData) {                                              // 138
    check(documentId, String);                                                                                        // 139
                                                                                                                      //
    _user2['default'].verifyAnonUserData(anonUserData);                                                               // 141
    var userId = this.userId || anonUserData._id;                                                                     // 142
                                                                                                                      //
    var removeSelector = { _id: documentId, userId: userId };                                                         // 144
                                                                                                                      //
    var doc = CommentsCollection.findOne(removeSelector);                                                             // 146
                                                                                                                      //
    CommentsCollection.remove(removeSelector);                                                                        // 148
                                                                                                                      //
    triggerEvent('comment', 'remove', doc);                                                                           // 150
  },                                                                                                                  // 151
  'comments/like': function commentsLike(documentId, anonUserData) {                                                  // 152
    check(documentId, String);                                                                                        // 153
                                                                                                                      //
    _user2['default'].verifyAnonUserData(anonUserData);                                                               // 155
    var userId = this.userId || anonUserData._id;                                                                     // 156
                                                                                                                      //
    if (!userId || Comments.config().rating !== 'likes') {                                                            // 158
      return;                                                                                                         // 159
    }                                                                                                                 // 160
                                                                                                                      //
    var findSelector = { _id: documentId };                                                                           // 162
                                                                                                                      //
    var likedDoc = CommentsCollection.findOne({ _id: documentId, likes: { $in: [userId] } });                         // 164
                                                                                                                      //
    if (likedDoc) {                                                                                                   // 166
      CommentsCollection.update(findSelector, { $pull: { likes: userId } }, noOptOptions);                            // 167
    } else {                                                                                                          // 168
      CommentsCollection.update(findSelector, { $push: { likes: userId } }, noOptOptions);                            // 169
    }                                                                                                                 // 170
                                                                                                                      //
    updateRatingScoreOnDoc(documentId);                                                                               // 172
                                                                                                                      //
    triggerEvent('comment', 'like', Object.assign({}, likedDoc, findSelector, {                                       // 174
      ratedUserId: userId                                                                                             // 175
    }));                                                                                                              // 174
  },                                                                                                                  // 177
  'comments/star': function commentsStar(documentId, starsCount, anonUserData) {                                      // 178
    check(documentId, String);                                                                                        // 179
    check(starsCount, Number);                                                                                        // 180
                                                                                                                      //
    _user2['default'].verifyAnonUserData(anonUserData);                                                               // 182
    var userId = this.userId || anonUserData._id;                                                                     // 183
                                                                                                                      //
    if (!userId || Comments.config().rating !== 'stars') {                                                            // 185
      return;                                                                                                         // 186
    }                                                                                                                 // 187
                                                                                                                      //
    var findSelector = { _id: documentId };                                                                           // 189
                                                                                                                      //
    var starredDoc = CommentsCollection.findOne({ _id: documentId, 'starRatings.userId': userId });                   // 191
                                                                                                                      //
    if (starredDoc) {                                                                                                 // 193
      CommentsCollection.update(findSelector, { $pull: { starRatings: { userId: userId } } }, noOptOptions);          // 194
    }                                                                                                                 // 195
                                                                                                                      //
    CommentsCollection.update(findSelector, { $push: { starRatings: { userId: userId, rating: starsCount } } });      // 197
                                                                                                                      //
    updateRatingScoreOnDoc(documentId);                                                                               // 199
                                                                                                                      //
    triggerEvent('comment', 'star', Object.assign({}, starredDoc, findSelector, {                                     // 201
      ratedUserId: userId,                                                                                            // 202
      rating: starsCount                                                                                              // 203
    }));                                                                                                              // 201
  },                                                                                                                  // 205
  'comments/reply/add': function commentsReplyAdd(documentId, docScope, content, anonUserData) {                      // 206
    var _$push;                                                                                                       // 206
                                                                                                                      //
    check(documentId, String);                                                                                        // 207
    check(docScope, Object);                                                                                          // 208
    check(content, String);                                                                                           // 209
    _user2['default'].verifyAnonUserData(anonUserData);                                                               // 210
                                                                                                                      //
    var doc = CommentsCollection.findOne({ _id: documentId }),                                                        // 212
        userId = this.userId || anonUserData._id;                                                                     // 212
                                                                                                                      //
    content = content.trim();                                                                                         // 215
                                                                                                                      //
    if (!doc || !userId || !content || !Comments.config().replies) {                                                  // 217
      return false;                                                                                                   // 218
    }                                                                                                                 // 219
                                                                                                                      //
    var reply = {                                                                                                     // 221
      replyId: Random.id(),                                                                                           // 222
      content: content,                                                                                               // 223
      userId: userId,                                                                                                 // 224
      createdAt: new Date(),                                                                                          // 225
      replies: [], likes: [],                                                                                         // 226
      lastUpdatedAt: new Date(),                                                                                      // 227
      isAnonymous: !!anonUserData._id,                                                                                // 228
      media: _media2['default'].getMediaFromContent(content),                                                         // 229
      ratingScore: 0                                                                                                  // 230
    };                                                                                                                // 221
                                                                                                                      //
    check(reply, CommentsCollection.schemas.ReplySchema);                                                             // 233
                                                                                                                      //
    var fieldDescriptor = 'replies';                                                                                  // 235
                                                                                                                      //
    if (docScope.position) {                                                                                          // 237
      fieldDescriptor = getMongoReplyFieldDescriptor(docScope.position) + '.replies';                                 // 238
    }                                                                                                                 // 239
                                                                                                                      //
    var modifier = {                                                                                                  // 241
      $push: (_$push = {}, _$push[fieldDescriptor] = {                                                                // 242
        $each: [reply],                                                                                               // 244
        $position: 0                                                                                                  // 245
      }, _$push)                                                                                                      // 243
    };                                                                                                                // 241
                                                                                                                      //
    var findSelector = { _id: documentId };                                                                           // 250
                                                                                                                      //
    CommentsCollection.update(findSelector, modifier, noOptOptions);                                                  // 252
    triggerEvent('reply', 'add', Object.assign({}, reply, findSelector, {                                             // 253
      userId: userId,                                                                                                 // 254
      rootUserId: doc.userId                                                                                          // 255
    }));                                                                                                              // 253
  },                                                                                                                  // 257
  'comments/reply/edit': function commentsReplyEdit(documentId, docScope, newContent, anonUserData) {                 // 258
    check(documentId, String);                                                                                        // 259
    check(docScope, Object);                                                                                          // 260
    check(newContent, String);                                                                                        // 261
                                                                                                                      //
    _user2['default'].verifyAnonUserData(anonUserData);                                                               // 263
                                                                                                                      //
    var doc = CommentsCollection.findOne(documentId),                                                                 // 265
        userId = this.userId || anonUserData._id;                                                                     // 265
                                                                                                                      //
    var reply = {};                                                                                                   // 268
                                                                                                                      //
    newContent = newContent.trim();                                                                                   // 270
                                                                                                                      //
    if (!userId || !newContent || !Comments.config().replies) {                                                       // 272
      return;                                                                                                         // 273
    }                                                                                                                 // 274
                                                                                                                      //
    modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                                   // 276
      if (replies[index].userId === userId) {                                                                         // 277
        replies[index].content = newContent;                                                                          // 278
        replies[index].likes = [];                                                                                    // 279
        replies[index].starRatings = [];                                                                              // 280
        replies[index].ratingScore = 0;                                                                               // 281
        replies[index].media = _media2['default'].getMediaFromContent(newContent);                                    // 282
        reply = replies[index];                                                                                       // 283
      }                                                                                                               // 284
    });                                                                                                               // 285
                                                                                                                      //
    var findSelector = { _id: documentId };                                                                           // 287
                                                                                                                      //
    CommentsCollection.update(findSelector, { $set: { replies: doc.replies } }, noOptOptions);                        // 289
    triggerEvent('reply', 'edit', Object.assign({}, findSelector, reply, {                                            // 290
      ratedUserId: userId,                                                                                            // 291
      rootUserId: doc.userId                                                                                          // 292
    }));                                                                                                              // 290
  },                                                                                                                  // 294
  'comments/reply/like': function commentsReplyLike(documentId, docScope, anonUserData) {                             // 295
    check(documentId, String);                                                                                        // 296
    check(docScope, Object);                                                                                          // 297
    _user2['default'].verifyAnonUserData(anonUserData);                                                               // 298
                                                                                                                      //
    var doc = CommentsCollection.findOne({ _id: documentId }),                                                        // 300
        userId = this.userId || anonUserData._id;                                                                     // 300
                                                                                                                      //
    if (!userId || !Comments.config().replies || Comments.config().rating !== 'likes') {                              // 303
      return false;                                                                                                   // 304
    }                                                                                                                 // 305
                                                                                                                      //
    var reply = {};                                                                                                   // 307
                                                                                                                      //
    modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                                   // 309
      if (replies[index].likes.indexOf(userId) > -1) {                                                                // 310
        replies[index].likes.splice(replies[index].likes.indexOf(userId), 1);                                         // 311
      } else {                                                                                                        // 312
        replies[index].likes.push(userId);                                                                            // 313
      }                                                                                                               // 314
                                                                                                                      //
      reply = replies[index];                                                                                         // 316
      replies[index].ratingScore = getRatingScore(replies[index]);                                                    // 317
    });                                                                                                               // 318
                                                                                                                      //
    var findSelector = { _id: documentId };                                                                           // 320
                                                                                                                      //
    CommentsCollection.update(findSelector, { $set: { replies: doc.replies } }, noOptOptions);                        // 322
    triggerEvent('reply', 'like', Object.assign({}, reply, findSelector, {                                            // 323
      ratedUserId: userId,                                                                                            // 324
      rootUserId: doc.userId                                                                                          // 325
    }));                                                                                                              // 323
  },                                                                                                                  // 327
  'comments/reply/star': function commentsReplyStar(documentId, docScope, starsCount, anonUserData) {                 // 328
    check(documentId, String);                                                                                        // 329
    check(docScope, Object);                                                                                          // 330
    check(starsCount, Number);                                                                                        // 331
    _user2['default'].verifyAnonUserData(anonUserData);                                                               // 332
                                                                                                                      //
    var doc = CommentsCollection.findOne({ _id: documentId }),                                                        // 334
        userId = this.userId || anonUserData._id;                                                                     // 334
                                                                                                                      //
    if (!userId || !Comments.config().replies || Comments.config().rating !== 'stars') {                              // 337
      return false;                                                                                                   // 338
    }                                                                                                                 // 339
                                                                                                                      //
    var reply = {};                                                                                                   // 341
                                                                                                                      //
    modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                                   // 343
      var starRatings = replies[index].starRatings;                                                                   // 344
                                                                                                                      //
      if (!starRatings) {                                                                                             // 346
        starRatings = [];                                                                                             // 347
      }                                                                                                               // 348
                                                                                                                      //
      var ratings = starRatings;                                                                                      // 350
                                                                                                                      //
      if (_.find(starRatings, function (rating) {                                                                     // 352
        return rating.userId === userId;                                                                              // 352
      })) {                                                                                                           // 352
        ratings = _.filter(starRatings, function (rating) {                                                           // 353
          return rating.userId !== userId;                                                                            // 353
        });                                                                                                           // 353
      }                                                                                                               // 354
                                                                                                                      //
      ratings.push({ userId: userId, rating: starsCount });                                                           // 356
      replies[index].starRatings = ratings;                                                                           // 357
      replies[index].ratingScore = getRatingScore(replies[index]);                                                    // 358
      reply = replies[index];                                                                                         // 359
    });                                                                                                               // 360
                                                                                                                      //
    var findSelector = { _id: documentId };                                                                           // 362
                                                                                                                      //
    CommentsCollection.update(findSelector, { $set: { replies: doc.replies } }, noOptOptions);                        // 364
    triggerEvent('reply', 'star', Object.assign({}, reply, findSelector, {                                            // 365
      ratedUserId: userId,                                                                                            // 366
      rating: starsCount,                                                                                             // 367
      rootUserId: doc.userId                                                                                          // 368
    }));                                                                                                              // 365
  },                                                                                                                  // 370
  'comments/reply/remove': function commentsReplyRemove(documentId, docScope, anonUserData) {                         // 371
    check(documentId, String);                                                                                        // 372
    check(docScope, Object);                                                                                          // 373
    _user2['default'].verifyAnonUserData(anonUserData);                                                               // 374
                                                                                                                      //
    var doc = CommentsCollection.findOne({ _id: documentId }),                                                        // 376
        userId = this.userId || anonUserData._id;                                                                     // 376
                                                                                                                      //
    var reply = {};                                                                                                   // 379
                                                                                                                      //
    if (!userId || !Comments.config().replies) {                                                                      // 381
      return;                                                                                                         // 382
    }                                                                                                                 // 383
                                                                                                                      //
    modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                                   // 385
      if (replies[index].userId === userId) {                                                                         // 386
        reply = replies[index];                                                                                       // 387
        replies.splice(index, 1);                                                                                     // 388
      }                                                                                                               // 389
    });                                                                                                               // 390
                                                                                                                      //
    var findSelector = { _id: documentId };                                                                           // 392
                                                                                                                      //
    CommentsCollection.update(findSelector, { $set: { replies: doc.replies } }, noOptOptions);                        // 394
    triggerEvent('reply', 'remove', Object.assign({}, reply, findSelector, {                                          // 395
      rootUserId: doc.userId                                                                                          // 396
    }));                                                                                                              // 395
  },                                                                                                                  // 398
  'comments/count': function commentsCount(referenceId) {                                                             // 399
    check(referenceId, String);                                                                                       // 400
    return CommentsCollection.find({ referenceId: referenceId }).count();                                             // 401
  }                                                                                                                   // 402
});                                                                                                                   // 88
                                                                                                                      //
CommentsCollection.methods = {                                                                                        // 405
  add: function add(referenceId, content) {                                                                           // 406
    return callWithAnonUserData('comments/add', referenceId, content);                                                // 406
  },                                                                                                                  // 406
  reply: function reply(documentId, docScope, content) {                                                              // 407
    return callWithAnonUserData('comments/reply/add', documentId, docScope, content);                                 // 407
  },                                                                                                                  // 407
  like: function like(documentId) {                                                                                   // 408
    return callWithAnonUserData('comments/like', documentId);                                                         // 408
  },                                                                                                                  // 408
  likeReply: function likeReply(documentId, docScope) {                                                               // 409
    return callWithAnonUserData('comments/reply/like', documentId, docScope);                                         // 409
  },                                                                                                                  // 409
  star: function star(documentId, starsCount) {                                                                       // 410
    return callWithAnonUserData('comments/star', documentId, starsCount);                                             // 410
  },                                                                                                                  // 410
  starReply: function starReply(documentId, docScope, starsCount) {                                                   // 411
    return callWithAnonUserData('comments/reply/star', documentId, docScope, starsCount);                             // 411
  },                                                                                                                  // 411
  edit: function edit(documentId, newContent) {                                                                       // 412
    return callWithAnonUserData('comments/edit', documentId, newContent);                                             // 412
  },                                                                                                                  // 412
  editReply: function editReply(documentId, docScope, content) {                                                      // 413
    return callWithAnonUserData('comments/reply/edit', documentId, docScope, content);                                // 413
  },                                                                                                                  // 413
  remove: function remove(documentId) {                                                                               // 414
    return callWithAnonUserData('comments/remove', documentId);                                                       // 414
  },                                                                                                                  // 414
  removeReply: function removeReply(documentId, docScope) {                                                           // 415
    return callWithAnonUserData('comments/reply/remove', documentId, docScope);                                       // 415
  }                                                                                                                   // 415
};                                                                                                                    // 405
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"services":{"media-analyzers":{"image.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/services/media-analyzers/image.js                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
var imageAnalyzer = {                                                                                                 // 1
  name: 'image',                                                                                                      // 2
  /**                                                                                                                 //
   * @param {String} content                                                                                          //
   *                                                                                                                  //
   * @return {String}                                                                                                 //
   */                                                                                                                 //
  getMediaFromContent: function getMediaFromContent(content) {                                                        // 8
    if (content) {                                                                                                    // 9
      var urls = content.match(/(\S+\.[^/\s]+(\/\S+|\/|))(.jpg|.png|.gif)/g);                                         // 10
                                                                                                                      //
      if (urls && urls[0]) {                                                                                          // 12
        return urls[0];                                                                                               // 13
      }                                                                                                               // 14
    }                                                                                                                 // 15
                                                                                                                      //
    return '';                                                                                                        // 17
  },                                                                                                                  // 18
                                                                                                                      //
  /**                                                                                                                 //
   * @param {String} mediaContent                                                                                     //
   *                                                                                                                  //
   * @return {String}                                                                                                 //
   */                                                                                                                 //
  getMarkup: function getMarkup(mediaContent) {                                                                       // 24
    return '<img src="' + mediaContent + '" />';                                                                      // 24
  }                                                                                                                   // 24
};                                                                                                                    // 1
                                                                                                                      //
exports['default'] = imageAnalyzer;                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"youtube.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/services/media-analyzers/youtube.js                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
var youtubeAnalyzer = {                                                                                               // 1
  name: 'youtube',                                                                                                    // 2
  /**                                                                                                                 //
   * @see http://stackoverflow.com/questions/19377262/regex-for-youtube-url                                           //
   *                                                                                                                  //
   * @param {String} content                                                                                          //
   *                                                                                                                  //
   * @return {String}                                                                                                 //
   */                                                                                                                 //
  getMediaFromContent: function getMediaFromContent(content) {                                                        // 10
    var parts = /(https?\:\/\/)?(www\.youtube\.com|youtu\.?be)\/([\w\=\?]+)/gm.exec(content);                         // 11
    var mediaContent = '';                                                                                            // 12
                                                                                                                      //
    if (parts && parts[3]) {                                                                                          // 14
      var id = parts[3];                                                                                              // 15
                                                                                                                      //
      if (id.indexOf('v=') > -1) {                                                                                    // 17
        var subParts = /v=([\w]+)+/g.exec(id);                                                                        // 18
                                                                                                                      //
        if (subParts && subParts[1]) {                                                                                // 20
          id = subParts[1];                                                                                           // 21
        }                                                                                                             // 22
      }                                                                                                               // 23
                                                                                                                      //
      mediaContent = 'http://www.youtube.com/embed/' + id;                                                            // 25
    }                                                                                                                 // 26
                                                                                                                      //
    return mediaContent;                                                                                              // 28
  },                                                                                                                  // 29
                                                                                                                      //
  /**                                                                                                                 //
   * @param {String} mediaContent                                                                                     //
   *                                                                                                                  //
   * @return {String}                                                                                                 //
   */                                                                                                                 //
  getMarkup: function getMarkup(mediaContent) {                                                                       // 35
    return '<iframe src="' + mediaContent + '" type="text/html" frameborder="0"></iframe>';                           // 35
  }                                                                                                                   // 35
};                                                                                                                    // 1
                                                                                                                      //
exports['default'] = youtubeAnalyzer;                                                                                 //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"user.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/services/user.js                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
var userService = function () {                                                                                       // 1
  if (Meteor.isClient) {                                                                                              // 2
    Meteor.startup(function () {                                                                                      // 3
      userService.setUserData({                                                                                       // 4
        _id: userService.getUserId(),                                                                                 // 5
        salt: localStorage.getItem('commentsui-anonSalt') || ''                                                       // 6
      });                                                                                                             // 4
    });                                                                                                               // 8
  }                                                                                                                   // 9
                                                                                                                      //
  return {                                                                                                            // 11
    /**                                                                                                               //
     * Return the user id with logic for anonymous users.                                                             //
     *                                                                                                                //
     * @returns {String}                                                                                              //
     */                                                                                                               //
                                                                                                                      //
    getUserId: function getUserId() {                                                                                 // 17
      var userId = '';                                                                                                // 18
                                                                                                                      //
      if (userService.isAnonymous()) {                                                                                // 20
        userId = localStorage.getItem('commentsui-anonUserId');                                                       // 21
      }                                                                                                               // 22
                                                                                                                      //
      if (!userId) {                                                                                                  // 24
        userId = Meteor.userId();                                                                                     // 25
      }                                                                                                               // 26
                                                                                                                      //
      return userId;                                                                                                  // 28
    },                                                                                                                // 29
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               //
     * Set reactive user data                                                                                         //
     *                                                                                                                //
     * @param {Object} userData                                                                                       //
     */                                                                                                               //
    setUserData: function setUserData(userData) {                                                                     // 36
      Comments.session.set('commentsui-anonData', userData);                                                          // 37
    },                                                                                                                // 38
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               //
     * Return user id and salt as an object                                                                           //
     *                                                                                                                //
     * @returns {Object}                                                                                              //
     */                                                                                                               //
    getUserData: function getUserData() {                                                                             // 45
      return Comments.session.get('commentsui-anonData');                                                             // 46
    },                                                                                                                // 47
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               //
     * Return anonymous user data                                                                                     //
     *                                                                                                                //
     * @returns {Object}                                                                                              //
     */                                                                                                               //
    getAnonymousUserData: function getAnonymousUserData(_id) {                                                        // 54
      return AnonymousUserCollection.findOne({ _id: _id });                                                           // 54
    },                                                                                                                // 54
                                                                                                                      //
    /**                                                                                                               //
     * Return true if current user has changed it's profile data.                                                     //
     */                                                                                                               //
    userHasChanged: function userHasChanged(data) {                                                                   // 59
      var userData = this.getAnonymousUserData(this.getUserData()._id);                                               // 60
                                                                                                                      //
      return data.username && data.email && userData && (userData.username !== data.username || userData.email !== data.email);
    },                                                                                                                // 67
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               //
     * Update anonymous user based on given data.                                                                     //
     *                                                                                                                //
     * @param {Object} data                                                                                           //
     * @param {Function} callback                                                                                     //
     */                                                                                                               //
    updateAnonymousUser: function updateAnonymousUser(data, callback) {                                               // 75
      var userData = userService.getUserData();                                                                       // 76
                                                                                                                      //
      // check if user still exists                                                                                   //
      if (userData._id && userData.salt && !AnonymousUserCollection.findOne({ _id: userData._id, salt: userData.salt })) {
        userData._id = null;                                                                                          // 80
        userData.salt = null;                                                                                         // 81
      }                                                                                                               // 82
                                                                                                                      //
      if (!userData._id || !userData.salt) {                                                                          // 84
        AnonymousUserCollection.methods.add(data, function (err, data) {                                              // 85
          if (err) throw new Error(err);                                                                              // 86
                                                                                                                      //
          localStorage.setItem('commentsui-anonUserId', data._id);                                                    // 89
          localStorage.setItem('commentsui-anonSalt', data.salt);                                                     // 90
          userService.setUserData(data);                                                                              // 91
          callback(data);                                                                                             // 92
        });                                                                                                           // 93
      } else if (this.userHasChanged(data)) {                                                                         // 94
        AnonymousUserCollection.methods.update(userData._id, userData.salt, data, function () {                       // 95
          return callback(data);                                                                                      // 95
        });                                                                                                           // 95
      } else {                                                                                                        // 96
        callback(data);                                                                                               // 97
      }                                                                                                               // 98
    },                                                                                                                // 99
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               //
     * Return true if anonymous form fields should be displayed                                                       //
     *                                                                                                                //
     * @returns {Boolean}                                                                                             //
     */                                                                                                               //
    isAnonymous: function isAnonymous() {                                                                             // 106
      return Comments.config().anonymous && !Meteor.userId();                                                         // 106
    },                                                                                                                // 106
                                                                                                                      //
    /**                                                                                                               //
     * Return user information of the provided userId                                                                 //
     *                                                                                                                //
     * @returns {Object}                                                                                              //
     */                                                                                                               //
    getUserById: function getUserById(userId) {                                                                       // 113
      var user = Meteor.users.findOne(userId),                                                                        // 114
          anonymousUser = AnonymousUserCollection.findOne({ _id: userId }),                                           // 114
          generateUsername = Comments.config().generateUsername;                                                      // 114
                                                                                                                      //
      if (user) {                                                                                                     // 118
        var displayName = void 0;                                                                                     // 119
                                                                                                                      //
        //oauth facebook users (maybe others)                                                                         //
        if (user.profile) {                                                                                           // 122
          displayName = user.profile.name;                                                                            // 123
        }                                                                                                             // 124
                                                                                                                      //
        if (user.emails && user.emails[0]) {                                                                          // 126
          displayName = user.emails[0].address;                                                                       // 127
        }                                                                                                             // 128
                                                                                                                      //
        if (user.username) {                                                                                          // 130
          displayName = user.username;                                                                                // 131
        }                                                                                                             // 132
                                                                                                                      //
        if (generateUsername) {                                                                                       // 134
          displayName = generateUsername(user);                                                                       // 135
        }                                                                                                             // 136
                                                                                                                      //
        return { displayName: displayName };                                                                          // 138
      } else if (anonymousUser) {                                                                                     // 139
        return { displayName: anonymousUser.username };                                                               // 140
      }                                                                                                               // 141
    },                                                                                                                // 142
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               //
     * Throw an error if provided anon user data is invalid.                                                          //
     *                                                                                                                //
     * @params {Object} anonUserData                                                                                  //
     */                                                                                                               //
    verifyAnonUserData: function verifyAnonUserData(anonUserData) {                                                   // 149
      if (anonUserData._id) {                                                                                         // 150
        check(anonUserData, {                                                                                         // 151
          _id: String,                                                                                                // 152
          salt: String                                                                                                // 153
        });                                                                                                           // 151
                                                                                                                      //
        if (Meteor.isServer && !AnonymousUserCollection.findOne(anonUserData)) {                                      // 156
          throw new Error('Invalid anon user data provided');                                                         // 157
        }                                                                                                             // 158
      } else {                                                                                                        // 159
        check(anonUserData, {});                                                                                      // 160
      }                                                                                                               // 161
    }                                                                                                                 // 162
  };                                                                                                                  // 11
}();                                                                                                                  // 164
                                                                                                                      //
exports['default'] = userService;                                                                                     //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"time-tick.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/services/time-tick.js                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
var timeTickService = function () {                                                                                   // 1
  var timeTick = new Tracker.Dependency();                                                                            // 2
                                                                                                                      //
  // Reactive moment changes                                                                                          //
  Meteor.setInterval(function () {                                                                                    // 5
    return timeTick.changed();                                                                                        // 5
  }, 1000);                                                                                                           // 5
                                                                                                                      //
  moment.locale('en');                                                                                                // 7
                                                                                                                      //
  return {                                                                                                            // 9
    fromNowReactive: function fromNowReactive(mmt) {                                                                  // 10
      timeTick.depend();                                                                                              // 11
      return mmt.fromNow();                                                                                           // 12
    }                                                                                                                 // 13
  };                                                                                                                  // 9
}();                                                                                                                  // 15
                                                                                                                      //
exports['default'] = timeTickService;                                                                                 //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"media.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/services/media.js                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
var mediaService = function () {                                                                                      // 1
  return {                                                                                                            // 2
    getMediaFromContent: function getMediaFromContent(content) {                                                      // 3
      var analyzers = Comments.config().mediaAnalyzers;                                                               // 4
      var media = {};                                                                                                 // 5
                                                                                                                      //
      if (analyzers && _.isArray(analyzers)) {                                                                        // 7
        _.forEach(analyzers, function (analyzer) {                                                                    // 8
          var mediaContent = analyzer.getMediaFromContent(content);                                                   // 9
                                                                                                                      //
          if (mediaContent && !media.content) {                                                                       // 11
            media = {                                                                                                 // 12
              type: analyzer.name,                                                                                    // 13
              content: mediaContent                                                                                   // 14
            };                                                                                                        // 12
          }                                                                                                           // 16
        });                                                                                                           // 17
      }                                                                                                               // 18
                                                                                                                      //
      return media;                                                                                                   // 20
    },                                                                                                                // 21
    getMarkup: function getMarkup(media) {                                                                            // 22
      var analyzers = Comments.config().mediaAnalyzers;                                                               // 23
                                                                                                                      //
      var filteredAnalyzers = _.filter(analyzers, function (filter) {                                                 // 25
        return filter.name === media.type;                                                                            // 26
      });                                                                                                             // 27
                                                                                                                      //
      if (filteredAnalyzers && filteredAnalyzers.length > 0) {                                                        // 29
        return filteredAnalyzers[0].getMarkup(media.content);                                                         // 30
      }                                                                                                               // 31
    }                                                                                                                 // 32
  };                                                                                                                  // 2
}();                                                                                                                  // 34
                                                                                                                      //
exports["default"] = mediaService;                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"hashing.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/services/hashing.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
var hashingService = {                                                                                                // 1
  /**                                                                                                                 //
   * Hash the given data with a random secret.                                                                        //
   *                                                                                                                  //
   * @param {Object} data                                                                                             //
   *                                                                                                                  //
   * @returns {String}                                                                                                //
   */                                                                                                                 //
                                                                                                                      //
  hash: function hash(data) {                                                                                         // 9
    return this.getHashFromData(data) + '+' + Random.secret(50);                                                      // 10
  },                                                                                                                  // 11
                                                                                                                      //
  /**                                                                                                                 //
   * Return a hash from the given data.                                                                               //
   *                                                                                                                  //
   * @param {Object} data                                                                                             //
   *                                                                                                                  //
   * @returns {String}                                                                                                //
   */                                                                                                                 //
  getHashFromData: function getHashFromData(data) {                                                                   // 19
    var hashedSalt = '';                                                                                              // 20
    var anonSalt = Comments.config().anonymousSalt;                                                                   // 21
                                                                                                                      //
    _.times(20, function () {                                                                                         // 23
      hashedSalt += Random.choice(anonSalt) + Random.choice(data.username) + Random.choice(data.email);               // 24
    });                                                                                                               // 25
                                                                                                                      //
    return hashedSalt;                                                                                                // 27
  }                                                                                                                   // 28
};                                                                                                                    // 1
                                                                                                                      //
exports['default'] = hashingService;                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"api.js":["./services/media","./services/media-analyzers/image","./services/media-analyzers/youtube","./services/user",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/api.js                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _media = require('./services/media');                                                                             // 1
                                                                                                                      //
var _media2 = _interopRequireDefault(_media);                                                                         //
                                                                                                                      //
var _image = require('./services/media-analyzers/image');                                                             // 2
                                                                                                                      //
var _image2 = _interopRequireDefault(_image);                                                                         //
                                                                                                                      //
var _youtube = require('./services/media-analyzers/youtube');                                                         // 3
                                                                                                                      //
var _youtube2 = _interopRequireDefault(_youtube);                                                                     //
                                                                                                                      //
var _user = require('./services/user');                                                                               // 4
                                                                                                                      //
var _user2 = _interopRequireDefault(_user);                                                                           //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                     //
                                                                                                                      //
var _CommentsCollection$m = CommentsCollection.methods;                                                               //
var add = _CommentsCollection$m.add;                                                                                  //
var reply = _CommentsCollection$m.reply;                                                                              //
var remove = _CommentsCollection$m.remove;                                                                            //
var removeReply = _CommentsCollection$m.removeReply;                                                                  //
var edit = _CommentsCollection$m.edit;                                                                                //
var editReply = _CommentsCollection$m.editReply;                                                                      //
var like = _CommentsCollection$m.like;                                                                                //
var likeReply = _CommentsCollection$m.likeReply;                                                                      //
var star = _CommentsCollection$m.star;                                                                                //
var starReply = _CommentsCollection$m.starReply;                                                                      //
                                                                                                                      //
                                                                                                                      //
Comments = {                                                                                                          // 19
  config: function () {                                                                                               // 20
    var config = {                                                                                                    // 21
      replies: true,                                                                                                  // 22
      anonymous: false,                                                                                               // 23
      rating: 'likes',                                                                                                // 24
      anonymousSalt: 'changeMe',                                                                                      // 25
      mediaAnalyzers: [_image2['default'], _youtube2['default']],                                                     // 26
      publishUserFields: { profile: 1, emails: 1, username: 1 },                                                      // 27
      onEvent: function onEvent() {},                                                                                 // 28
      sortingOptions: [{ value: 'newest', label: 'Newest', sortSpecifier: { createdAt: -1 } }, { value: 'oldest', label: 'Oldest', sortSpecifier: { createdAt: 1 } }, { value: 'rating', label: 'Best rating', sortSpecifier: { ratingScore: -1 } }]
    };                                                                                                                // 21
                                                                                                                      //
    return function (newConfig) {                                                                                     // 36
      if (!newConfig) {                                                                                               // 37
        return config;                                                                                                // 38
      }                                                                                                               // 39
                                                                                                                      //
      config = _.extend(config, newConfig);                                                                           // 41
    };                                                                                                                // 42
  }(),                                                                                                                // 43
  get: function get(id) {                                                                                             // 44
    var sorting = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];                          // 44
                                                                                                                      //
    if (!sorting) {                                                                                                   // 45
      sorting = { createdAt: -1 };                                                                                    // 46
    }                                                                                                                 // 47
                                                                                                                      //
    return CommentsCollection.find({ referenceId: id }, { sort: sorting });                                           // 49
  },                                                                                                                  // 50
  getOne: function getOne(id) {                                                                                       // 51
    return CommentsCollection.findOne({ _id: id });                                                                   // 51
  },                                                                                                                  // 51
  getAll: function getAll() {                                                                                         // 52
    return CommentsCollection.find({}, { sort: { createdAt: -1 } });                                                  // 52
  },                                                                                                                  // 52
  add: add,                                                                                                           // 53
  reply: reply,                                                                                                       // 54
  remove: remove,                                                                                                     // 55
  removeReply: removeReply,                                                                                           // 56
  edit: edit,                                                                                                         // 57
  editReply: editReply,                                                                                               // 58
  like: like,                                                                                                         // 59
  likeReply: likeReply,                                                                                               // 60
  star: star,                                                                                                         // 61
  starReply: starReply,                                                                                               // 62
  session: new ReactiveDict('commentsUi'),                                                                            // 63
  changeSchema: function changeSchema(cb) {                                                                           // 64
    var currentSchema = CommentsCollection.simpleSchema().schema(),                                                   // 65
        callbackResult = cb(currentSchema),                                                                           // 65
        newSchema;                                                                                                    // 65
                                                                                                                      //
    newSchema = callbackResult ? callbackResult : currentSchema;                                                      // 69
    !!newSchema && CommentsCollection.attachSchema(newSchema, { replace: true });                                     // 70
  },                                                                                                                  // 71
  getCount: function getCount(id, cb) {                                                                               // 72
    return Meteor.call('comments/count', id, cb);                                                                     // 72
  },                                                                                                                  // 72
  analyzers: {                                                                                                        // 73
    image: _image2['default'],                                                                                        // 74
    youtube: _youtube2['default']                                                                                     // 75
  },                                                                                                                  // 73
  getCollection: function getCollection() {                                                                           // 77
    return CommentsCollection;                                                                                        // 77
  },                                                                                                                  // 77
  getSortOption: function getSortOption(sorting) {                                                                    // 78
    var options = _.filter(Comments.config().sortingOptions, function (option) {                                      // 79
      return option.value === sorting;                                                                                // 79
    });                                                                                                               // 79
                                                                                                                      //
    if (0 === options.length) {                                                                                       // 81
      throw new Meteor.Error('Invalid sorting specified');                                                            // 82
    }                                                                                                                 // 83
                                                                                                                      //
    return options[0].sortSpecifier;                                                                                  // 85
  },                                                                                                                  // 86
  _collection: CommentsCollection,                                                                                    // 87
  _anonymousCollection: AnonymousUserCollection,                                                                      // 88
  _mediaService: _media2['default']                                                                                   // 89
};                                                                                                                    // 19
                                                                                                                      //
var setDefaultAvatar = function setDefaultAvatar(defaultImageUrl) {                                                   // 92
  Avatar.setOptions({ defaultImageUrl: defaultImageUrl });                                                            // 93
};                                                                                                                    // 94
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 96
  Comments.ui = function () {                                                                                         // 97
    var _config = {                                                                                                   // 98
      limit: 5,                                                                                                       // 99
      loadMoreCount: 10,                                                                                              // 100
      template: 'semantic-ui',                                                                                        // 101
      defaultAvatar: 'http://s3.amazonaws.com/37assets/svn/765-default-avatar.png',                                   // 102
      markdown: false                                                                                                 // 103
    };                                                                                                                // 98
                                                                                                                      //
    setDefaultAvatar(_config.defaultAvatar);                                                                          // 106
                                                                                                                      //
    return {                                                                                                          // 108
      config: function config(newConfig) {                                                                            // 109
        if (!newConfig) {                                                                                             // 110
          return _config;                                                                                             // 111
        }                                                                                                             // 112
                                                                                                                      //
        _config = _.extend(_config, newConfig);                                                                       // 114
        setDefaultAvatar(_config.defaultAvatar);                                                                      // 115
      },                                                                                                              // 116
      setContent: function setContent(content) {                                                                      // 117
        return Comments.session.set('content', content);                                                              // 117
      },                                                                                                              // 117
      callIfLoggedIn: function callIfLoggedIn(action, cb) {                                                           // 118
        if (!_user2['default'].getUserId()) {                                                                         // 119
          Comments.session.set('loginAction', action);                                                                // 120
        } else {                                                                                                      // 121
          return cb();                                                                                                // 122
        }                                                                                                             // 123
      },                                                                                                              // 124
      getSorting: function getSorting(id) {                                                                           // 125
        return Comments.session.get(id + '_sorting');                                                                 // 126
      }                                                                                                               // 127
    };                                                                                                                // 108
  }();                                                                                                                // 129
}                                                                                                                     // 130
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"server":{"publish.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/server/publish.js                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   //
 * Return user ids by the given comment.                                                                              //
 *                                                                                                                    //
 * @param {Object} comment                                                                                            //
 *                                                                                                                    //
 * @returns {Array}                                                                                                   //
 */                                                                                                                   //
function getUserIdsByComment(comment) {                                                                               // 8
  var ids = [];                                                                                                       // 9
                                                                                                                      //
  ids.push(comment.userId);                                                                                           // 11
                                                                                                                      //
  if (comment.replies) {                                                                                              // 13
    _.each(comment.replies, function (reply) {                                                                        // 14
      ids = _.union(ids, getUserIdsByComment(reply));                                                                 // 15
    });                                                                                                               // 16
  }                                                                                                                   // 17
                                                                                                                      //
  return ids;                                                                                                         // 19
}                                                                                                                     // 20
                                                                                                                      //
Meteor.publish('comments/anonymous', function (data) {                                                                // 22
  check(data, {                                                                                                       // 23
    _id: String,                                                                                                      // 24
    salt: String                                                                                                      // 25
  });                                                                                                                 // 23
                                                                                                                      //
  return AnonymousUserCollection.find(data);                                                                          // 28
});                                                                                                                   // 29
                                                                                                                      //
Meteor.publishComposite('comments/reference', function (id, sorting, limit) {                                         // 31
  var skip = arguments.length <= 3 || arguments[3] === undefined ? 0 : arguments[3];                                  // 31
                                                                                                                      //
  check(id, String);                                                                                                  // 32
  check(sorting, String);                                                                                             // 33
  check(limit, Number);                                                                                               // 34
  check(skip, Number);                                                                                                // 35
                                                                                                                      //
  return {                                                                                                            // 37
    find: function find() {                                                                                           // 38
      return Comments._collection.find({ referenceId: id }, { limit: limit, skip: skip, sort: Comments.getSortOption(sorting) });
    },                                                                                                                // 38
    children: [{                                                                                                      // 42
      find: function find(comment) {                                                                                  // 43
        var userIds = getUserIdsByComment(comment);                                                                   // 44
                                                                                                                      //
        return Meteor.users.find({ _id: { $in: userIds } }, { fields: Comments.config().publishUserFields });         // 46
      }                                                                                                               // 50
    }, {                                                                                                              // 42
      find: function find(comment) {                                                                                  // 52
        var userIds = getUserIdsByComment(comment);                                                                   // 53
                                                                                                                      //
        return AnonymousUserCollection.find({ _id: { $in: userIds } }, {                                              // 55
          fields: { salt: 0, email: 0 }                                                                               // 58
        });                                                                                                           // 57
      }                                                                                                               // 61
    }]                                                                                                                // 51
  };                                                                                                                  // 37
});                                                                                                                   // 64
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"node_modules":{"linkifyjs":{"string.js":["./lib/linkify-string",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/string.js                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.exports = require('./lib/linkify-string').default;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"lib":{"linkify-string.js":["./linkify",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/lib/linkify-string.js                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';

exports.__esModule = true;

var _linkify = require('./linkify');

var linkify = _interopRequireWildcard(_linkify);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var tokenize = linkify.tokenize; /**
                                 	Convert strings of text into linkable HTML text
                                 */

var options = linkify.options;

function escapeText(text) {
	return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function escapeAttr(href) {
	return href.replace(/"/g, '&quot;');
}

function attributesToString(attributes) {

	if (!attributes) return '';
	var result = [];

	for (var attr in attributes) {
		var val = (attributes[attr] + '').replace(/"/g, '&quot;');
		result.push(attr + '="' + escapeAttr(val) + '"');
	}
	return result.join(' ');
}

function linkifyStr(str) {
	var opts = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];


	opts = options.normalize(opts);

	var tokens = tokenize(str),
	    result = [];

	for (var i = 0; i < tokens.length; i++) {
		var token = tokens[i];
		var validated = token.isLink && options.resolve(opts.validate, token.toString(), token.type);

		if (token.isLink && validated) {

			var href = token.toHref(opts.defaultProtocol),
			    formatted = options.resolve(opts.format, token.toString(), token.type),
			    formattedHref = options.resolve(opts.formatHref, href, token.type),
			    attributesHash = options.resolve(opts.attributes, href, token.type),
			    tagName = options.resolve(opts.tagName, href, token.type),
			    linkClass = options.resolve(opts.linkClass, href, token.type),
			    target = options.resolve(opts.target, href, token.type);

			var link = '<' + tagName + ' href="' + escapeAttr(formattedHref) + '" class="' + escapeAttr(linkClass) + '"';
			if (target) {
				link += ' target="' + escapeAttr(target) + '"';
			}

			if (attributesHash) {
				link += ' ' + attributesToString(attributesHash);
			}

			link += '>' + escapeText(formatted) + '</' + tagName + '>';
			result.push(link);
		} else if (token.type === 'nl' && opts.nl2br) {
			if (opts.newLine) {
				result.push(opts.newLine);
			} else {
				result.push('<br>\n');
			}
		} else {
			result.push(escapeText(token.toString()));
		}
	}

	return result.join('');
}

if (!String.prototype.linkify) {
	String.prototype.linkify = function (options) {
		return linkifyStr(this, options);
	};
}

exports.default = linkifyStr;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"linkify.js":["./linkify/utils/options","./linkify/core/scanner","./linkify/core/parser",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/lib/linkify.js                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';

exports.__esModule = true;
exports.tokenize = exports.test = exports.scanner = exports.parser = exports.options = exports.find = undefined;

var _options = require('./linkify/utils/options');

var options = _interopRequireWildcard(_options);

var _scanner = require('./linkify/core/scanner');

var scanner = _interopRequireWildcard(_scanner);

var _parser = require('./linkify/core/parser');

var parser = _interopRequireWildcard(_parser);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

if (!Array.isArray) {
	Array.isArray = function (arg) {
		return Object.prototype.toString.call(arg) === '[object Array]';
	};
}

/**
	Converts a string into tokens that represent linkable and non-linkable bits
	@method tokenize
	@param {String} str
	@return {Array} tokens
*/
var tokenize = function tokenize(str) {
	return parser.run(scanner.run(str));
};

/**
	Returns a list of linkable items in the given string.
*/
var find = function find(str) {
	var type = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];


	var tokens = tokenize(str),
	    filtered = [];

	for (var i = 0; i < tokens.length; i++) {
		if (tokens[i].isLink && (!type || tokens[i].type === type)) {
			filtered.push(tokens[i].toObject());
		}
	}

	return filtered;
};

/**
	Is the given string valid linkable text of some sort
	Note that this does not trim the text for you.

	Optionally pass in a second `type` param, which is the type of link to test
	for.

	For example,

		test(str, 'email');

	Will return `true` if str is a valid email.
*/
var test = function test(str) {
	var type = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];

	var tokens = tokenize(str);
	return tokens.length === 1 && tokens[0].isLink && (!type || tokens[0].type === type);
};

// Scanner and parser provide states and tokens for the lexicographic stage
// (will be used to add additional link types)
exports.find = find;
exports.options = options;
exports.parser = parser;
exports.scanner = scanner;
exports.test = test;
exports.tokenize = tokenize;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"linkify":{"utils":{"options.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/lib/linkify/utils/options.js                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';

exports.__esModule = true;
exports.normalize = normalize;
exports.resolve = resolve;
exports.contains = contains;
/**
 * Convert set of options into objects including all the defaults
 */
function normalize(opts) {
	opts = opts || {};
	var newLine = opts.newLine || false; // deprecated
	var ignoreTags = opts.ignoreTags || [];

	// Make all tags names upper case
	for (var i = 0; i < ignoreTags.length; i++) {
		ignoreTags[i] = ignoreTags[i].toUpperCase();
	}

	return {
		attributes: opts.linkAttributes || null,
		defaultProtocol: opts.defaultProtocol || 'http',
		events: opts.events || null,
		format: opts.format || noop,
		validate: opts.validate || yes,
		formatHref: opts.formatHref || noop,
		newLine: opts.newLine || false, // deprecated
		nl2br: !!newLine || opts.nl2br || false,
		tagName: opts.tagName || 'a',
		target: opts.target || typeToTarget,
		linkClass: opts.linkClass || 'linkified',
		ignoreTags: ignoreTags
	};
}

/**
 * Resolve an option's value based on the value of the option and the given
 * params
 */
function resolve(value) {
	for (var _len = arguments.length, params = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
		params[_key - 1] = arguments[_key];
	}

	return typeof value === 'function' ? value.apply(undefined, params) : value;
}

/**
 * Quick indexOf replacement for checking the ignoreTags option
 */
function contains(arr, value) {
	for (var i = 0; i < arr.length; i++) {
		if (arr[i] == value) {
			return true;
		}
	}
	return false;
}

function noop(val) {
	return val;
}

function yes(val) {
	return true;
}

function typeToTarget(href, type) {
	return type === 'url' ? '_blank' : null;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"core":{"scanner.js":["./tokens","./state",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/lib/linkify/core/scanner.js                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';

exports.__esModule = true;
exports.start = exports.run = exports.TOKENS = exports.State = undefined;

var _tokens = require('./tokens');

var _state = require('./state');

/**
	The scanner provides an interface that takes a string of text as input, and
	outputs an array of tokens instances that can be used for easy URL parsing.

	@module linkify
	@submodule scanner
	@main scanner
*/

var tlds = 'abogado|ac|academy|accountants|active|actor|ad|adult|ae|aero|af|ag|agency|ai|airforce|al|allfinanz|alsace|am|an|android|ao|aq|aquarelle|ar|archi|army|arpa|as|asia|associates|at|attorney|au|auction|audio|autos|aw|ax|axa|az|ba|band|bar|bargains|bayern|bb|bd|be|beer|berlin|best|bf|bg|bh|bi|bid|bike|bio|biz|bj|black|blackfriday|bloomberg|blue|bm|bmw|bn|bnpparibas|bo|boo|boutique|br|brussels|bs|bt|budapest|build|builders|business|buzz|bv|bw|by|bz|bzh|ca|cab|cal|camera|camp|cancerresearch|capetown|capital|caravan|cards|care|career|careers|casa|cash|cat|catering|cc|cd|center|ceo|cern|cf|cg|ch|channel|cheap|christmas|chrome|church|ci|citic|city|ck|cl|claims|cleaning|click|clinic|clothing|club|cm|cn|co|coach|codes|coffee|college|cologne|com|community|company|computer|condos|construction|consulting|contractors|cooking|cool|coop|country|cr|credit|creditcard|cricket|crs|cruises|cu|cuisinella|cv|cw|cx|cy|cymru|cz|dad|dance|dating|day|de|deals|degree|delivery|democrat|dental|dentist|desi|diamonds|diet|digital|direct|directory|discount|dj|dk|dm|dnp|do|domains|durban|dvag|dz|eat|ec|edu|education|ee|eg|email|emerck|energy|engineer|engineering|enterprises|equipment|er|es|esq|estate|et|eu|eurovision|eus|events|everbank|exchange|expert|exposed|fail|farm|fashion|feedback|fi|finance|financial|firmdale|fish|fishing|fitness|fj|fk|flights|florist|flsmidth|fly|fm|fo|foo|forsale|foundation|fr|frl|frogans|fund|furniture|futbol|ga|gal|gallery|gb|gbiz|gd|ge|gent|gf|gg|gh|gi|gift|gifts|gives|gl|glass|gle|global|globo|gm|gmail|gmo|gmx|gn|google|gop|gov|gp|gq|gr|graphics|gratis|green|gripe|gs|gt|gu|guide|guitars|guru|gw|gy|hamburg|haus|healthcare|help|here|hiphop|hiv|hk|hm|hn|holdings|holiday|homes|horse|host|hosting|house|how|hr|ht|hu|ibm|id|ie|il|im|immo|immobilien|in|industries|info|ing|ink|institute|insure|int|international|investments|io|iq|ir|irish|is|it|je|jetzt|jm|jo|jobs|joburg|jp|juegos|kaufen|ke|kg|kh|ki|kim|kitchen|kiwi|km|kn|koeln|kp|kr|krd|kred|kw|ky|kz|la|lacaixa|land|latrobe|lawyer|lb|lc|lds|lease|legal|lgbt|li|life|lighting|limited|limo|link|lk|loans|local|london|lotto|lr|ls|lt|ltda|lu|luxe|luxury|lv|ly|ma|madrid|maison|management|mango|market|marketing|mc|md|me|media|meet|melbourne|meme|memorial|menu|mg|mh|miami|mil|mini|mk|ml|mm|mn|mo|mobi|moda|moe|monash|money|mormon|mortgage|moscow|motorcycles|mov|mp|mq|mr|ms|mt|mu|museum|mv|mw|mx|my|mz|na|nagoya|name|navy|nc|ne|net|network|neustar|new|nexus|nf|ng|ngo|nhk|ni|ninja|nl|no|np|nr|nra|nrw|nu|nyc|nz|okinawa|om|ong|onl|ooo|org|organic|otsuka|ovh|pa|paris|partners|parts|party|pe|pf|pg|ph|pharmacy|photo|photography|photos|physio|pics|pictures|pink|pizza|pk|pl|place|plumbing|pm|pn|pohl|poker|porn|post|pr|praxi|press|pro|prod|productions|prof|properties|property|ps|pt|pub|pw|py|qa|qpon|quebec|re|realtor|recipes|red|rehab|reise|reisen|reit|ren|rentals|repair|report|republican|rest|restaurant|reviews|rich|rio|rip|ro|rocks|rodeo|rs|rsvp|ru|ruhr|rw|ryukyu|sa|saarland|sarl|sb|sc|sca|scb|schmidt|schule|science|scot|sd|se|services|sexy|sg|sh|shiksha|shoes|si|singles|sj|sk|sl|sm|sn|so|social|software|sohu|solar|solutions|soy|space|spiegel|sr|st|su|supplies|supply|support|surf|surgery|suzuki|sv|sx|sy|sydney|systems|sz|taipei|tatar|tattoo|tax|tc|td|technology|tel|tf|tg|th|tienda|tips|tirol|tj|tk|tl|tm|tn|to|today|tokyo|tools|top|town|toys|tp|tr|trade|training|travel|trust|tt|tui|tv|tw|tz|ua|ug|uk|university|uno|uol|us|uy|uz|va|vacations|vc|ve|vegas|ventures|versicherung|vet|vg|vi|viajes|villas|vision|vlaanderen|vn|vodka|vote|voting|voto|voyage|vu|wales|wang|watch|webcam|website|wed|wedding|wf|whoswho|wien|wiki|williamhill|wme|work|works|world|ws|wtc|wtf|xxx|xyz|yachts|yandex|ye|yoga|yokohama|youtube|yt|za|zip|zm|zone|zw'.split('|'); // macro, see gulpfile.js

var REGEXP_NUM = /[0-9]/,
    REGEXP_ALPHANUM = /[a-z0-9]/,
    COLON = ':';

var domainStates = [],
    // states that jump to DOMAIN on /[a-z0-9]/
makeState = function makeState(tokenClass) {
	return new _state.CharacterState(tokenClass);
};

var // Frequently used tokens
T_DOMAIN = _tokens.text.DOMAIN,
    T_LOCALHOST = _tokens.text.LOCALHOST,
    T_NUM = _tokens.text.NUM,
    T_PROTOCOL = _tokens.text.PROTOCOL,
    T_TLD = _tokens.text.TLD,
    T_WS = _tokens.text.WS;

var // Frequently used states
S_START = makeState(),
    // start state
S_NUM = makeState(T_NUM),
    S_DOMAIN = makeState(T_DOMAIN),
    S_DOMAIN_HYPHEN = makeState(),
    // domain followed by 1 or more hyphen characters
S_WS = makeState(T_WS);

// States for special URL symbols
S_START.on('@', makeState(_tokens.text.AT)).on('.', makeState(_tokens.text.DOT)).on('+', makeState(_tokens.text.PLUS)).on('#', makeState(_tokens.text.POUND)).on('?', makeState(_tokens.text.QUERY)).on('/', makeState(_tokens.text.SLASH)).on(COLON, makeState(_tokens.text.COLON)).on('{', makeState(_tokens.text.OPENBRACE)).on('[', makeState(_tokens.text.OPENBRACKET)).on('(', makeState(_tokens.text.OPENPAREN)).on('}', makeState(_tokens.text.CLOSEBRACE)).on(']', makeState(_tokens.text.CLOSEBRACKET)).on(')', makeState(_tokens.text.CLOSEPAREN)).on(/[,;!]/, makeState(_tokens.text.PUNCTUATION));

// Whitespace jumps
// Tokens of only non-newline whitespace are arbitrarily long
S_START.on(/\n/, makeState(_tokens.text.NL)).on(/\s/, S_WS);

// If any whitespace except newline, more whitespace!
S_WS.on(/[^\S\n]/, S_WS);

// Generates states for top-level domains
// Note that this is most accurate when tlds are in alphabetical order
for (var i = 0; i < tlds.length; i++) {
	var newStates = (0, _state.stateify)(tlds[i], S_START, T_TLD, T_DOMAIN);
	domainStates.push.apply(domainStates, newStates);
}

// Collect the states generated by different protocls
var partialProtocolFileStates = (0, _state.stateify)('file', S_START, T_DOMAIN, T_DOMAIN),
    partialProtocolFtpStates = (0, _state.stateify)('ftp', S_START, T_DOMAIN, T_DOMAIN),
    partialProtocolHttpStates = (0, _state.stateify)('http', S_START, T_DOMAIN, T_DOMAIN);

// Add the states to the array of DOMAINeric states
domainStates.push.apply(domainStates, partialProtocolFileStates);
domainStates.push.apply(domainStates, partialProtocolFtpStates);
domainStates.push.apply(domainStates, partialProtocolHttpStates);

var // Protocol states
S_PROTOCOL_FILE = partialProtocolFileStates.pop(),
    S_PROTOCOL_FTP = partialProtocolFtpStates.pop(),
    S_PROTOCOL_HTTP = partialProtocolHttpStates.pop(),
    S_PROTOCOL_SECURE = makeState(T_DOMAIN),
    S_FULL_PROTOCOL = makeState(T_PROTOCOL); // Full protocol ends with COLON

// Secure protocols (end with 's')
S_PROTOCOL_FTP.on('s', S_PROTOCOL_SECURE).on(COLON, S_FULL_PROTOCOL);

S_PROTOCOL_HTTP.on('s', S_PROTOCOL_SECURE).on(COLON, S_FULL_PROTOCOL);

domainStates.push(S_PROTOCOL_SECURE);

// Become protocol tokens after a COLON
S_PROTOCOL_FILE.on(COLON, S_FULL_PROTOCOL);
S_PROTOCOL_SECURE.on(COLON, S_FULL_PROTOCOL);

// Localhost
var partialLocalhostStates = (0, _state.stateify)('localhost', S_START, T_LOCALHOST, T_DOMAIN);
domainStates.push.apply(domainStates, partialLocalhostStates);

// Everything else
// DOMAINs make more DOMAINs
// Number and character transitions
S_START.on(REGEXP_NUM, S_NUM);
S_NUM.on('-', S_DOMAIN_HYPHEN).on(REGEXP_NUM, S_NUM).on(REGEXP_ALPHANUM, S_DOMAIN); // number becomes DOMAIN

S_DOMAIN.on('-', S_DOMAIN_HYPHEN).on(REGEXP_ALPHANUM, S_DOMAIN);

// All the generated states should have a jump to DOMAIN
for (var _i = 0; _i < domainStates.length; _i++) {
	domainStates[_i].on('-', S_DOMAIN_HYPHEN).on(REGEXP_ALPHANUM, S_DOMAIN);
}

S_DOMAIN_HYPHEN.on('-', S_DOMAIN_HYPHEN).on(REGEXP_NUM, S_DOMAIN).on(REGEXP_ALPHANUM, S_DOMAIN);

// Any other character is considered a single symbol token
S_START.on(/./, makeState(_tokens.text.SYM));

/**
	Given a string, returns an array of TOKEN instances representing the
	composition of that string.

	@method run
	@param {String} str Input string to scan
	@return {Array} Array of TOKEN instances
*/
var run = function run(str) {

	// The state machine only looks at lowercase strings.
	// This selective `toLowerCase` is used because lowercasing the entire
	// string causes the length and character position to vary in some in some
	// non-English strings. This happens only on V8-based runtimes.
	var lowerStr = str.replace(/[A-Z]/g, function (c) {
		return c.toLowerCase();
	});
	var len = str.length;
	var tokens = []; // return value

	var cursor = 0;

	// Tokenize the string
	while (cursor < len) {

		var state = S_START,
		    secondState = null,
		    nextState = null,
		    tokenLength = 0,
		    latestAccepting = null,
		    sinceAccepts = -1;

		while (cursor < len && (nextState = state.next(lowerStr[cursor]))) {
			secondState = null;
			state = nextState;

			// Keep track of the latest accepting state
			if (state.accepts()) {
				sinceAccepts = 0;
				latestAccepting = state;
			} else if (sinceAccepts >= 0) {
				sinceAccepts++;
			}

			tokenLength++;
			cursor++;
		}

		if (sinceAccepts < 0) continue; // Should never happen

		// Roll back to the latest accepting state
		cursor -= sinceAccepts;
		tokenLength -= sinceAccepts;

		// Get the class for the new token
		var TOKEN = latestAccepting.emit(); // Current token class

		// No more jumps, just make a new token
		tokens.push(new TOKEN(str.substr(cursor - tokenLength, tokenLength)));
	}

	return tokens;
};

var start = S_START;
exports.State = _state.CharacterState;
exports.TOKENS = _tokens.text;
exports.run = run;
exports.start = start;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"tokens.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/lib/linkify/core/tokens.js                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';

exports.__esModule = true;

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/******************************************************************************
	Text Tokens
	Tokens composed of strings
******************************************************************************/

/**
	Abstract class used for manufacturing text tokens.
	Pass in the value this token represents

	@class TextToken
	@abstract
*/

var TextToken = function () {
	/**
 	@method constructor
 	@param {String} value The string of characters representing this particular Token
 */

	function TextToken(value) {
		_classCallCheck(this, TextToken);

		this.v = value;
	}

	/**
 	String representing the type for this token
 	@property type
 	@default 'TOKEN'
 */

	TextToken.prototype.toString = function toString() {
		return this.v + '';
	};

	return TextToken;
}();

/**
	A valid domain token
	@class DOMAIN
	@extends TextToken
*/


var DOMAIN = function (_TextToken) {
	_inherits(DOMAIN, _TextToken);

	function DOMAIN() {
		_classCallCheck(this, DOMAIN);

		return _possibleConstructorReturn(this, _TextToken.apply(this, arguments));
	}

	return DOMAIN;
}(TextToken);

/**
	@class AT
	@extends TextToken
*/


var AT = function (_TextToken2) {
	_inherits(AT, _TextToken2);

	function AT() {
		_classCallCheck(this, AT);

		return _possibleConstructorReturn(this, _TextToken2.call(this, '@'));
	}

	return AT;
}(TextToken);

/**
	Represents a single colon `:` character

	@class COLON
	@extends TextToken
*/


var COLON = function (_TextToken3) {
	_inherits(COLON, _TextToken3);

	function COLON() {
		_classCallCheck(this, COLON);

		return _possibleConstructorReturn(this, _TextToken3.call(this, ':'));
	}

	return COLON;
}(TextToken);

/**
	@class DOT
	@extends TextToken
*/


var DOT = function (_TextToken4) {
	_inherits(DOT, _TextToken4);

	function DOT() {
		_classCallCheck(this, DOT);

		return _possibleConstructorReturn(this, _TextToken4.call(this, '.'));
	}

	return DOT;
}(TextToken);

/**
	A character class that can surround the URL, but which the URL cannot begin
	or end with. Does not include certain English punctuation like parentheses.

	@class PUNCTUATION
	@extends TextToken
*/


var PUNCTUATION = function (_TextToken5) {
	_inherits(PUNCTUATION, _TextToken5);

	function PUNCTUATION() {
		_classCallCheck(this, PUNCTUATION);

		return _possibleConstructorReturn(this, _TextToken5.apply(this, arguments));
	}

	return PUNCTUATION;
}(TextToken);

/**
	The word localhost (by itself)
	@class LOCALHOST
	@extends TextToken
*/


var LOCALHOST = function (_TextToken6) {
	_inherits(LOCALHOST, _TextToken6);

	function LOCALHOST() {
		_classCallCheck(this, LOCALHOST);

		return _possibleConstructorReturn(this, _TextToken6.apply(this, arguments));
	}

	return LOCALHOST;
}(TextToken);

/**
	Newline token
	@class TNL
	@extends TextToken
*/


var TNL = function (_TextToken7) {
	_inherits(TNL, _TextToken7);

	function TNL() {
		_classCallCheck(this, TNL);

		return _possibleConstructorReturn(this, _TextToken7.call(this, '\n'));
	}

	return TNL;
}(TextToken);

/**
	@class NUM
	@extends TextToken
*/


var NUM = function (_TextToken8) {
	_inherits(NUM, _TextToken8);

	function NUM() {
		_classCallCheck(this, NUM);

		return _possibleConstructorReturn(this, _TextToken8.apply(this, arguments));
	}

	return NUM;
}(TextToken);

/**
	@class PLUS
	@extends TextToken
*/


var PLUS = function (_TextToken9) {
	_inherits(PLUS, _TextToken9);

	function PLUS() {
		_classCallCheck(this, PLUS);

		return _possibleConstructorReturn(this, _TextToken9.call(this, '+'));
	}

	return PLUS;
}(TextToken);

/**
	@class POUND
	@extends TextToken
*/


var POUND = function (_TextToken10) {
	_inherits(POUND, _TextToken10);

	function POUND() {
		_classCallCheck(this, POUND);

		return _possibleConstructorReturn(this, _TextToken10.call(this, '#'));
	}

	return POUND;
}(TextToken);

/**
	Represents a web URL protocol. Supported types include

	* `http:`
	* `https:`
	* `ftp:`
	* `ftps:`
	* There's Another super weird one

	@class PROTOCOL
	@extends TextToken
*/


var PROTOCOL = function (_TextToken11) {
	_inherits(PROTOCOL, _TextToken11);

	function PROTOCOL() {
		_classCallCheck(this, PROTOCOL);

		return _possibleConstructorReturn(this, _TextToken11.apply(this, arguments));
	}

	return PROTOCOL;
}(TextToken);

/**
	@class QUERY
	@extends TextToken
*/


var QUERY = function (_TextToken12) {
	_inherits(QUERY, _TextToken12);

	function QUERY() {
		_classCallCheck(this, QUERY);

		return _possibleConstructorReturn(this, _TextToken12.call(this, '?'));
	}

	return QUERY;
}(TextToken);

/**
	@class SLASH
	@extends TextToken
*/


var SLASH = function (_TextToken13) {
	_inherits(SLASH, _TextToken13);

	function SLASH() {
		_classCallCheck(this, SLASH);

		return _possibleConstructorReturn(this, _TextToken13.call(this, '/'));
	}

	return SLASH;
}(TextToken);

/**
	One ore more non-whitespace symbol.
	@class SYM
	@extends TextToken
*/


var SYM = function (_TextToken14) {
	_inherits(SYM, _TextToken14);

	function SYM() {
		_classCallCheck(this, SYM);

		return _possibleConstructorReturn(this, _TextToken14.apply(this, arguments));
	}

	return SYM;
}(TextToken);

/**
	@class TLD
	@extends TextToken
*/


var TLD = function (_TextToken15) {
	_inherits(TLD, _TextToken15);

	function TLD() {
		_classCallCheck(this, TLD);

		return _possibleConstructorReturn(this, _TextToken15.apply(this, arguments));
	}

	return TLD;
}(TextToken);

/**
	Represents a string of consecutive whitespace characters

	@class WS
	@extends TextToken
*/


var WS = function (_TextToken16) {
	_inherits(WS, _TextToken16);

	function WS() {
		_classCallCheck(this, WS);

		return _possibleConstructorReturn(this, _TextToken16.apply(this, arguments));
	}

	return WS;
}(TextToken);

/**
	Opening/closing bracket classes
*/

var OPENBRACE = function (_TextToken17) {
	_inherits(OPENBRACE, _TextToken17);

	function OPENBRACE() {
		_classCallCheck(this, OPENBRACE);

		return _possibleConstructorReturn(this, _TextToken17.call(this, '{'));
	}

	return OPENBRACE;
}(TextToken);

var OPENBRACKET = function (_TextToken18) {
	_inherits(OPENBRACKET, _TextToken18);

	function OPENBRACKET() {
		_classCallCheck(this, OPENBRACKET);

		return _possibleConstructorReturn(this, _TextToken18.call(this, '['));
	}

	return OPENBRACKET;
}(TextToken);

var OPENPAREN = function (_TextToken19) {
	_inherits(OPENPAREN, _TextToken19);

	function OPENPAREN() {
		_classCallCheck(this, OPENPAREN);

		return _possibleConstructorReturn(this, _TextToken19.call(this, '('));
	}

	return OPENPAREN;
}(TextToken);

var CLOSEBRACE = function (_TextToken20) {
	_inherits(CLOSEBRACE, _TextToken20);

	function CLOSEBRACE() {
		_classCallCheck(this, CLOSEBRACE);

		return _possibleConstructorReturn(this, _TextToken20.call(this, '}'));
	}

	return CLOSEBRACE;
}(TextToken);

var CLOSEBRACKET = function (_TextToken21) {
	_inherits(CLOSEBRACKET, _TextToken21);

	function CLOSEBRACKET() {
		_classCallCheck(this, CLOSEBRACKET);

		return _possibleConstructorReturn(this, _TextToken21.call(this, ']'));
	}

	return CLOSEBRACKET;
}(TextToken);

var CLOSEPAREN = function (_TextToken22) {
	_inherits(CLOSEPAREN, _TextToken22);

	function CLOSEPAREN() {
		_classCallCheck(this, CLOSEPAREN);

		return _possibleConstructorReturn(this, _TextToken22.call(this, ')'));
	}

	return CLOSEPAREN;
}(TextToken);

var text = {
	Base: TextToken,
	DOMAIN: DOMAIN,
	AT: AT,
	COLON: COLON,
	DOT: DOT,
	PUNCTUATION: PUNCTUATION,
	LOCALHOST: LOCALHOST,
	NL: TNL,
	NUM: NUM,
	PLUS: PLUS,
	POUND: POUND,
	QUERY: QUERY,
	PROTOCOL: PROTOCOL,
	SLASH: SLASH,
	SYM: SYM,
	TLD: TLD,
	WS: WS,
	OPENBRACE: OPENBRACE,
	OPENBRACKET: OPENBRACKET,
	OPENPAREN: OPENPAREN,
	CLOSEBRACE: CLOSEBRACE,
	CLOSEBRACKET: CLOSEBRACKET,
	CLOSEPAREN: CLOSEPAREN
};

/******************************************************************************
	Multi-Tokens
	Tokens composed of arrays of TextTokens
******************************************************************************/

// Is the given token a valid domain token?
// Should nums be included here?
function isDomainToken(token) {
	return token instanceof DOMAIN || token instanceof TLD;
}

/**
	Abstract class used for manufacturing tokens of text tokens. That is rather
	than the value for a token being a small string of text, it's value an array
	of text tokens.

	Used for grouping together URLs, emails, hashtags, and other potential
	creations.

	@class MultiToken
	@abstract
*/

var MultiToken = function () {
	/**
 	@method constructor
 	@param {Array} value The array of `TextToken`s representing this
 	particular MultiToken
 */

	function MultiToken(value) {
		_classCallCheck(this, MultiToken);

		this.v = value;

		/**
  	String representing the type for this token
  	@property type
  	@default 'TOKEN'
  */
		this.type = 'token';

		/**
  	Is this multitoken a link?
  	@property isLink
  	@default false
  */
		this.isLink = false;
	}

	/**
 	Return the string this token represents.
 	@method toString
 	@return {String}
 */


	MultiToken.prototype.toString = function toString() {
		var result = [];
		for (var i = 0; i < this.v.length; i++) {
			result.push(this.v[i].toString());
		}
		return result.join('');
	};

	/**
 	What should the value for this token be in the `href` HTML attribute?
 	Returns the `.toString` value by default.
 		@method toHref
 	@return {String}
 */


	MultiToken.prototype.toHref = function toHref() {
		return this.toString();
	};

	/**
 	Returns a hash of relevant values for this token, which includes keys
 	* type - Kind of token ('url', 'email', etc.)
 	* value - Original text
 	* href - The value that should be added to the anchor tag's href
 		attribute
 		@method toObject
 	@param {String} [protocol] `'http'` by default
 	@return {Object}
 */


	MultiToken.prototype.toObject = function toObject() {
		var protocol = arguments.length <= 0 || arguments[0] === undefined ? 'http' : arguments[0];

		return {
			type: this.type,
			value: this.toString(),
			href: this.toHref(protocol)
		};
	};

	return MultiToken;
}();

/**
	Represents a list of tokens making up a valid email address
	@class EMAIL
	@extends MultiToken
*/


var EMAIL = function (_MultiToken) {
	_inherits(EMAIL, _MultiToken);

	function EMAIL(value) {
		_classCallCheck(this, EMAIL);

		var _this23 = _possibleConstructorReturn(this, _MultiToken.call(this, value));

		_this23.type = 'email';
		_this23.isLink = true;
		return _this23;
	}

	EMAIL.prototype.toHref = function toHref() {
		return 'mailto:' + this.toString();
	};

	return EMAIL;
}(MultiToken);

/**
	Represents some plain text
	@class TEXT
	@extends MultiToken
*/


var TEXT = function (_MultiToken2) {
	_inherits(TEXT, _MultiToken2);

	function TEXT(value) {
		_classCallCheck(this, TEXT);

		var _this24 = _possibleConstructorReturn(this, _MultiToken2.call(this, value));

		_this24.type = 'text';
		return _this24;
	}

	return TEXT;
}(MultiToken);

/**
	Multi-linebreak token - represents a line break
	@class MNL
	@extends MultiToken
*/


var MNL = function (_MultiToken3) {
	_inherits(MNL, _MultiToken3);

	function MNL(value) {
		_classCallCheck(this, MNL);

		var _this25 = _possibleConstructorReturn(this, _MultiToken3.call(this, value));

		_this25.type = 'nl';
		return _this25;
	}

	return MNL;
}(MultiToken);

/**
	Represents a list of tokens making up a valid URL
	@class URL
	@extends MultiToken
*/


var URL = function (_MultiToken4) {
	_inherits(URL, _MultiToken4);

	function URL(value) {
		_classCallCheck(this, URL);

		var _this26 = _possibleConstructorReturn(this, _MultiToken4.call(this, value));

		_this26.type = 'url';
		_this26.isLink = true;
		return _this26;
	}

	/**
 	Lowercases relevant parts of the domain and adds the protocol if
 	required. Note that this will not escape unsafe HTML characters in the
 	URL.
 		@method href
 	@param {String} protocol
 	@return {String}
 */


	URL.prototype.toHref = function toHref() {
		var protocol = arguments.length <= 0 || arguments[0] === undefined ? 'http' : arguments[0];

		var hasProtocol = false,
		    hasSlashSlash = false,
		    tokens = this.v,
		    result = [],
		    i = 0;

		// Make the first part of the domain lowercase
		// Lowercase protocol
		while (tokens[i] instanceof PROTOCOL) {
			hasProtocol = true;
			result.push(tokens[i].toString().toLowerCase());
			i++;
		}

		// Skip slash-slash
		while (tokens[i] instanceof SLASH) {
			hasSlashSlash = true;
			result.push(tokens[i].toString());
			i++;
		}

		// Lowercase all other characters in the domain
		while (isDomainToken(tokens[i])) {
			result.push(tokens[i].toString().toLowerCase());
			i++;
		}

		// Leave all other characters as they were written
		for (; i < tokens.length; i++) {
			result.push(tokens[i].toString());
		}

		result = result.join('');

		if (!(hasProtocol || hasSlashSlash)) {
			result = protocol + '://' + result;
		}

		return result;
	};

	URL.prototype.hasProtocol = function hasProtocol() {
		return this.v[0] instanceof PROTOCOL;
	};

	return URL;
}(MultiToken);

var multi = {
	Base: MultiToken,
	EMAIL: EMAIL,
	NL: MNL,
	TEXT: TEXT,
	URL: URL
};

exports.text = text;
exports.multi = multi;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"state.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/lib/linkify/core/state.js                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
"use strict";

exports.__esModule = true;

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
	A simple state machine that can emit token classes

	The `j` property in this class refers to state jumps. It's a
	multidimensional array where for each element:

	* index [0] is a symbol or class of symbols to transition to.
	* index [1] is a State instance which matches

	The type of symbol will depend on the target implementation for this class.
	In Linkify, we have a two-stage scanner. Each stage uses this state machine
	but with a slighly different (polymorphic) implementation.

	The `T` property refers to the token class.

	TODO: Can the `on` and `next` methods be combined?

	@class BaseState
*/

var BaseState = function () {

	/**
 	@method constructor
 	@param {Class} tClass Pass in the kind of token to emit if there are
 		no jumps after this state and the state is accepting.
 */

	function BaseState(tClass) {
		_classCallCheck(this, BaseState);

		this.j = [];
		this.T = tClass || null;
	}

	/**
 	On the given symbol(s), this machine should go to the given state
 		@method on
 	@param {Array|Mixed} symbol
 	@param {BaseState} state Note that the type of this state should be the
 		same as the current instance (i.e., don't pass in a different
 		subclass)
 */


	BaseState.prototype.on = function on(symbol, state) {
		if (symbol instanceof Array) {
			for (var i = 0; i < symbol.length; i++) {
				this.j.push([symbol[i], state]);
			}
			return this;
		}
		this.j.push([symbol, state]);
		return this;
	};

	/**
 	Given the next item, returns next state for that item
 	@method next
 	@param {Mixed} item Should be an instance of the symbols handled by
 		this particular machine.
 	@return {State} state Returns false if no jumps are available
 */


	BaseState.prototype.next = function next(item) {

		for (var i = 0; i < this.j.length; i++) {

			var jump = this.j[i],
			    symbol = jump[0],
			    // Next item to check for
			state = jump[1]; // State to jump to if items match

			// compare item with symbol
			if (this.test(item, symbol)) return state;
		}

		// Nowhere left to jump!
		return false;
	};

	/**
 	Does this state accept?
 	`true` only of `this.T` exists
 		@method accepts
 	@return {Boolean}
 */


	BaseState.prototype.accepts = function accepts() {
		return !!this.T;
	};

	/**
 	Determine whether a given item "symbolizes" the symbol, where symbol is
 	a class of items handled by this state machine.
 		This method should be overriden in extended classes.
 		@method test
 	@param {Mixed} item Does this item match the given symbol?
 	@param {Mixed} symbol
 	@return {Boolean}
 */


	BaseState.prototype.test = function test(item, symbol) {
		return item === symbol;
	};

	/**
 	Emit the token for this State (just return it in this case)
 	If this emits a token, this instance is an accepting state
 	@method emit
 	@return {Class} T
 */


	BaseState.prototype.emit = function emit() {
		return this.T;
	};

	return BaseState;
}();

/**
	State machine for string-based input

	@class CharacterState
	@extends BaseState
*/


var CharacterState = function (_BaseState) {
	_inherits(CharacterState, _BaseState);

	function CharacterState() {
		_classCallCheck(this, CharacterState);

		return _possibleConstructorReturn(this, _BaseState.apply(this, arguments));
	}

	/**
 	Does the given character match the given character or regular
 	expression?
 		@method test
 	@param {String} char
 	@param {String|RegExp} charOrRegExp
 	@return {Boolean}
 */

	CharacterState.prototype.test = function test(character, charOrRegExp) {
		return character === charOrRegExp || charOrRegExp instanceof RegExp && charOrRegExp.test(character);
	};

	return CharacterState;
}(BaseState);

/**
	State machine for input in the form of TextTokens

	@class TokenState
	@extends BaseState
*/


var TokenState = function (_BaseState2) {
	_inherits(TokenState, _BaseState2);

	function TokenState() {
		_classCallCheck(this, TokenState);

		return _possibleConstructorReturn(this, _BaseState2.apply(this, arguments));
	}

	/**
 	Is the given token an instance of the given token class?
 		@method test
 	@param {TextToken} token
 	@param {Class} tokenClass
 	@return {Boolean}
 */

	TokenState.prototype.test = function test(token, tokenClass) {
		return token instanceof tokenClass;
	};

	return TokenState;
}(BaseState);

/**
	Given a non-empty target string, generates states (if required) for each
	consecutive substring of characters in str starting from the beginning of
	the string. The final state will have a special value, as specified in
	options. All other "in between" substrings will have a default end state.

	This turns the state machine into a Trie-like data structure (rather than a
	intelligently-designed DFA).

	Note that I haven't really tried these with any strings other than
	DOMAIN.

	@param {String} str
	@param {CharacterState} start State to jump from the first character
	@param {Class} endToken Token class to emit when the given string has been
		matched and no more jumps exist.
	@param {Class} defaultToken "Filler token", or which token type to emit when
		we don't have a full match
	@return {Array} list of newly-created states
*/


function stateify(str, start, endToken, defaultToken) {

	var i = 0,
	    len = str.length,
	    state = start,
	    newStates = [],
	    nextState = void 0;

	// Find the next state without a jump to the next character
	while (i < len && (nextState = state.next(str[i]))) {
		state = nextState;
		i++;
	}

	if (i >= len) return []; // no new tokens were added

	while (i < len - 1) {
		nextState = new CharacterState(defaultToken);
		newStates.push(nextState);
		state.on(str[i], nextState);
		state = nextState;
		i++;
	}

	nextState = new CharacterState(endToken);
	newStates.push(nextState);
	state.on(str[len - 1], nextState);

	return newStates;
}

exports.CharacterState = CharacterState;
exports.TokenState = TokenState;
exports.stateify = stateify;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"parser.js":["./tokens","./state",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/lib/linkify/core/parser.js                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';

exports.__esModule = true;
exports.start = exports.run = exports.TOKENS = exports.State = undefined;

var _tokens = require('./tokens');

var _state = require('./state');

/**
	Not exactly parser, more like the second-stage scanner (although we can
	theoretically hotswap the code here with a real parser in the future... but
	for a little URL-finding utility abstract syntax trees may be a little
	overkill).

	URL format: http://en.wikipedia.org/wiki/URI_scheme
	Email format: http://en.wikipedia.org/wiki/Email_address (links to RFC in
	reference)

	@module linkify
	@submodule parser
	@main parser
*/

var makeState = function makeState(tokenClass) {
	return new _state.TokenState(tokenClass);
};

var TT_DOMAIN = _tokens.text.DOMAIN,
    TT_AT = _tokens.text.AT,
    TT_COLON = _tokens.text.COLON,
    TT_DOT = _tokens.text.DOT,
    TT_PUNCTUATION = _tokens.text.PUNCTUATION,
    TT_LOCALHOST = _tokens.text.LOCALHOST,
    TT_NL = _tokens.text.NL,
    TT_NUM = _tokens.text.NUM,
    TT_PLUS = _tokens.text.PLUS,
    TT_POUND = _tokens.text.POUND,
    TT_PROTOCOL = _tokens.text.PROTOCOL,
    TT_QUERY = _tokens.text.QUERY,
    TT_SLASH = _tokens.text.SLASH,
    TT_SYM = _tokens.text.SYM,
    TT_TLD = _tokens.text.TLD,
    TT_OPENBRACE = _tokens.text.OPENBRACE,
    TT_OPENBRACKET = _tokens.text.OPENBRACKET,
    TT_OPENPAREN = _tokens.text.OPENPAREN,
    TT_CLOSEBRACE = _tokens.text.CLOSEBRACE,
    TT_CLOSEBRACKET = _tokens.text.CLOSEBRACKET,
    TT_CLOSEPAREN = _tokens.text.CLOSEPAREN;

// TT_WS 			= TEXT_TOKENS.WS;

var T_EMAIL = _tokens.multi.EMAIL,
    T_NL = _tokens.multi.NL,
    T_TEXT = _tokens.multi.TEXT,
    T_URL = _tokens.multi.URL;

// The universal starting state.
var S_START = makeState();

// Intermediate states for URLs. Note that domains that begin with a protocol
// are treated slighly differently from those that don't.
var S_PROTOCOL = makeState(),
    // e.g., 'http:'
S_PROTOCOL_SLASH = makeState(),
    // e.g., '/', 'http:/''
S_PROTOCOL_SLASH_SLASH = makeState(),
    // e.g., '//', 'http://'
S_DOMAIN = makeState(),
    // parsed string ends with a potential domain name (A)
S_DOMAIN_DOT = makeState(),
    // (A) domain followed by DOT
S_TLD = makeState(T_URL),
    // (A) Simplest possible URL with no query string
S_TLD_COLON = makeState(),
    // (A) URL followed by colon (potential port number here)
S_TLD_PORT = makeState(T_URL),
    // TLD followed by a port number
S_URL = makeState(T_URL),
    // Long URL with optional port and maybe query string
S_URL_SYMS = makeState(),
    // URL followed by some symbols (will not be part of the final URL)
S_URL_OPENBRACE = makeState(),
    // URL followed by {
S_URL_OPENBRACKET = makeState(),
    // URL followed by [
S_URL_OPENPAREN = makeState(),
    // URL followed by (
S_URL_OPENBRACE_Q = makeState(T_URL),
    // URL followed by { and some symbols that the URL can end it
S_URL_OPENBRACKET_Q = makeState(T_URL),
    // URL followed by [ and some symbols that the URL can end it
S_URL_OPENPAREN_Q = makeState(T_URL),
    // URL followed by ( and some symbols that the URL can end it
S_URL_OPENBRACE_SYMS = makeState(),
    // S_URL_OPENBRACE_Q followed by some symbols it cannot end it
S_URL_OPENBRACKET_SYMS = makeState(),
    // S_URL_OPENBRACKET_Q followed by some symbols it cannot end it
S_URL_OPENPAREN_SYMS = makeState(),
    // S_URL_OPENPAREN_Q followed by some symbols it cannot end it
S_EMAIL_DOMAIN = makeState(),
    // parsed string starts with local email info + @ with a potential domain name (C)
S_EMAIL_DOMAIN_DOT = makeState(),
    // (C) domain followed by DOT
S_EMAIL = makeState(T_EMAIL),
    // (C) Possible email address (could have more tlds)
S_EMAIL_COLON = makeState(),
    // (C) URL followed by colon (potential port number here)
S_EMAIL_PORT = makeState(T_EMAIL),
    // (C) Email address with a port
S_LOCALPART = makeState(),
    // Local part of the email address
S_LOCALPART_AT = makeState(),
    // Local part of the email address plus @
S_LOCALPART_DOT = makeState(),
    // Local part of the email address plus '.' (localpart cannot end in .)
S_NL = makeState(T_NL); // single new line

// Make path from start to protocol (with '//')
S_START.on(TT_NL, S_NL).on(TT_PROTOCOL, S_PROTOCOL).on(TT_SLASH, S_PROTOCOL_SLASH);

S_PROTOCOL.on(TT_SLASH, S_PROTOCOL_SLASH);
S_PROTOCOL_SLASH.on(TT_SLASH, S_PROTOCOL_SLASH_SLASH);

// The very first potential domain name
S_START.on(TT_TLD, S_DOMAIN).on(TT_DOMAIN, S_DOMAIN).on(TT_LOCALHOST, S_TLD).on(TT_NUM, S_DOMAIN);

// Force URL for anything sane followed by protocol
S_PROTOCOL_SLASH_SLASH.on(TT_TLD, S_URL).on(TT_DOMAIN, S_URL).on(TT_NUM, S_URL).on(TT_LOCALHOST, S_URL);

// Account for dots and hyphens
// hyphens are usually parts of domain names
S_DOMAIN.on(TT_DOT, S_DOMAIN_DOT);
S_EMAIL_DOMAIN.on(TT_DOT, S_EMAIL_DOMAIN_DOT);

// Hyphen can jump back to a domain name

// After the first domain and a dot, we can find either a URL or another domain
S_DOMAIN_DOT.on(TT_TLD, S_TLD).on(TT_DOMAIN, S_DOMAIN).on(TT_NUM, S_DOMAIN).on(TT_LOCALHOST, S_DOMAIN);

S_EMAIL_DOMAIN_DOT.on(TT_TLD, S_EMAIL).on(TT_DOMAIN, S_EMAIL_DOMAIN).on(TT_NUM, S_EMAIL_DOMAIN).on(TT_LOCALHOST, S_EMAIL_DOMAIN);

// S_TLD accepts! But the URL could be longer, try to find a match greedily
// The `run` function should be able to "rollback" to the accepting state
S_TLD.on(TT_DOT, S_DOMAIN_DOT);
S_EMAIL.on(TT_DOT, S_EMAIL_DOMAIN_DOT);

// Become real URLs after `SLASH` or `COLON NUM SLASH`
// Here PSS and non-PSS converge
S_TLD.on(TT_COLON, S_TLD_COLON).on(TT_SLASH, S_URL);
S_TLD_COLON.on(TT_NUM, S_TLD_PORT);
S_TLD_PORT.on(TT_SLASH, S_URL);
S_EMAIL.on(TT_COLON, S_EMAIL_COLON);
S_EMAIL_COLON.on(TT_NUM, S_EMAIL_PORT);

// Types of characters the URL can definitely end in
var qsAccepting = [TT_DOMAIN, TT_AT, TT_LOCALHOST, TT_NUM, TT_PLUS, TT_POUND, TT_PROTOCOL, TT_SLASH, TT_TLD];

// Types of tokens that can follow a URL and be part of the query string
// but cannot be the very last characters
// Characters that cannot appear in the URL at all should be excluded
var qsNonAccepting = [TT_COLON, TT_DOT, TT_QUERY, TT_PUNCTUATION, TT_CLOSEBRACE, TT_CLOSEBRACKET, TT_CLOSEPAREN, TT_OPENBRACE, TT_OPENBRACKET, TT_OPENPAREN, TT_SYM];

// These states are responsible primarily for determining whether or not to
// include the final round bracket.

// URL, followed by an opening bracket
S_URL.on(TT_OPENBRACE, S_URL_OPENBRACE).on(TT_OPENBRACKET, S_URL_OPENBRACKET).on(TT_OPENPAREN, S_URL_OPENPAREN);

// URL with extra symbols at the end, followed by an opening bracket
S_URL_SYMS.on(TT_OPENBRACE, S_URL_OPENBRACE).on(TT_OPENBRACKET, S_URL_OPENBRACKET).on(TT_OPENPAREN, S_URL_OPENPAREN);

// Closing bracket component. This character WILL be included in the URL
S_URL_OPENBRACE.on(TT_CLOSEBRACE, S_URL);
S_URL_OPENBRACKET.on(TT_CLOSEBRACKET, S_URL);
S_URL_OPENPAREN.on(TT_CLOSEPAREN, S_URL);
S_URL_OPENBRACE_Q.on(TT_CLOSEBRACE, S_URL);
S_URL_OPENBRACKET_Q.on(TT_CLOSEBRACKET, S_URL);
S_URL_OPENPAREN_Q.on(TT_CLOSEPAREN, S_URL);
S_URL_OPENBRACE_SYMS.on(TT_CLOSEBRACE, S_URL);
S_URL_OPENBRACKET_SYMS.on(TT_CLOSEBRACKET, S_URL);
S_URL_OPENPAREN_SYMS.on(TT_CLOSEPAREN, S_URL);

// URL that beings with an opening bracket, followed by a symbols.
// Note that the final state can still be `S_URL_OPENBRACE_Q` (if the URL only
// has a single opening bracket for some reason).
S_URL_OPENBRACE.on(qsAccepting, S_URL_OPENBRACE_Q);
S_URL_OPENBRACKET.on(qsAccepting, S_URL_OPENBRACKET_Q);
S_URL_OPENPAREN.on(qsAccepting, S_URL_OPENPAREN_Q);
S_URL_OPENBRACE.on(qsNonAccepting, S_URL_OPENBRACE_SYMS);
S_URL_OPENBRACKET.on(qsNonAccepting, S_URL_OPENBRACKET_SYMS);
S_URL_OPENPAREN.on(qsNonAccepting, S_URL_OPENPAREN_SYMS);

// URL that begins with an opening bracket, followed by some symbols
S_URL_OPENBRACE_Q.on(qsAccepting, S_URL_OPENBRACE_Q);
S_URL_OPENBRACKET_Q.on(qsAccepting, S_URL_OPENBRACKET_Q);
S_URL_OPENPAREN_Q.on(qsAccepting, S_URL_OPENPAREN_Q);
S_URL_OPENBRACE_Q.on(qsNonAccepting, S_URL_OPENBRACE_Q);
S_URL_OPENBRACKET_Q.on(qsNonAccepting, S_URL_OPENBRACKET_Q);
S_URL_OPENPAREN_Q.on(qsNonAccepting, S_URL_OPENPAREN_Q);

S_URL_OPENBRACE_SYMS.on(qsAccepting, S_URL_OPENBRACE_Q);
S_URL_OPENBRACKET_SYMS.on(qsAccepting, S_URL_OPENBRACKET_Q);
S_URL_OPENPAREN_SYMS.on(qsAccepting, S_URL_OPENPAREN_Q);
S_URL_OPENBRACE_SYMS.on(qsNonAccepting, S_URL_OPENBRACE_SYMS);
S_URL_OPENBRACKET_SYMS.on(qsNonAccepting, S_URL_OPENBRACKET_SYMS);
S_URL_OPENPAREN_SYMS.on(qsNonAccepting, S_URL_OPENPAREN_SYMS);

// Account for the query string
S_URL.on(qsAccepting, S_URL);
S_URL_SYMS.on(qsAccepting, S_URL);

S_URL.on(qsNonAccepting, S_URL_SYMS);
S_URL_SYMS.on(qsNonAccepting, S_URL_SYMS);

// Email address-specific state definitions
// Note: We are not allowing '/' in email addresses since this would interfere
// with real URLs

// Tokens allowed in the localpart of the email
var localpartAccepting = [TT_DOMAIN, TT_NUM, TT_PLUS, TT_POUND, TT_QUERY, TT_SYM, TT_TLD];

// Some of the tokens in `localpartAccepting` are already accounted for here and
// will not be overwritten (don't worry)
S_DOMAIN.on(localpartAccepting, S_LOCALPART).on(TT_AT, S_LOCALPART_AT);
S_TLD.on(localpartAccepting, S_LOCALPART).on(TT_AT, S_LOCALPART_AT);
S_DOMAIN_DOT.on(localpartAccepting, S_LOCALPART);

// Okay we're on a localpart. Now what?
// TODO: IP addresses and what if the email starts with numbers?
S_LOCALPART.on(localpartAccepting, S_LOCALPART).on(TT_AT, S_LOCALPART_AT) // close to an email address now
.on(TT_DOT, S_LOCALPART_DOT);
S_LOCALPART_DOT.on(localpartAccepting, S_LOCALPART);
S_LOCALPART_AT.on(TT_TLD, S_EMAIL_DOMAIN).on(TT_DOMAIN, S_EMAIL_DOMAIN).on(TT_LOCALHOST, S_EMAIL);
// States following `@` defined above

var run = function run(tokens) {
	var len = tokens.length,
	    cursor = 0,
	    multis = [],
	    textTokens = [];

	while (cursor < len) {

		var state = S_START,
		    secondState = null,
		    nextState = null,
		    multiLength = 0,
		    latestAccepting = null,
		    sinceAccepts = -1;

		while (cursor < len && !(secondState = state.next(tokens[cursor]))) {
			// Starting tokens with nowhere to jump to.
			// Consider these to be just plain text
			textTokens.push(tokens[cursor++]);
		}

		while (cursor < len && (nextState = secondState || state.next(tokens[cursor]))) {

			// Get the next state
			secondState = null;
			state = nextState;

			// Keep track of the latest accepting state
			if (state.accepts()) {
				sinceAccepts = 0;
				latestAccepting = state;
			} else if (sinceAccepts >= 0) {
				sinceAccepts++;
			}

			cursor++;
			multiLength++;
		}

		if (sinceAccepts < 0) {

			// No accepting state was found, part of a regular text token
			// Add all the tokens we looked at to the text tokens array
			for (var i = cursor - multiLength; i < cursor; i++) {
				textTokens.push(tokens[i]);
			}
		} else {

			// Accepting state!

			// First close off the textTokens (if available)
			if (textTokens.length > 0) {
				multis.push(new T_TEXT(textTokens));
				textTokens = [];
			}

			// Roll back to the latest accepting state
			cursor -= sinceAccepts;
			multiLength -= sinceAccepts;

			// Create a new multitoken
			var MULTI = latestAccepting.emit();
			multis.push(new MULTI(tokens.slice(cursor - multiLength, cursor)));
		}
	}

	// Finally close off the textTokens (if available)
	if (textTokens.length > 0) {
		multis.push(new T_TEXT(textTokens));
	}

	return multis;
};

var TOKENS = _tokens.multi,
    start = S_START;
exports.State = _state.TokenState;
exports.TOKENS = TOKENS;
exports.run = run;
exports.start = start;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}}}}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/arkham:comments-ui/lib/collections/anonymous-user.js");
require("./node_modules/meteor/arkham:comments-ui/lib/collections/comments.js");
require("./node_modules/meteor/arkham:comments-ui/lib/collections/methods/anonymous-user.js");
require("./node_modules/meteor/arkham:comments-ui/lib/collections/methods/comments.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/media-analyzers/image.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/media-analyzers/youtube.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/user.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/time-tick.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/media.js");
require("./node_modules/meteor/arkham:comments-ui/lib/api.js");
require("./node_modules/meteor/arkham:comments-ui/lib/server/publish.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/hashing.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['arkham:comments-ui'] = {}, {
  Comments: Comments
});

})();

//# sourceMappingURL=arkham_comments-ui.js.map
