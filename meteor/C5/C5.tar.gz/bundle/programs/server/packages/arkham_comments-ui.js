(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Accounts = Package['accounts-base'].Accounts;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var Random = Package.random.Random;
var Showdown = Package.markdown.Showdown;
var ReactiveDict = Package['reactive-dict'].ReactiveDict;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var moment = Package['momentjs:moment'].moment;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Collection2 = Package['aldeed:collection2-core'].Collection2;

/* Package-scope variables */
var AnonymousUserCollection, CommentsCollection, Comments;

var require = meteorInstall({"node_modules":{"meteor":{"arkham:comments-ui":{"lib":{"collections":{"anonymous-user.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/arkham_comments-ui/lib/collections/anonymous-user.js                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
AnonymousUserCollection = new Mongo.Collection('commentsui-anonymoususer');                                        // 1
                                                                                                                   //
AnonymousUserCollection.allow({                                                                                    // 3
  insert: function () {                                                                                            // 4
    function insert() {                                                                                            // 4
      return false;                                                                                                // 4
    }                                                                                                              // 4
                                                                                                                   //
    return insert;                                                                                                 // 4
  }(),                                                                                                             // 4
  update: function () {                                                                                            // 5
    function update() {                                                                                            // 5
      return false;                                                                                                // 5
    }                                                                                                              // 5
                                                                                                                   //
    return update;                                                                                                 // 5
  }(),                                                                                                             // 5
  remove: function () {                                                                                            // 6
    function remove() {                                                                                            // 6
      return false;                                                                                                // 6
    }                                                                                                              // 6
                                                                                                                   //
    return remove;                                                                                                 // 6
  }()                                                                                                              // 6
});                                                                                                                // 3
                                                                                                                   //
AnonymousUserCollection.attachSchema(new SimpleSchema({                                                            // 9
  username: {                                                                                                      // 10
    type: String,                                                                                                  // 11
    optional: true                                                                                                 // 12
  },                                                                                                               // 10
  email: {                                                                                                         // 14
    type: String,                                                                                                  // 15
    optional: true                                                                                                 // 16
  },                                                                                                               // 14
  anonIp: {                                                                                                        // 18
    type: String                                                                                                   // 19
  },                                                                                                               // 18
  salt: {                                                                                                          // 21
    type: String                                                                                                   // 22
  },                                                                                                               // 21
  createdAt: {                                                                                                     // 24
    type: Date,                                                                                                    // 25
    autoValue: function () {                                                                                       // 26
      function autoValue() {                                                                                       // 24
        if (this.isInsert) {                                                                                       // 27
          return new Date();                                                                                       // 28
        } else if (this.isUpsert) {                                                                                // 29
          return { $setOnInsert: new Date() };                                                                     // 30
        } else {                                                                                                   // 31
          this.unset();                                                                                            // 32
        }                                                                                                          // 33
      }                                                                                                            // 34
                                                                                                                   //
      return autoValue;                                                                                            // 24
    }()                                                                                                            // 24
  }                                                                                                                // 24
}));                                                                                                               // 9
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":["babel-runtime/helpers/extends","../services/time-tick","../services/user","linkifyjs/string",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/arkham_comments-ui/lib/collections/comments.js                                                         //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _extends;module.import('babel-runtime/helpers/extends',{"default":function(v){_extends=v}});var timeTickService;module.import('../services/time-tick',{"default":function(v){timeTickService=v}});var userService;module.import('../services/user',{"default":function(v){userService=v}});var linkifyStr;module.import('linkifyjs/string',{"default":function(v){linkifyStr=v}});
                                                                                                                   // 1
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   //
CommentsCollection = new Mongo.Collection('comments');                                                             // 5
                                                                                                                   //
CommentsCollection.schemas = {};                                                                                   // 7
                                                                                                                   //
CommentsCollection.schemas.StarRatingSchema = new SimpleSchema({                                                   // 9
  userId: {                                                                                                        // 10
    type: String                                                                                                   // 11
  },                                                                                                               // 10
  rating: {                                                                                                        // 13
    type: Number                                                                                                   // 14
  }                                                                                                                // 13
});                                                                                                                // 9
                                                                                                                   //
var likeableConfig = {                                                                                             // 18
  type: [String],                                                                                                  // 19
  autoValue: function () {                                                                                         // 20
    function autoValue() {                                                                                         // 20
      if (this.isInsert) {                                                                                         // 21
        return [];                                                                                                 // 22
      }                                                                                                            // 23
    }                                                                                                              // 24
                                                                                                                   //
    return autoValue;                                                                                              // 20
  }(),                                                                                                             // 20
  optional: true                                                                                                   // 25
};                                                                                                                 // 18
                                                                                                                   //
/**                                                                                                                // 28
 * Return a comment schema enhanced with the given schema config.                                                  //
 *                                                                                                                 //
 * @param additionalSchemaConfig                                                                                   //
 *                                                                                                                 //
 * @returns {Object}                                                                                               //
 */                                                                                                                //
function getCommonCommentSchema() {                                                                                // 35
  var additionalSchemaConfig = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};             // 35
                                                                                                                   //
  return _extends({                                                                                                // 36
    userId: {                                                                                                      // 37
      type: String                                                                                                 // 38
    },                                                                                                             // 37
    isAnonymous: {                                                                                                 // 40
      type: Boolean                                                                                                // 41
    },                                                                                                             // 40
    'media.type': {                                                                                                // 43
      type: String,                                                                                                // 44
      optional: true                                                                                               // 45
    },                                                                                                             // 43
    'media.content': {                                                                                             // 47
      type: String,                                                                                                // 48
      optional: true                                                                                               // 49
    },                                                                                                             // 47
    content: {                                                                                                     // 51
      type: String,                                                                                                // 52
      min: 1,                                                                                                      // 53
      max: 10000                                                                                                   // 54
    },                                                                                                             // 51
    replies: {                                                                                                     // 56
      type: [Object],                                                                                              // 57
      autoValue: function () {                                                                                     // 58
        function autoValue() {                                                                                     // 58
          if (this.isInsert) {                                                                                     // 59
            return [];                                                                                             // 60
          }                                                                                                        // 61
        }                                                                                                          // 62
                                                                                                                   //
        return autoValue;                                                                                          // 58
      }(),                                                                                                         // 58
      optional: true                                                                                               // 63
    },                                                                                                             // 56
    likes: _extends({}, likeableConfig),                                                                           // 65
    dislikes: _extends({}, likeableConfig),                                                                        // 66
    starRatings: {                                                                                                 // 67
      type: [CommentsCollection.schemas.StarRatingSchema],                                                         // 68
      autoValue: function () {                                                                                     // 69
        function autoValue() {                                                                                     // 69
          if (this.isInsert) {                                                                                     // 70
            return [];                                                                                             // 71
          }                                                                                                        // 72
        }                                                                                                          // 73
                                                                                                                   //
        return autoValue;                                                                                          // 69
      }(),                                                                                                         // 69
      optional: true                                                                                               // 74
    },                                                                                                             // 67
    // general rating number that is used for sorting                                                              // 76
    ratingScore: {                                                                                                 // 77
      type: Number,                                                                                                // 78
      decimal: true,                                                                                               // 79
      autoValue: function () {                                                                                     // 80
        function autoValue() {                                                                                     // 80
          if (this.isInsert) {                                                                                     // 81
            return 0;                                                                                              // 82
          }                                                                                                        // 83
        }                                                                                                          // 84
                                                                                                                   //
        return autoValue;                                                                                          // 80
      }()                                                                                                          // 80
    },                                                                                                             // 77
    createdAt: {                                                                                                   // 86
      type: Date,                                                                                                  // 87
      autoValue: function () {                                                                                     // 88
        function autoValue() {                                                                                     // 88
          if (this.isInsert) {                                                                                     // 89
            return new Date();                                                                                     // 90
          } else if (this.isUpsert) {                                                                              // 91
            return { $setOnInsert: new Date() };                                                                   // 92
          } else {                                                                                                 // 93
            this.unset();                                                                                          // 94
          }                                                                                                        // 95
        }                                                                                                          // 96
                                                                                                                   //
        return autoValue;                                                                                          // 88
      }()                                                                                                          // 88
    },                                                                                                             // 86
    lastUpdatedAt: {                                                                                               // 98
      type: Date,                                                                                                  // 99
      autoValue: function () {                                                                                     // 100
        function autoValue() {                                                                                     // 100
          if (this.isUpdate) {                                                                                     // 101
            return new Date();                                                                                     // 102
          }                                                                                                        // 103
        }                                                                                                          // 104
                                                                                                                   //
        return autoValue;                                                                                          // 100
      }(),                                                                                                         // 100
      denyInsert: true,                                                                                            // 105
      optional: true                                                                                               // 106
    }                                                                                                              // 98
  }, additionalSchemaConfig);                                                                                      // 36
}                                                                                                                  // 110
                                                                                                                   //
/**                                                                                                                // 112
 * Enhance nested replies with correct data.                                                                       //
 *                                                                                                                 //
 * @param {Object} scope                                                                                           //
 * @param {Array} position                                                                                         //
 *                                                                                                                 //
 * @returns {Array}                                                                                                //
 */                                                                                                                //
function enhanceReplies(scope, position) {                                                                         // 120
  if (!position) {                                                                                                 // 121
    position = [];                                                                                                 // 122
  }                                                                                                                // 123
                                                                                                                   //
  return _.map(scope.replies, function (reply, index) {                                                            // 125
    position.push(index);                                                                                          // 126
                                                                                                                   //
    reply = Object.assign(reply, {                                                                                 // 128
      position: position.slice(0),                                                                                 // 129
      documentId: scope._id,                                                                                       // 130
      user: scope.user.bind(reply),                                                                                // 131
      likesCount: scope.likesCount.bind(reply),                                                                    // 132
      dislikesCount: scope.dislikesCount.bind(reply),                                                              // 133
      createdAgo: scope.createdAgo.bind(reply),                                                                    // 134
      getStarRating: scope.getStarRating.bind(reply),                                                              // 135
      enhancedContent: scope.enhancedContent.bind(reply)                                                           // 136
    });                                                                                                            // 128
                                                                                                                   //
    if (reply.replies) {                                                                                           // 139
      // recursive!                                                                                                // 140
      reply.enhancedReplies = _.bind(enhanceReplies, null, _.extend(_.clone(scope), { replies: reply.replies }), position)();
    }                                                                                                              // 147
                                                                                                                   //
    position.pop();                                                                                                // 149
                                                                                                                   //
    return reply;                                                                                                  // 151
  });                                                                                                              // 152
}                                                                                                                  // 153
                                                                                                                   //
CommentsCollection.schemas.ReplySchema = new SimpleSchema(getCommonCommentSchema({                                 // 155
  replyId: {                                                                                                       // 156
    type: String                                                                                                   // 157
  }                                                                                                                // 156
}));                                                                                                               // 155
                                                                                                                   //
CommentsCollection.schemas.CommentSchema = new SimpleSchema(getCommonCommentSchema({                               // 161
  referenceId: {                                                                                                   // 162
    type: String                                                                                                   // 163
  }                                                                                                                // 162
}));                                                                                                               // 161
                                                                                                                   //
CommentsCollection.attachSchema(CommentsCollection.schemas.CommentSchema);                                         // 167
                                                                                                                   //
// Is handled with Meteor.methods                                                                                  // 169
CommentsCollection.allow({                                                                                         // 170
  insert: function () {                                                                                            // 171
    function insert() {                                                                                            // 171
      return false;                                                                                                // 171
    }                                                                                                              // 171
                                                                                                                   //
    return insert;                                                                                                 // 171
  }(),                                                                                                             // 171
  update: function () {                                                                                            // 172
    function update() {                                                                                            // 172
      return false;                                                                                                // 172
    }                                                                                                              // 172
                                                                                                                   //
    return update;                                                                                                 // 172
  }(),                                                                                                             // 172
  remove: function () {                                                                                            // 173
    function remove() {                                                                                            // 173
      return false;                                                                                                // 173
    }                                                                                                              // 173
                                                                                                                   //
    return remove;                                                                                                 // 173
  }()                                                                                                              // 173
});                                                                                                                // 170
                                                                                                                   //
var calculateAverageRating = function calculateAverageRating(ratings) {                                            // 176
  return _.reduce(ratings, function (averageRating, rating) {                                                      // 176
    return averageRating + rating.rating / ratings.length;                                                         // 178
  }, 0);                                                                                                           // 178
};                                                                                                                 // 176
                                                                                                                   //
CommentsCollection._calculateAverageRating = calculateAverageRating;                                               // 182
                                                                                                                   //
var getCount = function getCount(scope, field) {                                                                   // 184
  return scope[field] && scope[field].length ? scope[field].length : 0;                                            // 184
};                                                                                                                 // 184
                                                                                                                   //
CommentsCollection.helpers({                                                                                       // 186
  likesCount: function () {                                                                                        // 187
    function likesCount() {                                                                                        // 187
      return getCount(this, 'likes');                                                                              // 188
    }                                                                                                              // 189
                                                                                                                   //
    return likesCount;                                                                                             // 187
  }(),                                                                                                             // 187
  dislikesCount: function () {                                                                                     // 190
    function dislikesCount() {                                                                                     // 190
      return getCount(this, 'dislikes');                                                                           // 191
    }                                                                                                              // 192
                                                                                                                   //
    return dislikesCount;                                                                                          // 190
  }(),                                                                                                             // 190
  user: function () {                                                                                              // 193
    function user() {                                                                                              // 193
      return userService.getUserById(this.userId);                                                                 // 194
    }                                                                                                              // 195
                                                                                                                   //
    return user;                                                                                                   // 193
  }(),                                                                                                             // 193
  createdAgo: function () {                                                                                        // 196
    function createdAgo() {                                                                                        // 196
      return timeTickService.fromNowReactive(moment(this.createdAt));                                              // 197
    }                                                                                                              // 198
                                                                                                                   //
    return createdAgo;                                                                                             // 196
  }(),                                                                                                             // 196
  enhancedReplies: function () {                                                                                   // 199
    function enhancedReplies(position) {                                                                           // 199
      return enhanceReplies(this, position);                                                                       // 200
    }                                                                                                              // 201
                                                                                                                   //
    return enhancedReplies;                                                                                        // 199
  }(),                                                                                                             // 199
  enhancedContent: function () {                                                                                   // 202
    function enhancedContent() {                                                                                   // 202
      return linkifyStr(this.content);                                                                             // 203
    }                                                                                                              // 204
                                                                                                                   //
    return enhancedContent;                                                                                        // 202
  }(),                                                                                                             // 202
  getStarRating: function () {                                                                                     // 205
    function getStarRating() {                                                                                     // 205
      if (_.isArray(this.starRatings)) {                                                                           // 206
        var ownRating = _.find(this.starRatings, function (rating) {                                               // 207
          return rating.userId === Meteor.userId();                                                                // 207
        });                                                                                                        // 207
                                                                                                                   //
        if (ownRating) {                                                                                           // 209
          return {                                                                                                 // 210
            type: 'user',                                                                                          // 211
            rating: ownRating.rating                                                                               // 212
          };                                                                                                       // 210
        }                                                                                                          // 214
                                                                                                                   //
        return {                                                                                                   // 216
          type: 'average',                                                                                         // 217
          rating: calculateAverageRating(this.starRatings)                                                         // 218
        };                                                                                                         // 216
      }                                                                                                            // 220
                                                                                                                   //
      return {                                                                                                     // 222
        type: 'average',                                                                                           // 223
        rating: 0                                                                                                  // 224
      };                                                                                                           // 222
    }                                                                                                              // 226
                                                                                                                   //
    return getStarRating;                                                                                          // 205
  }()                                                                                                              // 205
});                                                                                                                // 186
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods":{"anonymous-user.js":["../../services/hashing",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/arkham_comments-ui/lib/collections/methods/anonymous-user.js                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var hashingService;module.import('../../services/hashing',{"default":function(v){hashingService=v}});              // 1
                                                                                                                   //
Meteor.methods({                                                                                                   // 3
  'commentsUiAnonymousUser/add': function () {                                                                     // 4
    function commentsUiAnonymousUserAdd(data) {                                                                    // 3
      check(data, {                                                                                                // 5
        username: String,                                                                                          // 6
        email: String                                                                                              // 7
      });                                                                                                          // 5
                                                                                                                   //
      if (Meteor.isServer) {                                                                                       // 10
        data.salt = hashingService.hash(data);                                                                     // 11
        data.anonIp = this.connection.clientAddress;                                                               // 12
      } else {                                                                                                     // 13
        data.salt = 'fake';                                                                                        // 14
        data.anonIp = 'fake';                                                                                      // 15
      }                                                                                                            // 16
                                                                                                                   //
      if (AnonymousUserCollection.find({ anonIp: data.anonIp, createdAt: { $gte: moment().subtract(10, 'days').toDate() } }).count() >= 5) {
        throw new Meteor.Error('More than 5 anonymous accounts with the same IP');                                 // 19
      }                                                                                                            // 20
                                                                                                                   //
      return {                                                                                                     // 22
        _id: AnonymousUserCollection.insert(data),                                                                 // 23
        salt: data.salt                                                                                            // 24
      };                                                                                                           // 22
    }                                                                                                              // 26
                                                                                                                   //
    return commentsUiAnonymousUserAdd;                                                                             // 3
  }(),                                                                                                             // 3
  'commentsUiAnonymousUser/update': function () {                                                                  // 27
    function commentsUiAnonymousUserUpdate(_id, salt, data) {                                                      // 3
      check(_id, String);                                                                                          // 28
      check(salt, String);                                                                                         // 29
      check(data, {                                                                                                // 30
        username: Match.Optional(String),                                                                          // 31
        email: Match.Optional(String)                                                                              // 32
      });                                                                                                          // 30
                                                                                                                   //
      return AnonymousUserCollection.update({ _id: _id, salt: salt }, { $set: data });                             // 35
    }                                                                                                              // 36
                                                                                                                   //
    return commentsUiAnonymousUserUpdate;                                                                          // 3
  }()                                                                                                              // 3
});                                                                                                                // 3
                                                                                                                   //
AnonymousUserCollection.methods = {                                                                                // 39
  add: function () {                                                                                               // 40
    function add(data, cb) {                                                                                       // 40
      return Meteor.call('commentsUiAnonymousUser/add', data, cb);                                                 // 40
    }                                                                                                              // 40
                                                                                                                   //
    return add;                                                                                                    // 40
  }(),                                                                                                             // 40
  update: function () {                                                                                            // 41
    function update(id, salt, data, cb) {                                                                          // 41
      return Meteor.call('commentsUiAnonymousUser/update', id, salt, data, cb);                                    // 41
    }                                                                                                              // 41
                                                                                                                   //
    return update;                                                                                                 // 41
  }()                                                                                                              // 41
};                                                                                                                 // 39
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"comments.js":["../../services/media","../../services/user","../../services/comment",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/arkham_comments-ui/lib/collections/methods/comments.js                                                 //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var mediaService;module.import('../../services/media',{"default":function(v){mediaService=v}});var userService;module.import('../../services/user',{"default":function(v){userService=v}});var commentService;module.import('../../services/comment',{"default":function(v){commentService=v}});
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   //
var noOptOptions = {                                                                                               // 5
  validate: false,                                                                                                 // 6
  filter: false,                                                                                                   // 7
  getAutoValues: false,                                                                                            // 8
  removeEmptyStrings: false                                                                                        // 9
};                                                                                                                 // 5
                                                                                                                   //
/**                                                                                                                // 12
 * Modify replies with a callback in a nested array.                                                               //
 *                                                                                                                 //
 * @param {Array} nestedArray                                                                                      //
 * @param {Array} position Array of numbers with indexes throughout the reply tree.                                //
 * @param {Function} callback                                                                                      //
 */                                                                                                                //
function modifyNestedReplies(nestedArray, position, callback) {                                                    // 19
  var currentPos = position.shift();                                                                               // 20
                                                                                                                   //
  if (nestedArray[currentPos]) {                                                                                   // 22
    if (position.length && nestedArray[currentPos] && nestedArray[currentPos].replies) {                           // 23
      modifyNestedReplies(nestedArray[currentPos].replies, position, callback);                                    // 24
    } else {                                                                                                       // 25
      callback(nestedArray, currentPos);                                                                           // 26
    }                                                                                                              // 27
  }                                                                                                                // 28
}                                                                                                                  // 29
                                                                                                                   //
/**                                                                                                                // 31
 * Call a meteor method with anonymous user id if there is as the last argument.                                   //
 *                                                                                                                 //
 * @param {String} methodName                                                                                      //
 * @param {Array} methodArgs                                                                                       //
 */                                                                                                                //
function callWithAnonUserData(methodName) {                                                                        // 37
  var anonUserData = userService.isAnonymous() ? userService.getUserData() : {};                                   // 38
                                                                                                                   //
  for (var _len = arguments.length, methodArgs = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {  // 37
    methodArgs[_key - 1] = arguments[_key];                                                                        // 37
  }                                                                                                                // 37
                                                                                                                   //
  Meteor.apply(methodName, [].concat(methodArgs, [anonUserData]));                                                 // 39
}                                                                                                                  // 40
                                                                                                                   //
/**                                                                                                                // 42
 * Return a mongodb style field descriptor                                                                         //
 *                                                                                                                 //
 * e.g "replies.0.replies.1" which points at the second reply of the first reply.                                  //
 *                                                                                                                 //
 * @param {undefined|Array} position                                                                               //
 *                                                                                                                 //
 * @return {String}                                                                                                //
 */                                                                                                                //
function getMongoReplyFieldDescriptor(position) {                                                                  // 51
  if (!position) {                                                                                                 // 52
    return '';                                                                                                     // 53
  }                                                                                                                // 54
                                                                                                                   //
  var descriptorWithLeadingDot = _.reduce(position, function (descriptor, positionNumber) {                        // 56
    return descriptor + 'replies.' + positionNumber + '.';                                                         // 57
  }, '');                                                                                                          // 58
                                                                                                                   //
  return descriptorWithLeadingDot.substr(0, descriptorWithLeadingDot.length - 1);                                  // 60
}                                                                                                                  // 61
                                                                                                                   //
var triggerEvent = function triggerEvent(name, action, payload) {                                                  // 63
  var func = Comments.config().onEvent;                                                                            // 64
                                                                                                                   //
  if (_.isFunction(func)) {                                                                                        // 66
    func(name, action, payload);                                                                                   // 67
  }                                                                                                                // 68
};                                                                                                                 // 69
                                                                                                                   //
var getRatingScore = function getRatingScore(doc) {                                                                // 71
  var score = CommentsCollection._calculateAverageRating(doc.starRatings);                                         // 72
                                                                                                                   //
  if (score === 0) {                                                                                               // 74
    score = doc.likes.length - (doc.dislikes && doc.dislikes.length ? doc.dislikes.length : 0);                    // 75
  }                                                                                                                // 76
                                                                                                                   //
  return score;                                                                                                    // 78
};                                                                                                                 // 79
                                                                                                                   //
var updateRatingScoreOnDoc = function updateRatingScoreOnDoc(_id) {                                                // 81
  CommentsCollection.update({ _id: _id }, {                                                                        // 82
    $set: { ratingScore: getRatingScore(CommentsCollection.findOne(_id)) }                                         // 83
  });                                                                                                              // 82
};                                                                                                                 // 85
                                                                                                                   //
var allowReplies = function allowReplies(documentId) {                                                             // 87
  var config = Comments.config();                                                                                  // 88
  var referenceId = getReferenceIdByDocumentId(documentId);                                                        // 89
                                                                                                                   //
  return config.allowReplies ? config.allowReplies(referenceId) : config.replies;                                  // 91
};                                                                                                                 // 92
                                                                                                                   //
var getReferenceIdByDocumentId = function getReferenceIdByDocumentId(documentId) {                                 // 94
  var doc = CommentsCollection.findOne({ _id: documentId }, { fields: { referenceId: 1 } });                       // 95
                                                                                                                   //
  if (doc) {                                                                                                       // 97
    return doc.referenceId;                                                                                        // 98
  }                                                                                                                // 99
};                                                                                                                 // 100
                                                                                                                   //
// TODO: add unit tests + good user testing (bootstrap, ionic and so on)!                                          // 102
                                                                                                                   //
Meteor.methods({                                                                                                   // 104
  'comments/add': function () {                                                                                    // 105
    function commentsAdd(referenceId, content, anonUserData) {                                                     // 105
      check(referenceId, String);                                                                                  // 106
      check(content, String);                                                                                      // 107
                                                                                                                   //
      userService.verifyAnonUserData(anonUserData, referenceId);                                                   // 109
      var userId = this.userId || anonUserData._id;                                                                // 110
                                                                                                                   //
      content = content.trim();                                                                                    // 112
                                                                                                                   //
      if (userId && content) {                                                                                     // 114
        var doc = {                                                                                                // 115
          referenceId: referenceId,                                                                                // 116
          content: content,                                                                                        // 117
          userId: userId,                                                                                          // 118
          createdAt: new Date(),                                                                                   // 119
          likes: [],                                                                                               // 120
          dislikes: [],                                                                                            // 121
          replies: [],                                                                                             // 122
          isAnonymous: !!anonUserData._id,                                                                         // 123
          media: mediaService.getMediaFromContent(content)                                                         // 124
        };                                                                                                         // 115
                                                                                                                   //
        var docId = CommentsCollection.insert(doc);                                                                // 127
                                                                                                                   //
        triggerEvent('comment', 'add', Object.assign({}, doc, { _id: docId }));                                    // 129
      }                                                                                                            // 130
    }                                                                                                              // 131
                                                                                                                   //
    return commentsAdd;                                                                                            // 105
  }(),                                                                                                             // 105
  'comments/edit': function () {                                                                                   // 132
    function commentsEdit(documentId, newContent, anonUserData) {                                                  // 132
      check(documentId, String);                                                                                   // 133
      check(newContent, String);                                                                                   // 134
                                                                                                                   //
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                        // 136
      var userId = this.userId || anonUserData._id;                                                                // 137
                                                                                                                   //
      newContent = newContent.trim();                                                                              // 139
                                                                                                                   //
      if (!userId || !newContent) {                                                                                // 141
        return;                                                                                                    // 142
      }                                                                                                            // 143
                                                                                                                   //
      var setDoc = { content: newContent, likes: [], media: mediaService.getMediaFromContent(newContent), ratingScore: 0 };
      var findSelector = { _id: documentId, userId: userId };                                                      // 146
                                                                                                                   //
      CommentsCollection.update(findSelector, { $set: setDoc });                                                   // 148
                                                                                                                   //
      triggerEvent('comment', 'edit', Object.assign({}, setDoc, findSelector));                                    // 153
    }                                                                                                              // 154
                                                                                                                   //
    return commentsEdit;                                                                                           // 132
  }(),                                                                                                             // 132
  'comments/remove': function () {                                                                                 // 155
    function commentsRemove(documentId, anonUserData) {                                                            // 155
      check(documentId, String);                                                                                   // 156
                                                                                                                   //
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                        // 158
      var userId = this.userId || anonUserData._id;                                                                // 159
                                                                                                                   //
      var removeSelector = { _id: documentId, userId: userId };                                                    // 161
                                                                                                                   //
      var doc = CommentsCollection.findOne(removeSelector);                                                        // 163
                                                                                                                   //
      CommentsCollection.remove(removeSelector);                                                                   // 165
                                                                                                                   //
      triggerEvent('comment', 'remove', doc);                                                                      // 167
    }                                                                                                              // 168
                                                                                                                   //
    return commentsRemove;                                                                                         // 155
  }(),                                                                                                             // 155
  'comments/like': function () {                                                                                   // 169
    function commentsLike(documentId, anonUserData) {                                                              // 169
      check(documentId, String);                                                                                   // 170
                                                                                                                   //
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                        // 172
      var userId = this.userId || anonUserData._id;                                                                // 173
                                                                                                                   //
      if (!userId || !['likes', 'likes-and-dislikes'].includes(Comments.config().rating)) {                        // 175
        return;                                                                                                    // 176
      }                                                                                                            // 177
                                                                                                                   //
      var findSelector = { _id: documentId };                                                                      // 179
                                                                                                                   //
      var likedDoc = CommentsCollection.findOne({ _id: documentId, likes: { $in: [userId] } });                    // 181
                                                                                                                   //
      if (likedDoc) {                                                                                              // 183
        CommentsCollection.update(findSelector, { $pull: { likes: userId } }, noOptOptions);                       // 184
      } else {                                                                                                     // 185
        CommentsCollection.update(findSelector, { $push: { likes: userId } }, noOptOptions);                       // 186
      }                                                                                                            // 187
                                                                                                                   //
      updateRatingScoreOnDoc(documentId);                                                                          // 189
                                                                                                                   //
      triggerEvent('comment', 'like', Object.assign({}, likedDoc, findSelector, {                                  // 191
        ratedUserId: userId                                                                                        // 192
      }));                                                                                                         // 191
    }                                                                                                              // 194
                                                                                                                   //
    return commentsLike;                                                                                           // 169
  }(),                                                                                                             // 169
  'comments/dislike': function () {                                                                                // 195
    function commentsDislike(documentId, anonUserData) {                                                           // 195
      check(documentId, String);                                                                                   // 196
                                                                                                                   //
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                        // 198
      var userId = this.userId || anonUserData._id;                                                                // 199
                                                                                                                   //
      if (!userId || !['likes', 'likes-and-dislikes'].includes(Comments.config().rating)) {                        // 201
        return;                                                                                                    // 202
      }                                                                                                            // 203
                                                                                                                   //
      var findSelector = { _id: documentId };                                                                      // 205
                                                                                                                   //
      var dislikedDoc = CommentsCollection.findOne({ _id: documentId, dislikes: { $in: [userId] } });              // 207
                                                                                                                   //
      if (dislikedDoc) {                                                                                           // 209
        CommentsCollection.update(findSelector, { $pull: { dislikes: userId } }, noOptOptions);                    // 210
      } else {                                                                                                     // 211
        CommentsCollection.update(findSelector, { $push: { dislikes: userId } }, noOptOptions);                    // 212
      }                                                                                                            // 213
                                                                                                                   //
      updateRatingScoreOnDoc(documentId);                                                                          // 215
                                                                                                                   //
      triggerEvent('comment', 'dislike', Object.assign({}, dislikedDoc, findSelector, {                            // 217
        ratedUserId: userId                                                                                        // 218
      }));                                                                                                         // 217
    }                                                                                                              // 220
                                                                                                                   //
    return commentsDislike;                                                                                        // 195
  }(),                                                                                                             // 195
  'comments/star': function () {                                                                                   // 221
    function commentsStar(documentId, starsCount, anonUserData) {                                                  // 221
      check(documentId, String);                                                                                   // 222
      check(starsCount, Number);                                                                                   // 223
                                                                                                                   //
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                        // 225
      var userId = this.userId || anonUserData._id;                                                                // 226
                                                                                                                   //
      if (!userId || Comments.config().rating !== 'stars') {                                                       // 228
        return;                                                                                                    // 229
      }                                                                                                            // 230
                                                                                                                   //
      var findSelector = { _id: documentId };                                                                      // 232
                                                                                                                   //
      var starredDoc = CommentsCollection.findOne({ _id: documentId, 'starRatings.userId': userId });              // 234
                                                                                                                   //
      if (starredDoc) {                                                                                            // 236
        CommentsCollection.update(findSelector, { $pull: { starRatings: { userId: userId } } }, noOptOptions);     // 237
      }                                                                                                            // 238
                                                                                                                   //
      CommentsCollection.update(findSelector, { $push: { starRatings: { userId: userId, rating: starsCount } } });
                                                                                                                   //
      updateRatingScoreOnDoc(documentId);                                                                          // 242
                                                                                                                   //
      triggerEvent('comment', 'star', Object.assign({}, starredDoc, findSelector, {                                // 244
        ratedUserId: userId,                                                                                       // 245
        rating: starsCount                                                                                         // 246
      }));                                                                                                         // 244
    }                                                                                                              // 248
                                                                                                                   //
    return commentsStar;                                                                                           // 221
  }(),                                                                                                             // 221
  'comments/reply/add': function () {                                                                              // 249
    function commentsReplyAdd(documentId, docScope, content, anonUserData) {                                       // 249
      var _$push;                                                                                                  // 249
                                                                                                                   //
      check(documentId, String);                                                                                   // 250
      check(docScope, Object);                                                                                     // 251
      check(content, String);                                                                                      // 252
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                        // 253
                                                                                                                   //
      var doc = CommentsCollection.findOne({ _id: documentId }),                                                   // 255
          userId = this.userId || anonUserData._id;                                                                // 255
                                                                                                                   //
      content = content.trim();                                                                                    // 258
                                                                                                                   //
      if (!doc || !userId || !content || !allowReplies(documentId)) {                                              // 260
        return false;                                                                                              // 261
      }                                                                                                            // 262
                                                                                                                   //
      var reply = {                                                                                                // 264
        replyId: Random.id(),                                                                                      // 265
        content: content,                                                                                          // 266
        userId: userId,                                                                                            // 267
        createdAt: new Date(),                                                                                     // 268
        replies: [], likes: [],                                                                                    // 269
        lastUpdatedAt: new Date(),                                                                                 // 270
        isAnonymous: !!anonUserData._id,                                                                           // 271
        media: mediaService.getMediaFromContent(content),                                                          // 272
        ratingScore: 0                                                                                             // 273
      };                                                                                                           // 264
                                                                                                                   //
      check(reply, CommentsCollection.schemas.ReplySchema);                                                        // 276
                                                                                                                   //
      var fieldDescriptor = 'replies';                                                                             // 278
                                                                                                                   //
      if (docScope.position) {                                                                                     // 280
        if (commentService.denyReply(docScope)) {                                                                  // 281
          throw new Meteor.Error('Cannot have more nesting than 4 levels');                                        // 282
        }                                                                                                          // 283
                                                                                                                   //
        fieldDescriptor = getMongoReplyFieldDescriptor(docScope.position) + '.replies';                            // 285
      }                                                                                                            // 286
                                                                                                                   //
      var modifier = {                                                                                             // 288
        $push: (_$push = {}, _$push[fieldDescriptor] = {                                                           // 289
          $each: [reply],                                                                                          // 291
          $position: 0                                                                                             // 292
        }, _$push)                                                                                                 // 290
      };                                                                                                           // 288
                                                                                                                   //
      var findSelector = { _id: documentId };                                                                      // 297
                                                                                                                   //
      CommentsCollection.update(findSelector, modifier, noOptOptions);                                             // 299
      triggerEvent('reply', 'add', Object.assign({}, reply, findSelector, {                                        // 300
        userId: userId,                                                                                            // 301
        rootUserId: doc.userId                                                                                     // 302
      }));                                                                                                         // 300
    }                                                                                                              // 304
                                                                                                                   //
    return commentsReplyAdd;                                                                                       // 249
  }(),                                                                                                             // 249
  'comments/reply/edit': function () {                                                                             // 305
    function commentsReplyEdit(documentId, docScope, newContent, anonUserData) {                                   // 305
      check(documentId, String);                                                                                   // 306
      check(docScope, Object);                                                                                     // 307
      check(newContent, String);                                                                                   // 308
                                                                                                                   //
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                        // 310
                                                                                                                   //
      var doc = CommentsCollection.findOne(documentId),                                                            // 312
          userId = this.userId || anonUserData._id;                                                                // 312
                                                                                                                   //
      var reply = {};                                                                                              // 315
                                                                                                                   //
      newContent = newContent.trim();                                                                              // 317
                                                                                                                   //
      if (!userId || !newContent || !allowReplies(documentId)) {                                                   // 319
        return;                                                                                                    // 320
      }                                                                                                            // 321
                                                                                                                   //
      modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                              // 323
        if (replies[index].userId === userId) {                                                                    // 324
          replies[index].content = newContent;                                                                     // 325
          replies[index].likes = [];                                                                               // 326
          replies[index].starRatings = [];                                                                         // 327
          replies[index].ratingScore = 0;                                                                          // 328
          replies[index].media = mediaService.getMediaFromContent(newContent);                                     // 329
          reply = replies[index];                                                                                  // 330
        }                                                                                                          // 331
      });                                                                                                          // 332
                                                                                                                   //
      var findSelector = { _id: documentId };                                                                      // 334
                                                                                                                   //
      CommentsCollection.update(findSelector, { $set: { replies: doc.replies } }, noOptOptions);                   // 336
      triggerEvent('reply', 'edit', Object.assign({}, findSelector, reply, {                                       // 337
        ratedUserId: userId,                                                                                       // 338
        rootUserId: doc.userId                                                                                     // 339
      }));                                                                                                         // 337
    }                                                                                                              // 341
                                                                                                                   //
    return commentsReplyEdit;                                                                                      // 305
  }(),                                                                                                             // 305
  'comments/reply/like': function () {                                                                             // 342
    function commentsReplyLike(documentId, docScope, anonUserData) {                                               // 342
      check(documentId, String);                                                                                   // 343
      check(docScope, Object);                                                                                     // 344
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                        // 345
                                                                                                                   //
      var doc = CommentsCollection.findOne({ _id: documentId }),                                                   // 347
          userId = this.userId || anonUserData._id;                                                                // 347
                                                                                                                   //
      if (!userId || !allowReplies(documentId) || !['likes', 'likes-and-dislikes'].includes(Comments.config().rating)) {
        return false;                                                                                              // 353
      }                                                                                                            // 354
                                                                                                                   //
      var reply = {};                                                                                              // 356
                                                                                                                   //
      modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                              // 358
        if (replies[index].likes.indexOf(userId) > -1) {                                                           // 359
          replies[index].likes.splice(replies[index].likes.indexOf(userId), 1);                                    // 360
        } else {                                                                                                   // 361
          replies[index].likes.push(userId);                                                                       // 362
        }                                                                                                          // 363
                                                                                                                   //
        reply = replies[index];                                                                                    // 365
        replies[index].ratingScore = getRatingScore(replies[index]);                                               // 366
      });                                                                                                          // 367
                                                                                                                   //
      var findSelector = { _id: documentId };                                                                      // 369
                                                                                                                   //
      CommentsCollection.update(findSelector, { $set: { replies: doc.replies } }, noOptOptions);                   // 371
      triggerEvent('reply', 'like', Object.assign({}, reply, findSelector, {                                       // 372
        ratedUserId: userId,                                                                                       // 373
        rootUserId: doc.userId                                                                                     // 374
      }));                                                                                                         // 372
    }                                                                                                              // 376
                                                                                                                   //
    return commentsReplyLike;                                                                                      // 342
  }(),                                                                                                             // 342
  'comments/reply/dislike': function () {                                                                          // 377
    function commentsReplyDislike(documentId, docScope, anonUserData) {                                            // 377
      check(documentId, String);                                                                                   // 378
      check(docScope, Object);                                                                                     // 379
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                        // 380
                                                                                                                   //
      var doc = CommentsCollection.findOne({ _id: documentId }),                                                   // 382
          userId = this.userId || anonUserData._id;                                                                // 382
                                                                                                                   //
      if (!userId || !allowReplies(documentId) || !['likes', 'likes-and-dislikes'].includes(Comments.config().rating)) {
        return false;                                                                                              // 388
      }                                                                                                            // 389
                                                                                                                   //
      var reply = {};                                                                                              // 391
                                                                                                                   //
      modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                              // 393
        if (!replies[index].dislikes) {                                                                            // 394
          replies[index].dislikes = [];                                                                            // 395
        }                                                                                                          // 396
                                                                                                                   //
        if (replies[index].dislikes.indexOf(userId) > -1) {                                                        // 398
          replies[index].dislikes.splice(replies[index].dislikes.indexOf(userId), 1);                              // 399
        } else {                                                                                                   // 400
          replies[index].dislikes.push(userId);                                                                    // 401
        }                                                                                                          // 402
                                                                                                                   //
        reply = replies[index];                                                                                    // 404
        replies[index].ratingScore = getRatingScore(replies[index]);                                               // 405
      });                                                                                                          // 406
                                                                                                                   //
      var findSelector = { _id: documentId };                                                                      // 408
                                                                                                                   //
      CommentsCollection.update(findSelector, { $set: { replies: doc.replies } }, noOptOptions);                   // 410
      triggerEvent('reply', 'like', Object.assign({}, reply, findSelector, {                                       // 411
        ratedUserId: userId,                                                                                       // 412
        rootUserId: doc.userId                                                                                     // 413
      }));                                                                                                         // 411
    }                                                                                                              // 415
                                                                                                                   //
    return commentsReplyDislike;                                                                                   // 377
  }(),                                                                                                             // 377
  'comments/reply/star': function () {                                                                             // 416
    function commentsReplyStar(documentId, docScope, starsCount, anonUserData) {                                   // 416
      check(documentId, String);                                                                                   // 417
      check(docScope, Object);                                                                                     // 418
      check(starsCount, Number);                                                                                   // 419
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                        // 420
                                                                                                                   //
      var doc = CommentsCollection.findOne({ _id: documentId }),                                                   // 422
          userId = this.userId || anonUserData._id;                                                                // 422
                                                                                                                   //
      if (!userId || !allowReplies(documentId) || Comments.config().rating !== 'stars') {                          // 425
        return false;                                                                                              // 426
      }                                                                                                            // 427
                                                                                                                   //
      var reply = {};                                                                                              // 429
                                                                                                                   //
      modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                              // 431
        var starRatings = replies[index].starRatings;                                                              // 432
                                                                                                                   //
        if (!starRatings) {                                                                                        // 434
          starRatings = [];                                                                                        // 435
        }                                                                                                          // 436
                                                                                                                   //
        var ratings = starRatings;                                                                                 // 438
                                                                                                                   //
        if (_.find(starRatings, function (rating) {                                                                // 440
          return rating.userId === userId;                                                                         // 440
        })) {                                                                                                      // 440
          ratings = _.filter(starRatings, function (rating) {                                                      // 441
            return rating.userId !== userId;                                                                       // 441
          });                                                                                                      // 441
        }                                                                                                          // 442
                                                                                                                   //
        ratings.push({ userId: userId, rating: starsCount });                                                      // 444
        replies[index].starRatings = ratings;                                                                      // 445
        replies[index].ratingScore = getRatingScore(replies[index]);                                               // 446
        reply = replies[index];                                                                                    // 447
      });                                                                                                          // 448
                                                                                                                   //
      var findSelector = { _id: documentId };                                                                      // 450
                                                                                                                   //
      CommentsCollection.update(findSelector, { $set: { replies: doc.replies } }, noOptOptions);                   // 452
      triggerEvent('reply', 'star', Object.assign({}, reply, findSelector, {                                       // 453
        ratedUserId: userId,                                                                                       // 454
        rating: starsCount,                                                                                        // 455
        rootUserId: doc.userId                                                                                     // 456
      }));                                                                                                         // 453
    }                                                                                                              // 458
                                                                                                                   //
    return commentsReplyStar;                                                                                      // 416
  }(),                                                                                                             // 416
  'comments/reply/remove': function () {                                                                           // 459
    function commentsReplyRemove(documentId, docScope, anonUserData) {                                             // 459
      check(documentId, String);                                                                                   // 460
      check(docScope, Object);                                                                                     // 461
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                        // 462
                                                                                                                   //
      var doc = CommentsCollection.findOne({ _id: documentId }),                                                   // 464
          userId = this.userId || anonUserData._id;                                                                // 464
                                                                                                                   //
      var reply = {};                                                                                              // 467
                                                                                                                   //
      if (!userId || !allowReplies(documentId)) {                                                                  // 469
        return;                                                                                                    // 470
      }                                                                                                            // 471
                                                                                                                   //
      modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                              // 473
        if (replies[index].userId === userId) {                                                                    // 474
          reply = replies[index];                                                                                  // 475
          replies.splice(index, 1);                                                                                // 476
        }                                                                                                          // 477
      });                                                                                                          // 478
                                                                                                                   //
      var findSelector = { _id: documentId };                                                                      // 480
                                                                                                                   //
      CommentsCollection.update(findSelector, { $set: { replies: doc.replies } }, noOptOptions);                   // 482
      triggerEvent('reply', 'remove', Object.assign({}, reply, findSelector, {                                     // 483
        rootUserId: doc.userId                                                                                     // 484
      }));                                                                                                         // 483
    }                                                                                                              // 486
                                                                                                                   //
    return commentsReplyRemove;                                                                                    // 459
  }(),                                                                                                             // 459
  'comments/count': function () {                                                                                  // 487
    function commentsCount(referenceId) {                                                                          // 487
      check(referenceId, String);                                                                                  // 488
      return CommentsCollection.find({ referenceId: referenceId }).count();                                        // 489
    }                                                                                                              // 490
                                                                                                                   //
    return commentsCount;                                                                                          // 487
  }()                                                                                                              // 487
});                                                                                                                // 104
                                                                                                                   //
CommentsCollection.methods = {                                                                                     // 493
  add: function () {                                                                                               // 494
    function add(referenceId, content) {                                                                           // 494
      return callWithAnonUserData('comments/add', referenceId, content);                                           // 494
    }                                                                                                              // 494
                                                                                                                   //
    return add;                                                                                                    // 494
  }(),                                                                                                             // 494
  reply: function () {                                                                                             // 495
    function reply(documentId, docScope, content) {                                                                // 495
      return callWithAnonUserData('comments/reply/add', documentId, docScope, content);                            // 495
    }                                                                                                              // 495
                                                                                                                   //
    return reply;                                                                                                  // 495
  }(),                                                                                                             // 495
  like: function () {                                                                                              // 496
    function like(documentId) {                                                                                    // 496
      return callWithAnonUserData('comments/like', documentId);                                                    // 496
    }                                                                                                              // 496
                                                                                                                   //
    return like;                                                                                                   // 496
  }(),                                                                                                             // 496
  likeReply: function () {                                                                                         // 497
    function likeReply(documentId, docScope) {                                                                     // 497
      return callWithAnonUserData('comments/reply/like', documentId, docScope);                                    // 497
    }                                                                                                              // 497
                                                                                                                   //
    return likeReply;                                                                                              // 497
  }(),                                                                                                             // 497
  dislike: function () {                                                                                           // 498
    function dislike(documentId) {                                                                                 // 498
      return callWithAnonUserData('comments/dislike', documentId);                                                 // 498
    }                                                                                                              // 498
                                                                                                                   //
    return dislike;                                                                                                // 498
  }(),                                                                                                             // 498
  dislikeReply: function () {                                                                                      // 499
    function dislikeReply(documentId, docScope) {                                                                  // 499
      return callWithAnonUserData('comments/reply/dislike', documentId, docScope);                                 // 499
    }                                                                                                              // 499
                                                                                                                   //
    return dislikeReply;                                                                                           // 499
  }(),                                                                                                             // 499
  star: function () {                                                                                              // 500
    function star(documentId, starsCount) {                                                                        // 500
      return callWithAnonUserData('comments/star', documentId, starsCount);                                        // 500
    }                                                                                                              // 500
                                                                                                                   //
    return star;                                                                                                   // 500
  }(),                                                                                                             // 500
  starReply: function () {                                                                                         // 501
    function starReply(documentId, docScope, starsCount) {                                                         // 501
      return callWithAnonUserData('comments/reply/star', documentId, docScope, starsCount);                        // 501
    }                                                                                                              // 501
                                                                                                                   //
    return starReply;                                                                                              // 501
  }(),                                                                                                             // 501
  edit: function () {                                                                                              // 502
    function edit(documentId, newContent) {                                                                        // 502
      return callWithAnonUserData('comments/edit', documentId, newContent);                                        // 502
    }                                                                                                              // 502
                                                                                                                   //
    return edit;                                                                                                   // 502
  }(),                                                                                                             // 502
  editReply: function () {                                                                                         // 503
    function editReply(documentId, docScope, content) {                                                            // 503
      return callWithAnonUserData('comments/reply/edit', documentId, docScope, content);                           // 503
    }                                                                                                              // 503
                                                                                                                   //
    return editReply;                                                                                              // 503
  }(),                                                                                                             // 503
  remove: function () {                                                                                            // 504
    function remove(documentId) {                                                                                  // 504
      return callWithAnonUserData('comments/remove', documentId);                                                  // 504
    }                                                                                                              // 504
                                                                                                                   //
    return remove;                                                                                                 // 504
  }(),                                                                                                             // 504
  removeReply: function () {                                                                                       // 505
    function removeReply(documentId, docScope) {                                                                   // 505
      return callWithAnonUserData('comments/reply/remove', documentId, docScope);                                  // 505
    }                                                                                                              // 505
                                                                                                                   //
    return removeReply;                                                                                            // 505
  }()                                                                                                              // 505
};                                                                                                                 // 493
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"services":{"media-analyzers":{"image.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/arkham_comments-ui/lib/services/media-analyzers/image.js                                               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var imageAnalyzer = {                                                                                              // 1
  name: 'image',                                                                                                   // 2
  /**                                                                                                              // 3
   * @param {String} content                                                                                       //
   *                                                                                                               //
   * @return {String}                                                                                              //
   */                                                                                                              //
  getMediaFromContent: function () {                                                                               // 8
    function getMediaFromContent(content) {                                                                        // 1
      if (content) {                                                                                               // 9
        var urls = content.match(/(\S+\.[^/\s]+(\/\S+|\/|))(.jpg|.png|.gif)/g);                                    // 10
                                                                                                                   //
        if (urls && urls[0]) {                                                                                     // 12
          return urls[0];                                                                                          // 13
        }                                                                                                          // 14
      }                                                                                                            // 15
                                                                                                                   //
      return '';                                                                                                   // 17
    }                                                                                                              // 18
                                                                                                                   //
    return getMediaFromContent;                                                                                    // 1
  }(),                                                                                                             // 1
                                                                                                                   //
  /**                                                                                                              // 19
   * @param {String} mediaContent                                                                                  //
   *                                                                                                               //
   * @return {String}                                                                                              //
   */                                                                                                              //
  getMarkup: function () {                                                                                         // 24
    function getMarkup(mediaContent) {                                                                             // 24
      return '<img src="' + mediaContent + '" />';                                                                 // 24
    }                                                                                                              // 24
                                                                                                                   //
    return getMarkup;                                                                                              // 24
  }()                                                                                                              // 24
};                                                                                                                 // 1
                                                                                                                   //
module.export("default",exports.default=(imageAnalyzer));                                                          // 27
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"youtube.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/arkham_comments-ui/lib/services/media-analyzers/youtube.js                                             //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var youtubeAnalyzer = {                                                                                            // 1
  name: 'youtube',                                                                                                 // 2
  /**                                                                                                              // 3
   * @see http://stackoverflow.com/questions/19377262/regex-for-youtube-url                                        //
   *                                                                                                               //
   * @param {String} content                                                                                       //
   *                                                                                                               //
   * @return {String}                                                                                              //
   */                                                                                                              //
  getMediaFromContent: function () {                                                                               // 10
    function getMediaFromContent(content) {                                                                        // 1
      var parts = /(https?\:\/\/)?(www\.youtube\.com|youtu\.?be)\/([\w\=\?]+)/gm.exec(content);                    // 11
      var mediaContent = '';                                                                                       // 12
                                                                                                                   //
      if (parts && parts[3]) {                                                                                     // 14
        var id = parts[3];                                                                                         // 15
                                                                                                                   //
        if (id.indexOf('v=') > -1) {                                                                               // 17
          var subParts = /v=([\w]+)+/g.exec(id);                                                                   // 18
                                                                                                                   //
          if (subParts && subParts[1]) {                                                                           // 20
            id = subParts[1];                                                                                      // 21
          }                                                                                                        // 22
        }                                                                                                          // 23
                                                                                                                   //
        mediaContent = 'http://www.youtube.com/embed/' + id;                                                       // 25
      }                                                                                                            // 26
                                                                                                                   //
      return mediaContent;                                                                                         // 28
    }                                                                                                              // 29
                                                                                                                   //
    return getMediaFromContent;                                                                                    // 1
  }(),                                                                                                             // 1
                                                                                                                   //
  /**                                                                                                              // 30
   * @param {String} mediaContent                                                                                  //
   *                                                                                                               //
   * @return {String}                                                                                              //
   */                                                                                                              //
  getMarkup: function () {                                                                                         // 35
    function getMarkup(mediaContent) {                                                                             // 35
      return '<iframe src="' + mediaContent + '" type="text/html" frameborder="0"></iframe>';                      // 35
    }                                                                                                              // 35
                                                                                                                   //
    return getMarkup;                                                                                              // 35
  }()                                                                                                              // 35
};                                                                                                                 // 1
                                                                                                                   //
module.export("default",exports.default=(youtubeAnalyzer));                                                        // 38
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"user.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/arkham_comments-ui/lib/services/user.js                                                                //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var userService = function () {                                                                                    // 1
  if (Meteor.isClient) {                                                                                           // 2
    Meteor.startup(function () {                                                                                   // 3
      userService.setUserData({                                                                                    // 4
        _id: localStorage.getItem('commentsui-anonUserId') || '',                                                  // 5
        salt: localStorage.getItem('commentsui-anonSalt') || ''                                                    // 6
      });                                                                                                          // 4
    });                                                                                                            // 8
  }                                                                                                                // 9
                                                                                                                   //
  return {                                                                                                         // 11
    /**                                                                                                            // 12
     * Return the user id with logic for anonymous users.                                                          //
     *                                                                                                             //
     * @returns {String}                                                                                           //
     */                                                                                                            //
    getUserId: function () {                                                                                       // 17
      function getUserId() {                                                                                       // 11
        var userId = Meteor.userId();                                                                              // 18
                                                                                                                   //
        if (!userId && userService.isAnonymous()) {                                                                // 20
          userId = (this.getUserData() || {})._id;                                                                 // 21
        }                                                                                                          // 22
                                                                                                                   //
        return userId;                                                                                             // 24
      }                                                                                                            // 25
                                                                                                                   //
      return getUserId;                                                                                            // 11
    }(),                                                                                                           // 11
                                                                                                                   //
                                                                                                                   //
    /**                                                                                                            // 27
     * Set reactive user data                                                                                      //
     *                                                                                                             //
     * @param {Object} userData                                                                                    //
     */                                                                                                            //
    setUserData: function () {                                                                                     // 32
      function setUserData(userData) {                                                                             // 11
        Comments.session.set('commentsui-anonData', userData);                                                     // 33
      }                                                                                                            // 34
                                                                                                                   //
      return setUserData;                                                                                          // 11
    }(),                                                                                                           // 11
                                                                                                                   //
                                                                                                                   //
    /**                                                                                                            // 36
     * Return user id and salt as an object                                                                        //
     *                                                                                                             //
     * @returns {Object}                                                                                           //
     */                                                                                                            //
    getUserData: function () {                                                                                     // 41
      function getUserData() {                                                                                     // 11
        return Comments.session.get('commentsui-anonData');                                                        // 42
      }                                                                                                            // 43
                                                                                                                   //
      return getUserData;                                                                                          // 11
    }(),                                                                                                           // 11
                                                                                                                   //
                                                                                                                   //
    /**                                                                                                            // 45
     * Return anonymous user data                                                                                  //
     *                                                                                                             //
     * @returns {Object}                                                                                           //
     */                                                                                                            //
    getAnonymousUserData: function () {                                                                            // 50
      function getAnonymousUserData(_id) {                                                                         // 50
        return AnonymousUserCollection.findOne({ _id: _id });                                                      // 50
      }                                                                                                            // 50
                                                                                                                   //
      return getAnonymousUserData;                                                                                 // 50
    }(),                                                                                                           // 50
                                                                                                                   //
    /**                                                                                                            // 52
     * Return true if current user has changed it's profile data.                                                  //
     */                                                                                                            //
    userHasChanged: function () {                                                                                  // 55
      function userHasChanged(data) {                                                                              // 11
        var userData = this.getAnonymousUserData(this.getUserData()._id);                                          // 56
                                                                                                                   //
        return data.username && data.email && userData && (userData.username !== data.username || userData.email !== data.email);
      }                                                                                                            // 63
                                                                                                                   //
      return userHasChanged;                                                                                       // 11
    }(),                                                                                                           // 11
                                                                                                                   //
                                                                                                                   //
    /**                                                                                                            // 65
     * Update anonymous user based on given data.                                                                  //
     *                                                                                                             //
     * @param {Object} data                                                                                        //
     * @param {Function} callback                                                                                  //
     */                                                                                                            //
    updateAnonymousUser: function () {                                                                             // 71
      function updateAnonymousUser(data, callback) {                                                               // 11
        var userData = userService.getUserData();                                                                  // 72
                                                                                                                   //
        // check if user still exists                                                                              // 74
        if (userData._id && userData.salt && !AnonymousUserCollection.findOne({ _id: userData._id })) {            // 75
          userData._id = null;                                                                                     // 76
          userData.salt = null;                                                                                    // 77
        }                                                                                                          // 78
                                                                                                                   //
        if (!userData._id || !userData.salt) {                                                                     // 80
          AnonymousUserCollection.methods.add(data, function (err, generatedData) {                                // 81
            if (err) throw new Error(err);                                                                         // 82
                                                                                                                   //
            localStorage.setItem('commentsui-anonUserId', generatedData._id);                                      // 85
            localStorage.setItem('commentsui-anonSalt', generatedData.salt);                                       // 86
            userService.setUserData(generatedData);                                                                // 87
            callback(data);                                                                                        // 88
          });                                                                                                      // 89
        } else if (this.userHasChanged(data)) {                                                                    // 90
          AnonymousUserCollection.methods.update(userData._id, userData.salt, data, function () {                  // 91
            return callback(data);                                                                                 // 91
          });                                                                                                      // 91
        } else {                                                                                                   // 92
          callback(data);                                                                                          // 93
        }                                                                                                          // 94
      }                                                                                                            // 95
                                                                                                                   //
      return updateAnonymousUser;                                                                                  // 11
    }(),                                                                                                           // 11
                                                                                                                   //
                                                                                                                   //
    /**                                                                                                            // 97
     * @param {String} referenceId                                                                                 //
     *                                                                                                             //
     * @returns {Boolean}                                                                                          //
     */                                                                                                            //
    allowAnonymous: function () {                                                                                  // 102
      function allowAnonymous() {                                                                                  // 102
        var referenceId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;                // 102
                                                                                                                   //
        var config = Comments.config();                                                                            // 103
        return config.allowAnonymous ? config.allowAnonymous(referenceId) : config.anonymous;                      // 104
      }                                                                                                            // 105
                                                                                                                   //
      return allowAnonymous;                                                                                       // 102
    }(),                                                                                                           // 102
                                                                                                                   //
    /**                                                                                                            // 107
     * Return true if anonymous form fields should be displayed                                                    //
     *                                                                                                             //
     * @returns {Boolean}                                                                                          //
     */                                                                                                            //
    isAnonymous: function () {                                                                                     // 112
      function isAnonymous() {                                                                                     // 11
        return this.allowAnonymous() && !Meteor.userId();                                                          // 113
      }                                                                                                            // 114
                                                                                                                   //
      return isAnonymous;                                                                                          // 11
    }(),                                                                                                           // 11
                                                                                                                   //
                                                                                                                   //
    /**                                                                                                            // 116
     * Return user information of the provided userId                                                              //
     *                                                                                                             //
     * @returns {Object}                                                                                           //
     */                                                                                                            //
    getUserById: function () {                                                                                     // 121
      function getUserById(userId) {                                                                               // 11
        var user = Meteor.users.findOne(userId),                                                                   // 122
            anonymousUser = AnonymousUserCollection.findOne({ _id: userId }),                                      // 122
            generateUsername = Comments.config().generateUsername;                                                 // 122
                                                                                                                   //
        if (user) {                                                                                                // 126
          var displayName = void 0;                                                                                // 127
                                                                                                                   //
          if (generateUsername) {                                                                                  // 129
            displayName = generateUsername(user);                                                                  // 130
          } else {                                                                                                 // 131
            // oauth facebook users (maybe others)                                                                 // 132
            if (user.profile) {                                                                                    // 133
              displayName = user.profile.name;                                                                     // 134
            }                                                                                                      // 135
                                                                                                                   //
            if (user.emails && user.emails[0]) {                                                                   // 137
              displayName = user.emails[0].address;                                                                // 138
            }                                                                                                      // 139
                                                                                                                   //
            if (user.username) {                                                                                   // 141
              displayName = user.username;                                                                         // 142
            }                                                                                                      // 143
          }                                                                                                        // 144
                                                                                                                   //
          return { displayName: displayName };                                                                     // 146
        } else if (anonymousUser) {                                                                                // 147
          return { displayName: anonymousUser.username };                                                          // 148
        }                                                                                                          // 149
      }                                                                                                            // 150
                                                                                                                   //
      return getUserById;                                                                                          // 11
    }(),                                                                                                           // 11
                                                                                                                   //
                                                                                                                   //
    /**                                                                                                            // 152
     * Throw an error if provided anon user data is invalid.                                                       //
     *                                                                                                             //
     * @params {Object} anonUserData                                                                               //
     * @params {String} referenceId                                                                                //
     */                                                                                                            //
    verifyAnonUserData: function () {                                                                              // 158
      function verifyAnonUserData(anonUserData, referenceId) {                                                     // 11
        if (anonUserData._id) {                                                                                    // 159
          check(anonUserData, {                                                                                    // 160
            _id: String,                                                                                           // 161
            salt: String                                                                                           // 162
          });                                                                                                      // 160
                                                                                                                   //
          if (!this.allowAnonymous(referenceId)) {                                                                 // 165
            throw new Error('Anonymous not allowed');                                                              // 166
          }                                                                                                        // 167
                                                                                                                   //
          if (Meteor.isServer && !AnonymousUserCollection.findOne(anonUserData)) {                                 // 169
            throw new Error('Invalid anon user data provided');                                                    // 170
          }                                                                                                        // 171
        } else {                                                                                                   // 172
          check(anonUserData, {});                                                                                 // 173
        }                                                                                                          // 174
      }                                                                                                            // 175
                                                                                                                   //
      return verifyAnonUserData;                                                                                   // 11
    }()                                                                                                            // 11
  };                                                                                                               // 11
}();                                                                                                               // 177
                                                                                                                   //
module.export("default",exports.default=(userService));                                                            // 179
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"time-tick.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/arkham_comments-ui/lib/services/time-tick.js                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var timeTickService = function () {                                                                                // 1
  var timeTick = new Tracker.Dependency();                                                                         // 2
                                                                                                                   //
  // Reactive moment changes                                                                                       // 4
  Meteor.setInterval(function () {                                                                                 // 5
    return timeTick.changed();                                                                                     // 5
  }, 1000);                                                                                                        // 5
                                                                                                                   //
  moment.locale('en');                                                                                             // 7
                                                                                                                   //
  return {                                                                                                         // 9
    fromNowReactive: function () {                                                                                 // 10
      function fromNowReactive(mmt) {                                                                              // 9
        timeTick.depend();                                                                                         // 11
        return mmt.fromNow();                                                                                      // 12
      }                                                                                                            // 13
                                                                                                                   //
      return fromNowReactive;                                                                                      // 9
    }()                                                                                                            // 9
  };                                                                                                               // 9
}();                                                                                                               // 15
                                                                                                                   //
module.export("default",exports.default=(timeTickService));                                                        // 17
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"media.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/arkham_comments-ui/lib/services/media.js                                                               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var mediaService = function () {                                                                                   // 1
  return {                                                                                                         // 2
    getMediaFromContent: function () {                                                                             // 3
      function getMediaFromContent(content) {                                                                      // 2
        var analyzers = Comments.config().mediaAnalyzers;                                                          // 4
        var media = {};                                                                                            // 5
                                                                                                                   //
        if (analyzers && _.isArray(analyzers)) {                                                                   // 7
          _.forEach(analyzers, function (analyzer) {                                                               // 8
            var mediaContent = analyzer.getMediaFromContent(content);                                              // 9
                                                                                                                   //
            if (mediaContent && !media.content) {                                                                  // 11
              media = {                                                                                            // 12
                type: analyzer.name,                                                                               // 13
                content: mediaContent                                                                              // 14
              };                                                                                                   // 12
            }                                                                                                      // 16
          });                                                                                                      // 17
        }                                                                                                          // 18
                                                                                                                   //
        return media;                                                                                              // 20
      }                                                                                                            // 21
                                                                                                                   //
      return getMediaFromContent;                                                                                  // 2
    }(),                                                                                                           // 2
    getMarkup: function () {                                                                                       // 22
      function getMarkup(media) {                                                                                  // 2
        var analyzers = Comments.config().mediaAnalyzers;                                                          // 23
                                                                                                                   //
        var filteredAnalyzers = _.filter(analyzers, function (filter) {                                            // 25
          return filter.name === media.type;                                                                       // 26
        });                                                                                                        // 27
                                                                                                                   //
        if (filteredAnalyzers && filteredAnalyzers.length > 0) {                                                   // 29
          return filteredAnalyzers[0].getMarkup(media.content);                                                    // 30
        }                                                                                                          // 31
      }                                                                                                            // 32
                                                                                                                   //
      return getMarkup;                                                                                            // 2
    }()                                                                                                            // 2
  };                                                                                                               // 2
}();                                                                                                               // 34
                                                                                                                   //
module.export("default",exports.default=(mediaService));                                                           // 36
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"hashing.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/arkham_comments-ui/lib/services/hashing.js                                                             //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var hashingService = {                                                                                             // 1
  /**                                                                                                              // 2
   * Hash the given data with a random secret.                                                                     //
   *                                                                                                               //
   * @param {Object} data                                                                                          //
   *                                                                                                               //
   * @returns {String}                                                                                             //
   */                                                                                                              //
  hash: function () {                                                                                              // 9
    function hash(data) {                                                                                          // 1
      return this.getHashFromData(data) + '+' + Random.secret(50);                                                 // 10
    }                                                                                                              // 11
                                                                                                                   //
    return hash;                                                                                                   // 1
  }(),                                                                                                             // 1
                                                                                                                   //
  /**                                                                                                              // 12
   * Return a hash from the given data.                                                                            //
   *                                                                                                               //
   * @param {Object} data                                                                                          //
   *                                                                                                               //
   * @returns {String}                                                                                             //
   */                                                                                                              //
  getHashFromData: function () {                                                                                   // 19
    function getHashFromData(data) {                                                                               // 19
      var hashedSalt = '';                                                                                         // 20
      var anonSalt = Comments.config().anonymousSalt;                                                              // 21
                                                                                                                   //
      _.times(20, function () {                                                                                    // 23
        hashedSalt += Random.choice(anonSalt) + Random.choice(data.username) + Random.choice(data.email);          // 24
      });                                                                                                          // 25
                                                                                                                   //
      return hashedSalt;                                                                                           // 27
    }                                                                                                              // 28
                                                                                                                   //
    return getHashFromData;                                                                                        // 19
  }()                                                                                                              // 19
};                                                                                                                 // 1
                                                                                                                   //
module.export("default",exports.default=(hashingService));                                                         // 31
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comment.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/arkham_comments-ui/lib/services/comment.js                                                             //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export("default",exports.default=({                                                                         // 1
  denyReply: function () {                                                                                         // 2
    function denyReply(scope) {                                                                                    // 2
      return scope.position && scope.position.length >= 4;                                                         // 2
    }                                                                                                              // 2
                                                                                                                   //
    return denyReply;                                                                                              // 2
  }()                                                                                                              // 2
}));                                                                                                               // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"api.js":["./services/media","./services/media-analyzers/image","./services/media-analyzers/youtube","./services/user",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/arkham_comments-ui/lib/api.js                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var mediaService;module.import('./services/media',{"default":function(v){mediaService=v}});var imageAnalyzer;module.import('./services/media-analyzers/image',{"default":function(v){imageAnalyzer=v}});var youtubeAnalyzer;module.import('./services/media-analyzers/youtube',{"default":function(v){youtubeAnalyzer=v}});var userService;module.import('./services/user',{"default":function(v){userService=v}});
                                                                                                                   // 2
                                                                                                                   // 3
                                                                                                                   // 4
                                                                                                                   //
var _CommentsCollection$m = CommentsCollection.methods;                                                            //
var add = _CommentsCollection$m.add;                                                                               //
var reply = _CommentsCollection$m.reply;                                                                           //
var remove = _CommentsCollection$m.remove;                                                                         //
var removeReply = _CommentsCollection$m.removeReply;                                                               //
var edit = _CommentsCollection$m.edit;                                                                             //
var editReply = _CommentsCollection$m.editReply;                                                                   //
var like = _CommentsCollection$m.like;                                                                             //
var likeReply = _CommentsCollection$m.likeReply;                                                                   //
var dislike = _CommentsCollection$m.dislike;                                                                       //
var dislikeReply = _CommentsCollection$m.dislikeReply;                                                             //
var star = _CommentsCollection$m.star;                                                                             //
var starReply = _CommentsCollection$m.starReply;                                                                   //
                                                                                                                   //
                                                                                                                   //
Comments = {                                                                                                       // 21
  config: function () {                                                                                            // 22
    var config = {                                                                                                 // 23
      replies: true,                                                                                               // 24
      anonymous: false,                                                                                            // 25
      rating: 'likes',                                                                                             // 26
      anonymousSalt: 'changeMe',                                                                                   // 27
      mediaAnalyzers: [imageAnalyzer, youtubeAnalyzer],                                                            // 28
      publishUserFields: { profile: 1, emails: 1, username: 1 },                                                   // 29
      onEvent: function () {                                                                                       // 30
        function onEvent() {}                                                                                      // 30
                                                                                                                   //
        return onEvent;                                                                                            // 30
      }(),                                                                                                         // 30
      sortingOptions: [{ value: 'newest', label: 'Newest', sortSpecifier: { createdAt: -1 } }, { value: 'oldest', label: 'Oldest', sortSpecifier: { createdAt: 1 } }, { value: 'rating', label: 'Best rating', sortSpecifier: { ratingScore: -1 } }]
    };                                                                                                             // 23
                                                                                                                   //
    return function (newConfig) {                                                                                  // 38
      if (!newConfig) {                                                                                            // 39
        return config;                                                                                             // 40
      }                                                                                                            // 41
                                                                                                                   //
      config = _.extend(config, newConfig);                                                                        // 43
    };                                                                                                             // 44
  }(),                                                                                                             // 45
  get: function () {                                                                                               // 46
    function get(id) {                                                                                             // 46
      var sorting = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;                      // 46
                                                                                                                   //
      if (!sorting) {                                                                                              // 47
        sorting = { createdAt: -1 };                                                                               // 48
      }                                                                                                            // 49
                                                                                                                   //
      return CommentsCollection.find({ referenceId: id }, { sort: sorting });                                      // 51
    }                                                                                                              // 52
                                                                                                                   //
    return get;                                                                                                    // 46
  }(),                                                                                                             // 46
  getOne: function () {                                                                                            // 53
    function getOne(id) {                                                                                          // 53
      return CommentsCollection.findOne({ _id: id });                                                              // 53
    }                                                                                                              // 53
                                                                                                                   //
    return getOne;                                                                                                 // 53
  }(),                                                                                                             // 53
  getAll: function () {                                                                                            // 54
    function getAll() {                                                                                            // 54
      return CommentsCollection.find({}, { sort: { createdAt: -1 } });                                             // 54
    }                                                                                                              // 54
                                                                                                                   //
    return getAll;                                                                                                 // 54
  }(),                                                                                                             // 54
  add: add,                                                                                                        // 55
  reply: reply,                                                                                                    // 56
  remove: remove,                                                                                                  // 57
  removeReply: removeReply,                                                                                        // 58
  edit: edit,                                                                                                      // 59
  editReply: editReply,                                                                                            // 60
  like: like,                                                                                                      // 61
  likeReply: likeReply,                                                                                            // 62
  dislike: dislike,                                                                                                // 63
  dislikeReply: dislikeReply,                                                                                      // 64
  star: star,                                                                                                      // 65
  starReply: starReply,                                                                                            // 66
  session: new ReactiveDict('commentsUi'),                                                                         // 67
  changeSchema: function () {                                                                                      // 68
    function changeSchema(cb) {                                                                                    // 68
      var currentSchema = CommentsCollection.simpleSchema().schema(),                                              // 69
          callbackResult = cb(currentSchema),                                                                      // 69
          newSchema;                                                                                               // 69
                                                                                                                   //
      newSchema = callbackResult ? callbackResult : currentSchema;                                                 // 73
      !!newSchema && CommentsCollection.attachSchema(newSchema, { replace: true });                                // 74
    }                                                                                                              // 75
                                                                                                                   //
    return changeSchema;                                                                                           // 68
  }(),                                                                                                             // 68
  getCount: function () {                                                                                          // 76
    function getCount(id, cb) {                                                                                    // 76
      return Meteor.call('comments/count', id, cb);                                                                // 76
    }                                                                                                              // 76
                                                                                                                   //
    return getCount;                                                                                               // 76
  }(),                                                                                                             // 76
  analyzers: {                                                                                                     // 77
    image: imageAnalyzer,                                                                                          // 78
    youtube: youtubeAnalyzer                                                                                       // 79
  },                                                                                                               // 77
  getCollection: function () {                                                                                     // 81
    function getCollection() {                                                                                     // 81
      return CommentsCollection;                                                                                   // 81
    }                                                                                                              // 81
                                                                                                                   //
    return getCollection;                                                                                          // 81
  }(),                                                                                                             // 81
  getSortOption: function () {                                                                                     // 82
    function getSortOption(sorting) {                                                                              // 82
      var options = _.filter(Comments.config().sortingOptions, function (option) {                                 // 83
        return option.value === sorting;                                                                           // 83
      });                                                                                                          // 83
                                                                                                                   //
      if (0 === options.length) {                                                                                  // 85
        throw new Meteor.Error('Invalid sorting specified');                                                       // 86
      }                                                                                                            // 87
                                                                                                                   //
      return options[0].sortSpecifier;                                                                             // 89
    }                                                                                                              // 90
                                                                                                                   //
    return getSortOption;                                                                                          // 82
  }(),                                                                                                             // 82
  _collection: CommentsCollection,                                                                                 // 91
  _anonymousCollection: AnonymousUserCollection,                                                                   // 92
  _mediaService: mediaService                                                                                      // 93
};                                                                                                                 // 21
                                                                                                                   //
if (Meteor.isClient) {                                                                                             // 96
  Comments.ui = function () {                                                                                      // 97
    var _config = {                                                                                                // 98
      limit: 5,                                                                                                    // 99
      loadMoreCount: 10,                                                                                           // 100
      template: 'semantic-ui',                                                                                     // 101
      defaultAvatar: 'http://s3.amazonaws.com/37assets/svn/765-default-avatar.png',                                // 102
      markdown: false,                                                                                             // 103
      commentActions: []                                                                                           // 104
    };                                                                                                             // 98
                                                                                                                   //
    return {                                                                                                       // 107
      config: function () {                                                                                        // 108
        function config(newConfig) {                                                                               // 108
          if (!newConfig) {                                                                                        // 109
            return _config;                                                                                        // 110
          }                                                                                                        // 111
                                                                                                                   //
          _config = _.extend(_config, newConfig);                                                                  // 113
        }                                                                                                          // 114
                                                                                                                   //
        return config;                                                                                             // 108
      }(),                                                                                                         // 108
      setContent: function () {                                                                                    // 115
        function setContent(content) {                                                                             // 115
          return Comments.session.set('content', content);                                                         // 115
        }                                                                                                          // 115
                                                                                                                   //
        return setContent;                                                                                         // 115
      }(),                                                                                                         // 115
      callIfLoggedIn: function () {                                                                                // 116
        function callIfLoggedIn(action, cb) {                                                                      // 116
          if (!userService.getUserId()) {                                                                          // 117
            Comments.session.set('loginAction', action);                                                           // 118
          } else {                                                                                                 // 119
            return cb();                                                                                           // 120
          }                                                                                                        // 121
        }                                                                                                          // 122
                                                                                                                   //
        return callIfLoggedIn;                                                                                     // 116
      }(),                                                                                                         // 116
      getSorting: function () {                                                                                    // 123
        function getSorting(id) {                                                                                  // 123
          return Comments.session.get(id + '_sorting');                                                            // 124
        }                                                                                                          // 125
                                                                                                                   //
        return getSorting;                                                                                         // 123
      }()                                                                                                          // 123
    };                                                                                                             // 107
  }();                                                                                                             // 127
}                                                                                                                  // 128
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"server":{"publish.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/arkham_comments-ui/lib/server/publish.js                                                               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
/**                                                                                                                // 1
 * Return user ids by the given comment.                                                                           //
 *                                                                                                                 //
 * @param {Object} comment                                                                                         //
 *                                                                                                                 //
 * @returns {Array}                                                                                                //
 */                                                                                                                //
function getUserIdsByComment(comment) {                                                                            // 8
  var ids = [];                                                                                                    // 9
                                                                                                                   //
  ids.push(comment.userId);                                                                                        // 11
                                                                                                                   //
  if (comment.replies) {                                                                                           // 13
    _.each(comment.replies, function (reply) {                                                                     // 14
      ids = _.union(ids, getUserIdsByComment(reply));                                                              // 15
    });                                                                                                            // 16
  }                                                                                                                // 17
                                                                                                                   //
  return ids;                                                                                                      // 19
}                                                                                                                  // 20
                                                                                                                   //
Meteor.publish('comments/anonymous', function (data) {                                                             // 22
  check(data, {                                                                                                    // 23
    _id: String,                                                                                                   // 24
    salt: String                                                                                                   // 25
  });                                                                                                              // 23
                                                                                                                   //
  return AnonymousUserCollection.find(data, {                                                                      // 28
    fields: { salt: 0, anonIp: 0 }                                                                                 // 29
  });                                                                                                              // 28
});                                                                                                                // 31
                                                                                                                   //
var getCompositeCommentCursor = function getCompositeCommentCursor(rootCursor) {                                   // 33
  return {                                                                                                         // 33
    find: function () {                                                                                            // 34
      function find() {                                                                                            // 34
        return rootCursor;                                                                                         // 34
      }                                                                                                            // 34
                                                                                                                   //
      return find;                                                                                                 // 34
    }(),                                                                                                           // 34
    children: [{                                                                                                   // 35
      find: function () {                                                                                          // 37
        function find(comment) {                                                                                   // 36
          var userIds = getUserIdsByComment(comment);                                                              // 38
                                                                                                                   //
          return Meteor.users.find({ _id: { $in: userIds } }, { fields: Comments.config().publishUserFields });    // 40
        }                                                                                                          // 44
                                                                                                                   //
        return find;                                                                                               // 36
      }()                                                                                                          // 36
    }, {                                                                                                           // 36
      find: function () {                                                                                          // 47
        function find(comment) {                                                                                   // 46
          var userIds = getUserIdsByComment(comment);                                                              // 48
                                                                                                                   //
          return AnonymousUserCollection.find({ _id: { $in: userIds } }, {                                         // 50
            fields: { salt: 0, email: 0, anonIp: 0 }                                                               // 53
          });                                                                                                      // 52
        }                                                                                                          // 56
                                                                                                                   //
        return find;                                                                                               // 46
      }()                                                                                                          // 46
    }]                                                                                                             // 46
  };                                                                                                               // 33
};                                                                                                                 // 33
                                                                                                                   //
Meteor.publishComposite('comments/reference', function (id, sorting, limit) {                                      // 61
  var skip = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;                                // 61
                                                                                                                   //
  check(id, String);                                                                                               // 62
  check(sorting, String);                                                                                          // 63
  check(limit, Number);                                                                                            // 64
  check(skip, Number);                                                                                             // 65
                                                                                                                   //
  return getCompositeCommentCursor(Comments._collection.find({ referenceId: id }, { limit: limit, skip: skip, sort: Comments.getSortOption(sorting) }));
});                                                                                                                // 71
                                                                                                                   //
Meteor.publishComposite('comments/single', function (commentOrReplyId) {                                           // 73
  check(commentOrReplyId, String);                                                                                 // 74
                                                                                                                   //
  return getCompositeCommentCursor(Comments._collection.find({                                                     // 76
    $or: [{ _id: commentOrReplyId }, { 'replies.replyId': commentOrReplyId }, { 'replies.replies.replyId': commentOrReplyId }, { 'replies.replies.replies.replyId': commentOrReplyId }, { 'replies.replies.replies.replies.replyId': commentOrReplyId }]
  }));                                                                                                             // 77
});                                                                                                                // 87
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"node_modules":{"linkifyjs":{"string.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/string.js                                         //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.exports = require('./lib/linkify-string').default;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/arkham:comments-ui/lib/collections/anonymous-user.js");
require("./node_modules/meteor/arkham:comments-ui/lib/collections/comments.js");
require("./node_modules/meteor/arkham:comments-ui/lib/collections/methods/anonymous-user.js");
require("./node_modules/meteor/arkham:comments-ui/lib/collections/methods/comments.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/media-analyzers/image.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/media-analyzers/youtube.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/user.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/time-tick.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/media.js");
require("./node_modules/meteor/arkham:comments-ui/lib/api.js");
require("./node_modules/meteor/arkham:comments-ui/lib/server/publish.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/hashing.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['arkham:comments-ui'] = {}, {
  Comments: Comments
});

})();

//# sourceMappingURL=arkham_comments-ui.js.map
