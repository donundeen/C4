(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['flowkey:bootstrap-tour'] = {};

})();

//# sourceMappingURL=flowkey_bootstrap-tour.js.map
