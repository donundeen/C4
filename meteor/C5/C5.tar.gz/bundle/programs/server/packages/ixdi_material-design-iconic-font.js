(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ixdi:material-design-iconic-font'] = {};

})();

//# sourceMappingURL=ixdi_material-design-iconic-font.js.map
