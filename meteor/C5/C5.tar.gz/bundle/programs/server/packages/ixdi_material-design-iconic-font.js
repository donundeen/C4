(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ixdi:material-design-iconic-font'] = {};

})();
