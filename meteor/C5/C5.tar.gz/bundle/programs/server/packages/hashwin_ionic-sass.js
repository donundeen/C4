(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['hashwin:ionic-sass'] = {};

})();

//# sourceMappingURL=hashwin_ionic-sass.js.map
