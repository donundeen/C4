(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['flemay:less-autoprefixer'] = {};

})();
