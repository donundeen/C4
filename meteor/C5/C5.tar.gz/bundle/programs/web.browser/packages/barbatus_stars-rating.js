//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
// Source maps are supported by all recent versions of Chrome, Safari,  //
// and Firefox, and by Internet Explorer 11.                            //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;
var $ = Package.jquery.$;
var jQuery = Package.jquery.jQuery;
var Template = Package['templating-runtime'].Template;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var HTML = Package.htmljs.HTML;

var require = meteorInstall({"node_modules":{"meteor":{"barbatus:stars-rating":{"template.stars_rating.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/barbatus_stars-rating/template.stars_rating.js                                                 //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
                                                                                                           // 1
Template.__checkName("starsRating");                                                                       // 2
Template["starsRating"] = new Template("Template.starsRating", (function() {                               // 3
  var view = this;                                                                                         // 4
  return HTML.DIV({                                                                                        // 5
    id: function() {                                                                                       // 6
      return Spacebars.mustache(view.lookup("getId"));                                                     // 7
    },                                                                                                     // 8
    class: function() {                                                                                    // 9
      return [ "stars-rating ", Spacebars.mustache(view.lookup("class")), " ", Spacebars.mustache(view.lookup("css"), view.lookup("size")) ];
    },                                                                                                     // 11
    style: function() {                                                                                    // 12
      return Spacebars.mustache(view.lookup("font"), view.lookup("size"));                                 // 13
    },                                                                                                     // 14
    "data-rating": function() {                                                                            // 15
      return Spacebars.mustache(view.lookup("rating"));                                                    // 16
    },                                                                                                     // 17
    star: function() {                                                                                     // 18
      return Spacebars.mustache(view.lookup("star"));                                                      // 19
    }                                                                                                      // 20
  }, "\n    ", HTML.DIV({                                                                                  // 21
    class: "stars-inner-wrap"                                                                              // 22
  }, "\n      ", Blaze._TemplateWith(function() {                                                          // 23
    return {                                                                                               // 24
      mutable: Spacebars.call(view.lookup("getMutable")),                                                  // 25
      size: Spacebars.call(5)                                                                              // 26
    };                                                                                                     // 27
  }, function() {                                                                                          // 28
    return Spacebars.include(view.lookupTemplate("_stars"));                                               // 29
  }), "\n      ", Blaze._TemplateWith(function() {                                                         // 30
    return {                                                                                               // 31
      mutable: Spacebars.call(view.lookup("getMutable")),                                                  // 32
      size: Spacebars.call(4)                                                                              // 33
    };                                                                                                     // 34
  }, function() {                                                                                          // 35
    return Spacebars.include(view.lookupTemplate("_stars"));                                               // 36
  }), "\n      ", Blaze._TemplateWith(function() {                                                         // 37
    return {                                                                                               // 38
      mutable: Spacebars.call(view.lookup("getMutable")),                                                  // 39
      size: Spacebars.call(3)                                                                              // 40
    };                                                                                                     // 41
  }, function() {                                                                                          // 42
    return Spacebars.include(view.lookupTemplate("_stars"));                                               // 43
  }), "\n      ", Blaze._TemplateWith(function() {                                                         // 44
    return {                                                                                               // 45
      mutable: Spacebars.call(view.lookup("getMutable")),                                                  // 46
      size: Spacebars.call(2)                                                                              // 47
    };                                                                                                     // 48
  }, function() {                                                                                          // 49
    return Spacebars.include(view.lookupTemplate("_stars"));                                               // 50
  }), "\n      ", Blaze._TemplateWith(function() {                                                         // 51
    return {                                                                                               // 52
      mutable: Spacebars.call(view.lookup("getMutable")),                                                  // 53
      size: Spacebars.call(1)                                                                              // 54
    };                                                                                                     // 55
  }, function() {                                                                                          // 56
    return Spacebars.include(view.lookupTemplate("_stars"));                                               // 57
  }), "\n    "), "\n  ");                                                                                  // 58
}));                                                                                                       // 59
                                                                                                           // 60
Template.__checkName("_stars");                                                                            // 61
Template["_stars"] = new Template("Template._stars", (function() {                                         // 62
  var view = this;                                                                                         // 63
  return HTML.DIV({                                                                                        // 64
    class: "stars",                                                                                        // 65
    "data-stars": function() {                                                                             // 66
      return Spacebars.mustache(Spacebars.dot(view.lookup("stars"), "length"));                            // 67
    }                                                                                                      // 68
  }, "\n    ", Blaze.Each(function() {                                                                     // 69
    return Spacebars.call(view.lookup("stars"));                                                           // 70
  }, function() {                                                                                          // 71
    return HTML.SPAN({                                                                                     // 72
      class: function() {                                                                                  // 73
        return [ "star-", Spacebars.mustache(view.lookup(".")) ];                                          // 74
      }                                                                                                    // 75
    }, HTML.I({                                                                                            // 76
      class: "star-glyph"                                                                                  // 77
    }));                                                                                                   // 78
  }), "\n  ");                                                                                             // 79
}));                                                                                                       // 80
                                                                                                           // 81
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"stars_rating.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/barbatus_stars-rating/stars_rating.js                                                          //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
'use strict';                                                                                              // 1
                                                                                                           //
var rtCss = 'current-rating';                                                                              // 3
var prCss = 'percent';                                                                                     // 4
var hasUserCss = 'has-user-rating';                                                                        // 5
                                                                                                           //
function getStarsEl($parent, index) {                                                                      // 7
  return $parent.find('[data-stars="' + index + '"]');                                                     // 8
}                                                                                                          // 9
                                                                                                           //
function getPercentStarEl($parent, index) {                                                                // 11
  return getStarsEl($parent, index).find('.star-' + index);                                                // 12
}                                                                                                          // 13
                                                                                                           //
function getStarColor($el) {                                                                               // 15
  var span = $('<span>').addClass(rtCss).appendTo($el);                                                    // 16
  var starColor = span.css('color');                                                                       // 17
  span.remove();                                                                                           // 18
  return starColor;                                                                                        // 19
}                                                                                                          // 20
                                                                                                           //
function getStarGlyph($el) {                                                                               // 22
  var starGlyph = $el.attr('star');                                                                        // 23
                                                                                                           //
  if (!starGlyph) {                                                                                        // 25
    // For compatibility with older versions.                                                              // 26
    //                                                                                                     // 27
    // If now star attr is set, take the star symbol                                                       // 28
    // from the upper CSS class (via content property).                                                    // 29
    // This will work in most browsers except IE.                                                          // 30
    starGlyph = $el.css('content');                                                                        // 31
                                                                                                           //
    if (!starGlyph || starGlyph === 'none') {                                                              // 33
      starGlyph = '\\2605';                                                                                // 34
    } else {                                                                                               // 35
      // if it's IE replace glyph with the default symbol.                                                 // 36
      if (starGlyph === 'normal') {                                                                        // 37
        starGlyph = '\\2605';                                                                              // 38
      }                                                                                                    // 39
    }                                                                                                      // 40
  }                                                                                                        // 41
                                                                                                           //
  // Prepare glyph for styles.                                                                             // 43
  starGlyph = '"' + starGlyph.trim().replace(/[\',\"]/g, '') + '"';                                        // 44
                                                                                                           //
  return starGlyph;                                                                                        // 46
}                                                                                                          // 47
                                                                                                           //
function buildStyle(className, styles) {                                                                   // 49
  var styleStr = '';                                                                                       // 50
  for (var style in meteorBabelHelpers.sanitizeForInObject(styles)) {                                      // 51
    styleStr += style + ':' + styles[style] + ';';                                                         // 52
  }                                                                                                        // 53
  return '.' + className + ' {' + styleStr + '};';                                                         // 54
}                                                                                                          // 55
                                                                                                           //
function setRating($el, rating, isUser, starGlyph) {                                                       // 57
  var ceil = Math.ceil(rating);                                                                            // 58
  var floor = Math.floor(rating);                                                                          // 59
  var percent = rating - floor;                                                                            // 60
                                                                                                           //
  $el.find('.stars').removeClass(rtCss);                                                                   // 62
  $el.find('.stars').find('.percent').removeClass(prCss);                                                  // 63
                                                                                                           //
  $el.toggleClass(hasUserCss, isUser);                                                                     // 65
  for (var i = floor; i >= 0; i--) {                                                                       // 66
    getStarsEl($el, i).addClass(rtCss);                                                                    // 67
  }                                                                                                        // 68
                                                                                                           //
  if (percent) {                                                                                           // 70
    var $perStar = getPercentStarEl($el, ceil).addClass(prCss);                                            // 71
    var starColor = getStarColor($el);                                                                     // 72
    $perStar.find('style').remove();                                                                       // 73
    var style = '\n        <style>\n          #' + getOrSetTmplId() + ' ' + buildStyle('percent:before', {
      width: percent * 100 + '% !important',                                                               // 78
      color: starColor,                                                                                    // 79
      content: starGlyph                                                                                   // 80
    }) + '\n        </style>\n      ';                                                                     // 77
    $perStar.append(style);                                                                                // 85
  }                                                                                                        // 86
  $el.trigger('change');                                                                                   // 87
}                                                                                                          // 88
                                                                                                           //
function addjQuryApi($el) {                                                                                // 90
  $el.bind('reset', function () {                                                                          // 91
    $el.find('.stars').removeClass(rtCss);                                                                 // 92
    $el.find('.stars').find('.percent').removeClass(prCss);                                                // 93
  });                                                                                                      // 94
}                                                                                                          // 95
                                                                                                           //
function destroyApi() {                                                                                    // 97
  $el.unbind('reset');                                                                                     // 98
}                                                                                                          // 99
                                                                                                           //
function getOrSetTmplId(opt_id) {                                                                          // 101
  if (!Template.instance()._id) {                                                                          // 102
    Template.instance()._id = opt_id || _.uniqueId('stars_');                                              // 103
  }                                                                                                        // 104
  return Template.instance()._id;                                                                          // 105
}                                                                                                          // 106
                                                                                                           //
Template.starsRating.helpers({                                                                             // 108
  getId: function () {                                                                                     // 109
    function getId() {                                                                                     // 108
      return getOrSetTmplId(this.id);                                                                      // 110
    }                                                                                                      // 111
                                                                                                           //
    return getId;                                                                                          // 108
  }(),                                                                                                     // 108
  css: function () {                                                                                       // 112
    function css(size) {                                                                                   // 108
      if (_.isString(size)) {                                                                              // 113
        return 'stars-rating-' + (size || 'sm');                                                           // 114
      }                                                                                                    // 115
    }                                                                                                      // 116
                                                                                                           //
    return css;                                                                                            // 108
  }(),                                                                                                     // 108
  font: function () {                                                                                      // 117
    function font(size) {                                                                                  // 108
      if (_.isNumber(size)) {                                                                              // 118
        return 'font-size:' + size + 'px';                                                                 // 119
      }                                                                                                    // 120
    }                                                                                                      // 121
                                                                                                           //
    return font;                                                                                           // 108
  }()                                                                                                      // 108
});                                                                                                        // 108
                                                                                                           //
function onDataChange($el, rating, starGlyph) {                                                            // 124
  setRating($el, rating, false, starGlyph);                                                                // 125
}                                                                                                          // 126
                                                                                                           //
Template.starsRating.destroyed = function () {                                                             // 128
  if (this.firstNode) {                                                                                    // 129
    destroyApi($(this.firstNode));                                                                         // 130
  }                                                                                                        // 131
};                                                                                                         // 132
                                                                                                           //
Template.starsRating.rendered = function () {                                                              // 134
  var self = this;                                                                                         // 135
  var $el = $(self.firstNode);                                                                             // 136
                                                                                                           //
  var starGlyph = getStarGlyph($el);                                                                       // 138
                                                                                                           //
  addjQuryApi($el);                                                                                        // 140
                                                                                                           //
  // Adds all required styles to set new symbol for the internal                                           // 142
  // pseudo elements.                                                                                      // 143
  var style = '\n    <style>\n      #' + getOrSetTmplId() + ' ' + buildStyle('star-glyph:before', {        // 144
    content: starGlyph                                                                                     // 148
  }) + '\n    </style>\n  ';                                                                               // 147
  $el.append(style);                                                                                       // 153
                                                                                                           //
  this.autorun(function () {                                                                               // 155
    var userData = Template.currentData();                                                                 // 156
    if (userData) {                                                                                        // 157
      var rating = userData.rating;                                                                        // 158
      if (rating !== undefined) {                                                                          // 159
        onDataChange($el, rating, starGlyph);                                                              // 160
      }                                                                                                    // 161
    }                                                                                                      // 162
  });                                                                                                      // 163
};                                                                                                         // 164
                                                                                                           //
Template.starsRating.events({                                                                              // 166
  'mouseover .stars': function () {                                                                        // 167
    function mouseoverStars(event) {                                                                       // 167
      if (this.isMutable || this.mutable) {                                                                // 168
        var $this = $(event.currentTarget);                                                                // 169
        var rating = $this.data('stars');                                                                  // 170
                                                                                                           //
        for (var i = rating; i >= 0; i--) {                                                                // 172
          getStarsEl($this.parent(), i).addClass('active');                                                // 173
        }                                                                                                  // 174
                                                                                                           //
        for (var _i = rating + 1; _i <= 5; _i++) {                                                         // 176
          getStarsEl($this.parent(), _i).removeClass('active');                                            // 177
        }                                                                                                  // 178
      }                                                                                                    // 179
    }                                                                                                      // 180
                                                                                                           //
    return mouseoverStars;                                                                                 // 167
  }(),                                                                                                     // 167
  'mouseleave .stars-rating': function () {                                                                // 181
    function mouseleaveStarsRating(event) {                                                                // 181
      if (this.isMutable || this.mutable) {                                                                // 182
        var $this = $(event.currentTarget);                                                                // 183
        $this.find('.stars').removeClass('active');                                                        // 184
      }                                                                                                    // 185
    }                                                                                                      // 186
                                                                                                           //
    return mouseleaveStarsRating;                                                                          // 181
  }(),                                                                                                     // 181
  'click .stars': function () {                                                                            // 187
    function clickStars(event) {                                                                           // 187
      if (this.isMutable || this.mutable) {                                                                // 188
        var $this = $(event.currentTarget);                                                                // 189
        var userRating = $this.data('stars');                                                              // 190
        var _$el = $this.parent().parent();                                                                // 191
        _$el.data('userrating', userRating);                                                               // 192
                                                                                                           //
        var $starsWrap = $this.parent();                                                                   // 194
        setRating($starsWrap, userRating, true);                                                           // 195
                                                                                                           //
        $starsWrap.children().removeClass('active');                                                       // 197
      }                                                                                                    // 198
    }                                                                                                      // 199
                                                                                                           //
    return clickStars;                                                                                     // 187
  }()                                                                                                      // 187
});                                                                                                        // 166
                                                                                                           //
Template.starsRating.helpers({                                                                             // 202
  getMutable: function () {                                                                                // 203
    function getMutable(size) {                                                                            // 203
      return this.isMutable || this.mutable;                                                               // 204
    }                                                                                                      // 205
                                                                                                           //
    return getMutable;                                                                                     // 203
  }()                                                                                                      // 203
});                                                                                                        // 202
                                                                                                           //
Template._stars.helpers({                                                                                  // 208
  stars: function () {                                                                                     // 209
    function stars() {                                                                                     // 209
      return _.range(1, this.size + 1);                                                                    // 210
    }                                                                                                      // 211
                                                                                                           //
    return stars;                                                                                          // 209
  }()                                                                                                      // 209
});                                                                                                        // 208
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json",".html",".less"]});
require("./node_modules/meteor/barbatus:stars-rating/template.stars_rating.js");
require("./node_modules/meteor/barbatus:stars-rating/stars_rating.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['barbatus:stars-rating'] = {};

})();
