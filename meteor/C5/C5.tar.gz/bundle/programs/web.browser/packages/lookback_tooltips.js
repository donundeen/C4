//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
// Source maps are supported by all recent versions of Chrome, Safari,  //
// and Firefox, and by Internet Explorer 11.                            //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var $ = Package.jquery.$;
var jQuery = Package.jquery.jQuery;
var Template = Package['templating-runtime'].Template;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var __coffeescriptShare, Tooltips;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/lookback_tooltips/packages/lookback_tooltips.js                                         //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
(function () {                                                                                      // 1
                                                                                                    // 2
////////////////////////////////////////////////////////////////////////////////////////////////    // 3
//                                                                                            //    // 4
// packages/lookback:tooltips/template.tooltips.js                                            //    // 5
//                                                                                            //    // 6
////////////////////////////////////////////////////////////////////////////////////////////////    // 7
                                                                                              //    // 8
                                                                                              // 1  // 9
Template.__checkName("tooltips");                                                             // 2  // 10
Template["tooltips"] = new Template("Template.tooltips", (function() {                        // 3  // 11
  var view = this;                                                                            // 4  // 12
  return HTML.DIV({                                                                           // 5  // 13
    "class": function() {                                                                     // 6  // 14
      return [ "tooltip ", Spacebars.mustache(view.lookup("direction")), " ", Spacebars.mustache(view.lookup("display")) ];
    },                                                                                        // 8  // 16
    style: function() {                                                                       // 9  // 17
      return Spacebars.mustache(view.lookup("position"));                                     // 10
    }                                                                                         // 11
  }, "\n		", Blaze.If(function() {                                                            // 12
    return Spacebars.call(view.lookup("content"));                                            // 13
  }, function() {                                                                             // 14
    return [ "\n			", HTML.DIV({                                                              // 15
      "class": "inner"                                                                        // 16
    }, Blaze.View("lookup:content", function() {                                              // 17
      return Spacebars.makeRaw(Spacebars.mustache(view.lookup("content")));                   // 18
    })), "\n		" ];                                                                            // 19
  }), "\n	");                                                                                 // 20
}));                                                                                          // 21
                                                                                              // 22
Template.__checkName("tooltip");                                                              // 23
Template["tooltip"] = new Template("Template.tooltip", (function() {                          // 24
  var view = this;                                                                            // 25
  return HTML.SPAN({                                                                          // 26
    "data-tooltip-wrapper": ""                                                                // 27
  }, "\n		", Blaze._InOuterTemplateScope(view, function() {                                   // 28
    return Spacebars.include(function() {                                                     // 29
      return Spacebars.call(view.templateContentBlock);                                       // 30
    });                                                                                       // 31
  }), "\n	");                                                                                 // 32
}));                                                                                          // 33
                                                                                              // 34
////////////////////////////////////////////////////////////////////////////////////////////////    // 43
                                                                                                    // 44
}).call(this);                                                                                      // 45
                                                                                                    // 46
                                                                                                    // 47
                                                                                                    // 48
                                                                                                    // 49
                                                                                                    // 50
                                                                                                    // 51
(function () {                                                                                      // 52
                                                                                                    // 53
////////////////////////////////////////////////////////////////////////////////////////////////    // 54
//                                                                                            //    // 55
// packages/lookback:tooltips/tooltips.coffee.js                                              //    // 56
//                                                                                            //    // 57
////////////////////////////////////////////////////////////////////////////////////////////////    // 58
                                                                                              //    // 59
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var DIRECTION_MAP, Tooltip, center, dep, getTooltip, hideTooltip, horizontally, offset, positionTooltip, setPosition, setTooltip, showTooltip, toggleTooltip, vertically;          
                                                                                                    // 62
Tooltip = {                                                                                         // 63
  text: false,                                                                                      // 64
  css: {                                                                                            // 65
    top: 0,                                                                                         // 66
    left: 0                                                                                         // 67
  },                                                                                                // 68
  direction: 'tooltip--top'                                                                         // 69
};                                                                                                  // 70
                                                                                                    // 71
dep = new Tracker.Dependency();                                                                     // 72
                                                                                                    // 73
offset = [10, 10];                                                                                  // 74
                                                                                                    // 75
DIRECTION_MAP = {                                                                                   // 76
  'n': 'tooltip--top',                                                                              // 77
  's': 'tooltip--bottom',                                                                           // 78
  'e': 'tooltip--right',                                                                            // 79
  'w': 'tooltip--left'                                                                              // 80
};                                                                                                  // 81
                                                                                                    // 82
getTooltip = function() {                                                                           // 83
  dep.depend();                                                                                     // 84
  return Tooltip;                                                                                   // 85
};                                                                                                  // 86
                                                                                                    // 87
setTooltip = function(what, where) {                                                                // 88
  if (where) {                                                                                      // 89
    Tooltip.css = where;                                                                            // 90
  }                                                                                                 // 91
  Tooltip.text = what;                                                                              // 92
  return dep.changed();                                                                             // 93
};                                                                                                  // 94
                                                                                                    // 95
setPosition = function(position, direction) {                                                       // 96
  Tooltip.css = position;                                                                           // 97
  if (direction) {                                                                                  // 98
    Tooltip.direction = DIRECTION_MAP[direction];                                                   // 99
  }                                                                                                 // 100
  return dep.changed();                                                                             // 101
};                                                                                                  // 102
                                                                                                    // 103
hideTooltip = function() {                                                                          // 104
  return setTooltip(false);                                                                         // 105
};                                                                                                  // 106
                                                                                                    // 107
toggleTooltip = function() {                                                                        // 108
  if (getTooltip().text) {                                                                          // 109
    return hideTooltip();                                                                           // 110
  } else {                                                                                          // 111
    return showTooltip(null, $(this));                                                              // 112
  }                                                                                                 // 113
};                                                                                                  // 114
                                                                                                    // 115
positionTooltip = function($el) {                                                                   // 116
  var $tooltip, direction, hasOffsetLeft, hasOffsetTop, offLeft, offTop, position;                  // 117
  direction = $el.attr('data-tooltip-direction') || 'n';                                            // 118
  $tooltip = $(".tooltip");                                                                         // 119
  position = $el.offset();                                                                          // 120
  offLeft = $el.attr('data-tooltip-left');                                                          // 121
  offTop = $el.attr('data-tooltip-top');                                                            // 122
  if (_.isUndefined(offLeft)) {                                                                     // 123
    offLeft = 0;                                                                                    // 124
  } else {                                                                                          // 125
    hasOffsetLeft = true;                                                                           // 126
  }                                                                                                 // 127
  if (_.isUndefined(offTop)) {                                                                      // 128
    offTop = 0;                                                                                     // 129
  } else {                                                                                          // 130
    hasOffsetTop = true;                                                                            // 131
  }                                                                                                 // 132
  position.top = (function() {                                                                      // 133
    switch (direction) {                                                                            // 134
      case 'w':                                                                                     // 135
      case 'e':                                                                                     // 136
        return (center(vertically($tooltip, $el))) + offTop;                                        // 137
      case 'n':                                                                                     // 138
        return position.top - $tooltip.outerHeight() - (hasOffsetTop ? offTop : offset[1]);         // 139
      case 's':                                                                                     // 140
        return position.top + $el.outerHeight() + (hasOffsetTop ? offTop : offset[1]);              // 141
    }                                                                                               // 142
  })();                                                                                             // 143
  position.left = (function() {                                                                     // 144
    switch (direction) {                                                                            // 145
      case 'n':                                                                                     // 146
      case 's':                                                                                     // 147
        return (center(horizontally($tooltip, $el))) + offLeft;                                     // 148
      case 'w':                                                                                     // 149
        return position.left - $tooltip.outerWidth() - (hasOffsetLeft ? offLeft : offset[0]);       // 150
      case 'e':                                                                                     // 151
        return position.left + $el.outerWidth() + (hasOffsetLeft ? offLeft : offset[0]);            // 152
    }                                                                                               // 153
  })();                                                                                             // 154
  return setPosition(position, direction);                                                          // 155
};                                                                                                  // 156
                                                                                                    // 157
showTooltip = function(evt, $el) {                                                                  // 158
  var $target, content, mq, selector, viewport;                                                     // 159
  $el = $el || $(this);                                                                             // 160
  viewport = $el.attr('data-tooltip-disable');                                                      // 161
  if (viewport && _.isString(viewport)) {                                                           // 162
    mq = window.matchMedia(viewport);                                                               // 163
    if (mq.matches) {                                                                               // 164
      return false;                                                                                 // 165
    }                                                                                               // 166
  }                                                                                                 // 167
  content = (selector = $el.attr('data-tooltip-element')) ? ($target = $(selector), $target.length && $target.html()) : $el.attr('data-tooltip');
  setTooltip(content);                                                                              // 169
  setPosition({                                                                                     // 170
    top: 0,                                                                                         // 171
    left: 0                                                                                         // 172
  });                                                                                               // 173
  return Tracker.afterFlush(function() {                                                            // 174
    return positionTooltip($el);                                                                    // 175
  });                                                                                               // 176
};                                                                                                  // 177
                                                                                                    // 178
center = function(args) {                                                                           // 179
  var middle;                                                                                       // 180
  middle = args[0] + args[1] / 2;                                                                   // 181
  return middle - Math.round(args[2] / 2);                                                          // 182
};                                                                                                  // 183
                                                                                                    // 184
horizontally = function($el, $reference) {                                                          // 185
  return [$reference.offset().left, $reference.outerWidth(), $el.outerWidth()];                     // 186
};                                                                                                  // 187
                                                                                                    // 188
vertically = function($el, $reference) {                                                            // 189
  return [$reference.offset().top, $reference.outerHeight(), $el.outerHeight()];                    // 190
};                                                                                                  // 191
                                                                                                    // 192
Tooltips = {                                                                                        // 193
  disable: false,                                                                                   // 194
  set: setTooltip,                                                                                  // 195
  get: getTooltip,                                                                                  // 196
  hide: hideTooltip,                                                                                // 197
  setPosition: setPosition                                                                          // 198
};                                                                                                  // 199
                                                                                                    // 200
Template.tooltips.onCreated(function() {                                                            // 201
  var mq;                                                                                           // 202
  this.disabled = new ReactiveVar(Tooltips.disable);                                                // 203
  if (Tooltips.disable && _.isString(Tooltips.disable)) {                                           // 204
    mq = window.matchMedia(Tooltips.disable);                                                       // 205
    this.disabled.set(mq.matches);                                                                  // 206
    return mq.addListener((function(_this) {                                                        // 207
      return function(changed) {                                                                    // 208
        return _this.disabled.set(changed.matches);                                                 // 209
      };                                                                                            // 210
    })(this));                                                                                      // 211
  }                                                                                                 // 212
});                                                                                                 // 213
                                                                                                    // 214
Template.tooltips.helpers({                                                                         // 215
  display: function() {                                                                             // 216
    var tip;                                                                                        // 217
    tip = getTooltip();                                                                             // 218
    if (Template.instance().disabled.get() === true) {                                              // 219
      return 'hide';                                                                                // 220
    }                                                                                               // 221
    if (tip.text) {                                                                                 // 222
      return 'show';                                                                                // 223
    } else {                                                                                        // 224
      return 'hide';                                                                                // 225
    }                                                                                               // 226
  },                                                                                                // 227
  position: function() {                                                                            // 228
    var css;                                                                                        // 229
    css = getTooltip().css;                                                                         // 230
    return "position: absolute; top: " + css.top + "px; left: " + css.left + "px;";                 // 231
  },                                                                                                // 232
  content: function() {                                                                             // 233
    return getTooltip().text;                                                                       // 234
  },                                                                                                // 235
  direction: function() {                                                                           // 236
    return getTooltip().direction;                                                                  // 237
  }                                                                                                 // 238
});                                                                                                 // 239
                                                                                                    // 240
Template.tooltip.onRendered(function() {                                                            // 241
  return this.lastNode._uihooks = {                                                                 // 242
    insertElement: function(node, next) {                                                           // 243
      return next.parentNode.insertBefore(node, next);                                              // 244
    },                                                                                              // 245
    moveElement: function(next) {                                                                   // 246
      Tooltips.hide();                                                                              // 247
      return next.parentNode.insertBefore(node, next);                                              // 248
    },                                                                                              // 249
    removeElement: function(node) {                                                                 // 250
      Tooltips.hide();                                                                              // 251
      return node.parentNode.removeChild(node);                                                     // 252
    }                                                                                               // 253
  };                                                                                                // 254
});                                                                                                 // 255
                                                                                                    // 256
Meteor.startup(function() {                                                                         // 257
  $(document).on('mouseover', '[data-tooltip]:not([data-tooltip-trigger]), [data-tooltip-element]:not([data-tooltip-trigger]), [data-tooltip-trigger="hover"]', showTooltip);
  $(document).on('mouseout', '[data-tooltip]:not([data-tooltip-trigger]), [data-tooltip-element]:not([data-tooltip-trigger]), [data-tooltip-trigger="hover"]', hideTooltip);
  $(document).on('click', '[data-tooltip-trigger="click"]', toggleTooltip);                         // 260
  $(document).on('focus', '[data-tooltip-trigger="focus"]', showTooltip);                           // 261
  $(document).on('blur', '[data-tooltip-trigger="focus"]', hideTooltip);                            // 262
  $(document).on('tooltips:show', '[data-tooltip-trigger="manual"]', showTooltip);                  // 263
  $(document).on('tooltips:hide', '[data-tooltip-trigger="manual"]', hideTooltip);                  // 264
  return $(document).on('tooltips:toggle', '[data-tooltip-trigger="manual"]', toggleTooltip);       // 265
});                                                                                                 // 266
////////////////////////////////////////////////////////////////////////////////////////////////    // 267
                                                                                                    // 268
}).call(this);                                                                                      // 269
                                                                                                    // 270
//////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['lookback:tooltips'] = {}, {
  Tooltips: Tooltips
});

})();
