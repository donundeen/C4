//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
// Source maps are supported by all recent versions of Chrome, Safari,  //
// and Firefox, and by Internet Explorer 11.                            //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

(function(){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// packages/pagebakers_ionicons/packages/pagebakers_ionicons.js                //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
(function () {                                                                 // 1
                                                                               // 2
////////////////////////////////////////////////////////////////////////////   // 3
//                                                                        //   // 4
// packages/pagebakers:ionicons/ionicons.js                               //   // 5
//                                                                        //   // 6
////////////////////////////////////////////////////////////////////////////   // 7
                                                                          //   // 8
var head = document.getElementsByTagName('head')[0];                      // 1
var s = document.createElement('link');                                   // 2
                                                                          // 3
s.type = 'text/css';                                                      // 4
s.rel = 'stylesheet';                                                     // 5
s.href = '//code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css'; // 6
head.appendChild(s);                                                      // 7
////////////////////////////////////////////////////////////////////////////   // 16
                                                                               // 17
}).call(this);                                                                 // 18
                                                                               // 19
/////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['pagebakers:ionicons'] = {};

})();
