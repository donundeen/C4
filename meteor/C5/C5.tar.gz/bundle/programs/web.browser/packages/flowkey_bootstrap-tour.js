//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
// Source maps are supported by all recent versions of Chrome, Safari,  //
// and Firefox, and by Internet Explorer 11.                            //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var $ = Package.jquery.$;
var jQuery = Package.jquery.jQuery;
var Template = Package['templating-runtime'].Template;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var HTML = Package.htmljs.HTML;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/flowkey_bootstrap-tour/lib/bootstrap-tour-standalone.js                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/* ========================================================================                                            // 1
 * bootstrap-tour - v0.10.1                                                                                            // 2
 * http://bootstraptour.com                                                                                            // 3
 * ========================================================================                                            // 4
 * Copyright 2012-2013 Ulrich Sossou                                                                                   // 5
 *                                                                                                                     // 6
 * ========================================================================                                            // 7
 * Licensed under the Apache License, Version 2.0 (the "License");                                                     // 8
 * you may not use this file except in compliance with the License.                                                    // 9
 * You may obtain a copy of the License at                                                                             // 10
 *                                                                                                                     // 11
 *     http://www.apache.org/licenses/LICENSE-2.0                                                                      // 12
 *                                                                                                                     // 13
 * Unless required by applicable law or agreed to in writing, software                                                 // 14
 * distributed under the License is distributed on an "AS IS" BASIS,                                                   // 15
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.                                            // 16
 * See the License for the specific language governing permissions and                                                 // 17
 * limitations under the License.                                                                                      // 18
 * ========================================================================                                            // 19
 */                                                                                                                    // 20
                                                                                                                       // 21
/* ========================================================================                                            // 22
 * Bootstrap: tooltip.js v3.2.0                                                                                        // 23
 * http://getbootstrap.com/javascript/#tooltip                                                                         // 24
 * Inspired by the original jQuery.tipsy by Jason Frame                                                                // 25
 * ========================================================================                                            // 26
 * Copyright 2011-2014 Twitter, Inc.                                                                                   // 27
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)                                          // 28
 * ======================================================================== */                                         // 29
                                                                                                                       // 30
                                                                                                                       // 31
+function ($) {                                                                                                        // 32
  'use strict';                                                                                                        // 33
                                                                                                                       // 34
  // TOOLTIP PUBLIC CLASS DEFINITION                                                                                   // 35
  // ===============================                                                                                   // 36
                                                                                                                       // 37
  var Tooltip = function (element, options) {                                                                          // 38
    this.type       =                                                                                                  // 39
    this.options    =                                                                                                  // 40
    this.enabled    =                                                                                                  // 41
    this.timeout    =                                                                                                  // 42
    this.hoverState =                                                                                                  // 43
    this.$element   = null                                                                                             // 44
                                                                                                                       // 45
    this.init('tooltip', element, options)                                                                             // 46
  }                                                                                                                    // 47
                                                                                                                       // 48
  Tooltip.VERSION  = '3.2.0'                                                                                           // 49
                                                                                                                       // 50
  Tooltip.DEFAULTS = {                                                                                                 // 51
    animation: true,                                                                                                   // 52
    placement: 'top',                                                                                                  // 53
    selector: false,                                                                                                   // 54
    template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
    trigger: 'hover focus',                                                                                            // 56
    title: '',                                                                                                         // 57
    delay: 0,                                                                                                          // 58
    html: false,                                                                                                       // 59
    container: false,                                                                                                  // 60
    viewport: {                                                                                                        // 61
      selector: 'body',                                                                                                // 62
      padding: 0                                                                                                       // 63
    }                                                                                                                  // 64
  }                                                                                                                    // 65
                                                                                                                       // 66
  Tooltip.prototype.init = function (type, element, options) {                                                         // 67
    this.enabled   = true                                                                                              // 68
    this.type      = type                                                                                              // 69
    this.$element  = $(element)                                                                                        // 70
    this.options   = this.getOptions(options)                                                                          // 71
    this.$viewport = this.options.viewport && $(this.options.viewport.selector || this.options.viewport)               // 72
                                                                                                                       // 73
    var triggers = this.options.trigger.split(' ')                                                                     // 74
                                                                                                                       // 75
    for (var i = triggers.length; i--;) {                                                                              // 76
      var trigger = triggers[i]                                                                                        // 77
                                                                                                                       // 78
      if (trigger == 'click') {                                                                                        // 79
        this.$element.on('click.' + this.type, this.options.selector, $.proxy(this.toggle, this))                      // 80
      } else if (trigger != 'manual') {                                                                                // 81
        var eventIn  = trigger == 'hover' ? 'mouseenter' : 'focusin'                                                   // 82
        var eventOut = trigger == 'hover' ? 'mouseleave' : 'focusout'                                                  // 83
                                                                                                                       // 84
        this.$element.on(eventIn  + '.' + this.type, this.options.selector, $.proxy(this.enter, this))                 // 85
        this.$element.on(eventOut + '.' + this.type, this.options.selector, $.proxy(this.leave, this))                 // 86
      }                                                                                                                // 87
    }                                                                                                                  // 88
                                                                                                                       // 89
    this.options.selector ?                                                                                            // 90
      (this._options = $.extend({}, this.options, { trigger: 'manual', selector: '' })) :                              // 91
      this.fixTitle()                                                                                                  // 92
  }                                                                                                                    // 93
                                                                                                                       // 94
  Tooltip.prototype.getDefaults = function () {                                                                        // 95
    return Tooltip.DEFAULTS                                                                                            // 96
  }                                                                                                                    // 97
                                                                                                                       // 98
  Tooltip.prototype.getOptions = function (options) {                                                                  // 99
    options = $.extend({}, this.getDefaults(), this.$element.data(), options)                                          // 100
                                                                                                                       // 101
    if (options.delay && typeof options.delay == 'number') {                                                           // 102
      options.delay = {                                                                                                // 103
        show: options.delay,                                                                                           // 104
        hide: options.delay                                                                                            // 105
      }                                                                                                                // 106
    }                                                                                                                  // 107
                                                                                                                       // 108
    return options                                                                                                     // 109
  }                                                                                                                    // 110
                                                                                                                       // 111
  Tooltip.prototype.getDelegateOptions = function () {                                                                 // 112
    var options  = {}                                                                                                  // 113
    var defaults = this.getDefaults()                                                                                  // 114
                                                                                                                       // 115
    this._options && $.each(this._options, function (key, value) {                                                     // 116
      if (defaults[key] != value) options[key] = value                                                                 // 117
    })                                                                                                                 // 118
                                                                                                                       // 119
    return options                                                                                                     // 120
  }                                                                                                                    // 121
                                                                                                                       // 122
  Tooltip.prototype.enter = function (obj) {                                                                           // 123
    var self = obj instanceof this.constructor ?                                                                       // 124
      obj : $(obj.currentTarget).data('bs.' + this.type)                                                               // 125
                                                                                                                       // 126
    if (!self) {                                                                                                       // 127
      self = new this.constructor(obj.currentTarget, this.getDelegateOptions())                                        // 128
      $(obj.currentTarget).data('bs.' + this.type, self)                                                               // 129
    }                                                                                                                  // 130
                                                                                                                       // 131
    clearTimeout(self.timeout)                                                                                         // 132
                                                                                                                       // 133
    self.hoverState = 'in'                                                                                             // 134
                                                                                                                       // 135
    if (!self.options.delay || !self.options.delay.show) return self.show()                                            // 136
                                                                                                                       // 137
    self.timeout = setTimeout(function () {                                                                            // 138
      if (self.hoverState == 'in') self.show()                                                                         // 139
    }, self.options.delay.show)                                                                                        // 140
  }                                                                                                                    // 141
                                                                                                                       // 142
  Tooltip.prototype.leave = function (obj) {                                                                           // 143
    var self = obj instanceof this.constructor ?                                                                       // 144
      obj : $(obj.currentTarget).data('bs.' + this.type)                                                               // 145
                                                                                                                       // 146
    if (!self) {                                                                                                       // 147
      self = new this.constructor(obj.currentTarget, this.getDelegateOptions())                                        // 148
      $(obj.currentTarget).data('bs.' + this.type, self)                                                               // 149
    }                                                                                                                  // 150
                                                                                                                       // 151
    clearTimeout(self.timeout)                                                                                         // 152
                                                                                                                       // 153
    self.hoverState = 'out'                                                                                            // 154
                                                                                                                       // 155
    if (!self.options.delay || !self.options.delay.hide) return self.hide()                                            // 156
                                                                                                                       // 157
    self.timeout = setTimeout(function () {                                                                            // 158
      if (self.hoverState == 'out') self.hide()                                                                        // 159
    }, self.options.delay.hide)                                                                                        // 160
  }                                                                                                                    // 161
                                                                                                                       // 162
  Tooltip.prototype.show = function () {                                                                               // 163
    var e = $.Event('show.bs.' + this.type)                                                                            // 164
                                                                                                                       // 165
    if (this.hasContent() && this.enabled) {                                                                           // 166
      this.$element.trigger(e)                                                                                         // 167
                                                                                                                       // 168
      var inDom = $.contains(document.documentElement, this.$element[0])                                               // 169
      if (e.isDefaultPrevented() || !inDom) return                                                                     // 170
      var that = this                                                                                                  // 171
                                                                                                                       // 172
      var $tip = this.tip()                                                                                            // 173
                                                                                                                       // 174
      var tipId = this.getUID(this.type)                                                                               // 175
                                                                                                                       // 176
      this.setContent()                                                                                                // 177
      $tip.attr('id', tipId)                                                                                           // 178
      this.$element.attr('aria-describedby', tipId)                                                                    // 179
                                                                                                                       // 180
      if (this.options.animation) $tip.addClass('fade')                                                                // 181
                                                                                                                       // 182
      var placement = typeof this.options.placement == 'function' ?                                                    // 183
        this.options.placement.call(this, $tip[0], this.$element[0]) :                                                 // 184
        this.options.placement                                                                                         // 185
                                                                                                                       // 186
      var autoToken = /\s?auto?\s?/i                                                                                   // 187
      var autoPlace = autoToken.test(placement)                                                                        // 188
      if (autoPlace) placement = placement.replace(autoToken, '') || 'top'                                             // 189
                                                                                                                       // 190
      $tip                                                                                                             // 191
        .detach()                                                                                                      // 192
        .css({ top: 0, left: 0, display: 'block' })                                                                    // 193
        .addClass(placement)                                                                                           // 194
        .data('bs.' + this.type, this)                                                                                 // 195
                                                                                                                       // 196
      this.options.container ? $tip.appendTo(this.options.container) : $tip.insertAfter(this.$element)                 // 197
                                                                                                                       // 198
      var pos          = this.getPosition()                                                                            // 199
      var actualWidth  = $tip[0].offsetWidth                                                                           // 200
      var actualHeight = $tip[0].offsetHeight                                                                          // 201
                                                                                                                       // 202
      if (autoPlace) {                                                                                                 // 203
        var orgPlacement = placement                                                                                   // 204
        var $parent      = this.$element.parent()                                                                      // 205
        var parentDim    = this.getPosition($parent)                                                                   // 206
                                                                                                                       // 207
        placement = placement == 'bottom' && pos.top   + pos.height       + actualHeight - parentDim.scroll > parentDim.height ? 'top'    :
                    placement == 'top'    && pos.top   - parentDim.scroll - actualHeight < 0                                   ? 'bottom' :
                    placement == 'right'  && pos.right + actualWidth      > parentDim.width                                    ? 'left'   :
                    placement == 'left'   && pos.left  - actualWidth      < parentDim.left                                     ? 'right'  :
                    placement                                                                                          // 212
                                                                                                                       // 213
        $tip                                                                                                           // 214
          .removeClass(orgPlacement)                                                                                   // 215
          .addClass(placement)                                                                                         // 216
      }                                                                                                                // 217
                                                                                                                       // 218
      var calculatedOffset = this.getCalculatedOffset(placement, pos, actualWidth, actualHeight)                       // 219
                                                                                                                       // 220
      this.applyPlacement(calculatedOffset, placement)                                                                 // 221
                                                                                                                       // 222
      var complete = function () {                                                                                     // 223
        that.$element.trigger('shown.bs.' + that.type)                                                                 // 224
        that.hoverState = null                                                                                         // 225
      }                                                                                                                // 226
                                                                                                                       // 227
      $.support.transition && this.$tip.hasClass('fade') ?                                                             // 228
        $tip                                                                                                           // 229
          .one('bsTransitionEnd', complete)                                                                            // 230
          .emulateTransitionEnd(150) :                                                                                 // 231
        complete()                                                                                                     // 232
    }                                                                                                                  // 233
  }                                                                                                                    // 234
                                                                                                                       // 235
  Tooltip.prototype.applyPlacement = function (offset, placement) {                                                    // 236
    var $tip   = this.tip()                                                                                            // 237
    var width  = $tip[0].offsetWidth                                                                                   // 238
    var height = $tip[0].offsetHeight                                                                                  // 239
                                                                                                                       // 240
    // manually read margins because getBoundingClientRect includes difference                                         // 241
    var marginTop = parseInt($tip.css('margin-top'), 10)                                                               // 242
    var marginLeft = parseInt($tip.css('margin-left'), 10)                                                             // 243
                                                                                                                       // 244
    // we must check for NaN for ie 8/9                                                                                // 245
    if (isNaN(marginTop))  marginTop  = 0                                                                              // 246
    if (isNaN(marginLeft)) marginLeft = 0                                                                              // 247
                                                                                                                       // 248
    offset.top  = offset.top  + marginTop                                                                              // 249
    offset.left = offset.left + marginLeft                                                                             // 250
                                                                                                                       // 251
    // $.fn.offset doesn't round pixel values                                                                          // 252
    // so we use setOffset directly with our own function B-0                                                          // 253
    $.offset.setOffset($tip[0], $.extend({                                                                             // 254
      using: function (props) {                                                                                        // 255
        $tip.css({                                                                                                     // 256
          top: Math.round(props.top),                                                                                  // 257
          left: Math.round(props.left)                                                                                 // 258
        })                                                                                                             // 259
      }                                                                                                                // 260
    }, offset), 0)                                                                                                     // 261
                                                                                                                       // 262
    $tip.addClass('in')                                                                                                // 263
                                                                                                                       // 264
    // check to see if placing tip in new offset caused the tip to resize itself                                       // 265
    var actualWidth  = $tip[0].offsetWidth                                                                             // 266
    var actualHeight = $tip[0].offsetHeight                                                                            // 267
                                                                                                                       // 268
    if (placement == 'top' && actualHeight != height) {                                                                // 269
      offset.top = offset.top + height - actualHeight                                                                  // 270
    }                                                                                                                  // 271
                                                                                                                       // 272
    var delta = this.getViewportAdjustedDelta(placement, offset, actualWidth, actualHeight)                            // 273
                                                                                                                       // 274
    if (delta.left) offset.left += delta.left                                                                          // 275
    else offset.top += delta.top                                                                                       // 276
                                                                                                                       // 277
    var arrowDelta          = delta.left ? delta.left * 2 - width + actualWidth : delta.top * 2 - height + actualHeight
    var arrowPosition       = delta.left ? 'left'        : 'top'                                                       // 279
    var arrowOffsetPosition = delta.left ? 'offsetWidth' : 'offsetHeight'                                              // 280
                                                                                                                       // 281
    $tip.offset(offset)                                                                                                // 282
    this.replaceArrow(arrowDelta, $tip[0][arrowOffsetPosition], arrowPosition)                                         // 283
  }                                                                                                                    // 284
                                                                                                                       // 285
  Tooltip.prototype.replaceArrow = function (delta, dimension, position) {                                             // 286
    this.arrow().css(position, delta ? (50 * (1 - delta / dimension) + '%') : '')                                      // 287
  }                                                                                                                    // 288
                                                                                                                       // 289
  Tooltip.prototype.setContent = function () {                                                                         // 290
    var $tip  = this.tip()                                                                                             // 291
    var title = this.getTitle()                                                                                        // 292
                                                                                                                       // 293
    $tip.find('.tooltip-inner')[this.options.html ? 'html' : 'text'](title)                                            // 294
    $tip.removeClass('fade in top bottom left right')                                                                  // 295
  }                                                                                                                    // 296
                                                                                                                       // 297
  Tooltip.prototype.hide = function () {                                                                               // 298
    var that = this                                                                                                    // 299
    var $tip = this.tip()                                                                                              // 300
    var e    = $.Event('hide.bs.' + this.type)                                                                         // 301
                                                                                                                       // 302
    this.$element.removeAttr('aria-describedby')                                                                       // 303
                                                                                                                       // 304
    function complete() {                                                                                              // 305
      if (that.hoverState != 'in') $tip.detach()                                                                       // 306
      that.$element.trigger('hidden.bs.' + that.type)                                                                  // 307
    }                                                                                                                  // 308
                                                                                                                       // 309
    this.$element.trigger(e)                                                                                           // 310
                                                                                                                       // 311
    if (e.isDefaultPrevented()) return                                                                                 // 312
                                                                                                                       // 313
    $tip.removeClass('in')                                                                                             // 314
                                                                                                                       // 315
    $.support.transition && this.$tip.hasClass('fade') ?                                                               // 316
      $tip                                                                                                             // 317
        .one('bsTransitionEnd', complete)                                                                              // 318
        .emulateTransitionEnd(150) :                                                                                   // 319
      complete()                                                                                                       // 320
                                                                                                                       // 321
    this.hoverState = null                                                                                             // 322
                                                                                                                       // 323
    return this                                                                                                        // 324
  }                                                                                                                    // 325
                                                                                                                       // 326
  Tooltip.prototype.fixTitle = function () {                                                                           // 327
    var $e = this.$element                                                                                             // 328
    if ($e.attr('title') || typeof ($e.attr('data-original-title')) != 'string') {                                     // 329
      $e.attr('data-original-title', $e.attr('title') || '').attr('title', '')                                         // 330
    }                                                                                                                  // 331
  }                                                                                                                    // 332
                                                                                                                       // 333
  Tooltip.prototype.hasContent = function () {                                                                         // 334
    return this.getTitle()                                                                                             // 335
  }                                                                                                                    // 336
                                                                                                                       // 337
  Tooltip.prototype.getPosition = function ($element) {                                                                // 338
    $element   = $element || this.$element                                                                             // 339
    var el     = $element[0]                                                                                           // 340
    var isBody = el.tagName == 'BODY'                                                                                  // 341
    return $.extend({}, (typeof el.getBoundingClientRect == 'function') ? el.getBoundingClientRect() : null, {         // 342
      scroll: isBody ? document.documentElement.scrollTop || document.body.scrollTop : $element.scrollTop(),           // 343
      width:  isBody ? $(window).width()  : $element.outerWidth(),                                                     // 344
      height: isBody ? $(window).height() : $element.outerHeight()                                                     // 345
    }, isBody ? { top: 0, left: 0 } : $element.offset())                                                               // 346
  }                                                                                                                    // 347
                                                                                                                       // 348
  Tooltip.prototype.getCalculatedOffset = function (placement, pos, actualWidth, actualHeight) {                       // 349
    return placement == 'bottom' ? { top: pos.top + pos.height,   left: pos.left + pos.width / 2 - actualWidth / 2  } :
           placement == 'top'    ? { top: pos.top - actualHeight, left: pos.left + pos.width / 2 - actualWidth / 2  } :
           placement == 'left'   ? { top: pos.top + pos.height / 2 - actualHeight / 2, left: pos.left - actualWidth } :
        /* placement == 'right' */ { top: pos.top + pos.height / 2 - actualHeight / 2, left: pos.left + pos.width   }  // 353
                                                                                                                       // 354
  }                                                                                                                    // 355
                                                                                                                       // 356
  Tooltip.prototype.getViewportAdjustedDelta = function (placement, pos, actualWidth, actualHeight) {                  // 357
    var delta = { top: 0, left: 0 }                                                                                    // 358
    if (!this.$viewport) return delta                                                                                  // 359
                                                                                                                       // 360
    var viewportPadding = this.options.viewport && this.options.viewport.padding || 0                                  // 361
    var viewportDimensions = this.getPosition(this.$viewport)                                                          // 362
                                                                                                                       // 363
    if (/right|left/.test(placement)) {                                                                                // 364
      var topEdgeOffset    = pos.top - viewportPadding - viewportDimensions.scroll                                     // 365
      var bottomEdgeOffset = pos.top + viewportPadding - viewportDimensions.scroll + actualHeight                      // 366
      if (topEdgeOffset < viewportDimensions.top) { // top overflow                                                    // 367
        delta.top = viewportDimensions.top - topEdgeOffset                                                             // 368
      } else if (bottomEdgeOffset > viewportDimensions.top + viewportDimensions.height) { // bottom overflow           // 369
        delta.top = viewportDimensions.top + viewportDimensions.height - bottomEdgeOffset                              // 370
      }                                                                                                                // 371
    } else {                                                                                                           // 372
      var leftEdgeOffset  = pos.left - viewportPadding                                                                 // 373
      var rightEdgeOffset = pos.left + viewportPadding + actualWidth                                                   // 374
      if (leftEdgeOffset < viewportDimensions.left) { // left overflow                                                 // 375
        delta.left = viewportDimensions.left - leftEdgeOffset                                                          // 376
      } else if (rightEdgeOffset > viewportDimensions.width) { // right overflow                                       // 377
        delta.left = viewportDimensions.left + viewportDimensions.width - rightEdgeOffset                              // 378
      }                                                                                                                // 379
    }                                                                                                                  // 380
                                                                                                                       // 381
    return delta                                                                                                       // 382
  }                                                                                                                    // 383
                                                                                                                       // 384
  Tooltip.prototype.getTitle = function () {                                                                           // 385
    var title                                                                                                          // 386
    var $e = this.$element                                                                                             // 387
    var o  = this.options                                                                                              // 388
                                                                                                                       // 389
    title = $e.attr('data-original-title')                                                                             // 390
      || (typeof o.title == 'function' ? o.title.call($e[0]) :  o.title)                                               // 391
                                                                                                                       // 392
    return title                                                                                                       // 393
  }                                                                                                                    // 394
                                                                                                                       // 395
  Tooltip.prototype.getUID = function (prefix) {                                                                       // 396
    do prefix += ~~(Math.random() * 1000000)                                                                           // 397
    while (document.getElementById(prefix))                                                                            // 398
    return prefix                                                                                                      // 399
  }                                                                                                                    // 400
                                                                                                                       // 401
  Tooltip.prototype.tip = function () {                                                                                // 402
    return (this.$tip = this.$tip || $(this.options.template))                                                         // 403
  }                                                                                                                    // 404
                                                                                                                       // 405
  Tooltip.prototype.arrow = function () {                                                                              // 406
    return (this.$arrow = this.$arrow || this.tip().find('.tooltip-arrow'))                                            // 407
  }                                                                                                                    // 408
                                                                                                                       // 409
  Tooltip.prototype.validate = function () {                                                                           // 410
    if (!this.$element[0].parentNode) {                                                                                // 411
      this.hide()                                                                                                      // 412
      this.$element = null                                                                                             // 413
      this.options  = null                                                                                             // 414
    }                                                                                                                  // 415
  }                                                                                                                    // 416
                                                                                                                       // 417
  Tooltip.prototype.enable = function () {                                                                             // 418
    this.enabled = true                                                                                                // 419
  }                                                                                                                    // 420
                                                                                                                       // 421
  Tooltip.prototype.disable = function () {                                                                            // 422
    this.enabled = false                                                                                               // 423
  }                                                                                                                    // 424
                                                                                                                       // 425
  Tooltip.prototype.toggleEnabled = function () {                                                                      // 426
    this.enabled = !this.enabled                                                                                       // 427
  }                                                                                                                    // 428
                                                                                                                       // 429
  Tooltip.prototype.toggle = function (e) {                                                                            // 430
    var self = this                                                                                                    // 431
    if (e) {                                                                                                           // 432
      self = $(e.currentTarget).data('bs.' + this.type)                                                                // 433
      if (!self) {                                                                                                     // 434
        self = new this.constructor(e.currentTarget, this.getDelegateOptions())                                        // 435
        $(e.currentTarget).data('bs.' + this.type, self)                                                               // 436
      }                                                                                                                // 437
    }                                                                                                                  // 438
                                                                                                                       // 439
    self.tip().hasClass('in') ? self.leave(self) : self.enter(self)                                                    // 440
  }                                                                                                                    // 441
                                                                                                                       // 442
  Tooltip.prototype.destroy = function () {                                                                            // 443
    clearTimeout(this.timeout)                                                                                         // 444
    this.hide().$element.off('.' + this.type).removeData('bs.' + this.type)                                            // 445
  }                                                                                                                    // 446
                                                                                                                       // 447
                                                                                                                       // 448
  // TOOLTIP PLUGIN DEFINITION                                                                                         // 449
  // =========================                                                                                         // 450
                                                                                                                       // 451
  function Plugin(option) {                                                                                            // 452
    return this.each(function () {                                                                                     // 453
      var $this   = $(this)                                                                                            // 454
      var data    = $this.data('bs.tooltip')                                                                           // 455
      var options = typeof option == 'object' && option                                                                // 456
                                                                                                                       // 457
      if (!data && option == 'destroy') return                                                                         // 458
      if (!data) $this.data('bs.tooltip', (data = new Tooltip(this, options)))                                         // 459
      if (typeof option == 'string') data[option]()                                                                    // 460
    })                                                                                                                 // 461
  }                                                                                                                    // 462
                                                                                                                       // 463
  var old = $.fn.tooltip                                                                                               // 464
                                                                                                                       // 465
  $.fn.tooltip             = Plugin                                                                                    // 466
  $.fn.tooltip.Constructor = Tooltip                                                                                   // 467
                                                                                                                       // 468
                                                                                                                       // 469
  // TOOLTIP NO CONFLICT                                                                                               // 470
  // ===================                                                                                               // 471
                                                                                                                       // 472
  $.fn.tooltip.noConflict = function () {                                                                              // 473
    $.fn.tooltip = old                                                                                                 // 474
    return this                                                                                                        // 475
  }                                                                                                                    // 476
                                                                                                                       // 477
}(jQuery);                                                                                                             // 478
                                                                                                                       // 479
/* ========================================================================                                            // 480
 * Bootstrap: popover.js v3.2.0                                                                                        // 481
 * http://getbootstrap.com/javascript/#popovers                                                                        // 482
 * ========================================================================                                            // 483
 * Copyright 2011-2014 Twitter, Inc.                                                                                   // 484
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)                                          // 485
 * ======================================================================== */                                         // 486
                                                                                                                       // 487
                                                                                                                       // 488
+function ($) {                                                                                                        // 489
  'use strict';                                                                                                        // 490
                                                                                                                       // 491
  // POPOVER PUBLIC CLASS DEFINITION                                                                                   // 492
  // ===============================                                                                                   // 493
                                                                                                                       // 494
  var Popover = function (element, options) {                                                                          // 495
    this.init('popover', element, options)                                                                             // 496
  }                                                                                                                    // 497
                                                                                                                       // 498
  if (!$.fn.tooltip) throw new Error('Popover requires tooltip.js')                                                    // 499
                                                                                                                       // 500
  Popover.VERSION  = '3.2.0'                                                                                           // 501
                                                                                                                       // 502
  Popover.DEFAULTS = $.extend({}, $.fn.tooltip.Constructor.DEFAULTS, {                                                 // 503
    placement: 'right',                                                                                                // 504
    trigger: 'click',                                                                                                  // 505
    content: '',                                                                                                       // 506
    template: '<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'
  })                                                                                                                   // 508
                                                                                                                       // 509
                                                                                                                       // 510
  // NOTE: POPOVER EXTENDS tooltip.js                                                                                  // 511
  // ================================                                                                                  // 512
                                                                                                                       // 513
  Popover.prototype = $.extend({}, $.fn.tooltip.Constructor.prototype)                                                 // 514
                                                                                                                       // 515
  Popover.prototype.constructor = Popover                                                                              // 516
                                                                                                                       // 517
  Popover.prototype.getDefaults = function () {                                                                        // 518
    return Popover.DEFAULTS                                                                                            // 519
  }                                                                                                                    // 520
                                                                                                                       // 521
  Popover.prototype.setContent = function () {                                                                         // 522
    var $tip    = this.tip()                                                                                           // 523
    var title   = this.getTitle()                                                                                      // 524
    var content = this.getContent()                                                                                    // 525
                                                                                                                       // 526
    $tip.find('.popover-title')[this.options.html ? 'html' : 'text'](title)                                            // 527
    $tip.find('.popover-content').empty()[ // we use append for html objects to maintain js events                     // 528
      this.options.html ? (typeof content == 'string' ? 'html' : 'append') : 'text'                                    // 529
    ](content)                                                                                                         // 530
                                                                                                                       // 531
    $tip.removeClass('fade top bottom left right in')                                                                  // 532
                                                                                                                       // 533
    // IE8 doesn't accept hiding via the `:empty` pseudo selector, we have to do                                       // 534
    // this manually by checking the contents.                                                                         // 535
    if (!$tip.find('.popover-title').html()) $tip.find('.popover-title').hide()                                        // 536
  }                                                                                                                    // 537
                                                                                                                       // 538
  Popover.prototype.hasContent = function () {                                                                         // 539
    return this.getTitle() || this.getContent()                                                                        // 540
  }                                                                                                                    // 541
                                                                                                                       // 542
  Popover.prototype.getContent = function () {                                                                         // 543
    var $e = this.$element                                                                                             // 544
    var o  = this.options                                                                                              // 545
                                                                                                                       // 546
    return $e.attr('data-content')                                                                                     // 547
      || (typeof o.content == 'function' ?                                                                             // 548
            o.content.call($e[0]) :                                                                                    // 549
            o.content)                                                                                                 // 550
  }                                                                                                                    // 551
                                                                                                                       // 552
  Popover.prototype.arrow = function () {                                                                              // 553
    return (this.$arrow = this.$arrow || this.tip().find('.arrow'))                                                    // 554
  }                                                                                                                    // 555
                                                                                                                       // 556
  Popover.prototype.tip = function () {                                                                                // 557
    if (!this.$tip) this.$tip = $(this.options.template)                                                               // 558
    return this.$tip                                                                                                   // 559
  }                                                                                                                    // 560
                                                                                                                       // 561
                                                                                                                       // 562
  // POPOVER PLUGIN DEFINITION                                                                                         // 563
  // =========================                                                                                         // 564
                                                                                                                       // 565
  function Plugin(option) {                                                                                            // 566
    return this.each(function () {                                                                                     // 567
      var $this   = $(this)                                                                                            // 568
      var data    = $this.data('bs.popover')                                                                           // 569
      var options = typeof option == 'object' && option                                                                // 570
                                                                                                                       // 571
      if (!data && option == 'destroy') return                                                                         // 572
      if (!data) $this.data('bs.popover', (data = new Popover(this, options)))                                         // 573
      if (typeof option == 'string') data[option]()                                                                    // 574
    })                                                                                                                 // 575
  }                                                                                                                    // 576
                                                                                                                       // 577
  var old = $.fn.popover                                                                                               // 578
                                                                                                                       // 579
  $.fn.popover             = Plugin                                                                                    // 580
  $.fn.popover.Constructor = Popover                                                                                   // 581
                                                                                                                       // 582
                                                                                                                       // 583
  // POPOVER NO CONFLICT                                                                                               // 584
  // ===================                                                                                               // 585
                                                                                                                       // 586
  $.fn.popover.noConflict = function () {                                                                              // 587
    $.fn.popover = old                                                                                                 // 588
    return this                                                                                                        // 589
  }                                                                                                                    // 590
                                                                                                                       // 591
}(jQuery);                                                                                                             // 592
                                                                                                                       // 593
(function($, window) {                                                                                                 // 594
  var Tour, document;                                                                                                  // 595
  document = window.document;                                                                                          // 596
  Tour = (function() {                                                                                                 // 597
    function Tour(options) {                                                                                           // 598
      var storage;                                                                                                     // 599
      try {                                                                                                            // 600
        storage = window.localStorage;                                                                                 // 601
      } catch (_error) {                                                                                               // 602
        storage = false;                                                                                               // 603
      }                                                                                                                // 604
      this._options = $.extend({                                                                                       // 605
        name: 'tour',                                                                                                  // 606
        steps: [],                                                                                                     // 607
        container: 'body',                                                                                             // 608
        autoscroll: true,                                                                                              // 609
        keyboard: true,                                                                                                // 610
        storage: storage,                                                                                              // 611
        debug: false,                                                                                                  // 612
        backdrop: false,                                                                                               // 613
        backdropPadding: 0,                                                                                            // 614
        redirect: true,                                                                                                // 615
        orphan: false,                                                                                                 // 616
        duration: false,                                                                                               // 617
        delay: false,                                                                                                  // 618
        basePath: '',                                                                                                  // 619
        template: '<div class="popover" role="tooltip"> <div class="arrow"></div> <h3 class="popover-title"></h3> <div class="popover-content"></div> <div class="popover-navigation"> <div class="btn-group"> <button class="btn btn-sm btn-default" data-role="prev">&laquo; Prev</button> <button class="btn btn-sm btn-default" data-role="next">Next &raquo;</button> <button class="btn btn-sm btn-default" data-role="pause-resume" data-pause-text="Pause" data-resume-text="Resume">Pause</button> </div> <button class="btn btn-sm btn-default" data-role="end">End tour</button> </div> </div>',
        afterSetState: function(key, value) {},                                                                        // 621
        afterGetState: function(key, value) {},                                                                        // 622
        afterRemoveState: function(key) {},                                                                            // 623
        onStart: function(tour) {},                                                                                    // 624
        onEnd: function(tour) {},                                                                                      // 625
        onShow: function(tour) {},                                                                                     // 626
        onShown: function(tour) {},                                                                                    // 627
        onHide: function(tour) {},                                                                                     // 628
        onHidden: function(tour) {},                                                                                   // 629
        onNext: function(tour) {},                                                                                     // 630
        onPrev: function(tour) {},                                                                                     // 631
        onPause: function(tour, duration) {},                                                                          // 632
        onResume: function(tour, duration) {}                                                                          // 633
      }, options);                                                                                                     // 634
      this._force = false;                                                                                             // 635
      this._inited = false;                                                                                            // 636
      this.backdrop = {                                                                                                // 637
        overlay: null,                                                                                                 // 638
        $element: null,                                                                                                // 639
        $background: null,                                                                                             // 640
        backgroundShown: false,                                                                                        // 641
        overlayElementShown: false                                                                                     // 642
      };                                                                                                               // 643
      this;                                                                                                            // 644
    }                                                                                                                  // 645
                                                                                                                       // 646
    Tour.prototype.addSteps = function(steps) {                                                                        // 647
      var step, _i, _len;                                                                                              // 648
      for (_i = 0, _len = steps.length; _i < _len; _i++) {                                                             // 649
        step = steps[_i];                                                                                              // 650
        this.addStep(step);                                                                                            // 651
      }                                                                                                                // 652
      return this;                                                                                                     // 653
    };                                                                                                                 // 654
                                                                                                                       // 655
    Tour.prototype.addStep = function(step) {                                                                          // 656
      this._options.steps.push(step);                                                                                  // 657
      return this;                                                                                                     // 658
    };                                                                                                                 // 659
                                                                                                                       // 660
    Tour.prototype.getStep = function(i) {                                                                             // 661
      if (this._options.steps[i] != null) {                                                                            // 662
        return $.extend({                                                                                              // 663
          id: "step-" + i,                                                                                             // 664
          path: '',                                                                                                    // 665
          placement: 'right',                                                                                          // 666
          title: '',                                                                                                   // 667
          content: '<p></p>',                                                                                          // 668
          next: i === this._options.steps.length - 1 ? -1 : i + 1,                                                     // 669
          prev: i - 1,                                                                                                 // 670
          animation: true,                                                                                             // 671
          container: this._options.container,                                                                          // 672
          autoscroll: this._options.autoscroll,                                                                        // 673
          backdrop: this._options.backdrop,                                                                            // 674
          backdropPadding: this._options.backdropPadding,                                                              // 675
          redirect: this._options.redirect,                                                                            // 676
          orphan: this._options.orphan,                                                                                // 677
          duration: this._options.duration,                                                                            // 678
          delay: this._options.delay,                                                                                  // 679
          template: this._options.template,                                                                            // 680
          onShow: this._options.onShow,                                                                                // 681
          onShown: this._options.onShown,                                                                              // 682
          onHide: this._options.onHide,                                                                                // 683
          onHidden: this._options.onHidden,                                                                            // 684
          onNext: this._options.onNext,                                                                                // 685
          onPrev: this._options.onPrev,                                                                                // 686
          onPause: this._options.onPause,                                                                              // 687
          onResume: this._options.onResume                                                                             // 688
        }, this._options.steps[i]);                                                                                    // 689
      }                                                                                                                // 690
    };                                                                                                                 // 691
                                                                                                                       // 692
    Tour.prototype.init = function(force) {                                                                            // 693
      this._force = force;                                                                                             // 694
      if (this.ended()) {                                                                                              // 695
        this._debug('Tour ended, init prevented.');                                                                    // 696
        return this;                                                                                                   // 697
      }                                                                                                                // 698
      this.setCurrentStep();                                                                                           // 699
      this._initMouseNavigation();                                                                                     // 700
      this._initKeyboardNavigation();                                                                                  // 701
      this._onResize((function(_this) {                                                                                // 702
        return function() {                                                                                            // 703
          return _this.showStep(_this._current);                                                                       // 704
        };                                                                                                             // 705
      })(this));                                                                                                       // 706
      if (this._current !== null) {                                                                                    // 707
        this.showStep(this._current);                                                                                  // 708
      }                                                                                                                // 709
      this._inited = true;                                                                                             // 710
      return this;                                                                                                     // 711
    };                                                                                                                 // 712
                                                                                                                       // 713
    Tour.prototype.start = function(force) {                                                                           // 714
      var promise;                                                                                                     // 715
      if (force == null) {                                                                                             // 716
        force = false;                                                                                                 // 717
      }                                                                                                                // 718
      if (!this._inited) {                                                                                             // 719
        this.init(force);                                                                                              // 720
      }                                                                                                                // 721
      if (this._current === null) {                                                                                    // 722
        promise = this._makePromise(this._options.onStart != null ? this._options.onStart(this) : void 0);             // 723
        this._callOnPromiseDone(promise, this.showStep, 0);                                                            // 724
      }                                                                                                                // 725
      return this;                                                                                                     // 726
    };                                                                                                                 // 727
                                                                                                                       // 728
    Tour.prototype.next = function() {                                                                                 // 729
      var promise;                                                                                                     // 730
      promise = this.hideStep(this._current);                                                                          // 731
      return this._callOnPromiseDone(promise, this._showNextStep);                                                     // 732
    };                                                                                                                 // 733
                                                                                                                       // 734
    Tour.prototype.prev = function() {                                                                                 // 735
      var promise;                                                                                                     // 736
      promise = this.hideStep(this._current);                                                                          // 737
      return this._callOnPromiseDone(promise, this._showPrevStep);                                                     // 738
    };                                                                                                                 // 739
                                                                                                                       // 740
    Tour.prototype.goTo = function(i) {                                                                                // 741
      var promise;                                                                                                     // 742
      promise = this.hideStep(this._current);                                                                          // 743
      return this._callOnPromiseDone(promise, this.showStep, i);                                                       // 744
    };                                                                                                                 // 745
                                                                                                                       // 746
    Tour.prototype.end = function() {                                                                                  // 747
      var endHelper, promise;                                                                                          // 748
      endHelper = (function(_this) {                                                                                   // 749
        return function(e) {                                                                                           // 750
          $(document).off("click.tour-" + _this._options.name);                                                        // 751
          $(document).off("keyup.tour-" + _this._options.name);                                                        // 752
          $(window).off("resize.tour-" + _this._options.name);                                                         // 753
          _this._setState('end', 'yes');                                                                               // 754
          _this._inited = false;                                                                                       // 755
          _this._force = false;                                                                                        // 756
          _this._clearTimer();                                                                                         // 757
          if (_this._options.onEnd != null) {                                                                          // 758
            return _this._options.onEnd(_this);                                                                        // 759
          }                                                                                                            // 760
        };                                                                                                             // 761
      })(this);                                                                                                        // 762
      promise = this.hideStep(this._current);                                                                          // 763
      return this._callOnPromiseDone(promise, endHelper);                                                              // 764
    };                                                                                                                 // 765
                                                                                                                       // 766
    Tour.prototype.ended = function() {                                                                                // 767
      return !this._force && !!this._getState('end');                                                                  // 768
    };                                                                                                                 // 769
                                                                                                                       // 770
    Tour.prototype.restart = function() {                                                                              // 771
      this._removeState('current_step');                                                                               // 772
      this._removeState('end');                                                                                        // 773
      return this.start();                                                                                             // 774
    };                                                                                                                 // 775
                                                                                                                       // 776
    Tour.prototype.pause = function() {                                                                                // 777
      var step;                                                                                                        // 778
      step = this.getStep(this._current);                                                                              // 779
      if (!(step && step.duration)) {                                                                                  // 780
        return this;                                                                                                   // 781
      }                                                                                                                // 782
      this._paused = true;                                                                                             // 783
      this._duration -= new Date().getTime() - this._start;                                                            // 784
      window.clearTimeout(this._timer);                                                                                // 785
      this._debug("Paused/Stopped step " + (this._current + 1) + " timer (" + this._duration + " remaining).");        // 786
      if (step.onPause != null) {                                                                                      // 787
        return step.onPause(this, this._duration);                                                                     // 788
      }                                                                                                                // 789
    };                                                                                                                 // 790
                                                                                                                       // 791
    Tour.prototype.resume = function() {                                                                               // 792
      var step;                                                                                                        // 793
      step = this.getStep(this._current);                                                                              // 794
      if (!(step && step.duration)) {                                                                                  // 795
        return this;                                                                                                   // 796
      }                                                                                                                // 797
      this._paused = false;                                                                                            // 798
      this._start = new Date().getTime();                                                                              // 799
      this._duration = this._duration || step.duration;                                                                // 800
      this._timer = window.setTimeout((function(_this) {                                                               // 801
        return function() {                                                                                            // 802
          if (_this._isLast()) {                                                                                       // 803
            return _this.next();                                                                                       // 804
          } else {                                                                                                     // 805
            return _this.end();                                                                                        // 806
          }                                                                                                            // 807
        };                                                                                                             // 808
      })(this), this._duration);                                                                                       // 809
      this._debug("Started step " + (this._current + 1) + " timer with duration " + this._duration);                   // 810
      if ((step.onResume != null) && this._duration !== step.duration) {                                               // 811
        return step.onResume(this, this._duration);                                                                    // 812
      }                                                                                                                // 813
    };                                                                                                                 // 814
                                                                                                                       // 815
    Tour.prototype.hideStep = function(i) {                                                                            // 816
      var hideStepHelper, promise, step;                                                                               // 817
      step = this.getStep(i);                                                                                          // 818
      if (!step) {                                                                                                     // 819
        return;                                                                                                        // 820
      }                                                                                                                // 821
      this._clearTimer();                                                                                              // 822
      promise = this._makePromise(step.onHide != null ? step.onHide(this, i) : void 0);                                // 823
      hideStepHelper = (function(_this) {                                                                              // 824
        return function(e) {                                                                                           // 825
          var $element;                                                                                                // 826
          $element = $(step.element);                                                                                  // 827
          if (!($element.data('bs.popover') || $element.data('popover'))) {                                            // 828
            $element = $('body');                                                                                      // 829
          }                                                                                                            // 830
          $element.popover('destroy').removeClass("tour-" + _this._options.name + "-element tour-" + _this._options.name + "-" + i + "-element");
          if (step.reflex) {                                                                                           // 832
            $element.removeClass('tour-step-element-reflex').off("" + (_this._reflexEvent(step.reflex)) + ".tour-" + _this._options.name);
          }                                                                                                            // 834
          if (step.backdrop) {                                                                                         // 835
            _this._hideBackdrop();                                                                                     // 836
          }                                                                                                            // 837
          if (step.onHidden != null) {                                                                                 // 838
            return step.onHidden(_this);                                                                               // 839
          }                                                                                                            // 840
        };                                                                                                             // 841
      })(this);                                                                                                        // 842
      this._callOnPromiseDone(promise, hideStepHelper);                                                                // 843
      return promise;                                                                                                  // 844
    };                                                                                                                 // 845
                                                                                                                       // 846
    Tour.prototype.showStep = function(i) {                                                                            // 847
      var promise, showStepHelper, skipToPrevious, step;                                                               // 848
      if (this.ended()) {                                                                                              // 849
        this._debug('Tour ended, showStep prevented.');                                                                // 850
        return this;                                                                                                   // 851
      }                                                                                                                // 852
      step = this.getStep(i);                                                                                          // 853
      if (!step) {                                                                                                     // 854
        return;                                                                                                        // 855
      }                                                                                                                // 856
      skipToPrevious = i < this._current;                                                                              // 857
      promise = this._makePromise(step.onShow != null ? step.onShow(this, i) : void 0);                                // 858
      showStepHelper = (function(_this) {                                                                              // 859
        return function(e) {                                                                                           // 860
          var current_path, path, showPopoverAndOverlay;                                                               // 861
          _this.setCurrentStep(i);                                                                                     // 862
          path = (function() {                                                                                         // 863
            switch ({}.toString.call(step.path)) {                                                                     // 864
              case '[object Function]':                                                                                // 865
                return step.path();                                                                                    // 866
              case '[object String]':                                                                                  // 867
                return this._options.basePath + step.path;                                                             // 868
              default:                                                                                                 // 869
                return step.path;                                                                                      // 870
            }                                                                                                          // 871
          }).call(_this);                                                                                              // 872
          current_path = [document.location.pathname, document.location.hash].join('');                                // 873
          if (_this._isRedirect(path, current_path)) {                                                                 // 874
            _this._redirect(step, path);                                                                               // 875
            return;                                                                                                    // 876
          }                                                                                                            // 877
          if (_this._isOrphan(step)) {                                                                                 // 878
            if (!step.orphan) {                                                                                        // 879
              _this._debug("Skip the orphan step " + (_this._current + 1) + ".\nOrphan option is false and the element does not exist or is hidden.");
              if (skipToPrevious) {                                                                                    // 881
                _this._showPrevStep();                                                                                 // 882
              } else {                                                                                                 // 883
                _this._showNextStep();                                                                                 // 884
              }                                                                                                        // 885
              return;                                                                                                  // 886
            }                                                                                                          // 887
            _this._debug("Show the orphan step " + (_this._current + 1) + ". Orphans option is true.");                // 888
          }                                                                                                            // 889
          if (step.backdrop) {                                                                                         // 890
            _this._showBackdrop(!_this._isOrphan(step) ? step.element : void 0);                                       // 891
          }                                                                                                            // 892
          showPopoverAndOverlay = function() {                                                                         // 893
            if (_this.getCurrentStep() !== i) {                                                                        // 894
              return;                                                                                                  // 895
            }                                                                                                          // 896
            if ((step.element != null) && step.backdrop) {                                                             // 897
              _this._showOverlayElement(step);                                                                         // 898
            }                                                                                                          // 899
            _this._showPopover(step, i);                                                                               // 900
            if (step.onShown != null) {                                                                                // 901
              step.onShown(_this);                                                                                     // 902
            }                                                                                                          // 903
            return _this._debug("Step " + (_this._current + 1) + " of " + _this._options.steps.length);                // 904
          };                                                                                                           // 905
          if (step.autoscroll) {                                                                                       // 906
            _this._scrollIntoView(step.element, showPopoverAndOverlay);                                                // 907
          } else {                                                                                                     // 908
            showPopoverAndOverlay();                                                                                   // 909
          }                                                                                                            // 910
          if (step.duration) {                                                                                         // 911
            return _this.resume();                                                                                     // 912
          }                                                                                                            // 913
        };                                                                                                             // 914
      })(this);                                                                                                        // 915
      if (step.delay) {                                                                                                // 916
        this._debug("Wait " + step.delay + " milliseconds to show the step " + (this._current + 1));                   // 917
        window.setTimeout((function(_this) {                                                                           // 918
          return function() {                                                                                          // 919
            return _this._callOnPromiseDone(promise, showStepHelper);                                                  // 920
          };                                                                                                           // 921
        })(this), step.delay);                                                                                         // 922
      } else {                                                                                                         // 923
        this._callOnPromiseDone(promise, showStepHelper);                                                              // 924
      }                                                                                                                // 925
      return promise;                                                                                                  // 926
    };                                                                                                                 // 927
                                                                                                                       // 928
    Tour.prototype.getCurrentStep = function() {                                                                       // 929
      return this._current;                                                                                            // 930
    };                                                                                                                 // 931
                                                                                                                       // 932
    Tour.prototype.setCurrentStep = function(value) {                                                                  // 933
      if (value != null) {                                                                                             // 934
        this._current = value;                                                                                         // 935
        this._setState('current_step', value);                                                                         // 936
      } else {                                                                                                         // 937
        this._current = this._getState('current_step');                                                                // 938
        this._current = this._current === null ? null : parseInt(this._current, 10);                                   // 939
      }                                                                                                                // 940
      return this;                                                                                                     // 941
    };                                                                                                                 // 942
                                                                                                                       // 943
    Tour.prototype._setState = function(key, value) {                                                                  // 944
      var e, keyName;                                                                                                  // 945
      if (this._options.storage) {                                                                                     // 946
        keyName = "" + this._options.name + "_" + key;                                                                 // 947
        try {                                                                                                          // 948
          this._options.storage.setItem(keyName, value);                                                               // 949
        } catch (_error) {                                                                                             // 950
          e = _error;                                                                                                  // 951
          if (e.code === DOMException.QUOTA_EXCEEDED_ERR) {                                                            // 952
            this._debug('LocalStorage quota exceeded. State storage failed.');                                         // 953
          }                                                                                                            // 954
        }                                                                                                              // 955
        return this._options.afterSetState(keyName, value);                                                            // 956
      } else {                                                                                                         // 957
        if (this._state == null) {                                                                                     // 958
          this._state = {};                                                                                            // 959
        }                                                                                                              // 960
        return this._state[key] = value;                                                                               // 961
      }                                                                                                                // 962
    };                                                                                                                 // 963
                                                                                                                       // 964
    Tour.prototype._removeState = function(key) {                                                                      // 965
      var keyName;                                                                                                     // 966
      if (this._options.storage) {                                                                                     // 967
        keyName = "" + this._options.name + "_" + key;                                                                 // 968
        this._options.storage.removeItem(keyName);                                                                     // 969
        return this._options.afterRemoveState(keyName);                                                                // 970
      } else {                                                                                                         // 971
        if (this._state != null) {                                                                                     // 972
          return delete this._state[key];                                                                              // 973
        }                                                                                                              // 974
      }                                                                                                                // 975
    };                                                                                                                 // 976
                                                                                                                       // 977
    Tour.prototype._getState = function(key) {                                                                         // 978
      var keyName, value;                                                                                              // 979
      if (this._options.storage) {                                                                                     // 980
        keyName = "" + this._options.name + "_" + key;                                                                 // 981
        value = this._options.storage.getItem(keyName);                                                                // 982
      } else {                                                                                                         // 983
        if (this._state != null) {                                                                                     // 984
          value = this._state[key];                                                                                    // 985
        }                                                                                                              // 986
      }                                                                                                                // 987
      if (value === void 0 || value === 'null') {                                                                      // 988
        value = null;                                                                                                  // 989
      }                                                                                                                // 990
      this._options.afterGetState(key, value);                                                                         // 991
      return value;                                                                                                    // 992
    };                                                                                                                 // 993
                                                                                                                       // 994
    Tour.prototype._showNextStep = function() {                                                                        // 995
      var promise, showNextStepHelper, step;                                                                           // 996
      step = this.getStep(this._current);                                                                              // 997
      showNextStepHelper = (function(_this) {                                                                          // 998
        return function(e) {                                                                                           // 999
          return _this.showStep(step.next);                                                                            // 1000
        };                                                                                                             // 1001
      })(this);                                                                                                        // 1002
      promise = this._makePromise(step.onNext != null ? step.onNext(this) : void 0);                                   // 1003
      return this._callOnPromiseDone(promise, showNextStepHelper);                                                     // 1004
    };                                                                                                                 // 1005
                                                                                                                       // 1006
    Tour.prototype._showPrevStep = function() {                                                                        // 1007
      var promise, showPrevStepHelper, step;                                                                           // 1008
      step = this.getStep(this._current);                                                                              // 1009
      showPrevStepHelper = (function(_this) {                                                                          // 1010
        return function(e) {                                                                                           // 1011
          return _this.showStep(step.prev);                                                                            // 1012
        };                                                                                                             // 1013
      })(this);                                                                                                        // 1014
      promise = this._makePromise(step.onPrev != null ? step.onPrev(this) : void 0);                                   // 1015
      return this._callOnPromiseDone(promise, showPrevStepHelper);                                                     // 1016
    };                                                                                                                 // 1017
                                                                                                                       // 1018
    Tour.prototype._debug = function(text) {                                                                           // 1019
      if (this._options.debug) {                                                                                       // 1020
        return window.console.log("Bootstrap Tour '" + this._options.name + "' | " + text);                            // 1021
      }                                                                                                                // 1022
    };                                                                                                                 // 1023
                                                                                                                       // 1024
    Tour.prototype._isRedirect = function(path, currentPath) {                                                         // 1025
      return (path != null) && path !== '' && (({}.toString.call(path) === '[object RegExp]' && !path.test(currentPath)) || ({}.toString.call(path) === '[object String]' && path.replace(/\?.*$/, '').replace(/\/?$/, '') !== currentPath.replace(/\/?$/, '')));
    };                                                                                                                 // 1027
                                                                                                                       // 1028
    Tour.prototype._redirect = function(step, path) {                                                                  // 1029
      if ($.isFunction(step.redirect)) {                                                                               // 1030
        return step.redirect.call(this, path);                                                                         // 1031
      } else if (step.redirect === true) {                                                                             // 1032
        this._debug("Redirect to " + path);                                                                            // 1033
        return document.location.href = path;                                                                          // 1034
      }                                                                                                                // 1035
    };                                                                                                                 // 1036
                                                                                                                       // 1037
    Tour.prototype._isOrphan = function(step) {                                                                        // 1038
      return (step.element == null) || !$(step.element).length || $(step.element).is(':hidden') && ($(step.element)[0].namespaceURI !== 'http://www.w3.org/2000/svg');
    };                                                                                                                 // 1040
                                                                                                                       // 1041
    Tour.prototype._isLast = function() {                                                                              // 1042
      return this._current < this._options.steps.length - 1;                                                           // 1043
    };                                                                                                                 // 1044
                                                                                                                       // 1045
    Tour.prototype._showPopover = function(step, i) {                                                                  // 1046
      var $element, $tip, isOrphan, options;                                                                           // 1047
      $(".tour-" + this._options.name).remove();                                                                       // 1048
      options = $.extend({}, this._options);                                                                           // 1049
      isOrphan = this._isOrphan(step);                                                                                 // 1050
      step.template = this._template(step, i);                                                                         // 1051
      if (isOrphan) {                                                                                                  // 1052
        step.element = 'body';                                                                                         // 1053
        step.placement = 'top';                                                                                        // 1054
      }                                                                                                                // 1055
      $element = $(step.element);                                                                                      // 1056
      $element.addClass("tour-" + this._options.name + "-element tour-" + this._options.name + "-" + i + "-element");  // 1057
      if (step.options) {                                                                                              // 1058
        $.extend(options, step.options);                                                                               // 1059
      }                                                                                                                // 1060
      if (step.reflex && !isOrphan) {                                                                                  // 1061
        $element.addClass('tour-step-element-reflex');                                                                 // 1062
        $element.off("" + (this._reflexEvent(step.reflex)) + ".tour-" + this._options.name);                           // 1063
        $element.on("" + (this._reflexEvent(step.reflex)) + ".tour-" + this._options.name, (function(_this) {          // 1064
          return function() {                                                                                          // 1065
            if (_this._isLast()) {                                                                                     // 1066
              return _this.next();                                                                                     // 1067
            } else {                                                                                                   // 1068
              return _this.end();                                                                                      // 1069
            }                                                                                                          // 1070
          };                                                                                                           // 1071
        })(this));                                                                                                     // 1072
      }                                                                                                                // 1073
      $element.popover({                                                                                               // 1074
        placement: step.placement,                                                                                     // 1075
        trigger: 'manual',                                                                                             // 1076
        title: step.title,                                                                                             // 1077
        content: step.content,                                                                                         // 1078
        html: true,                                                                                                    // 1079
        animation: step.animation,                                                                                     // 1080
        container: step.container,                                                                                     // 1081
        template: step.template,                                                                                       // 1082
        selector: step.element                                                                                         // 1083
      }).popover('show');                                                                                              // 1084
      $tip = $element.data('bs.popover') ? $element.data('bs.popover').tip() : $element.data('popover').tip();         // 1085
      $tip.attr('id', step.id);                                                                                        // 1086
      this._reposition($tip, step);                                                                                    // 1087
      if (isOrphan) {                                                                                                  // 1088
        return this._center($tip);                                                                                     // 1089
      }                                                                                                                // 1090
    };                                                                                                                 // 1091
                                                                                                                       // 1092
    Tour.prototype._template = function(step, i) {                                                                     // 1093
      var $navigation, $next, $prev, $resume, $template;                                                               // 1094
      $template = $.isFunction(step.template) ? $(step.template(i, step)) : $(step.template);                          // 1095
      $navigation = $template.find('.popover-navigation');                                                             // 1096
      $prev = $navigation.find('[data-role="prev"]');                                                                  // 1097
      $next = $navigation.find('[data-role="next"]');                                                                  // 1098
      $resume = $navigation.find('[data-role="pause-resume"]');                                                        // 1099
      if (this._isOrphan(step)) {                                                                                      // 1100
        $template.addClass('orphan');                                                                                  // 1101
      }                                                                                                                // 1102
      $template.addClass("tour-" + this._options.name + " tour-" + this._options.name + "-" + i);                      // 1103
      if (step.prev < 0) {                                                                                             // 1104
        $prev.addClass('disabled');                                                                                    // 1105
      }                                                                                                                // 1106
      if (step.next < 0) {                                                                                             // 1107
        $next.addClass('disabled');                                                                                    // 1108
      }                                                                                                                // 1109
      if (!step.duration) {                                                                                            // 1110
        $resume.remove();                                                                                              // 1111
      }                                                                                                                // 1112
      return $template.clone().wrap('<div>').parent().html();                                                          // 1113
    };                                                                                                                 // 1114
                                                                                                                       // 1115
    Tour.prototype._reflexEvent = function(reflex) {                                                                   // 1116
      if ({}.toString.call(reflex) === '[object Boolean]') {                                                           // 1117
        return 'click';                                                                                                // 1118
      } else {                                                                                                         // 1119
        return reflex;                                                                                                 // 1120
      }                                                                                                                // 1121
    };                                                                                                                 // 1122
                                                                                                                       // 1123
    Tour.prototype._reposition = function($tip, step) {                                                                // 1124
      var offsetBottom, offsetHeight, offsetRight, offsetWidth, originalLeft, originalTop, tipOffset;                  // 1125
      offsetWidth = $tip[0].offsetWidth;                                                                               // 1126
      offsetHeight = $tip[0].offsetHeight;                                                                             // 1127
      tipOffset = $tip.offset();                                                                                       // 1128
      originalLeft = tipOffset.left;                                                                                   // 1129
      originalTop = tipOffset.top;                                                                                     // 1130
      offsetBottom = $(document).outerHeight() - tipOffset.top - $tip.outerHeight();                                   // 1131
      if (offsetBottom < 0) {                                                                                          // 1132
        tipOffset.top = tipOffset.top + offsetBottom;                                                                  // 1133
      }                                                                                                                // 1134
      offsetRight = $('html').outerWidth() - tipOffset.left - $tip.outerWidth();                                       // 1135
      if (offsetRight < 0) {                                                                                           // 1136
        tipOffset.left = tipOffset.left + offsetRight;                                                                 // 1137
      }                                                                                                                // 1138
      if (tipOffset.top < 0) {                                                                                         // 1139
        tipOffset.top = 0;                                                                                             // 1140
      }                                                                                                                // 1141
      if (tipOffset.left < 0) {                                                                                        // 1142
        tipOffset.left = 0;                                                                                            // 1143
      }                                                                                                                // 1144
      $tip.offset(tipOffset);                                                                                          // 1145
      if (step.placement === 'bottom' || step.placement === 'top') {                                                   // 1146
        if (originalLeft !== tipOffset.left) {                                                                         // 1147
          return this._replaceArrow($tip, (tipOffset.left - originalLeft) * 2, offsetWidth, 'left');                   // 1148
        }                                                                                                              // 1149
      } else {                                                                                                         // 1150
        if (originalTop !== tipOffset.top) {                                                                           // 1151
          return this._replaceArrow($tip, (tipOffset.top - originalTop) * 2, offsetHeight, 'top');                     // 1152
        }                                                                                                              // 1153
      }                                                                                                                // 1154
    };                                                                                                                 // 1155
                                                                                                                       // 1156
    Tour.prototype._center = function($tip) {                                                                          // 1157
      return $tip.css('top', $(window).outerHeight() / 2 - $tip.outerHeight() / 2);                                    // 1158
    };                                                                                                                 // 1159
                                                                                                                       // 1160
    Tour.prototype._replaceArrow = function($tip, delta, dimension, position) {                                        // 1161
      return $tip.find('.arrow').css(position, delta ? 50 * (1 - delta / dimension) + '%' : '');                       // 1162
    };                                                                                                                 // 1163
                                                                                                                       // 1164
    Tour.prototype._scrollIntoView = function(element, callback) {                                                     // 1165
      var $element, $window, counter, offsetTop, scrollTop, windowHeight;                                              // 1166
      $element = $(element);                                                                                           // 1167
      if (!$element.length) {                                                                                          // 1168
        return callback();                                                                                             // 1169
      }                                                                                                                // 1170
      $window = $(window);                                                                                             // 1171
      offsetTop = $element.offset().top;                                                                               // 1172
      windowHeight = $window.height();                                                                                 // 1173
      scrollTop = Math.max(0, offsetTop - (windowHeight / 2));                                                         // 1174
      this._debug("Scroll into view. ScrollTop: " + scrollTop + ". Element offset: " + offsetTop + ". Window height: " + windowHeight + ".");
      counter = 0;                                                                                                     // 1176
      return $('body, html').stop(true, true).animate({                                                                // 1177
        scrollTop: Math.ceil(scrollTop)                                                                                // 1178
      }, (function(_this) {                                                                                            // 1179
        return function() {                                                                                            // 1180
          if (++counter === 2) {                                                                                       // 1181
            callback();                                                                                                // 1182
            return _this._debug("Scroll into view.\nAnimation end element offset: " + ($element.offset().top) + ".\nWindow height: " + ($window.height()) + ".");
          }                                                                                                            // 1184
        };                                                                                                             // 1185
      })(this));                                                                                                       // 1186
    };                                                                                                                 // 1187
                                                                                                                       // 1188
    Tour.prototype._onResize = function(callback, timeout) {                                                           // 1189
      return $(window).on("resize.tour-" + this._options.name, function() {                                            // 1190
        clearTimeout(timeout);                                                                                         // 1191
        return timeout = setTimeout(callback, 100);                                                                    // 1192
      });                                                                                                              // 1193
    };                                                                                                                 // 1194
                                                                                                                       // 1195
    Tour.prototype._initMouseNavigation = function() {                                                                 // 1196
      var _this;                                                                                                       // 1197
      _this = this;                                                                                                    // 1198
      return $(document).off("click.tour-" + this._options.name, ".popover.tour-" + this._options.name + " *[data-role='prev']").off("click.tour-" + this._options.name, ".popover.tour-" + this._options.name + " *[data-role='next']").off("click.tour-" + this._options.name, ".popover.tour-" + this._options.name + " *[data-role='end']").off("click.tour-" + this._options.name, ".popover.tour-" + this._options.name + " *[data-role='pause-resume']").on("click.tour-" + this._options.name, ".popover.tour-" + this._options.name + " *[data-role='next']", (function(_this) {
        return function(e) {                                                                                           // 1200
          e.preventDefault();                                                                                          // 1201
          return _this.next();                                                                                         // 1202
        };                                                                                                             // 1203
      })(this)).on("click.tour-" + this._options.name, ".popover.tour-" + this._options.name + " *[data-role='prev']", (function(_this) {
        return function(e) {                                                                                           // 1205
          e.preventDefault();                                                                                          // 1206
          return _this.prev();                                                                                         // 1207
        };                                                                                                             // 1208
      })(this)).on("click.tour-" + this._options.name, ".popover.tour-" + this._options.name + " *[data-role='end']", (function(_this) {
        return function(e) {                                                                                           // 1210
          e.preventDefault();                                                                                          // 1211
          return _this.end();                                                                                          // 1212
        };                                                                                                             // 1213
      })(this)).on("click.tour-" + this._options.name, ".popover.tour-" + this._options.name + " *[data-role='pause-resume']", function(e) {
        var $this;                                                                                                     // 1215
        e.preventDefault();                                                                                            // 1216
        $this = $(this);                                                                                               // 1217
        $this.text(_this._paused ? $this.data('pause-text') : $this.data('resume-text'));                              // 1218
        if (_this._paused) {                                                                                           // 1219
          return _this.resume();                                                                                       // 1220
        } else {                                                                                                       // 1221
          return _this.pause();                                                                                        // 1222
        }                                                                                                              // 1223
      });                                                                                                              // 1224
    };                                                                                                                 // 1225
                                                                                                                       // 1226
    Tour.prototype._initKeyboardNavigation = function() {                                                              // 1227
      if (!this._options.keyboard) {                                                                                   // 1228
        return;                                                                                                        // 1229
      }                                                                                                                // 1230
      return $(document).on("keyup.tour-" + this._options.name, (function(_this) {                                     // 1231
        return function(e) {                                                                                           // 1232
          if (!e.which) {                                                                                              // 1233
            return;                                                                                                    // 1234
          }                                                                                                            // 1235
          switch (e.which) {                                                                                           // 1236
            case 39:                                                                                                   // 1237
              e.preventDefault();                                                                                      // 1238
              if (_this._isLast()) {                                                                                   // 1239
                return _this.next();                                                                                   // 1240
              } else {                                                                                                 // 1241
                return _this.end();                                                                                    // 1242
              }                                                                                                        // 1243
              break;                                                                                                   // 1244
            case 37:                                                                                                   // 1245
              e.preventDefault();                                                                                      // 1246
              if (_this._current > 0) {                                                                                // 1247
                return _this.prev();                                                                                   // 1248
              }                                                                                                        // 1249
              break;                                                                                                   // 1250
            case 27:                                                                                                   // 1251
              e.preventDefault();                                                                                      // 1252
              return _this.end();                                                                                      // 1253
          }                                                                                                            // 1254
        };                                                                                                             // 1255
      })(this));                                                                                                       // 1256
    };                                                                                                                 // 1257
                                                                                                                       // 1258
    Tour.prototype._makePromise = function(result) {                                                                   // 1259
      if (result && $.isFunction(result.then)) {                                                                       // 1260
        return result;                                                                                                 // 1261
      } else {                                                                                                         // 1262
        return null;                                                                                                   // 1263
      }                                                                                                                // 1264
    };                                                                                                                 // 1265
                                                                                                                       // 1266
    Tour.prototype._callOnPromiseDone = function(promise, cb, arg) {                                                   // 1267
      if (promise) {                                                                                                   // 1268
        return promise.then((function(_this) {                                                                         // 1269
          return function(e) {                                                                                         // 1270
            return cb.call(_this, arg);                                                                                // 1271
          };                                                                                                           // 1272
        })(this));                                                                                                     // 1273
      } else {                                                                                                         // 1274
        return cb.call(this, arg);                                                                                     // 1275
      }                                                                                                                // 1276
    };                                                                                                                 // 1277
                                                                                                                       // 1278
    Tour.prototype._showBackdrop = function(element) {                                                                 // 1279
      if (this.backdrop.backgroundShown) {                                                                             // 1280
        return;                                                                                                        // 1281
      }                                                                                                                // 1282
      this.backdrop = $('<div>', {                                                                                     // 1283
        "class": 'tour-backdrop'                                                                                       // 1284
      });                                                                                                              // 1285
      this.backdrop.backgroundShown = true;                                                                            // 1286
      return $('body').append(this.backdrop);                                                                          // 1287
    };                                                                                                                 // 1288
                                                                                                                       // 1289
    Tour.prototype._hideBackdrop = function() {                                                                        // 1290
      this._hideOverlayElement();                                                                                      // 1291
      return this._hideBackground();                                                                                   // 1292
    };                                                                                                                 // 1293
                                                                                                                       // 1294
    Tour.prototype._hideBackground = function() {                                                                      // 1295
      if (this.backdrop) {                                                                                             // 1296
        this.backdrop.remove();                                                                                        // 1297
        this.backdrop.overlay = null;                                                                                  // 1298
        return this.backdrop.backgroundShown = false;                                                                  // 1299
      }                                                                                                                // 1300
    };                                                                                                                 // 1301
                                                                                                                       // 1302
    Tour.prototype._showOverlayElement = function(step) {                                                              // 1303
      var $element, elementData;                                                                                       // 1304
      $element = $(step.element);                                                                                      // 1305
      if (!$element || $element.length === 0 || this.backdrop.overlayElementShown) {                                   // 1306
        return;                                                                                                        // 1307
      }                                                                                                                // 1308
      this.backdrop.overlayElementShown = true;                                                                        // 1309
      this.backdrop.$element = $element.addClass('tour-step-backdrop');                                                // 1310
      this.backdrop.$background = $('<div>', {                                                                         // 1311
        "class": 'tour-step-background'                                                                                // 1312
      });                                                                                                              // 1313
      elementData = {                                                                                                  // 1314
        width: $element.innerWidth(),                                                                                  // 1315
        height: $element.innerHeight(),                                                                                // 1316
        offset: $element.offset()                                                                                      // 1317
      };                                                                                                               // 1318
      this.backdrop.$background.appendTo('body');                                                                      // 1319
      if (step.backdropPadding) {                                                                                      // 1320
        elementData = this._applyBackdropPadding(step.backdropPadding, elementData);                                   // 1321
      }                                                                                                                // 1322
      return this.backdrop.$background.width(elementData.width).height(elementData.height).offset(elementData.offset);
    };                                                                                                                 // 1324
                                                                                                                       // 1325
    Tour.prototype._hideOverlayElement = function() {                                                                  // 1326
      if (!this.backdrop.overlayElementShown) {                                                                        // 1327
        return;                                                                                                        // 1328
      }                                                                                                                // 1329
      this.backdrop.$element.removeClass('tour-step-backdrop');                                                        // 1330
      this.backdrop.$background.remove();                                                                              // 1331
      this.backdrop.$element = null;                                                                                   // 1332
      this.backdrop.$background = null;                                                                                // 1333
      return this.backdrop.overlayElementShown = false;                                                                // 1334
    };                                                                                                                 // 1335
                                                                                                                       // 1336
    Tour.prototype._applyBackdropPadding = function(padding, data) {                                                   // 1337
      if (typeof padding === 'object') {                                                                               // 1338
        if (padding.top == null) {                                                                                     // 1339
          padding.top = 0;                                                                                             // 1340
        }                                                                                                              // 1341
        if (padding.right == null) {                                                                                   // 1342
          padding.right = 0;                                                                                           // 1343
        }                                                                                                              // 1344
        if (padding.bottom == null) {                                                                                  // 1345
          padding.bottom = 0;                                                                                          // 1346
        }                                                                                                              // 1347
        if (padding.left == null) {                                                                                    // 1348
          padding.left = 0;                                                                                            // 1349
        }                                                                                                              // 1350
        data.offset.top = data.offset.top - padding.top;                                                               // 1351
        data.offset.left = data.offset.left - padding.left;                                                            // 1352
        data.width = data.width + padding.left + padding.right;                                                        // 1353
        data.height = data.height + padding.top + padding.bottom;                                                      // 1354
      } else {                                                                                                         // 1355
        data.offset.top = data.offset.top - padding;                                                                   // 1356
        data.offset.left = data.offset.left - padding;                                                                 // 1357
        data.width = data.width + (padding * 2);                                                                       // 1358
        data.height = data.height + (padding * 2);                                                                     // 1359
      }                                                                                                                // 1360
      return data;                                                                                                     // 1361
    };                                                                                                                 // 1362
                                                                                                                       // 1363
    Tour.prototype._clearTimer = function() {                                                                          // 1364
      window.clearTimeout(this._timer);                                                                                // 1365
      this._timer = null;                                                                                              // 1366
      return this._duration = null;                                                                                    // 1367
    };                                                                                                                 // 1368
                                                                                                                       // 1369
    return Tour;                                                                                                       // 1370
                                                                                                                       // 1371
  })();                                                                                                                // 1372
  return window.Tour = Tour;                                                                                           // 1373
})(jQuery, window);                                                                                                    // 1374
                                                                                                                       // 1375
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['flowkey:bootstrap-tour'] = {};

})();
