//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
// Source maps are supported by all recent versions of Chrome, Safari,  //
// and Firefox, and by Internet Explorer 11.                            //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Accounts = Package['accounts-base'].Accounts;
var _ = Package.underscore._;
var Template = Package['templating-runtime'].Template;
var $ = Package.jquery.$;
var jQuery = Package.jquery.jQuery;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var Random = Package.random.Random;
var Showdown = Package.markdown.Showdown;
var ReactiveDict = Package['reactive-dict'].ReactiveDict;
var Session = Package.session.Session;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var moment = Package['momentjs:moment'].moment;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Mongo = Package.mongo.Mongo;
var Collection2 = Package['aldeed:collection2-core'].Collection2;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var AnonymousUserCollection, CommentsCollection, Comments, defaultCommentHelpers;

var require = meteorInstall({"node_modules":{"meteor":{"arkham:comments-ui":{"lib":{"collections":{"anonymous-user.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/collections/anonymous-user.js                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
AnonymousUserCollection = new Mongo.Collection('commentsui-anonymoususer');                                           // 1
                                                                                                                      //
AnonymousUserCollection.allow({                                                                                       // 3
  insert: function () {                                                                                               // 4
    function insert() {                                                                                               // 4
      return false;                                                                                                   // 4
    }                                                                                                                 // 4
                                                                                                                      //
    return insert;                                                                                                    // 4
  }(),                                                                                                                // 4
  update: function () {                                                                                               // 5
    function update() {                                                                                               // 5
      return false;                                                                                                   // 5
    }                                                                                                                 // 5
                                                                                                                      //
    return update;                                                                                                    // 5
  }(),                                                                                                                // 5
  remove: function () {                                                                                               // 6
    function remove() {                                                                                               // 6
      return false;                                                                                                   // 6
    }                                                                                                                 // 6
                                                                                                                      //
    return remove;                                                                                                    // 6
  }()                                                                                                                 // 6
});                                                                                                                   // 3
                                                                                                                      //
AnonymousUserCollection.attachSchema(new SimpleSchema({                                                               // 9
  username: {                                                                                                         // 10
    type: String,                                                                                                     // 11
    optional: true                                                                                                    // 12
  },                                                                                                                  // 10
  email: {                                                                                                            // 14
    type: String,                                                                                                     // 15
    optional: true                                                                                                    // 16
  },                                                                                                                  // 14
  anonIp: {                                                                                                           // 18
    type: String                                                                                                      // 19
  },                                                                                                                  // 18
  salt: {                                                                                                             // 21
    type: String                                                                                                      // 22
  },                                                                                                                  // 21
  createdAt: {                                                                                                        // 24
    type: Date,                                                                                                       // 25
    autoValue: function () {                                                                                          // 26
      function autoValue() {                                                                                          // 24
        if (this.isInsert) {                                                                                          // 27
          return new Date();                                                                                          // 28
        } else if (this.isUpsert) {                                                                                   // 29
          return { $setOnInsert: new Date() };                                                                        // 30
        } else {                                                                                                      // 31
          this.unset();                                                                                               // 32
        }                                                                                                             // 33
      }                                                                                                               // 34
                                                                                                                      //
      return autoValue;                                                                                               // 24
    }()                                                                                                               // 24
  }                                                                                                                   // 24
}));                                                                                                                  // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":["babel-runtime/helpers/extends","../services/time-tick","../services/user","linkifyjs/string",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/collections/comments.js                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _extends;module.import('babel-runtime/helpers/extends',{"default":function(v){_extends=v}});var timeTickService;module.import('../services/time-tick',{"default":function(v){timeTickService=v}});var userService;module.import('../services/user',{"default":function(v){userService=v}});var linkifyStr;module.import('linkifyjs/string',{"default":function(v){linkifyStr=v}});
                                                                                                                      // 1
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      //
CommentsCollection = new Mongo.Collection('comments');                                                                // 5
                                                                                                                      //
CommentsCollection.schemas = {};                                                                                      // 7
                                                                                                                      //
CommentsCollection.schemas.StarRatingSchema = new SimpleSchema({                                                      // 9
  userId: {                                                                                                           // 10
    type: String                                                                                                      // 11
  },                                                                                                                  // 10
  rating: {                                                                                                           // 13
    type: Number                                                                                                      // 14
  }                                                                                                                   // 13
});                                                                                                                   // 9
                                                                                                                      //
var likeableConfig = {                                                                                                // 18
  type: [String],                                                                                                     // 19
  autoValue: function () {                                                                                            // 20
    function autoValue() {                                                                                            // 20
      if (this.isInsert) {                                                                                            // 21
        return [];                                                                                                    // 22
      }                                                                                                               // 23
    }                                                                                                                 // 24
                                                                                                                      //
    return autoValue;                                                                                                 // 20
  }(),                                                                                                                // 20
  optional: true                                                                                                      // 25
};                                                                                                                    // 18
                                                                                                                      //
/**                                                                                                                   // 28
 * Return a comment schema enhanced with the given schema config.                                                     //
 *                                                                                                                    //
 * @param additionalSchemaConfig                                                                                      //
 *                                                                                                                    //
 * @returns {Object}                                                                                                  //
 */                                                                                                                   //
function getCommonCommentSchema() {                                                                                   // 35
  var additionalSchemaConfig = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};                // 35
                                                                                                                      //
  return _extends({                                                                                                   // 36
    userId: {                                                                                                         // 37
      type: String                                                                                                    // 38
    },                                                                                                                // 37
    isAnonymous: {                                                                                                    // 40
      type: Boolean                                                                                                   // 41
    },                                                                                                                // 40
    'media.type': {                                                                                                   // 43
      type: String,                                                                                                   // 44
      optional: true                                                                                                  // 45
    },                                                                                                                // 43
    'media.content': {                                                                                                // 47
      type: String,                                                                                                   // 48
      optional: true                                                                                                  // 49
    },                                                                                                                // 47
    content: {                                                                                                        // 51
      type: String,                                                                                                   // 52
      min: 1,                                                                                                         // 53
      max: 10000                                                                                                      // 54
    },                                                                                                                // 51
    replies: {                                                                                                        // 56
      type: [Object],                                                                                                 // 57
      autoValue: function () {                                                                                        // 58
        function autoValue() {                                                                                        // 58
          if (this.isInsert) {                                                                                        // 59
            return [];                                                                                                // 60
          }                                                                                                           // 61
        }                                                                                                             // 62
                                                                                                                      //
        return autoValue;                                                                                             // 58
      }(),                                                                                                            // 58
      optional: true                                                                                                  // 63
    },                                                                                                                // 56
    likes: _extends({}, likeableConfig),                                                                              // 65
    dislikes: _extends({}, likeableConfig),                                                                           // 66
    starRatings: {                                                                                                    // 67
      type: [CommentsCollection.schemas.StarRatingSchema],                                                            // 68
      autoValue: function () {                                                                                        // 69
        function autoValue() {                                                                                        // 69
          if (this.isInsert) {                                                                                        // 70
            return [];                                                                                                // 71
          }                                                                                                           // 72
        }                                                                                                             // 73
                                                                                                                      //
        return autoValue;                                                                                             // 69
      }(),                                                                                                            // 69
      optional: true                                                                                                  // 74
    },                                                                                                                // 67
    // general rating number that is used for sorting                                                                 // 76
    ratingScore: {                                                                                                    // 77
      type: Number,                                                                                                   // 78
      decimal: true,                                                                                                  // 79
      autoValue: function () {                                                                                        // 80
        function autoValue() {                                                                                        // 80
          if (this.isInsert) {                                                                                        // 81
            return 0;                                                                                                 // 82
          }                                                                                                           // 83
        }                                                                                                             // 84
                                                                                                                      //
        return autoValue;                                                                                             // 80
      }()                                                                                                             // 80
    },                                                                                                                // 77
    createdAt: {                                                                                                      // 86
      type: Date,                                                                                                     // 87
      autoValue: function () {                                                                                        // 88
        function autoValue() {                                                                                        // 88
          if (this.isInsert) {                                                                                        // 89
            return new Date();                                                                                        // 90
          } else if (this.isUpsert) {                                                                                 // 91
            return { $setOnInsert: new Date() };                                                                      // 92
          } else {                                                                                                    // 93
            this.unset();                                                                                             // 94
          }                                                                                                           // 95
        }                                                                                                             // 96
                                                                                                                      //
        return autoValue;                                                                                             // 88
      }()                                                                                                             // 88
    },                                                                                                                // 86
    lastUpdatedAt: {                                                                                                  // 98
      type: Date,                                                                                                     // 99
      autoValue: function () {                                                                                        // 100
        function autoValue() {                                                                                        // 100
          if (this.isUpdate) {                                                                                        // 101
            return new Date();                                                                                        // 102
          }                                                                                                           // 103
        }                                                                                                             // 104
                                                                                                                      //
        return autoValue;                                                                                             // 100
      }(),                                                                                                            // 100
      denyInsert: true,                                                                                               // 105
      optional: true                                                                                                  // 106
    }                                                                                                                 // 98
  }, additionalSchemaConfig);                                                                                         // 36
}                                                                                                                     // 110
                                                                                                                      //
/**                                                                                                                   // 112
 * Enhance nested replies with correct data.                                                                          //
 *                                                                                                                    //
 * @param {Object} scope                                                                                              //
 * @param {Array} position                                                                                            //
 *                                                                                                                    //
 * @returns {Array}                                                                                                   //
 */                                                                                                                   //
function enhanceReplies(scope, position) {                                                                            // 120
  if (!position) {                                                                                                    // 121
    position = [];                                                                                                    // 122
  }                                                                                                                   // 123
                                                                                                                      //
  return _.map(scope.replies, function (reply, index) {                                                               // 125
    position.push(index);                                                                                             // 126
                                                                                                                      //
    reply = Object.assign(reply, {                                                                                    // 128
      position: position.slice(0),                                                                                    // 129
      documentId: scope._id,                                                                                          // 130
      user: scope.user.bind(reply),                                                                                   // 131
      likesCount: scope.likesCount.bind(reply),                                                                       // 132
      dislikesCount: scope.dislikesCount.bind(reply),                                                                 // 133
      createdAgo: scope.createdAgo.bind(reply),                                                                       // 134
      getStarRating: scope.getStarRating.bind(reply),                                                                 // 135
      enhancedContent: scope.enhancedContent.bind(reply)                                                              // 136
    });                                                                                                               // 128
                                                                                                                      //
    if (reply.replies) {                                                                                              // 139
      // recursive!                                                                                                   // 140
      reply.enhancedReplies = _.bind(enhanceReplies, null, _.extend(_.clone(scope), { replies: reply.replies }), position)();
    }                                                                                                                 // 147
                                                                                                                      //
    position.pop();                                                                                                   // 149
                                                                                                                      //
    return reply;                                                                                                     // 151
  });                                                                                                                 // 152
}                                                                                                                     // 153
                                                                                                                      //
CommentsCollection.schemas.ReplySchema = new SimpleSchema(getCommonCommentSchema({                                    // 155
  replyId: {                                                                                                          // 156
    type: String                                                                                                      // 157
  }                                                                                                                   // 156
}));                                                                                                                  // 155
                                                                                                                      //
CommentsCollection.schemas.CommentSchema = new SimpleSchema(getCommonCommentSchema({                                  // 161
  referenceId: {                                                                                                      // 162
    type: String                                                                                                      // 163
  }                                                                                                                   // 162
}));                                                                                                                  // 161
                                                                                                                      //
CommentsCollection.attachSchema(CommentsCollection.schemas.CommentSchema);                                            // 167
                                                                                                                      //
// Is handled with Meteor.methods                                                                                     // 169
CommentsCollection.allow({                                                                                            // 170
  insert: function () {                                                                                               // 171
    function insert() {                                                                                               // 171
      return false;                                                                                                   // 171
    }                                                                                                                 // 171
                                                                                                                      //
    return insert;                                                                                                    // 171
  }(),                                                                                                                // 171
  update: function () {                                                                                               // 172
    function update() {                                                                                               // 172
      return false;                                                                                                   // 172
    }                                                                                                                 // 172
                                                                                                                      //
    return update;                                                                                                    // 172
  }(),                                                                                                                // 172
  remove: function () {                                                                                               // 173
    function remove() {                                                                                               // 173
      return false;                                                                                                   // 173
    }                                                                                                                 // 173
                                                                                                                      //
    return remove;                                                                                                    // 173
  }()                                                                                                                 // 173
});                                                                                                                   // 170
                                                                                                                      //
var calculateAverageRating = function calculateAverageRating(ratings) {                                               // 176
  return _.reduce(ratings, function (averageRating, rating) {                                                         // 176
    return averageRating + rating.rating / ratings.length;                                                            // 178
  }, 0);                                                                                                              // 178
};                                                                                                                    // 176
                                                                                                                      //
CommentsCollection._calculateAverageRating = calculateAverageRating;                                                  // 182
                                                                                                                      //
var getCount = function getCount(scope, field) {                                                                      // 184
  return scope[field] && scope[field].length ? scope[field].length : 0;                                               // 184
};                                                                                                                    // 184
                                                                                                                      //
CommentsCollection.helpers({                                                                                          // 186
  likesCount: function () {                                                                                           // 187
    function likesCount() {                                                                                           // 187
      return getCount(this, 'likes');                                                                                 // 188
    }                                                                                                                 // 189
                                                                                                                      //
    return likesCount;                                                                                                // 187
  }(),                                                                                                                // 187
  dislikesCount: function () {                                                                                        // 190
    function dislikesCount() {                                                                                        // 190
      return getCount(this, 'dislikes');                                                                              // 191
    }                                                                                                                 // 192
                                                                                                                      //
    return dislikesCount;                                                                                             // 190
  }(),                                                                                                                // 190
  user: function () {                                                                                                 // 193
    function user() {                                                                                                 // 193
      return userService.getUserById(this.userId);                                                                    // 194
    }                                                                                                                 // 195
                                                                                                                      //
    return user;                                                                                                      // 193
  }(),                                                                                                                // 193
  createdAgo: function () {                                                                                           // 196
    function createdAgo() {                                                                                           // 196
      return timeTickService.fromNowReactive(moment(this.createdAt));                                                 // 197
    }                                                                                                                 // 198
                                                                                                                      //
    return createdAgo;                                                                                                // 196
  }(),                                                                                                                // 196
  enhancedReplies: function () {                                                                                      // 199
    function enhancedReplies(position) {                                                                              // 199
      return enhanceReplies(this, position);                                                                          // 200
    }                                                                                                                 // 201
                                                                                                                      //
    return enhancedReplies;                                                                                           // 199
  }(),                                                                                                                // 199
  enhancedContent: function () {                                                                                      // 202
    function enhancedContent() {                                                                                      // 202
      return linkifyStr(this.content);                                                                                // 203
    }                                                                                                                 // 204
                                                                                                                      //
    return enhancedContent;                                                                                           // 202
  }(),                                                                                                                // 202
  getStarRating: function () {                                                                                        // 205
    function getStarRating() {                                                                                        // 205
      if (_.isArray(this.starRatings)) {                                                                              // 206
        var ownRating = _.find(this.starRatings, function (rating) {                                                  // 207
          return rating.userId === Meteor.userId();                                                                   // 207
        });                                                                                                           // 207
                                                                                                                      //
        if (ownRating) {                                                                                              // 209
          return {                                                                                                    // 210
            type: 'user',                                                                                             // 211
            rating: ownRating.rating                                                                                  // 212
          };                                                                                                          // 210
        }                                                                                                             // 214
                                                                                                                      //
        return {                                                                                                      // 216
          type: 'average',                                                                                            // 217
          rating: calculateAverageRating(this.starRatings)                                                            // 218
        };                                                                                                            // 216
      }                                                                                                               // 220
                                                                                                                      //
      return {                                                                                                        // 222
        type: 'average',                                                                                              // 223
        rating: 0                                                                                                     // 224
      };                                                                                                              // 222
    }                                                                                                                 // 226
                                                                                                                      //
    return getStarRating;                                                                                             // 205
  }()                                                                                                                 // 205
});                                                                                                                   // 186
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods":{"anonymous-user.js":["../../services/hashing",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/collections/methods/anonymous-user.js                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var hashingService;module.import('../../services/hashing',{"default":function(v){hashingService=v}});                 // 1
                                                                                                                      //
Meteor.methods({                                                                                                      // 3
  'commentsUiAnonymousUser/add': function () {                                                                        // 4
    function commentsUiAnonymousUserAdd(data) {                                                                       // 3
      check(data, {                                                                                                   // 5
        username: String,                                                                                             // 6
        email: String                                                                                                 // 7
      });                                                                                                             // 5
                                                                                                                      //
      if (Meteor.isServer) {                                                                                          // 10
        data.salt = hashingService.hash(data);                                                                        // 11
        data.anonIp = this.connection.clientAddress;                                                                  // 12
      } else {                                                                                                        // 13
        data.salt = 'fake';                                                                                           // 14
        data.anonIp = 'fake';                                                                                         // 15
      }                                                                                                               // 16
                                                                                                                      //
      if (AnonymousUserCollection.find({ anonIp: data.anonIp, createdAt: { $gte: moment().subtract(10, 'days').toDate() } }).count() >= 5) {
        throw new Meteor.Error('More than 5 anonymous accounts with the same IP');                                    // 19
      }                                                                                                               // 20
                                                                                                                      //
      return {                                                                                                        // 22
        _id: AnonymousUserCollection.insert(data),                                                                    // 23
        salt: data.salt                                                                                               // 24
      };                                                                                                              // 22
    }                                                                                                                 // 26
                                                                                                                      //
    return commentsUiAnonymousUserAdd;                                                                                // 3
  }(),                                                                                                                // 3
  'commentsUiAnonymousUser/update': function () {                                                                     // 27
    function commentsUiAnonymousUserUpdate(_id, salt, data) {                                                         // 3
      check(_id, String);                                                                                             // 28
      check(salt, String);                                                                                            // 29
      check(data, {                                                                                                   // 30
        username: Match.Optional(String),                                                                             // 31
        email: Match.Optional(String)                                                                                 // 32
      });                                                                                                             // 30
                                                                                                                      //
      return AnonymousUserCollection.update({ _id: _id, salt: salt }, { $set: data });                                // 35
    }                                                                                                                 // 36
                                                                                                                      //
    return commentsUiAnonymousUserUpdate;                                                                             // 3
  }()                                                                                                                 // 3
});                                                                                                                   // 3
                                                                                                                      //
AnonymousUserCollection.methods = {                                                                                   // 39
  add: function () {                                                                                                  // 40
    function add(data, cb) {                                                                                          // 40
      return Meteor.call('commentsUiAnonymousUser/add', data, cb);                                                    // 40
    }                                                                                                                 // 40
                                                                                                                      //
    return add;                                                                                                       // 40
  }(),                                                                                                                // 40
  update: function () {                                                                                               // 41
    function update(id, salt, data, cb) {                                                                             // 41
      return Meteor.call('commentsUiAnonymousUser/update', id, salt, data, cb);                                       // 41
    }                                                                                                                 // 41
                                                                                                                      //
    return update;                                                                                                    // 41
  }()                                                                                                                 // 41
};                                                                                                                    // 39
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"comments.js":["../../services/media","../../services/user","../../services/comment",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/collections/methods/comments.js                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var mediaService;module.import('../../services/media',{"default":function(v){mediaService=v}});var userService;module.import('../../services/user',{"default":function(v){userService=v}});var commentService;module.import('../../services/comment',{"default":function(v){commentService=v}});
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      //
var noOptOptions = {                                                                                                  // 5
  validate: false,                                                                                                    // 6
  filter: false,                                                                                                      // 7
  getAutoValues: false,                                                                                               // 8
  removeEmptyStrings: false                                                                                           // 9
};                                                                                                                    // 5
                                                                                                                      //
/**                                                                                                                   // 12
 * Modify replies with a callback in a nested array.                                                                  //
 *                                                                                                                    //
 * @param {Array} nestedArray                                                                                         //
 * @param {Array} position Array of numbers with indexes throughout the reply tree.                                   //
 * @param {Function} callback                                                                                         //
 */                                                                                                                   //
function modifyNestedReplies(nestedArray, position, callback) {                                                       // 19
  var currentPos = position.shift();                                                                                  // 20
                                                                                                                      //
  if (nestedArray[currentPos]) {                                                                                      // 22
    if (position.length && nestedArray[currentPos] && nestedArray[currentPos].replies) {                              // 23
      modifyNestedReplies(nestedArray[currentPos].replies, position, callback);                                       // 24
    } else {                                                                                                          // 25
      callback(nestedArray, currentPos);                                                                              // 26
    }                                                                                                                 // 27
  }                                                                                                                   // 28
}                                                                                                                     // 29
                                                                                                                      //
/**                                                                                                                   // 31
 * Call a meteor method with anonymous user id if there is as the last argument.                                      //
 *                                                                                                                    //
 * @param {String} methodName                                                                                         //
 * @param {Array} methodArgs                                                                                          //
 */                                                                                                                   //
function callWithAnonUserData(methodName) {                                                                           // 37
  var anonUserData = userService.isAnonymous() ? userService.getUserData() : {};                                      // 38
                                                                                                                      //
  for (var _len = arguments.length, methodArgs = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {     // 37
    methodArgs[_key - 1] = arguments[_key];                                                                           // 37
  }                                                                                                                   // 37
                                                                                                                      //
  Meteor.apply(methodName, [].concat(methodArgs, [anonUserData]));                                                    // 39
}                                                                                                                     // 40
                                                                                                                      //
/**                                                                                                                   // 42
 * Return a mongodb style field descriptor                                                                            //
 *                                                                                                                    //
 * e.g "replies.0.replies.1" which points at the second reply of the first reply.                                     //
 *                                                                                                                    //
 * @param {undefined|Array} position                                                                                  //
 *                                                                                                                    //
 * @return {String}                                                                                                   //
 */                                                                                                                   //
function getMongoReplyFieldDescriptor(position) {                                                                     // 51
  if (!position) {                                                                                                    // 52
    return '';                                                                                                        // 53
  }                                                                                                                   // 54
                                                                                                                      //
  var descriptorWithLeadingDot = _.reduce(position, function (descriptor, positionNumber) {                           // 56
    return descriptor + 'replies.' + positionNumber + '.';                                                            // 57
  }, '');                                                                                                             // 58
                                                                                                                      //
  return descriptorWithLeadingDot.substr(0, descriptorWithLeadingDot.length - 1);                                     // 60
}                                                                                                                     // 61
                                                                                                                      //
var triggerEvent = function triggerEvent(name, action, payload) {                                                     // 63
  var func = Comments.config().onEvent;                                                                               // 64
                                                                                                                      //
  if (_.isFunction(func)) {                                                                                           // 66
    func(name, action, payload);                                                                                      // 67
  }                                                                                                                   // 68
};                                                                                                                    // 69
                                                                                                                      //
var getRatingScore = function getRatingScore(doc) {                                                                   // 71
  var score = CommentsCollection._calculateAverageRating(doc.starRatings);                                            // 72
                                                                                                                      //
  if (score === 0) {                                                                                                  // 74
    score = doc.likes.length - (doc.dislikes && doc.dislikes.length ? doc.dislikes.length : 0);                       // 75
  }                                                                                                                   // 76
                                                                                                                      //
  return score;                                                                                                       // 78
};                                                                                                                    // 79
                                                                                                                      //
var updateRatingScoreOnDoc = function updateRatingScoreOnDoc(_id) {                                                   // 81
  CommentsCollection.update({ _id: _id }, {                                                                           // 82
    $set: { ratingScore: getRatingScore(CommentsCollection.findOne(_id)) }                                            // 83
  });                                                                                                                 // 82
};                                                                                                                    // 85
                                                                                                                      //
var allowReplies = function allowReplies(documentId) {                                                                // 87
  var config = Comments.config();                                                                                     // 88
  var referenceId = getReferenceIdByDocumentId(documentId);                                                           // 89
                                                                                                                      //
  return config.allowReplies ? config.allowReplies(referenceId) : config.replies;                                     // 91
};                                                                                                                    // 92
                                                                                                                      //
var getReferenceIdByDocumentId = function getReferenceIdByDocumentId(documentId) {                                    // 94
  var doc = CommentsCollection.findOne({ _id: documentId }, { fields: { referenceId: 1 } });                          // 95
                                                                                                                      //
  if (doc) {                                                                                                          // 97
    return doc.referenceId;                                                                                           // 98
  }                                                                                                                   // 99
};                                                                                                                    // 100
                                                                                                                      //
// TODO: add unit tests + good user testing (bootstrap, ionic and so on)!                                             // 102
                                                                                                                      //
Meteor.methods({                                                                                                      // 104
  'comments/add': function () {                                                                                       // 105
    function commentsAdd(referenceId, content, anonUserData) {                                                        // 105
      check(referenceId, String);                                                                                     // 106
      check(content, String);                                                                                         // 107
                                                                                                                      //
      userService.verifyAnonUserData(anonUserData, referenceId);                                                      // 109
      var userId = this.userId || anonUserData._id;                                                                   // 110
                                                                                                                      //
      content = content.trim();                                                                                       // 112
                                                                                                                      //
      if (userId && content) {                                                                                        // 114
        var doc = {                                                                                                   // 115
          referenceId: referenceId,                                                                                   // 116
          content: content,                                                                                           // 117
          userId: userId,                                                                                             // 118
          createdAt: new Date(),                                                                                      // 119
          likes: [],                                                                                                  // 120
          dislikes: [],                                                                                               // 121
          replies: [],                                                                                                // 122
          isAnonymous: !!anonUserData._id,                                                                            // 123
          media: mediaService.getMediaFromContent(content)                                                            // 124
        };                                                                                                            // 115
                                                                                                                      //
        var docId = CommentsCollection.insert(doc);                                                                   // 127
                                                                                                                      //
        triggerEvent('comment', 'add', Object.assign({}, doc, { _id: docId }));                                       // 129
      }                                                                                                               // 130
    }                                                                                                                 // 131
                                                                                                                      //
    return commentsAdd;                                                                                               // 105
  }(),                                                                                                                // 105
  'comments/edit': function () {                                                                                      // 132
    function commentsEdit(documentId, newContent, anonUserData) {                                                     // 132
      check(documentId, String);                                                                                      // 133
      check(newContent, String);                                                                                      // 134
                                                                                                                      //
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                           // 136
      var userId = this.userId || anonUserData._id;                                                                   // 137
                                                                                                                      //
      newContent = newContent.trim();                                                                                 // 139
                                                                                                                      //
      if (!userId || !newContent) {                                                                                   // 141
        return;                                                                                                       // 142
      }                                                                                                               // 143
                                                                                                                      //
      var setDoc = { content: newContent, likes: [], media: mediaService.getMediaFromContent(newContent), ratingScore: 0 };
      var findSelector = { _id: documentId, userId: userId };                                                         // 146
                                                                                                                      //
      CommentsCollection.update(findSelector, { $set: setDoc });                                                      // 148
                                                                                                                      //
      triggerEvent('comment', 'edit', Object.assign({}, setDoc, findSelector));                                       // 153
    }                                                                                                                 // 154
                                                                                                                      //
    return commentsEdit;                                                                                              // 132
  }(),                                                                                                                // 132
  'comments/remove': function () {                                                                                    // 155
    function commentsRemove(documentId, anonUserData) {                                                               // 155
      check(documentId, String);                                                                                      // 156
                                                                                                                      //
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                           // 158
      var userId = this.userId || anonUserData._id;                                                                   // 159
                                                                                                                      //
      var removeSelector = { _id: documentId, userId: userId };                                                       // 161
                                                                                                                      //
      var doc = CommentsCollection.findOne(removeSelector);                                                           // 163
                                                                                                                      //
      CommentsCollection.remove(removeSelector);                                                                      // 165
                                                                                                                      //
      triggerEvent('comment', 'remove', doc);                                                                         // 167
    }                                                                                                                 // 168
                                                                                                                      //
    return commentsRemove;                                                                                            // 155
  }(),                                                                                                                // 155
  'comments/like': function () {                                                                                      // 169
    function commentsLike(documentId, anonUserData) {                                                                 // 169
      check(documentId, String);                                                                                      // 170
                                                                                                                      //
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                           // 172
      var userId = this.userId || anonUserData._id;                                                                   // 173
                                                                                                                      //
      if (!userId || !['likes', 'likes-and-dislikes'].includes(Comments.config().rating)) {                           // 175
        return;                                                                                                       // 176
      }                                                                                                               // 177
                                                                                                                      //
      var findSelector = { _id: documentId };                                                                         // 179
                                                                                                                      //
      var likedDoc = CommentsCollection.findOne({ _id: documentId, likes: { $in: [userId] } });                       // 181
                                                                                                                      //
      if (likedDoc) {                                                                                                 // 183
        CommentsCollection.update(findSelector, { $pull: { likes: userId } }, noOptOptions);                          // 184
      } else {                                                                                                        // 185
        CommentsCollection.update(findSelector, { $push: { likes: userId } }, noOptOptions);                          // 186
      }                                                                                                               // 187
                                                                                                                      //
      updateRatingScoreOnDoc(documentId);                                                                             // 189
                                                                                                                      //
      triggerEvent('comment', 'like', Object.assign({}, likedDoc, findSelector, {                                     // 191
        ratedUserId: userId                                                                                           // 192
      }));                                                                                                            // 191
    }                                                                                                                 // 194
                                                                                                                      //
    return commentsLike;                                                                                              // 169
  }(),                                                                                                                // 169
  'comments/dislike': function () {                                                                                   // 195
    function commentsDislike(documentId, anonUserData) {                                                              // 195
      check(documentId, String);                                                                                      // 196
                                                                                                                      //
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                           // 198
      var userId = this.userId || anonUserData._id;                                                                   // 199
                                                                                                                      //
      if (!userId || !['likes', 'likes-and-dislikes'].includes(Comments.config().rating)) {                           // 201
        return;                                                                                                       // 202
      }                                                                                                               // 203
                                                                                                                      //
      var findSelector = { _id: documentId };                                                                         // 205
                                                                                                                      //
      var dislikedDoc = CommentsCollection.findOne({ _id: documentId, dislikes: { $in: [userId] } });                 // 207
                                                                                                                      //
      if (dislikedDoc) {                                                                                              // 209
        CommentsCollection.update(findSelector, { $pull: { dislikes: userId } }, noOptOptions);                       // 210
      } else {                                                                                                        // 211
        CommentsCollection.update(findSelector, { $push: { dislikes: userId } }, noOptOptions);                       // 212
      }                                                                                                               // 213
                                                                                                                      //
      updateRatingScoreOnDoc(documentId);                                                                             // 215
                                                                                                                      //
      triggerEvent('comment', 'dislike', Object.assign({}, dislikedDoc, findSelector, {                               // 217
        ratedUserId: userId                                                                                           // 218
      }));                                                                                                            // 217
    }                                                                                                                 // 220
                                                                                                                      //
    return commentsDislike;                                                                                           // 195
  }(),                                                                                                                // 195
  'comments/star': function () {                                                                                      // 221
    function commentsStar(documentId, starsCount, anonUserData) {                                                     // 221
      check(documentId, String);                                                                                      // 222
      check(starsCount, Number);                                                                                      // 223
                                                                                                                      //
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                           // 225
      var userId = this.userId || anonUserData._id;                                                                   // 226
                                                                                                                      //
      if (!userId || Comments.config().rating !== 'stars') {                                                          // 228
        return;                                                                                                       // 229
      }                                                                                                               // 230
                                                                                                                      //
      var findSelector = { _id: documentId };                                                                         // 232
                                                                                                                      //
      var starredDoc = CommentsCollection.findOne({ _id: documentId, 'starRatings.userId': userId });                 // 234
                                                                                                                      //
      if (starredDoc) {                                                                                               // 236
        CommentsCollection.update(findSelector, { $pull: { starRatings: { userId: userId } } }, noOptOptions);        // 237
      }                                                                                                               // 238
                                                                                                                      //
      CommentsCollection.update(findSelector, { $push: { starRatings: { userId: userId, rating: starsCount } } });    // 240
                                                                                                                      //
      updateRatingScoreOnDoc(documentId);                                                                             // 242
                                                                                                                      //
      triggerEvent('comment', 'star', Object.assign({}, starredDoc, findSelector, {                                   // 244
        ratedUserId: userId,                                                                                          // 245
        rating: starsCount                                                                                            // 246
      }));                                                                                                            // 244
    }                                                                                                                 // 248
                                                                                                                      //
    return commentsStar;                                                                                              // 221
  }(),                                                                                                                // 221
  'comments/reply/add': function () {                                                                                 // 249
    function commentsReplyAdd(documentId, docScope, content, anonUserData) {                                          // 249
      var _$push;                                                                                                     // 249
                                                                                                                      //
      check(documentId, String);                                                                                      // 250
      check(docScope, Object);                                                                                        // 251
      check(content, String);                                                                                         // 252
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                           // 253
                                                                                                                      //
      var doc = CommentsCollection.findOne({ _id: documentId }),                                                      // 255
          userId = this.userId || anonUserData._id;                                                                   // 255
                                                                                                                      //
      content = content.trim();                                                                                       // 258
                                                                                                                      //
      if (!doc || !userId || !content || !allowReplies(documentId)) {                                                 // 260
        return false;                                                                                                 // 261
      }                                                                                                               // 262
                                                                                                                      //
      var reply = {                                                                                                   // 264
        replyId: Random.id(),                                                                                         // 265
        content: content,                                                                                             // 266
        userId: userId,                                                                                               // 267
        createdAt: new Date(),                                                                                        // 268
        replies: [], likes: [],                                                                                       // 269
        lastUpdatedAt: new Date(),                                                                                    // 270
        isAnonymous: !!anonUserData._id,                                                                              // 271
        media: mediaService.getMediaFromContent(content),                                                             // 272
        ratingScore: 0                                                                                                // 273
      };                                                                                                              // 264
                                                                                                                      //
      check(reply, CommentsCollection.schemas.ReplySchema);                                                           // 276
                                                                                                                      //
      var fieldDescriptor = 'replies';                                                                                // 278
                                                                                                                      //
      if (docScope.position) {                                                                                        // 280
        if (commentService.denyReply(docScope)) {                                                                     // 281
          throw new Meteor.Error('Cannot have more nesting than 4 levels');                                           // 282
        }                                                                                                             // 283
                                                                                                                      //
        fieldDescriptor = getMongoReplyFieldDescriptor(docScope.position) + '.replies';                               // 285
      }                                                                                                               // 286
                                                                                                                      //
      var modifier = {                                                                                                // 288
        $push: (_$push = {}, _$push[fieldDescriptor] = {                                                              // 289
          $each: [reply],                                                                                             // 291
          $position: 0                                                                                                // 292
        }, _$push)                                                                                                    // 290
      };                                                                                                              // 288
                                                                                                                      //
      var findSelector = { _id: documentId };                                                                         // 297
                                                                                                                      //
      CommentsCollection.update(findSelector, modifier, noOptOptions);                                                // 299
      triggerEvent('reply', 'add', Object.assign({}, reply, findSelector, {                                           // 300
        userId: userId,                                                                                               // 301
        rootUserId: doc.userId                                                                                        // 302
      }));                                                                                                            // 300
    }                                                                                                                 // 304
                                                                                                                      //
    return commentsReplyAdd;                                                                                          // 249
  }(),                                                                                                                // 249
  'comments/reply/edit': function () {                                                                                // 305
    function commentsReplyEdit(documentId, docScope, newContent, anonUserData) {                                      // 305
      check(documentId, String);                                                                                      // 306
      check(docScope, Object);                                                                                        // 307
      check(newContent, String);                                                                                      // 308
                                                                                                                      //
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                           // 310
                                                                                                                      //
      var doc = CommentsCollection.findOne(documentId),                                                               // 312
          userId = this.userId || anonUserData._id;                                                                   // 312
                                                                                                                      //
      var reply = {};                                                                                                 // 315
                                                                                                                      //
      newContent = newContent.trim();                                                                                 // 317
                                                                                                                      //
      if (!userId || !newContent || !allowReplies(documentId)) {                                                      // 319
        return;                                                                                                       // 320
      }                                                                                                               // 321
                                                                                                                      //
      modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                                 // 323
        if (replies[index].userId === userId) {                                                                       // 324
          replies[index].content = newContent;                                                                        // 325
          replies[index].likes = [];                                                                                  // 326
          replies[index].starRatings = [];                                                                            // 327
          replies[index].ratingScore = 0;                                                                             // 328
          replies[index].media = mediaService.getMediaFromContent(newContent);                                        // 329
          reply = replies[index];                                                                                     // 330
        }                                                                                                             // 331
      });                                                                                                             // 332
                                                                                                                      //
      var findSelector = { _id: documentId };                                                                         // 334
                                                                                                                      //
      CommentsCollection.update(findSelector, { $set: { replies: doc.replies } }, noOptOptions);                      // 336
      triggerEvent('reply', 'edit', Object.assign({}, findSelector, reply, {                                          // 337
        ratedUserId: userId,                                                                                          // 338
        rootUserId: doc.userId                                                                                        // 339
      }));                                                                                                            // 337
    }                                                                                                                 // 341
                                                                                                                      //
    return commentsReplyEdit;                                                                                         // 305
  }(),                                                                                                                // 305
  'comments/reply/like': function () {                                                                                // 342
    function commentsReplyLike(documentId, docScope, anonUserData) {                                                  // 342
      check(documentId, String);                                                                                      // 343
      check(docScope, Object);                                                                                        // 344
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                           // 345
                                                                                                                      //
      var doc = CommentsCollection.findOne({ _id: documentId }),                                                      // 347
          userId = this.userId || anonUserData._id;                                                                   // 347
                                                                                                                      //
      if (!userId || !allowReplies(documentId) || !['likes', 'likes-and-dislikes'].includes(Comments.config().rating)) {
        return false;                                                                                                 // 353
      }                                                                                                               // 354
                                                                                                                      //
      var reply = {};                                                                                                 // 356
                                                                                                                      //
      modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                                 // 358
        if (replies[index].likes.indexOf(userId) > -1) {                                                              // 359
          replies[index].likes.splice(replies[index].likes.indexOf(userId), 1);                                       // 360
        } else {                                                                                                      // 361
          replies[index].likes.push(userId);                                                                          // 362
        }                                                                                                             // 363
                                                                                                                      //
        reply = replies[index];                                                                                       // 365
        replies[index].ratingScore = getRatingScore(replies[index]);                                                  // 366
      });                                                                                                             // 367
                                                                                                                      //
      var findSelector = { _id: documentId };                                                                         // 369
                                                                                                                      //
      CommentsCollection.update(findSelector, { $set: { replies: doc.replies } }, noOptOptions);                      // 371
      triggerEvent('reply', 'like', Object.assign({}, reply, findSelector, {                                          // 372
        ratedUserId: userId,                                                                                          // 373
        rootUserId: doc.userId                                                                                        // 374
      }));                                                                                                            // 372
    }                                                                                                                 // 376
                                                                                                                      //
    return commentsReplyLike;                                                                                         // 342
  }(),                                                                                                                // 342
  'comments/reply/dislike': function () {                                                                             // 377
    function commentsReplyDislike(documentId, docScope, anonUserData) {                                               // 377
      check(documentId, String);                                                                                      // 378
      check(docScope, Object);                                                                                        // 379
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                           // 380
                                                                                                                      //
      var doc = CommentsCollection.findOne({ _id: documentId }),                                                      // 382
          userId = this.userId || anonUserData._id;                                                                   // 382
                                                                                                                      //
      if (!userId || !allowReplies(documentId) || !['likes', 'likes-and-dislikes'].includes(Comments.config().rating)) {
        return false;                                                                                                 // 388
      }                                                                                                               // 389
                                                                                                                      //
      var reply = {};                                                                                                 // 391
                                                                                                                      //
      modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                                 // 393
        if (!replies[index].dislikes) {                                                                               // 394
          replies[index].dislikes = [];                                                                               // 395
        }                                                                                                             // 396
                                                                                                                      //
        if (replies[index].dislikes.indexOf(userId) > -1) {                                                           // 398
          replies[index].dislikes.splice(replies[index].dislikes.indexOf(userId), 1);                                 // 399
        } else {                                                                                                      // 400
          replies[index].dislikes.push(userId);                                                                       // 401
        }                                                                                                             // 402
                                                                                                                      //
        reply = replies[index];                                                                                       // 404
        replies[index].ratingScore = getRatingScore(replies[index]);                                                  // 405
      });                                                                                                             // 406
                                                                                                                      //
      var findSelector = { _id: documentId };                                                                         // 408
                                                                                                                      //
      CommentsCollection.update(findSelector, { $set: { replies: doc.replies } }, noOptOptions);                      // 410
      triggerEvent('reply', 'like', Object.assign({}, reply, findSelector, {                                          // 411
        ratedUserId: userId,                                                                                          // 412
        rootUserId: doc.userId                                                                                        // 413
      }));                                                                                                            // 411
    }                                                                                                                 // 415
                                                                                                                      //
    return commentsReplyDislike;                                                                                      // 377
  }(),                                                                                                                // 377
  'comments/reply/star': function () {                                                                                // 416
    function commentsReplyStar(documentId, docScope, starsCount, anonUserData) {                                      // 416
      check(documentId, String);                                                                                      // 417
      check(docScope, Object);                                                                                        // 418
      check(starsCount, Number);                                                                                      // 419
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                           // 420
                                                                                                                      //
      var doc = CommentsCollection.findOne({ _id: documentId }),                                                      // 422
          userId = this.userId || anonUserData._id;                                                                   // 422
                                                                                                                      //
      if (!userId || !allowReplies(documentId) || Comments.config().rating !== 'stars') {                             // 425
        return false;                                                                                                 // 426
      }                                                                                                               // 427
                                                                                                                      //
      var reply = {};                                                                                                 // 429
                                                                                                                      //
      modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                                 // 431
        var starRatings = replies[index].starRatings;                                                                 // 432
                                                                                                                      //
        if (!starRatings) {                                                                                           // 434
          starRatings = [];                                                                                           // 435
        }                                                                                                             // 436
                                                                                                                      //
        var ratings = starRatings;                                                                                    // 438
                                                                                                                      //
        if (_.find(starRatings, function (rating) {                                                                   // 440
          return rating.userId === userId;                                                                            // 440
        })) {                                                                                                         // 440
          ratings = _.filter(starRatings, function (rating) {                                                         // 441
            return rating.userId !== userId;                                                                          // 441
          });                                                                                                         // 441
        }                                                                                                             // 442
                                                                                                                      //
        ratings.push({ userId: userId, rating: starsCount });                                                         // 444
        replies[index].starRatings = ratings;                                                                         // 445
        replies[index].ratingScore = getRatingScore(replies[index]);                                                  // 446
        reply = replies[index];                                                                                       // 447
      });                                                                                                             // 448
                                                                                                                      //
      var findSelector = { _id: documentId };                                                                         // 450
                                                                                                                      //
      CommentsCollection.update(findSelector, { $set: { replies: doc.replies } }, noOptOptions);                      // 452
      triggerEvent('reply', 'star', Object.assign({}, reply, findSelector, {                                          // 453
        ratedUserId: userId,                                                                                          // 454
        rating: starsCount,                                                                                           // 455
        rootUserId: doc.userId                                                                                        // 456
      }));                                                                                                            // 453
    }                                                                                                                 // 458
                                                                                                                      //
    return commentsReplyStar;                                                                                         // 416
  }(),                                                                                                                // 416
  'comments/reply/remove': function () {                                                                              // 459
    function commentsReplyRemove(documentId, docScope, anonUserData) {                                                // 459
      check(documentId, String);                                                                                      // 460
      check(docScope, Object);                                                                                        // 461
      userService.verifyAnonUserData(anonUserData, getReferenceIdByDocumentId(documentId));                           // 462
                                                                                                                      //
      var doc = CommentsCollection.findOne({ _id: documentId }),                                                      // 464
          userId = this.userId || anonUserData._id;                                                                   // 464
                                                                                                                      //
      var reply = {};                                                                                                 // 467
                                                                                                                      //
      if (!userId || !allowReplies(documentId)) {                                                                     // 469
        return;                                                                                                       // 470
      }                                                                                                               // 471
                                                                                                                      //
      modifyNestedReplies(doc.replies, docScope.position, function (replies, index) {                                 // 473
        if (replies[index].userId === userId) {                                                                       // 474
          reply = replies[index];                                                                                     // 475
          replies.splice(index, 1);                                                                                   // 476
        }                                                                                                             // 477
      });                                                                                                             // 478
                                                                                                                      //
      var findSelector = { _id: documentId };                                                                         // 480
                                                                                                                      //
      CommentsCollection.update(findSelector, { $set: { replies: doc.replies } }, noOptOptions);                      // 482
      triggerEvent('reply', 'remove', Object.assign({}, reply, findSelector, {                                        // 483
        rootUserId: doc.userId                                                                                        // 484
      }));                                                                                                            // 483
    }                                                                                                                 // 486
                                                                                                                      //
    return commentsReplyRemove;                                                                                       // 459
  }(),                                                                                                                // 459
  'comments/count': function () {                                                                                     // 487
    function commentsCount(referenceId) {                                                                             // 487
      check(referenceId, String);                                                                                     // 488
      return CommentsCollection.find({ referenceId: referenceId }).count();                                           // 489
    }                                                                                                                 // 490
                                                                                                                      //
    return commentsCount;                                                                                             // 487
  }()                                                                                                                 // 487
});                                                                                                                   // 104
                                                                                                                      //
CommentsCollection.methods = {                                                                                        // 493
  add: function () {                                                                                                  // 494
    function add(referenceId, content) {                                                                              // 494
      return callWithAnonUserData('comments/add', referenceId, content);                                              // 494
    }                                                                                                                 // 494
                                                                                                                      //
    return add;                                                                                                       // 494
  }(),                                                                                                                // 494
  reply: function () {                                                                                                // 495
    function reply(documentId, docScope, content) {                                                                   // 495
      return callWithAnonUserData('comments/reply/add', documentId, docScope, content);                               // 495
    }                                                                                                                 // 495
                                                                                                                      //
    return reply;                                                                                                     // 495
  }(),                                                                                                                // 495
  like: function () {                                                                                                 // 496
    function like(documentId) {                                                                                       // 496
      return callWithAnonUserData('comments/like', documentId);                                                       // 496
    }                                                                                                                 // 496
                                                                                                                      //
    return like;                                                                                                      // 496
  }(),                                                                                                                // 496
  likeReply: function () {                                                                                            // 497
    function likeReply(documentId, docScope) {                                                                        // 497
      return callWithAnonUserData('comments/reply/like', documentId, docScope);                                       // 497
    }                                                                                                                 // 497
                                                                                                                      //
    return likeReply;                                                                                                 // 497
  }(),                                                                                                                // 497
  dislike: function () {                                                                                              // 498
    function dislike(documentId) {                                                                                    // 498
      return callWithAnonUserData('comments/dislike', documentId);                                                    // 498
    }                                                                                                                 // 498
                                                                                                                      //
    return dislike;                                                                                                   // 498
  }(),                                                                                                                // 498
  dislikeReply: function () {                                                                                         // 499
    function dislikeReply(documentId, docScope) {                                                                     // 499
      return callWithAnonUserData('comments/reply/dislike', documentId, docScope);                                    // 499
    }                                                                                                                 // 499
                                                                                                                      //
    return dislikeReply;                                                                                              // 499
  }(),                                                                                                                // 499
  star: function () {                                                                                                 // 500
    function star(documentId, starsCount) {                                                                           // 500
      return callWithAnonUserData('comments/star', documentId, starsCount);                                           // 500
    }                                                                                                                 // 500
                                                                                                                      //
    return star;                                                                                                      // 500
  }(),                                                                                                                // 500
  starReply: function () {                                                                                            // 501
    function starReply(documentId, docScope, starsCount) {                                                            // 501
      return callWithAnonUserData('comments/reply/star', documentId, docScope, starsCount);                           // 501
    }                                                                                                                 // 501
                                                                                                                      //
    return starReply;                                                                                                 // 501
  }(),                                                                                                                // 501
  edit: function () {                                                                                                 // 502
    function edit(documentId, newContent) {                                                                           // 502
      return callWithAnonUserData('comments/edit', documentId, newContent);                                           // 502
    }                                                                                                                 // 502
                                                                                                                      //
    return edit;                                                                                                      // 502
  }(),                                                                                                                // 502
  editReply: function () {                                                                                            // 503
    function editReply(documentId, docScope, content) {                                                               // 503
      return callWithAnonUserData('comments/reply/edit', documentId, docScope, content);                              // 503
    }                                                                                                                 // 503
                                                                                                                      //
    return editReply;                                                                                                 // 503
  }(),                                                                                                                // 503
  remove: function () {                                                                                               // 504
    function remove(documentId) {                                                                                     // 504
      return callWithAnonUserData('comments/remove', documentId);                                                     // 504
    }                                                                                                                 // 504
                                                                                                                      //
    return remove;                                                                                                    // 504
  }(),                                                                                                                // 504
  removeReply: function () {                                                                                          // 505
    function removeReply(documentId, docScope) {                                                                      // 505
      return callWithAnonUserData('comments/reply/remove', documentId, docScope);                                     // 505
    }                                                                                                                 // 505
                                                                                                                      //
    return removeReply;                                                                                               // 505
  }()                                                                                                                 // 505
};                                                                                                                    // 493
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"services":{"media-analyzers":{"image.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/services/media-analyzers/image.js                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var imageAnalyzer = {                                                                                                 // 1
  name: 'image',                                                                                                      // 2
  /**                                                                                                                 // 3
   * @param {String} content                                                                                          //
   *                                                                                                                  //
   * @return {String}                                                                                                 //
   */                                                                                                                 //
  getMediaFromContent: function () {                                                                                  // 8
    function getMediaFromContent(content) {                                                                           // 1
      if (content) {                                                                                                  // 9
        var urls = content.match(/(\S+\.[^/\s]+(\/\S+|\/|))(.jpg|.png|.gif)/g);                                       // 10
                                                                                                                      //
        if (urls && urls[0]) {                                                                                        // 12
          return urls[0];                                                                                             // 13
        }                                                                                                             // 14
      }                                                                                                               // 15
                                                                                                                      //
      return '';                                                                                                      // 17
    }                                                                                                                 // 18
                                                                                                                      //
    return getMediaFromContent;                                                                                       // 1
  }(),                                                                                                                // 1
                                                                                                                      //
  /**                                                                                                                 // 19
   * @param {String} mediaContent                                                                                     //
   *                                                                                                                  //
   * @return {String}                                                                                                 //
   */                                                                                                                 //
  getMarkup: function () {                                                                                            // 24
    function getMarkup(mediaContent) {                                                                                // 24
      return '<img src="' + mediaContent + '" />';                                                                    // 24
    }                                                                                                                 // 24
                                                                                                                      //
    return getMarkup;                                                                                                 // 24
  }()                                                                                                                 // 24
};                                                                                                                    // 1
                                                                                                                      //
module.export("default",exports.default=(imageAnalyzer));                                                             // 27
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"youtube.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/services/media-analyzers/youtube.js                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var youtubeAnalyzer = {                                                                                               // 1
  name: 'youtube',                                                                                                    // 2
  /**                                                                                                                 // 3
   * @see http://stackoverflow.com/questions/19377262/regex-for-youtube-url                                           //
   *                                                                                                                  //
   * @param {String} content                                                                                          //
   *                                                                                                                  //
   * @return {String}                                                                                                 //
   */                                                                                                                 //
  getMediaFromContent: function () {                                                                                  // 10
    function getMediaFromContent(content) {                                                                           // 1
      var parts = /(https?\:\/\/)?(www\.youtube\.com|youtu\.?be)\/([\w\=\?]+)/gm.exec(content);                       // 11
      var mediaContent = '';                                                                                          // 12
                                                                                                                      //
      if (parts && parts[3]) {                                                                                        // 14
        var id = parts[3];                                                                                            // 15
                                                                                                                      //
        if (id.indexOf('v=') > -1) {                                                                                  // 17
          var subParts = /v=([\w]+)+/g.exec(id);                                                                      // 18
                                                                                                                      //
          if (subParts && subParts[1]) {                                                                              // 20
            id = subParts[1];                                                                                         // 21
          }                                                                                                           // 22
        }                                                                                                             // 23
                                                                                                                      //
        mediaContent = 'http://www.youtube.com/embed/' + id;                                                          // 25
      }                                                                                                               // 26
                                                                                                                      //
      return mediaContent;                                                                                            // 28
    }                                                                                                                 // 29
                                                                                                                      //
    return getMediaFromContent;                                                                                       // 1
  }(),                                                                                                                // 1
                                                                                                                      //
  /**                                                                                                                 // 30
   * @param {String} mediaContent                                                                                     //
   *                                                                                                                  //
   * @return {String}                                                                                                 //
   */                                                                                                                 //
  getMarkup: function () {                                                                                            // 35
    function getMarkup(mediaContent) {                                                                                // 35
      return '<iframe src="' + mediaContent + '" type="text/html" frameborder="0"></iframe>';                         // 35
    }                                                                                                                 // 35
                                                                                                                      //
    return getMarkup;                                                                                                 // 35
  }()                                                                                                                 // 35
};                                                                                                                    // 1
                                                                                                                      //
module.export("default",exports.default=(youtubeAnalyzer));                                                           // 38
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"user.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/services/user.js                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var userService = function () {                                                                                       // 1
  if (Meteor.isClient) {                                                                                              // 2
    Meteor.startup(function () {                                                                                      // 3
      userService.setUserData({                                                                                       // 4
        _id: localStorage.getItem('commentsui-anonUserId') || '',                                                     // 5
        salt: localStorage.getItem('commentsui-anonSalt') || ''                                                       // 6
      });                                                                                                             // 4
    });                                                                                                               // 8
  }                                                                                                                   // 9
                                                                                                                      //
  return {                                                                                                            // 11
    /**                                                                                                               // 12
     * Return the user id with logic for anonymous users.                                                             //
     *                                                                                                                //
     * @returns {String}                                                                                              //
     */                                                                                                               //
    getUserId: function () {                                                                                          // 17
      function getUserId() {                                                                                          // 11
        var userId = Meteor.userId();                                                                                 // 18
                                                                                                                      //
        if (!userId && userService.isAnonymous()) {                                                                   // 20
          userId = (this.getUserData() || {})._id;                                                                    // 21
        }                                                                                                             // 22
                                                                                                                      //
        return userId;                                                                                                // 24
      }                                                                                                               // 25
                                                                                                                      //
      return getUserId;                                                                                               // 11
    }(),                                                                                                              // 11
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 27
     * Set reactive user data                                                                                         //
     *                                                                                                                //
     * @param {Object} userData                                                                                       //
     */                                                                                                               //
    setUserData: function () {                                                                                        // 32
      function setUserData(userData) {                                                                                // 11
        Comments.session.set('commentsui-anonData', userData);                                                        // 33
      }                                                                                                               // 34
                                                                                                                      //
      return setUserData;                                                                                             // 11
    }(),                                                                                                              // 11
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 36
     * Return user id and salt as an object                                                                           //
     *                                                                                                                //
     * @returns {Object}                                                                                              //
     */                                                                                                               //
    getUserData: function () {                                                                                        // 41
      function getUserData() {                                                                                        // 11
        return Comments.session.get('commentsui-anonData');                                                           // 42
      }                                                                                                               // 43
                                                                                                                      //
      return getUserData;                                                                                             // 11
    }(),                                                                                                              // 11
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 45
     * Return anonymous user data                                                                                     //
     *                                                                                                                //
     * @returns {Object}                                                                                              //
     */                                                                                                               //
    getAnonymousUserData: function () {                                                                               // 50
      function getAnonymousUserData(_id) {                                                                            // 50
        return AnonymousUserCollection.findOne({ _id: _id });                                                         // 50
      }                                                                                                               // 50
                                                                                                                      //
      return getAnonymousUserData;                                                                                    // 50
    }(),                                                                                                              // 50
                                                                                                                      //
    /**                                                                                                               // 52
     * Return true if current user has changed it's profile data.                                                     //
     */                                                                                                               //
    userHasChanged: function () {                                                                                     // 55
      function userHasChanged(data) {                                                                                 // 11
        var userData = this.getAnonymousUserData(this.getUserData()._id);                                             // 56
                                                                                                                      //
        return data.username && data.email && userData && (userData.username !== data.username || userData.email !== data.email);
      }                                                                                                               // 63
                                                                                                                      //
      return userHasChanged;                                                                                          // 11
    }(),                                                                                                              // 11
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 65
     * Update anonymous user based on given data.                                                                     //
     *                                                                                                                //
     * @param {Object} data                                                                                           //
     * @param {Function} callback                                                                                     //
     */                                                                                                               //
    updateAnonymousUser: function () {                                                                                // 71
      function updateAnonymousUser(data, callback) {                                                                  // 11
        var userData = userService.getUserData();                                                                     // 72
                                                                                                                      //
        // check if user still exists                                                                                 // 74
        if (userData._id && userData.salt && !AnonymousUserCollection.findOne({ _id: userData._id })) {               // 75
          userData._id = null;                                                                                        // 76
          userData.salt = null;                                                                                       // 77
        }                                                                                                             // 78
                                                                                                                      //
        if (!userData._id || !userData.salt) {                                                                        // 80
          AnonymousUserCollection.methods.add(data, function (err, generatedData) {                                   // 81
            if (err) throw new Error(err);                                                                            // 82
                                                                                                                      //
            localStorage.setItem('commentsui-anonUserId', generatedData._id);                                         // 85
            localStorage.setItem('commentsui-anonSalt', generatedData.salt);                                          // 86
            userService.setUserData(generatedData);                                                                   // 87
            callback(data);                                                                                           // 88
          });                                                                                                         // 89
        } else if (this.userHasChanged(data)) {                                                                       // 90
          AnonymousUserCollection.methods.update(userData._id, userData.salt, data, function () {                     // 91
            return callback(data);                                                                                    // 91
          });                                                                                                         // 91
        } else {                                                                                                      // 92
          callback(data);                                                                                             // 93
        }                                                                                                             // 94
      }                                                                                                               // 95
                                                                                                                      //
      return updateAnonymousUser;                                                                                     // 11
    }(),                                                                                                              // 11
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 97
     * @param {String} referenceId                                                                                    //
     *                                                                                                                //
     * @returns {Boolean}                                                                                             //
     */                                                                                                               //
    allowAnonymous: function () {                                                                                     // 102
      function allowAnonymous() {                                                                                     // 102
        var referenceId = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;                   // 102
                                                                                                                      //
        var config = Comments.config();                                                                               // 103
        return config.allowAnonymous ? config.allowAnonymous(referenceId) : config.anonymous;                         // 104
      }                                                                                                               // 105
                                                                                                                      //
      return allowAnonymous;                                                                                          // 102
    }(),                                                                                                              // 102
                                                                                                                      //
    /**                                                                                                               // 107
     * Return true if anonymous form fields should be displayed                                                       //
     *                                                                                                                //
     * @returns {Boolean}                                                                                             //
     */                                                                                                               //
    isAnonymous: function () {                                                                                        // 112
      function isAnonymous() {                                                                                        // 11
        return this.allowAnonymous() && !Meteor.userId();                                                             // 113
      }                                                                                                               // 114
                                                                                                                      //
      return isAnonymous;                                                                                             // 11
    }(),                                                                                                              // 11
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 116
     * Return user information of the provided userId                                                                 //
     *                                                                                                                //
     * @returns {Object}                                                                                              //
     */                                                                                                               //
    getUserById: function () {                                                                                        // 121
      function getUserById(userId) {                                                                                  // 11
        var user = Meteor.users.findOne(userId),                                                                      // 122
            anonymousUser = AnonymousUserCollection.findOne({ _id: userId }),                                         // 122
            generateUsername = Comments.config().generateUsername;                                                    // 122
                                                                                                                      //
        if (user) {                                                                                                   // 126
          var displayName = void 0;                                                                                   // 127
                                                                                                                      //
          if (generateUsername) {                                                                                     // 129
            displayName = generateUsername(user);                                                                     // 130
          } else {                                                                                                    // 131
            // oauth facebook users (maybe others)                                                                    // 132
            if (user.profile) {                                                                                       // 133
              displayName = user.profile.name;                                                                        // 134
            }                                                                                                         // 135
                                                                                                                      //
            if (user.emails && user.emails[0]) {                                                                      // 137
              displayName = user.emails[0].address;                                                                   // 138
            }                                                                                                         // 139
                                                                                                                      //
            if (user.username) {                                                                                      // 141
              displayName = user.username;                                                                            // 142
            }                                                                                                         // 143
          }                                                                                                           // 144
                                                                                                                      //
          return { displayName: displayName };                                                                        // 146
        } else if (anonymousUser) {                                                                                   // 147
          return { displayName: anonymousUser.username };                                                             // 148
        }                                                                                                             // 149
      }                                                                                                               // 150
                                                                                                                      //
      return getUserById;                                                                                             // 11
    }(),                                                                                                              // 11
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 152
     * Throw an error if provided anon user data is invalid.                                                          //
     *                                                                                                                //
     * @params {Object} anonUserData                                                                                  //
     * @params {String} referenceId                                                                                   //
     */                                                                                                               //
    verifyAnonUserData: function () {                                                                                 // 158
      function verifyAnonUserData(anonUserData, referenceId) {                                                        // 11
        if (anonUserData._id) {                                                                                       // 159
          check(anonUserData, {                                                                                       // 160
            _id: String,                                                                                              // 161
            salt: String                                                                                              // 162
          });                                                                                                         // 160
                                                                                                                      //
          if (!this.allowAnonymous(referenceId)) {                                                                    // 165
            throw new Error('Anonymous not allowed');                                                                 // 166
          }                                                                                                           // 167
                                                                                                                      //
          if (Meteor.isServer && !AnonymousUserCollection.findOne(anonUserData)) {                                    // 169
            throw new Error('Invalid anon user data provided');                                                       // 170
          }                                                                                                           // 171
        } else {                                                                                                      // 172
          check(anonUserData, {});                                                                                    // 173
        }                                                                                                             // 174
      }                                                                                                               // 175
                                                                                                                      //
      return verifyAnonUserData;                                                                                      // 11
    }()                                                                                                               // 11
  };                                                                                                                  // 11
}();                                                                                                                  // 177
                                                                                                                      //
module.export("default",exports.default=(userService));                                                               // 179
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"time-tick.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/services/time-tick.js                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var timeTickService = function () {                                                                                   // 1
  var timeTick = new Tracker.Dependency();                                                                            // 2
                                                                                                                      //
  // Reactive moment changes                                                                                          // 4
  Meteor.setInterval(function () {                                                                                    // 5
    return timeTick.changed();                                                                                        // 5
  }, 1000);                                                                                                           // 5
                                                                                                                      //
  moment.locale('en');                                                                                                // 7
                                                                                                                      //
  return {                                                                                                            // 9
    fromNowReactive: function () {                                                                                    // 10
      function fromNowReactive(mmt) {                                                                                 // 9
        timeTick.depend();                                                                                            // 11
        return mmt.fromNow();                                                                                         // 12
      }                                                                                                               // 13
                                                                                                                      //
      return fromNowReactive;                                                                                         // 9
    }()                                                                                                               // 9
  };                                                                                                                  // 9
}();                                                                                                                  // 15
                                                                                                                      //
module.export("default",exports.default=(timeTickService));                                                           // 17
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"media.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/services/media.js                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var mediaService = function () {                                                                                      // 1
  return {                                                                                                            // 2
    getMediaFromContent: function () {                                                                                // 3
      function getMediaFromContent(content) {                                                                         // 2
        var analyzers = Comments.config().mediaAnalyzers;                                                             // 4
        var media = {};                                                                                               // 5
                                                                                                                      //
        if (analyzers && _.isArray(analyzers)) {                                                                      // 7
          _.forEach(analyzers, function (analyzer) {                                                                  // 8
            var mediaContent = analyzer.getMediaFromContent(content);                                                 // 9
                                                                                                                      //
            if (mediaContent && !media.content) {                                                                     // 11
              media = {                                                                                               // 12
                type: analyzer.name,                                                                                  // 13
                content: mediaContent                                                                                 // 14
              };                                                                                                      // 12
            }                                                                                                         // 16
          });                                                                                                         // 17
        }                                                                                                             // 18
                                                                                                                      //
        return media;                                                                                                 // 20
      }                                                                                                               // 21
                                                                                                                      //
      return getMediaFromContent;                                                                                     // 2
    }(),                                                                                                              // 2
    getMarkup: function () {                                                                                          // 22
      function getMarkup(media) {                                                                                     // 2
        var analyzers = Comments.config().mediaAnalyzers;                                                             // 23
                                                                                                                      //
        var filteredAnalyzers = _.filter(analyzers, function (filter) {                                               // 25
          return filter.name === media.type;                                                                          // 26
        });                                                                                                           // 27
                                                                                                                      //
        if (filteredAnalyzers && filteredAnalyzers.length > 0) {                                                      // 29
          return filteredAnalyzers[0].getMarkup(media.content);                                                       // 30
        }                                                                                                             // 31
      }                                                                                                               // 32
                                                                                                                      //
      return getMarkup;                                                                                               // 2
    }()                                                                                                               // 2
  };                                                                                                                  // 2
}();                                                                                                                  // 34
                                                                                                                      //
module.export("default",exports.default=(mediaService));                                                              // 36
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comment.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/services/comment.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export("default",exports.default=({                                                                            // 1
  denyReply: function () {                                                                                            // 2
    function denyReply(scope) {                                                                                       // 2
      return scope.position && scope.position.length >= 4;                                                            // 2
    }                                                                                                                 // 2
                                                                                                                      //
    return denyReply;                                                                                                 // 2
  }()                                                                                                                 // 2
}));                                                                                                                  // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"hashing.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/services/hashing.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var hashingService = {                                                                                                // 1
  /**                                                                                                                 // 2
   * Hash the given data with a random secret.                                                                        //
   *                                                                                                                  //
   * @param {Object} data                                                                                             //
   *                                                                                                                  //
   * @returns {String}                                                                                                //
   */                                                                                                                 //
  hash: function () {                                                                                                 // 9
    function hash(data) {                                                                                             // 1
      return this.getHashFromData(data) + '+' + Random.secret(50);                                                    // 10
    }                                                                                                                 // 11
                                                                                                                      //
    return hash;                                                                                                      // 1
  }(),                                                                                                                // 1
                                                                                                                      //
  /**                                                                                                                 // 12
   * Return a hash from the given data.                                                                               //
   *                                                                                                                  //
   * @param {Object} data                                                                                             //
   *                                                                                                                  //
   * @returns {String}                                                                                                //
   */                                                                                                                 //
  getHashFromData: function () {                                                                                      // 19
    function getHashFromData(data) {                                                                                  // 19
      var hashedSalt = '';                                                                                            // 20
      var anonSalt = Comments.config().anonymousSalt;                                                                 // 21
                                                                                                                      //
      _.times(20, function () {                                                                                       // 23
        hashedSalt += Random.choice(anonSalt) + Random.choice(data.username) + Random.choice(data.email);             // 24
      });                                                                                                             // 25
                                                                                                                      //
      return hashedSalt;                                                                                              // 27
    }                                                                                                                 // 28
                                                                                                                      //
    return getHashFromData;                                                                                           // 19
  }()                                                                                                                 // 19
};                                                                                                                    // 1
                                                                                                                      //
module.export("default",exports.default=(hashingService));                                                            // 31
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"components":{"commentsBox":{"template.commentsBox.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/components/commentsBox/template.commentsBox.js                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("commentsBox");                                                                                  // 2
Template["commentsBox"] = new Template("Template.commentsBox", (function() {                                          // 3
  var view = this;                                                                                                    // 4
  return [ "\n\n  ", Blaze.If(function() {                                                                            // 5
    return Spacebars.call(view.lookup("customBoxTemplate"));                                                          // 6
  }, function() {                                                                                                     // 7
    return [ "\n      ", Spacebars.include(view.lookupTemplate("customBoxTemplate")), "\n    " ];                     // 8
  }, function() {                                                                                                     // 9
    return [ "\n    ", HTML.DIV({                                                                                     // 10
      class: "comments-box"                                                                                           // 11
    }, "\n      ", Blaze.If(function() {                                                                              // 12
      return Spacebars.dataMustache(view.lookup("templateIs"), "bootstrap");                                          // 13
    }, function() {                                                                                                   // 14
      return [ "\n        ", Blaze.If(function() {                                                                    // 15
        return Spacebars.call(view.lookup("customHeaderTemplate"));                                                   // 16
      }, function() {                                                                                                 // 17
        return [ "\n          ", Spacebars.include(view.lookupTemplate("customHeaderTemplate")), "\n        " ];      // 18
      }, function() {                                                                                                 // 19
        return [ "\n          ", HTML.H3(Blaze.View("lookup:commentsBoxTitle", function() {                           // 20
          return Spacebars.mustache(view.lookup("commentsBoxTitle"));                                                 // 21
        })), "\n        " ];                                                                                          // 22
      }), "\n\n        ", Spacebars.include(view.lookupTemplate("commentsSubheader")), "\n\n        ", Blaze.If(function() {
        return Spacebars.dataMustache(view.lookup("sessionGet"), "loginAction");                                      // 24
      }, function() {                                                                                                 // 25
        return [ "\n          ", HTML.DIV({                                                                           // 26
          class: "alert alert-warning",                                                                               // 27
          role: "alert"                                                                                               // 28
        }, Blaze.View("lookup:youNeedToLogin", function() {                                                           // 29
          return Spacebars.mustache(view.lookup("youNeedToLogin"));                                                   // 30
        })), "\n        " ];                                                                                          // 31
      }), "\n\n        ", Spacebars.include(view.lookupTemplate("textarea")), "\n\n        ", Spacebars.include(view.lookupTemplate("commentsList")), "\n      " ];
    }), "\n\n      ", Blaze.If(function() {                                                                           // 33
      return Spacebars.dataMustache(view.lookup("templateIs"), "semantic-ui");                                        // 34
    }, function() {                                                                                                   // 35
      return [ "\n        ", HTML.DIV({                                                                               // 36
        class: "ui comments"                                                                                          // 37
      }, "\n          ", Blaze.If(function() {                                                                        // 38
        return Spacebars.call(view.lookup("customHeaderTemplate"));                                                   // 39
      }, function() {                                                                                                 // 40
        return [ "\n            ", Spacebars.include(view.lookupTemplate("customHeaderTemplate")), "\n          " ];  // 41
      }, function() {                                                                                                 // 42
        return [ "\n            ", HTML.H3({                                                                          // 43
          class: "ui header"                                                                                          // 44
        }, Blaze.View("lookup:commentsBoxTitle", function() {                                                         // 45
          return Spacebars.mustache(view.lookup("commentsBoxTitle"));                                                 // 46
        })), "\n          " ];                                                                                        // 47
      }), "\n\n          ", Spacebars.include(view.lookupTemplate("commentsSubheader")), "\n\n          ", Blaze.If(function() {
        return Spacebars.dataMustache(view.lookup("sessionGet"), "loginAction");                                      // 49
      }, function() {                                                                                                 // 50
        return [ "\n            ", HTML.DIV({                                                                         // 51
          class: "ui warning message"                                                                                 // 52
        }, Blaze.View("lookup:youNeedToLogin", function() {                                                           // 53
          return Spacebars.mustache(view.lookup("youNeedToLogin"));                                                   // 54
        })), "\n          " ];                                                                                        // 55
      }), "\n\n          ", Spacebars.include(view.lookupTemplate("textarea")), "\n\n          ", Spacebars.include(view.lookupTemplate("commentsList")), "\n        "), "\n      " ];
    }), "\n\n      ", Blaze.If(function() {                                                                           // 57
      return Spacebars.dataMustache(view.lookup("templateIs"), "ionic");                                              // 58
    }, function() {                                                                                                   // 59
      return [ "\n        ", Blaze.If(function() {                                                                    // 60
        return Spacebars.call(view.lookup("customHeaderTemplate"));                                                   // 61
      }, function() {                                                                                                 // 62
        return [ "\n          ", Spacebars.include(view.lookupTemplate("customHeaderTemplate")), "\n        " ];      // 63
      }, function() {                                                                                                 // 64
        return [ "\n          ", HTML.H3(Blaze.View("lookup:commentsBoxTitle", function() {                           // 65
          return Spacebars.mustache(view.lookup("commentsBoxTitle"));                                                 // 66
        })), "\n      " ];                                                                                            // 67
      }), "\n\n      ", Spacebars.include(view.lookupTemplate("commentsSubheader")), "\n\n      ", Blaze.If(function() {
        return Spacebars.dataMustache(view.lookup("sessionGet"), "loginAction");                                      // 69
      }, function() {                                                                                                 // 70
        return [ "\n        ", HTML.DIV({                                                                             // 71
          class: "bar bar-header bar-assertive"                                                                       // 72
        }, Blaze.View("lookup:youNeedToLogin", function() {                                                           // 73
          return Spacebars.mustache(view.lookup("youNeedToLogin"));                                                   // 74
        })), "\n      " ];                                                                                            // 75
      }), "\n\n      ", Spacebars.include(view.lookupTemplate("textarea")), "\n\n      ", Spacebars.include(view.lookupTemplate("commentsList")), "\n    " ];
    }), "\n  "), "\n  " ];                                                                                            // 77
  }) ];                                                                                                               // 78
}));                                                                                                                  // 79
                                                                                                                      // 80
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"commentsBox.js":["../../services/user",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/components/commentsBox/commentsBox.js                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var userService;module.import('../../services/user',{"default":function(v){userService=v}});                          // 1
                                                                                                                      //
/**                                                                                                                   // 3
 * Add a comment, reply if the user has permission to do so.                                                          //
 *                                                                                                                    //
 * @param {Object} event                                                                                              //
 * @param {String} type                                                                                               //
 * @param {String} selector                                                                                           //
 * @param {Function} callback                                                                                         //
 */                                                                                                                   //
var addComment = function addComment(event, type, selector, callback) {                                               // 11
  var container = $(event.target).parent();                                                                           // 12
                                                                                                                      //
  if ("submit" === event.type) {                                                                                      // 14
    event.preventDefault();                                                                                           // 15
    executeUserAction(event, type, function (anonymousData) {                                                         // 16
      var textarea = container.find(selector),                                                                        // 17
          value = textarea.val().trim();                                                                              // 17
                                                                                                                      //
      callback(textarea, value, anonymousData);                                                                       // 20
    });                                                                                                               // 21
  }                                                                                                                   // 22
};                                                                                                                    // 23
                                                                                                                      //
/**                                                                                                                   // 25
 * Run user actions, such as adding comments, replying etc.                                                           //
 *                                                                                                                    //
 * @param {Object} event                                                                                              //
 * @param {String} type                                                                                               //
 * @param {Function} callback                                                                                         //
 */                                                                                                                   //
var executeUserAction = function executeUserAction(event, type, callback) {                                           // 32
  if (userService.isAnonymous()) {                                                                                    // 33
    var container = $(event.target).parent(),                                                                         // 34
        anonUserData = {                                                                                              // 34
      username: container.find('.anon-username').val() || '',                                                         // 36
      email: container.find('.anon-email').val() || ''                                                                // 37
    };                                                                                                                // 35
                                                                                                                      //
    userService.updateAnonymousUser(anonUserData, callback);                                                          // 40
  } else {                                                                                                            // 41
    Comments.ui.callIfLoggedIn(type, callback);                                                                       // 42
  }                                                                                                                   // 43
};                                                                                                                    // 44
                                                                                                                      //
var loadMoreDocuments = function () {                                                                                 // 46
  var limit = Comments.ui.config().limit;                                                                             // 47
                                                                                                                      //
  var currentOffset = limit,                                                                                          // 49
      handles = [];                                                                                                   // 49
                                                                                                                      //
  function clearHandles() {                                                                                           // 52
    _.forEach(handles, function (handle) {                                                                            // 53
      return handle.stop();                                                                                           // 53
    });                                                                                                               // 53
    currentOffset = limit;                                                                                            // 54
    handles = [];                                                                                                     // 55
  }                                                                                                                   // 56
                                                                                                                      //
  Template.commentsBox.onDestroyed(function () {                                                                      // 58
    return clearHandles();                                                                                            // 58
  });                                                                                                                 // 58
                                                                                                                      //
  Comments.ui.clearHandles = clearHandles;                                                                            // 60
                                                                                                                      //
  /**                                                                                                                 // 62
   * @param {Object} tplInstance                                                                                      //
   */                                                                                                                 //
  return function (tplInstance) {                                                                                     // 65
    var loadMoreCount = Comments.ui.config().loadMoreCount;                                                           // 66
                                                                                                                      //
    handles.push(Meteor.subscribe('comments/reference', tplInstance.data.id, Comments.ui.getSorting(tplInstance.data.id), loadMoreCount, currentOffset));
                                                                                                                      //
    currentOffset += loadMoreCount;                                                                                   // 72
  };                                                                                                                  // 73
}();                                                                                                                  // 74
                                                                                                                      //
Comments.session.set('content', {});                                                                                  // 76
                                                                                                                      //
Template.commentsBox.onCreated(function () {                                                                          // 78
  var _this = this;                                                                                                   // 78
                                                                                                                      //
  Comments.session.setDefault(this.data.id + '_sorting', Comments.config().sortingOptions[0].value);                  // 79
                                                                                                                      //
  this.autorun(function () {                                                                                          // 81
    Comments.getCount(_this.data.id, function (err, count) {                                                          // 82
      Comments.session.set(_this.data.id + '_count', count);                                                          // 83
    });                                                                                                               // 84
                                                                                                                      //
    if (userService.isAnonymous()) {                                                                                  // 86
      var userData = userService.getUserData();                                                                       // 87
                                                                                                                      //
      Comments.session.set('loginAction', '');                                                                        // 89
                                                                                                                      //
      userData._id && userData.salt && _this.subscribe('comments/anonymous', userData);                               // 91
    }                                                                                                                 // 92
  });                                                                                                                 // 93
                                                                                                                      //
  this.autorun(function () {                                                                                          // 95
    if (Meteor.userId()) {                                                                                            // 96
      Comments.session.set('loginAction', '');                                                                        // 97
    }                                                                                                                 // 98
  });                                                                                                                 // 99
});                                                                                                                   // 100
                                                                                                                      //
Template.commentsBox.helpers(_.extend(defaultCommentHelpers, {                                                        // 102
  customBoxTemplate: function () {                                                                                    // 103
    function customBoxTemplate() {                                                                                    // 102
      return defaultCommentHelpers.getCustomTemplate('boxTemplate', 'commentsBox', this);                             // 104
    }                                                                                                                 // 105
                                                                                                                      //
    return customBoxTemplate;                                                                                         // 102
  }(),                                                                                                                // 102
  customHeaderTemplate: function () {                                                                                 // 106
    function customHeaderTemplate() {                                                                                 // 102
      return defaultCommentHelpers.getCustomTemplate('headerTemplate', 'commentsBox', this);                          // 107
    }                                                                                                                 // 108
                                                                                                                      //
    return customHeaderTemplate;                                                                                      // 102
  }(),                                                                                                                // 102
  commentsBoxTitle: function () {                                                                                     // 109
    function commentsBoxTitle() {                                                                                     // 102
      var title = defaultCommentHelpers.take({                                                                        // 110
        hash: {                                                                                                       // 111
          key: 'title',                                                                                               // 112
          'default': 'Comments'                                                                                       // 113
        }                                                                                                             // 111
      });                                                                                                             // 110
                                                                                                                      //
      var data = Template.instance().data;                                                                            // 117
                                                                                                                      //
      if (data && data.title) {                                                                                       // 119
        title = title + ' for ' + data.title;                                                                         // 120
      }                                                                                                               // 121
                                                                                                                      //
      return title;                                                                                                   // 123
    }                                                                                                                 // 124
                                                                                                                      //
    return commentsBoxTitle;                                                                                          // 102
  }(),                                                                                                                // 102
  youNeedToLogin: function () {                                                                                       // 125
    function youNeedToLogin() {                                                                                       // 102
      var title = defaultCommentHelpers.take({                                                                        // 126
        hash: {                                                                                                       // 127
          key: 'you-need-to-login',                                                                                   // 128
          'default': 'You need to login to'                                                                           // 129
        }                                                                                                             // 127
      });                                                                                                             // 126
                                                                                                                      //
      var defLoginAction = Comments.session.get('loginAction');                                                       // 133
                                                                                                                      //
      var loginAction = defaultCommentHelpers.take({                                                                  // 135
        hash: {                                                                                                       // 136
          key: defLoginAction,                                                                                        // 137
          'default': defLoginAction                                                                                   // 138
        }                                                                                                             // 136
      });                                                                                                             // 135
                                                                                                                      //
      return title + ' ' + loginAction;                                                                               // 142
    }                                                                                                                 // 143
                                                                                                                      //
    return youNeedToLogin;                                                                                            // 102
  }()                                                                                                                 // 102
}));                                                                                                                  // 102
                                                                                                                      //
Template.commentsBox.events({                                                                                         // 146
  'keydown .create-comment, keydown .create-reply': _.debounce(function (e) {                                         // 147
    if (e.originalEvent instanceof KeyboardEvent && e.keyCode === 13 && e.ctrlKey) {                                  // 148
      e.preventDefault();                                                                                             // 149
      $(e.target).closest('form').find('.submit.button').click();                                                     // 150
    }                                                                                                                 // 151
  }, 50),                                                                                                             // 152
  'keydown .anon-email, keydown .anon-username': function () {                                                        // 153
    function keydownAnonEmailKeydownAnonUsername(e) {                                                                 // 153
      if (e.keyCode === 13) {                                                                                         // 154
        e.preventDefault();                                                                                           // 155
      }                                                                                                               // 156
    }                                                                                                                 // 157
                                                                                                                      //
    return keydownAnonEmailKeydownAnonUsername;                                                                       // 153
  }(),                                                                                                                // 153
  'submit .comment-form': function () {                                                                               // 158
    function submitCommentForm(e) {                                                                                   // 158
      var eventScope = this;                                                                                          // 159
                                                                                                                      //
      addComment(e, 'add comments', '.create-comment', function (textarea, trimmedValue, anonData) {                  // 161
        function actuallyAddComment() {                                                                               // 162
          Comments.add(eventScope.id, trimmedValue);                                                                  // 163
          textarea.val('');                                                                                           // 164
        }                                                                                                             // 165
                                                                                                                      //
        if (trimmedValue) {                                                                                           // 167
          if (anonData && anonData.username && anonData.email) {                                                      // 168
            userService.updateAnonymousUser(anonData, function () {                                                   // 169
              return actuallyAddComment();                                                                            // 169
            });                                                                                                       // 169
          } else {                                                                                                    // 170
            actuallyAddComment();                                                                                     // 171
          }                                                                                                           // 172
        }                                                                                                             // 173
      });                                                                                                             // 174
    }                                                                                                                 // 175
                                                                                                                      //
    return submitCommentForm;                                                                                         // 158
  }(),                                                                                                                // 158
  'submit .reply-form': function () {                                                                                 // 176
    function submitReplyForm(e) {                                                                                     // 176
      var eventScope = this.scope;                                                                                    // 177
                                                                                                                      //
      addComment(e, 'add replies', '.create-reply', function (textarea, trimmedValue, anonData) {                     // 179
        function addReply() {                                                                                         // 180
          var id = eventScope._id || eventScope.documentId;                                                           // 181
                                                                                                                      //
          Comments.reply(id, eventScope, trimmedValue);                                                               // 183
          Comments.session.set('replyTo', null);                                                                      // 184
        }                                                                                                             // 185
                                                                                                                      //
        if (trimmedValue) {                                                                                           // 187
          if (anonData) {                                                                                             // 188
            if (anonData.username && anonData.email) {                                                                // 189
              userService.updateAnonymousUser(anonData, function () {                                                 // 190
                return addReply();                                                                                    // 190
              });                                                                                                     // 190
            }                                                                                                         // 191
          } else {                                                                                                    // 192
            addReply();                                                                                               // 193
          }                                                                                                           // 194
        }                                                                                                             // 195
      });                                                                                                             // 196
    }                                                                                                                 // 197
                                                                                                                      //
    return submitReplyForm;                                                                                           // 176
  }(),                                                                                                                // 176
  'click .like-action': function () {                                                                                 // 198
    function clickLikeAction(event) {                                                                                 // 198
      var eventScope = this;                                                                                          // 199
                                                                                                                      //
      executeUserAction(event, 'like comments', function () {                                                         // 201
        if (eventScope._id) {                                                                                         // 202
          Comments.like(eventScope._id);                                                                              // 203
        } else if (eventScope.replyId) {                                                                              // 204
          Comments.likeReply(eventScope.documentId, eventScope);                                                      // 205
        }                                                                                                             // 206
      });                                                                                                             // 207
    }                                                                                                                 // 208
                                                                                                                      //
    return clickLikeAction;                                                                                           // 198
  }(),                                                                                                                // 198
  'click .dislike-action': function () {                                                                              // 209
    function clickDislikeAction(event) {                                                                              // 209
      var eventScope = this;                                                                                          // 210
                                                                                                                      //
      executeUserAction(event, 'dislike comments', function () {                                                      // 212
        if (eventScope._id) {                                                                                         // 213
          Comments.dislike(eventScope._id);                                                                           // 214
        } else if (eventScope.replyId) {                                                                              // 215
          Comments.dislikeReply(eventScope.documentId, eventScope);                                                   // 216
        }                                                                                                             // 217
      });                                                                                                             // 218
    }                                                                                                                 // 219
                                                                                                                      //
    return clickDislikeAction;                                                                                        // 209
  }(),                                                                                                                // 209
  'click .stars-action': function () {                                                                                // 220
    function clickStarsAction(event) {                                                                                // 220
      var eventScope = this;                                                                                          // 221
                                                                                                                      //
      executeUserAction(event, 'rate comments', function () {                                                         // 223
        var starRating = parseInt($(event.target).parents('.stars-action').find('.stars-rating .current-rating').length, 10);
                                                                                                                      //
        if (eventScope._id) {                                                                                         // 229
          Comments.star(eventScope._id, starRating);                                                                  // 230
        } else if (eventScope.replyId) {                                                                              // 231
          Comments.starReply(eventScope.documentId, eventScope, starRating);                                          // 232
        }                                                                                                             // 233
      });                                                                                                             // 234
    }                                                                                                                 // 235
                                                                                                                      //
    return clickStarsAction;                                                                                          // 220
  }(),                                                                                                                // 220
  'click .remove-action': function () {                                                                               // 236
    function clickRemoveAction() {                                                                                    // 236
      var tplScope = Template.currentData(),                                                                          // 237
          eventScope = this;                                                                                          // 237
                                                                                                                      //
      Comments.ui.callIfLoggedIn('remove comments', function () {                                                     // 240
        if (eventScope._id) {                                                                                         // 241
          Comments.remove(eventScope._id);                                                                            // 242
          Comments.session.set(tplScope.id + '_count', Comments.session.get(tplScope.id + '_count') - 1);             // 243
        } else if (eventScope.replyId) {                                                                              // 244
          Comments.removeReply(eventScope.documentId, eventScope);                                                    // 245
        }                                                                                                             // 246
      });                                                                                                             // 247
    }                                                                                                                 // 248
                                                                                                                      //
    return clickRemoveAction;                                                                                         // 236
  }(),                                                                                                                // 236
  'click .reply-action': function () {                                                                                // 249
    function clickReplyAction() {                                                                                     // 249
      var id = this._id || this.replyId;                                                                              // 250
                                                                                                                      //
      if (Comments.session.equals('replyTo', id)) {                                                                   // 252
        id = null;                                                                                                    // 253
      }                                                                                                               // 254
                                                                                                                      //
      Comments.session.set('replyTo', id);                                                                            // 256
    }                                                                                                                 // 257
                                                                                                                      //
    return clickReplyAction;                                                                                          // 249
  }(),                                                                                                                // 249
  'click .edit-action': function () {                                                                                 // 258
    function clickEditAction(e) {                                                                                     // 258
      var id = this._id || this.replyId;                                                                              // 259
                                                                                                                      //
      $('#editComment').remove();                                                                                     // 261
                                                                                                                      //
      $(e.target).closest('.comment').find('.comment-content[data-id="' + id + '"] .text-span').hide().parent().append('\n      <div class="field" id="editComment">\n        <textarea class="edit-comment">' + this.content + '</textarea>\n      </div>');
                                                                                                                      //
      Comments.session.set('editingDocument', id);                                                                    // 273
    }                                                                                                                 // 274
                                                                                                                      //
    return clickEditAction;                                                                                           // 258
  }(),                                                                                                                // 258
  'click .save-action': function () {                                                                                 // 275
    function clickSaveAction(e) {                                                                                     // 275
      var id = this._id || this.replyId;                                                                              // 276
      var contentBox = $(e.target).closest('.comment').find('.comment-content[data-id="' + id + '"] .text-span');     // 277
      var editCommentWrapper = $('#editComment');                                                                     // 278
      var newContent = editCommentWrapper.find('textarea').val().trim();                                              // 279
                                                                                                                      //
      if (!newContent) {                                                                                              // 281
        return null;                                                                                                  // 282
      }                                                                                                               // 283
                                                                                                                      //
      editCommentWrapper.remove();                                                                                    // 285
      contentBox.show();                                                                                              // 286
                                                                                                                      //
      Comments.session.set('editingDocument', '');                                                                    // 288
                                                                                                                      //
      if (this.content !== newContent) {                                                                              // 290
        contentBox.html('');                                                                                          // 291
        if (this._id) {                                                                                               // 292
          Comments.edit(id, newContent);                                                                              // 293
        } else if (this.replyId) {                                                                                    // 294
          Comments.editReply(this.documentId, this, newContent);                                                      // 295
        }                                                                                                             // 296
      }                                                                                                               // 297
    }                                                                                                                 // 298
                                                                                                                      //
    return clickSaveAction;                                                                                           // 275
  }(),                                                                                                                // 275
  'click .loadmore-action': function () {                                                                             // 299
    function clickLoadmoreAction() {                                                                                  // 299
      return loadMoreDocuments(Template.instance());                                                                  // 299
    }                                                                                                                 // 299
                                                                                                                      //
    return clickLoadmoreAction;                                                                                       // 299
  }()                                                                                                                 // 299
});                                                                                                                   // 146
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"commentsSingleComment":{"template.commentsSingleComment.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/components/commentsSingleComment/template.commentsSingleComment.js                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("commentsSingleComment");                                                                        // 2
Template["commentsSingleComment"] = new Template("Template.commentsSingleComment", (function() {                      // 3
  var view = this;                                                                                                    // 4
  return Blaze.If(function() {                                                                                        // 5
    return Spacebars.call(view.lookup("customSingleCommentTemplate"));                                                // 6
  }, function() {                                                                                                     // 7
    return [ "\n    ", Spacebars.include(view.lookupTemplate("customSingleCommentTemplate")), "\n  " ];               // 8
  }, function() {                                                                                                     // 9
    return [ "\n  ", Blaze.If(function() {                                                                            // 10
      return Spacebars.dataMustache(view.lookup("templateIs"), "semantic-ui");                                        // 11
    }, function() {                                                                                                   // 12
      return [ "\n    ", HTML.DIV({                                                                                   // 13
        "data-id": function() {                                                                                       // 14
          return Spacebars.mustache(view.lookup("_id"));                                                              // 15
        },                                                                                                            // 16
        class: function() {                                                                                           // 17
          return [ "comment ", Blaze.If(function() {                                                                  // 18
            return Spacebars.call(view.lookup("isOwnComment"));                                                       // 19
          }, function() {                                                                                             // 20
            return "own-comment";                                                                                     // 21
          }) ];                                                                                                       // 22
        }                                                                                                             // 23
      }, "\n      ", HTML.A({                                                                                         // 24
        class: "avatar"                                                                                               // 25
      }, "\n        ", HTML.IMG({                                                                                     // 26
        alt: function() {                                                                                             // 27
          return [ "Avatar of ", Spacebars.mustache(Spacebars.dot(view.lookup("user"), "displayName")) ];             // 28
        },                                                                                                            // 29
        src: function() {                                                                                             // 30
          return Spacebars.mustache(view.lookup("avatarUrl"));                                                        // 31
        }                                                                                                             // 32
      }), "\n      "), "\n      ", HTML.DIV({                                                                         // 33
        class: "content"                                                                                              // 34
      }, "\n        ", HTML.A({                                                                                       // 35
        class: "author"                                                                                               // 36
      }, Blaze.View("lookup:user.displayName", function() {                                                           // 37
        return Spacebars.mustache(Spacebars.dot(view.lookup("user"), "displayName"));                                 // 38
      })), "\n        ", HTML.DIV({                                                                                   // 39
        class: "metadata"                                                                                             // 40
      }, "\n          ", HTML.SPAN({                                                                                  // 41
        class: "date"                                                                                                 // 42
      }, Blaze.View("lookup:createdAgo", function() {                                                                 // 43
        return Spacebars.mustache(view.lookup("createdAgo"));                                                         // 44
      })), "\n        "), "\n        ", HTML.DIV({                                                                    // 45
        class: "text comment-content",                                                                                // 46
        "data-id": function() {                                                                                       // 47
          return Spacebars.mustache(view.lookup("commentId"));                                                        // 48
        }                                                                                                             // 49
      }, "\n          ", Blaze.If(function() {                                                                        // 50
        return Spacebars.dataMustache(view.lookup("uiConfigGet"), "markdown");                                        // 51
      }, function() {                                                                                                 // 52
        return [ "\n            ", HTML.DIV({                                                                         // 53
          class: "text-span"                                                                                          // 54
        }, Spacebars.include(view.lookupTemplate("markdown"), function() {                                            // 55
          return Blaze.View("lookup:content", function() {                                                            // 56
            return Spacebars.mustache(view.lookup("content"));                                                        // 57
          });                                                                                                         // 58
        })), "\n          " ];                                                                                        // 59
      }, function() {                                                                                                 // 60
        return [ "\n            ", HTML.DIV({                                                                         // 61
          class: "text-span"                                                                                          // 62
        }, Blaze.View("lookup:enhancedContent", function() {                                                          // 63
          return Spacebars.makeRaw(Spacebars.mustache(view.lookup("enhancedContent")));                               // 64
        })), "\n          " ];                                                                                        // 65
      }), "\n        "), "\n        ", Blaze.If(function() {                                                          // 66
        return Spacebars.call(Spacebars.dot(view.lookup("media"), "content"));                                        // 67
      }, function() {                                                                                                 // 68
        return [ "\n          ", HTML.DIV({                                                                           // 69
          class: "content-media"                                                                                      // 70
        }, "\n            ", Blaze.View("lookup:mediaContent", function() {                                           // 71
          return Spacebars.makeRaw(Spacebars.mustache(view.lookup("mediaContent")));                                  // 72
        }), "\n          "), "\n        " ];                                                                          // 73
      }), "\n        ", HTML.DIV({                                                                                    // 74
        class: "actions"                                                                                              // 75
      }, "\n          ", Blaze.If(function() {                                                                        // 76
        return Spacebars.dataMustache(view.lookup("isRating"), "likes", "likes-and-dislikes");                        // 77
      }, function() {                                                                                                 // 78
        return [ "\n            ", HTML.A({                                                                           // 79
          class: function() {                                                                                         // 80
            return [ "rating unstyled-link like-action ", Blaze.If(function() {                                       // 81
              return Spacebars.call(view.lookup("hasLiked"));                                                         // 82
            }, function() {                                                                                           // 83
              return "active";                                                                                        // 84
            }) ];                                                                                                     // 85
          }                                                                                                           // 86
        }, "\n              ", Blaze.View("lookup:likesCount", function() {                                           // 87
          return Spacebars.mustache(view.lookup("likesCount"));                                                       // 88
        }), "\n              ", HTML.I({                                                                              // 89
          class: "angle up link icon"                                                                                 // 90
        }), "\n            "), "\n          " ];                                                                      // 91
      }), "\n\n          ", Blaze.If(function() {                                                                     // 92
        return Spacebars.dataMustache(view.lookup("isRating"), "likes-and-dislikes");                                 // 93
      }, function() {                                                                                                 // 94
        return [ "\n            ", HTML.A({                                                                           // 95
          class: function() {                                                                                         // 96
            return [ "rating unstyled-link dislike-action ", Blaze.If(function() {                                    // 97
              return Spacebars.call(view.lookup("hasDisliked"));                                                      // 98
            }, function() {                                                                                           // 99
              return "active";                                                                                        // 100
            }) ];                                                                                                     // 101
          }                                                                                                           // 102
        }, "\n              ", Blaze.View("lookup:dislikesCount", function() {                                        // 103
          return Spacebars.mustache(view.lookup("dislikesCount"));                                                    // 104
        }), "\n              ", HTML.I({                                                                              // 105
          class: "angle down link icon"                                                                               // 106
        }), "\n            "), "\n          " ];                                                                      // 107
      }), "\n\n          ", Blaze.If(function() {                                                                     // 108
        return Spacebars.dataMustache(view.lookup("isRating"), "stars");                                              // 109
      }, function() {                                                                                                 // 110
        return [ "\n            ", HTML.A({                                                                           // 111
          class: "rating unstyled-link stars-action"                                                                  // 112
        }, "\n              ", Blaze.Let({                                                                            // 113
          ratingCount: function() {                                                                                   // 114
            return Spacebars.call(Spacebars.dot(view.lookup("rating"), "rating"));                                    // 115
          },                                                                                                          // 116
          ratingClass: function() {                                                                                   // 117
            return Spacebars.call(Spacebars.dataMustache(view.lookup("getRatingClass"), Spacebars.dot(view.lookup("rating"), "type")));
          }                                                                                                           // 119
        }, function() {                                                                                               // 120
          return [ "\n                ", Blaze._TemplateWith(function() {                                             // 121
            return {                                                                                                  // 122
              rating: Spacebars.call(view.lookup("ratingCount")),                                                     // 123
              size: Spacebars.call(10),                                                                               // 124
              class: Spacebars.call(view.lookup("ratingClass")),                                                      // 125
              mutable: Spacebars.call(view.lookup("canRate"))                                                         // 126
            };                                                                                                        // 127
          }, function() {                                                                                             // 128
            return Spacebars.include(view.lookupTemplate("starsRating"));                                             // 129
          }), "\n              " ];                                                                                   // 130
        }), "\n            "), "\n          " ];                                                                      // 131
      }), "\n\n          ", Blaze.If(function() {                                                                     // 132
        return Spacebars.dataMustache(view.lookup("allowReplies"), view.lookup("_id"));                               // 133
      }, function() {                                                                                                 // 134
        return [ "\n            ", HTML.A({                                                                           // 135
          class: "reply-action"                                                                                       // 136
        }, Blaze.View("lookup:take", function() {                                                                     // 137
          return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                               // 138
            key: "reply",                                                                                             // 139
            default: "Reply"                                                                                          // 140
          }));                                                                                                        // 141
        })), "\n          " ];                                                                                        // 142
      }), "\n          ", Blaze.Each(function() {                                                                     // 143
        return Spacebars.call(view.lookup("commentAction"));                                                          // 144
      }, function() {                                                                                                 // 145
        return [ "\n            ", HTML.A({                                                                           // 146
          class: function() {                                                                                         // 147
            return Spacebars.mustache(view.lookup("cssClass"));                                                       // 148
          }                                                                                                           // 149
        }, Blaze.View("lookup:take", function() {                                                                     // 150
          return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                               // 151
            key: Spacebars.dot(view.lookup("text"), "key"),                                                           // 152
            default: Spacebars.dot(view.lookup("text"), "defaultText")                                                // 153
          }));                                                                                                        // 154
        })), "\n          " ];                                                                                        // 155
      }), "\n          ", Blaze.If(function() {                                                                       // 156
        return Spacebars.call(view.lookup("isChangeable"));                                                           // 157
      }, function() {                                                                                                 // 158
        return [ "\n            ", Blaze.If(function() {                                                              // 159
          return Spacebars.call(view.lookup("isEditable"));                                                           // 160
        }, function() {                                                                                               // 161
          return [ "\n              ", HTML.A({                                                                       // 162
            class: "save-action"                                                                                      // 163
          }, Blaze.View("lookup:take", function() {                                                                   // 164
            return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                             // 165
              key: "save",                                                                                            // 166
              default: "Save"                                                                                         // 167
            }));                                                                                                      // 168
          })), "\n            " ];                                                                                    // 169
        }, function() {                                                                                               // 170
          return [ "\n              ", HTML.A({                                                                       // 171
            class: "edit-action"                                                                                      // 172
          }, Blaze.View("lookup:take", function() {                                                                   // 173
            return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                             // 174
              key: "edit",                                                                                            // 175
              default: "Edit"                                                                                         // 176
            }));                                                                                                      // 177
          })), "\n            " ];                                                                                    // 178
        }), "\n            ", HTML.A({                                                                                // 179
          class: "remove-action"                                                                                      // 180
        }, Blaze.View("lookup:take", function() {                                                                     // 181
          return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                               // 182
            key: "remove",                                                                                            // 183
            default: "Remove"                                                                                         // 184
          }));                                                                                                        // 185
        })), "\n          " ];                                                                                        // 186
      }), "\n        "), "\n        ", HTML.DIV({                                                                     // 187
        class: "create-reply"                                                                                         // 188
      }, "\n          ", Blaze.If(function() {                                                                        // 189
        return Spacebars.call(view.lookup("addReply"));                                                               // 190
      }, function() {                                                                                                 // 191
        return [ "\n            ", Blaze._TemplateWith(function() {                                                   // 192
          return {                                                                                                    // 193
            reply: Spacebars.call(true),                                                                              // 194
            scope: Spacebars.call(view.lookup("."))                                                                   // 195
          };                                                                                                          // 196
        }, function() {                                                                                               // 197
          return Spacebars.include(view.lookupTemplate("textarea"));                                                  // 198
        }), "\n          " ];                                                                                         // 199
      }), "\n        "), "\n\n        ", Blaze.If(function() {                                                        // 200
        return Spacebars.call(view.lookup("reply"));                                                                  // 201
      }, function() {                                                                                                 // 202
        return [ "\n        ", HTML.DIV({                                                                             // 203
          class: "comments reply-wrapper"                                                                             // 204
        }, "\n          ", Blaze.Each(function() {                                                                    // 205
          return Spacebars.call(view.lookup("reply"));                                                                // 206
        }, function() {                                                                                               // 207
          return [ "\n            ", Spacebars.include(view.lookupTemplate("commentsSingleComment")), "\n          " ];
        }), "\n        "), "\n        " ];                                                                            // 209
      }), "\n      "), "\n    "), "\n  " ];                                                                           // 210
    }), "\n\n  ", Blaze.If(function() {                                                                               // 211
      return Spacebars.dataMustache(view.lookup("templateIs"), "bootstrap");                                          // 212
    }, function() {                                                                                                   // 213
      return [ "\n    ", HTML.DIV({                                                                                   // 214
        class: "media"                                                                                                // 215
      }, "\n      ", HTML.DIV({                                                                                       // 216
        class: "media-left"                                                                                           // 217
      }, "\n        ", HTML.IMG({                                                                                     // 218
        alt: function() {                                                                                             // 219
          return [ "Avatar of ", Spacebars.mustache(Spacebars.dot(view.lookup("user"), "displayName")) ];             // 220
        },                                                                                                            // 221
        class: "img-thumbnail img-avatar",                                                                            // 222
        src: function() {                                                                                             // 223
          return Spacebars.mustache(view.lookup("avatarUrl"));                                                        // 224
        }                                                                                                             // 225
      }), "\n      "), "\n      ", HTML.DIV({                                                                         // 226
        class: function() {                                                                                           // 227
          return [ "media-body comment ", Blaze.If(function() {                                                       // 228
            return Spacebars.call(view.lookup("isOwnComment"));                                                       // 229
          }, function() {                                                                                             // 230
            return "own-comment";                                                                                     // 231
          }) ];                                                                                                       // 232
        }                                                                                                             // 233
      }, "\n        ", HTML.H4({                                                                                      // 234
        class: "media-heading"                                                                                        // 235
      }, Blaze.View("lookup:user.displayName", function() {                                                           // 236
        return Spacebars.mustache(Spacebars.dot(view.lookup("user"), "displayName"));                                 // 237
      }), " ", HTML.SMALL(Blaze.View("lookup:createdAgo", function() {                                                // 238
        return Spacebars.mustache(view.lookup("createdAgo"));                                                         // 239
      }))), "\n        ", HTML.DIV({                                                                                  // 240
        class: "content"                                                                                              // 241
      }, "\n          ", HTML.P({                                                                                     // 242
        class: "comment-content",                                                                                     // 243
        "data-id": function() {                                                                                       // 244
          return Spacebars.mustache(view.lookup("commentId"));                                                        // 245
        }                                                                                                             // 246
      }, "\n            ", Blaze.If(function() {                                                                      // 247
        return Spacebars.dataMustache(view.lookup("uiConfigGet"), "markdown");                                        // 248
      }, function() {                                                                                                 // 249
        return [ "\n              ", HTML.DIV({                                                                       // 250
          class: "text-span"                                                                                          // 251
        }, Spacebars.include(view.lookupTemplate("markdown"), function() {                                            // 252
          return Blaze.View("lookup:content", function() {                                                            // 253
            return Spacebars.mustache(view.lookup("content"));                                                        // 254
          });                                                                                                         // 255
        })), "\n            " ];                                                                                      // 256
      }, function() {                                                                                                 // 257
        return [ "\n              ", HTML.DIV({                                                                       // 258
          class: "text-span"                                                                                          // 259
        }, Blaze.View("lookup:enhancedContent", function() {                                                          // 260
          return Spacebars.makeRaw(Spacebars.mustache(view.lookup("enhancedContent")));                               // 261
        })), "\n            " ];                                                                                      // 262
      }), "\n          "), "\n\n          ", Blaze.If(function() {                                                    // 263
        return Spacebars.call(Spacebars.dot(view.lookup("media"), "content"));                                        // 264
      }, function() {                                                                                                 // 265
        return [ "\n            ", HTML.DIV({                                                                         // 266
          class: "content-media"                                                                                      // 267
        }, "\n              ", Blaze.View("lookup:mediaContent", function() {                                         // 268
          return Spacebars.makeRaw(Spacebars.mustache(view.lookup("mediaContent")));                                  // 269
        }), "\n            "), "\n          " ];                                                                      // 270
      }), "\n\n          ", HTML.DIV({                                                                                // 271
        class: "actions btn-group btn-group-xs"                                                                       // 272
      }, "\n            ", Blaze.If(function() {                                                                      // 273
        return Spacebars.dataMustache(view.lookup("isRating"), "likes", "likes-and-dislikes");                        // 274
      }, function() {                                                                                                 // 275
        return [ "\n              ", HTML.DIV({                                                                       // 276
          class: function() {                                                                                         // 277
            return [ "btn ", Blaze.If(function() {                                                                    // 278
              return Spacebars.call(view.lookup("hasLiked"));                                                         // 279
            }, function() {                                                                                           // 280
              return "btn-primary";                                                                                   // 281
            }, function() {                                                                                           // 282
              return "btn-default";                                                                                   // 283
            }), " like-action" ];                                                                                     // 284
          },                                                                                                          // 285
          "aria-label": "Left Align"                                                                                  // 286
        }, "\n                ", HTML.SMALL(Blaze.View("lookup:likesCount", function() {                              // 287
          return Spacebars.mustache(view.lookup("likesCount"));                                                       // 288
        })), "\n                ", HTML.SPAN({                                                                        // 289
          class: "glyphicon glyphicon-thumbs-up",                                                                     // 290
          "aria-hidden": "true"                                                                                       // 291
        }), "\n              "), "\n            " ];                                                                  // 292
      }), "\n\n            ", Blaze.If(function() {                                                                   // 293
        return Spacebars.dataMustache(view.lookup("isRating"), "stars");                                              // 294
      }, function() {                                                                                                 // 295
        return [ "\n              ", HTML.DIV({                                                                       // 296
          class: "btn btn-default unstyled-link stars-action"                                                         // 297
        }, "\n                ", Blaze.Let({                                                                          // 298
          ratingCount: function() {                                                                                   // 299
            return Spacebars.call(Spacebars.dot(view.lookup("rating"), "rating"));                                    // 300
          },                                                                                                          // 301
          ratingClass: function() {                                                                                   // 302
            return Spacebars.call(Spacebars.dataMustache(view.lookup("getRatingClass"), Spacebars.dot(view.lookup("rating"), "type")));
          }                                                                                                           // 304
        }, function() {                                                                                               // 305
          return [ "\n                  ", Blaze._TemplateWith(function() {                                           // 306
            return {                                                                                                  // 307
              rating: Spacebars.call(view.lookup("ratingCount")),                                                     // 308
              size: Spacebars.call(10),                                                                               // 309
              class: Spacebars.call(view.lookup("ratingClass")),                                                      // 310
              mutable: Spacebars.call(view.lookup("canRate"))                                                         // 311
            };                                                                                                        // 312
          }, function() {                                                                                             // 313
            return Spacebars.include(view.lookupTemplate("starsRating"));                                             // 314
          }), "\n                " ];                                                                                 // 315
        }), "\n              "), "\n            " ];                                                                  // 316
      }), "\n\n            ", Blaze.If(function() {                                                                   // 317
        return Spacebars.dataMustache(view.lookup("allowReplies"), view.lookup("_id"));                               // 318
      }, function() {                                                                                                 // 319
        return [ "\n              ", HTML.DIV({                                                                       // 320
          class: "btn btn-default reply-action",                                                                      // 321
          "aria-label": "Left Align"                                                                                  // 322
        }, "\n                ", Blaze.View("lookup:take", function() {                                               // 323
          return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                               // 324
            key: "reply",                                                                                             // 325
            default: "Reply"                                                                                          // 326
          }));                                                                                                        // 327
        }), "\n              "), "\n            " ];                                                                  // 328
      }), "\n\n            ", Blaze.If(function() {                                                                   // 329
        return Spacebars.call(view.lookup("isChangeable"));                                                           // 330
      }, function() {                                                                                                 // 331
        return [ "\n              ", Blaze.If(function() {                                                            // 332
          return Spacebars.call(view.lookup("isEditable"));                                                           // 333
        }, function() {                                                                                               // 334
          return [ "\n                ", HTML.DIV({                                                                   // 335
            class: "btn btn-default save-action",                                                                     // 336
            "aria-label": "Left Align"                                                                                // 337
          }, "\n                  ", Blaze.View("lookup:take", function() {                                           // 338
            return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                             // 339
              key: "save",                                                                                            // 340
              default: "Save"                                                                                         // 341
            }));                                                                                                      // 342
          }), "\n                "), "\n              " ];                                                            // 343
        }, function() {                                                                                               // 344
          return [ "\n                ", HTML.DIV({                                                                   // 345
            class: "btn btn-default edit-action",                                                                     // 346
            "aria-label": "Left Align"                                                                                // 347
          }, "\n                  ", Blaze.View("lookup:take", function() {                                           // 348
            return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                             // 349
              key: "edit",                                                                                            // 350
              default: "Edit"                                                                                         // 351
            }));                                                                                                      // 352
          }), "\n                "), "\n              " ];                                                            // 353
        }), "\n              ", HTML.DIV({                                                                            // 354
          class: "btn btn-danger remove-action",                                                                      // 355
          "aria-label": "Left Align"                                                                                  // 356
        }, "\n                ", Blaze.View("lookup:take", function() {                                               // 357
          return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                               // 358
            key: "remove",                                                                                            // 359
            default: "Remove"                                                                                         // 360
          }));                                                                                                        // 361
        }), "\n              "), "\n            " ];                                                                  // 362
      }), "\n          "), "\n        "), "\n\n        ", Blaze.If(function() {                                       // 363
        return Spacebars.call(view.lookup("addReply"));                                                               // 364
      }, function() {                                                                                                 // 365
        return [ "\n          ", HTML.DIV({                                                                           // 366
          class: "create-reply"                                                                                       // 367
        }, "\n            ", Blaze._TemplateWith(function() {                                                         // 368
          return {                                                                                                    // 369
            reply: Spacebars.call(true),                                                                              // 370
            scope: Spacebars.call(view.lookup("."))                                                                   // 371
          };                                                                                                          // 372
        }, function() {                                                                                               // 373
          return Spacebars.include(view.lookupTemplate("textarea"));                                                  // 374
        }), "\n          "), "\n        " ];                                                                          // 375
      }), "\n\n        ", Blaze.If(function() {                                                                       // 376
        return Spacebars.call(view.lookup("reply"));                                                                  // 377
      }, function() {                                                                                                 // 378
        return [ "\n          ", Blaze.Each(function() {                                                              // 379
          return Spacebars.call(view.lookup("reply"));                                                                // 380
        }, function() {                                                                                               // 381
          return [ "\n            ", Spacebars.include(view.lookupTemplate("commentsSingleComment")), "\n          " ];
        }), "\n        " ];                                                                                           // 383
      }), "\n      "), "\n    "), "\n  " ];                                                                           // 384
    }), "\n\n  ", Blaze.If(function() {                                                                               // 385
      return Spacebars.dataMustache(view.lookup("templateIs"), "ionic");                                              // 386
    }, function() {                                                                                                   // 387
      return [ "\n    ", HTML.DIV({                                                                                   // 388
        class: "list card"                                                                                            // 389
      }, "\n      ", HTML.DIV({                                                                                       // 390
        class: "item item-avatar"                                                                                     // 391
      }, "\n        ", HTML.IMG({                                                                                     // 392
        alt: function() {                                                                                             // 393
          return [ "Avatar of ", Spacebars.mustache(Spacebars.dot(view.lookup("user"), "displayName")) ];             // 394
        },                                                                                                            // 395
        src: function() {                                                                                             // 396
          return Spacebars.mustache(view.lookup("avatarUrl"));                                                        // 397
        }                                                                                                             // 398
      }), "\n        ", HTML.P(HTML.SMALL(Blaze.View("lookup:createdAgo", function() {                                // 399
        return Spacebars.mustache(view.lookup("createdAgo"));                                                         // 400
      }))), "\n        ", HTML.P(HTML.STRONG(Blaze.View("lookup:user.displayName", function() {                       // 401
        return Spacebars.mustache(Spacebars.dot(view.lookup("user"), "displayName"));                                 // 402
      }))), "\n      "), "\n\n      ", HTML.DIV({                                                                     // 403
        class: function() {                                                                                           // 404
          return [ "item item-body comment ", Blaze.If(function() {                                                   // 405
            return Spacebars.call(view.lookup("isOwnComment"));                                                       // 406
          }, function() {                                                                                             // 407
            return "own-comment";                                                                                     // 408
          }) ];                                                                                                       // 409
        }                                                                                                             // 410
      }, "\n        ", HTML.P({                                                                                       // 411
        class: "comment-content",                                                                                     // 412
        "data-id": function() {                                                                                       // 413
          return Spacebars.mustache(view.lookup("commentId"));                                                        // 414
        }                                                                                                             // 415
      }, "\n          ", Blaze.If(function() {                                                                        // 416
        return Spacebars.dataMustache(view.lookup("uiConfigGet"), "markdown");                                        // 417
      }, function() {                                                                                                 // 418
        return [ "\n            ", HTML.DIV({                                                                         // 419
          class: "text-span"                                                                                          // 420
        }, Spacebars.include(view.lookupTemplate("markdown"), function() {                                            // 421
          return Blaze.View("lookup:content", function() {                                                            // 422
            return Spacebars.mustache(view.lookup("content"));                                                        // 423
          });                                                                                                         // 424
        })), "\n          " ];                                                                                        // 425
      }, function() {                                                                                                 // 426
        return [ "\n            ", HTML.DIV({                                                                         // 427
          class: "text-span"                                                                                          // 428
        }, Blaze.View("lookup:enhancedContent", function() {                                                          // 429
          return Spacebars.makeRaw(Spacebars.mustache(view.lookup("enhancedContent")));                               // 430
        })), "\n          " ];                                                                                        // 431
      }), "\n        "), "\n\n        ", Blaze.If(function() {                                                        // 432
        return Spacebars.call(Spacebars.dot(view.lookup("media"), "content"));                                        // 433
      }, function() {                                                                                                 // 434
        return [ "\n          ", HTML.DIV({                                                                           // 435
          class: "content-media"                                                                                      // 436
        }, "\n            ", Blaze.View("lookup:mediaContent", function() {                                           // 437
          return Spacebars.makeRaw(Spacebars.mustache(view.lookup("mediaContent")));                                  // 438
        }), "\n          "), "\n        " ];                                                                          // 439
      }), "\n\n        ", HTML.DIV({                                                                                  // 440
        class: "actions"                                                                                              // 441
      }, "\n          ", HTML.DIV({                                                                                   // 442
        class: "button-bar"                                                                                           // 443
      }, "\n            ", Blaze.If(function() {                                                                      // 444
        return Spacebars.dataMustache(view.lookup("isRating"), "likes", "likes-and-dislikes");                        // 445
      }, function() {                                                                                                 // 446
        return [ "\n              ", HTML.A({                                                                         // 447
          class: function() {                                                                                         // 448
            return [ "button button-clear ", Blaze.If(function() {                                                    // 449
              return Spacebars.call(view.lookup("hasLiked"));                                                         // 450
            }, function() {                                                                                           // 451
              return "button-positive";                                                                               // 452
            }), " icon-left ion-thumbsup like-action" ];                                                              // 453
          }                                                                                                           // 454
        }, "\n                ", Blaze.View("lookup:likesCount", function() {                                         // 455
          return Spacebars.mustache(view.lookup("likesCount"));                                                       // 456
        }), "\n              "), "\n            " ];                                                                  // 457
      }), "\n\n            ", Blaze.If(function() {                                                                   // 458
        return Spacebars.dataMustache(view.lookup("isRating"), "stars");                                              // 459
      }, function() {                                                                                                 // 460
        return [ "\n              ", HTML.DIV({                                                                       // 461
          class: "stars-action"                                                                                       // 462
        }, "\n                ", Blaze.Let({                                                                          // 463
          ratingCount: function() {                                                                                   // 464
            return Spacebars.call(Spacebars.dot(view.lookup("rating"), "rating"));                                    // 465
          },                                                                                                          // 466
          ratingClass: function() {                                                                                   // 467
            return Spacebars.call(Spacebars.dataMustache(view.lookup("getRatingClass"), Spacebars.dot(view.lookup("rating"), "type")));
          }                                                                                                           // 469
        }, function() {                                                                                               // 470
          return [ "\n                  ", Blaze._TemplateWith(function() {                                           // 471
            return {                                                                                                  // 472
              rating: Spacebars.call(view.lookup("ratingCount")),                                                     // 473
              size: Spacebars.call(10),                                                                               // 474
              class: Spacebars.call(view.lookup("ratingClass")),                                                      // 475
              mutable: Spacebars.call(view.lookup("canRate"))                                                         // 476
            };                                                                                                        // 477
          }, function() {                                                                                             // 478
            return Spacebars.include(view.lookupTemplate("starsRating"));                                             // 479
          }), "\n                " ];                                                                                 // 480
        }), "\n              "), "\n            " ];                                                                  // 481
      }), "\n\n            ", Blaze.If(function() {                                                                   // 482
        return Spacebars.dataMustache(view.lookup("allowReplies"), view.lookup("_id"));                               // 483
      }, function() {                                                                                                 // 484
        return [ "\n              ", HTML.DIV({                                                                       // 485
          class: "button button-clear ion-reply reply-action"                                                         // 486
        }, "\n                ", Blaze.View("lookup:take", function() {                                               // 487
          return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                               // 488
            key: "reply"                                                                                              // 489
          }));                                                                                                        // 490
        }), "\n              "), "\n            " ];                                                                  // 491
      }), "\n\n            ", Blaze.If(function() {                                                                   // 492
        return Spacebars.call(view.lookup("isChangeable"));                                                           // 493
      }, function() {                                                                                                 // 494
        return [ "\n              ", Blaze.If(function() {                                                            // 495
          return Spacebars.call(view.lookup("isEditable"));                                                           // 496
        }, function() {                                                                                               // 497
          return [ "\n                ", HTML.DIV({                                                                   // 498
            class: "button button-clear ion-archive save-action"                                                      // 499
          }, "\n                  ", Blaze.View("lookup:take", function() {                                           // 500
            return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                             // 501
              key: "save"                                                                                             // 502
            }));                                                                                                      // 503
          }), "\n                "), "\n              " ];                                                            // 504
        }, function() {                                                                                               // 505
          return [ "\n                ", HTML.DIV({                                                                   // 506
            class: "button button-clear ion-edit edit-action"                                                         // 507
          }, "\n                  ", Blaze.View("lookup:take", function() {                                           // 508
            return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                             // 509
              key: "edit"                                                                                             // 510
            }));                                                                                                      // 511
          }), "\n                "), "\n              " ];                                                            // 512
        }), "\n              ", HTML.DIV({                                                                            // 513
          class: "button button-clear button-assertive ion-trash-a remove-action"                                     // 514
        }, "\n                ", Blaze.View("lookup:take", function() {                                               // 515
          return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                               // 516
            key: "remove"                                                                                             // 517
          }));                                                                                                        // 518
        }), "\n              "), "\n            " ];                                                                  // 519
      }, function() {                                                                                                 // 520
        return [ "\n              ", HTML.A({                                                                         // 521
          class: "button button-clear"                                                                                // 522
        }), "\n              ", HTML.A({                                                                              // 523
          class: "button button-clear"                                                                                // 524
        }), "\n            " ];                                                                                       // 525
      }), "\n          "), "\n        "), "\n\n      "), "\n    "), "\n    ", Blaze.If(function() {                   // 526
        return Spacebars.call(view.lookup("addReply"));                                                               // 527
      }, function() {                                                                                                 // 528
        return [ "\n    ", HTML.DIV({                                                                                 // 529
          class: "padding-left"                                                                                       // 530
        }, "\n      ", HTML.DIV({                                                                                     // 531
          class: "card"                                                                                               // 532
        }, "\n        ", HTML.DIV({                                                                                   // 533
          class: "item"                                                                                               // 534
        }, "\n          ", HTML.DIV({                                                                                 // 535
          class: "create-reply"                                                                                       // 536
        }, "\n            ", Blaze._TemplateWith(function() {                                                         // 537
          return {                                                                                                    // 538
            reply: Spacebars.call(true),                                                                              // 539
            scope: Spacebars.call(view.lookup("."))                                                                   // 540
          };                                                                                                          // 541
        }, function() {                                                                                               // 542
          return Spacebars.include(view.lookupTemplate("textarea"));                                                  // 543
        }), "\n          "), "\n        "), "\n      "), "\n    "), "\n    " ];                                       // 544
      }), "\n\n    ", Blaze.If(function() {                                                                           // 545
        return Spacebars.call(view.lookup("reply"));                                                                  // 546
      }, function() {                                                                                                 // 547
        return [ "\n    ", HTML.DIV({                                                                                 // 548
          class: "padding-left"                                                                                       // 549
        }, "\n      ", Blaze.Each(function() {                                                                        // 550
          return Spacebars.call(view.lookup("reply"));                                                                // 551
        }, function() {                                                                                               // 552
          return [ "\n        ", Spacebars.include(view.lookupTemplate("commentsSingleComment")), "\n      " ];       // 553
        }), "\n    "), "\n    " ];                                                                                    // 554
      }), "\n  " ];                                                                                                   // 555
    }), "\n  " ];                                                                                                     // 556
  });                                                                                                                 // 557
}));                                                                                                                  // 558
                                                                                                                      // 559
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"commentsSingleComment.js":["meteor/meteor","../../services/media","../../services/user",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/components/commentsSingleComment/commentsSingleComment.js                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var mediaService;module.import('../../services/media',{"default":function(v){mediaService=v}});var userService;module.import('../../services/user',{"default":function(v){userService=v}});
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      //
Template.commentsSingleComment.helpers(_.extend(defaultCommentHelpers, {                                              // 5
  customSingleCommentTemplate: function () {                                                                          // 6
    function customSingleCommentTemplate() {                                                                          // 5
      return defaultCommentHelpers.getCustomTemplate('singleCommentTemplate', 'commentsSingleComment', Template.parentData());
    }                                                                                                                 // 8
                                                                                                                      //
    return customSingleCommentTemplate;                                                                               // 5
  }(),                                                                                                                // 5
  hasLiked: function () {                                                                                             // 9
    function hasLiked() {                                                                                             // 5
      return this.likes && this.likes.includes(userService.getUserId());                                              // 10
    }                                                                                                                 // 11
                                                                                                                      //
    return hasLiked;                                                                                                  // 5
  }(),                                                                                                                // 5
  hasDisliked: function () {                                                                                          // 12
    function hasDisliked() {                                                                                          // 5
      return this.dislikes && this.dislikes.includes(userService.getUserId());                                        // 13
    }                                                                                                                 // 14
                                                                                                                      //
    return hasDisliked;                                                                                               // 5
  }(),                                                                                                                // 5
  isOwnComment: function () {                                                                                         // 15
    function isOwnComment() {                                                                                         // 5
      return this.userId === userService.getUserId();                                                                 // 16
    }                                                                                                                 // 17
                                                                                                                      //
    return isOwnComment;                                                                                              // 5
  }(),                                                                                                                // 5
  isChangeable: function () {                                                                                         // 18
    function isChangeable() {                                                                                         // 5
      return this.userId === userService.getUserId();                                                                 // 19
    }                                                                                                                 // 20
                                                                                                                      //
    return isChangeable;                                                                                              // 5
  }(),                                                                                                                // 5
  addReply: function () {                                                                                             // 21
    function addReply() {                                                                                             // 5
      var id = this._id || this.replyId;                                                                              // 22
      return Comments.session.equals('replyTo', id);                                                                  // 23
    }                                                                                                                 // 24
                                                                                                                      //
    return addReply;                                                                                                  // 5
  }(),                                                                                                                // 5
  isEditable: function () {                                                                                           // 25
    function isEditable() {                                                                                           // 5
      var id = this._id || this.replyId;                                                                              // 26
      return Comments.session.equals('editingDocument', id);                                                          // 27
    }                                                                                                                 // 28
                                                                                                                      //
    return isEditable;                                                                                                // 5
  }(),                                                                                                                // 5
  mediaContent: function () {                                                                                         // 29
    function mediaContent() {                                                                                         // 5
      return mediaService.getMarkup(this.media);                                                                      // 30
    }                                                                                                                 // 31
                                                                                                                      //
    return mediaContent;                                                                                              // 5
  }(),                                                                                                                // 5
                                                                                                                      //
  isRating: function () {                                                                                             // 32
    function isRating() {                                                                                             // 32
      for (var _len = arguments.length, types = Array(_len), _key = 0; _key < _len; _key++) {                         // 32
        types[_key] = arguments[_key];                                                                                // 32
      }                                                                                                               // 32
                                                                                                                      //
      return types.includes(Comments.config().rating);                                                                // 32
    }                                                                                                                 // 32
                                                                                                                      //
    return isRating;                                                                                                  // 32
  }(),                                                                                                                // 32
  rating: function () {                                                                                               // 33
    function rating() {                                                                                               // 5
      return this.getStarRating();                                                                                    // 34
    }                                                                                                                 // 35
                                                                                                                      //
    return rating;                                                                                                    // 5
  }(),                                                                                                                // 5
                                                                                                                      //
  canRate: function () {                                                                                              // 36
    function canRate() {                                                                                              // 36
      return userService.getUserId();                                                                                 // 36
    }                                                                                                                 // 36
                                                                                                                      //
    return canRate;                                                                                                   // 36
  }(),                                                                                                                // 36
  forceRender: function () {                                                                                          // 37
    function forceRender() {                                                                                          // 5
      this.getStarRating();                                                                                           // 38
    }                                                                                                                 // 39
                                                                                                                      //
    return forceRender;                                                                                               // 5
  }(),                                                                                                                // 5
  getRatingClass: function () {                                                                                       // 40
    function getRatingClass(type) {                                                                                   // 5
      if ('user' === type) {                                                                                          // 41
        return 'own-rating';                                                                                          // 42
      }                                                                                                               // 43
                                                                                                                      //
      return '';                                                                                                      // 45
    }                                                                                                                 // 46
                                                                                                                      //
    return getRatingClass;                                                                                            // 5
  }(),                                                                                                                // 5
  commentAction: function () {                                                                                        // 47
    function commentAction() {                                                                                        // 5
      return Comments.ui.config().commentActions;                                                                     // 48
    }                                                                                                                 // 49
                                                                                                                      //
    return commentAction;                                                                                             // 5
  }(),                                                                                                                // 5
  reply: function () {                                                                                                // 50
    function reply() {                                                                                                // 5
      if (_.isFunction(this.enhancedReplies)) {                                                                       // 51
        return this.enhancedReplies();                                                                                // 52
      } else if (_.isArray(this.enhancedReplies)) {                                                                   // 53
        return this.enhancedReplies;                                                                                  // 54
      }                                                                                                               // 55
    }                                                                                                                 // 56
                                                                                                                      //
    return reply;                                                                                                     // 5
  }(),                                                                                                                // 5
  avatarUrl: function () {                                                                                            // 57
    function avatarUrl() {                                                                                            // 5
      var config = Comments.ui.config();                                                                              // 58
      var avatar = config.defaultAvatar;                                                                              // 59
                                                                                                                      //
      if (config.generateAvatar) {                                                                                    // 61
        var userId = this.userId;                                                                                     // 62
        var user = Meteor.users.findOne(userId);                                                                      // 63
        var anonymousUser = AnonymousUserCollection.findOne({ _id: userId });                                         // 64
                                                                                                                      //
        var isAnonymous = !!anonymousUser;                                                                            // 66
                                                                                                                      //
        if (isAnonymous) {                                                                                            // 68
          user = anonymousUser;                                                                                       // 69
        }                                                                                                             // 70
                                                                                                                      //
        avatar = config.generateAvatar(user, isAnonymous) || avatar;                                                  // 72
      }                                                                                                               // 73
                                                                                                                      //
      return avatar;                                                                                                  // 75
    }                                                                                                                 // 76
                                                                                                                      //
    return avatarUrl;                                                                                                 // 5
  }()                                                                                                                 // 5
}));                                                                                                                  // 5
                                                                                                                      //
Template.commentsSingleComment.onRendered(function () {                                                               // 79
  // fix wrong blaze rendering                                                                                        // 80
  $('.stars-rating').each(function () {                                                                               // 81
    var starRatingElement = $(this);                                                                                  // 82
                                                                                                                      //
    if (starRatingElement.data('rating') == 0) {                                                                      // 84
      starRatingElement.find('.current-rating').removeClass('current-rating');                                        // 85
    }                                                                                                                 // 86
  });                                                                                                                 // 87
});                                                                                                                   // 88
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"commentsTextarea":{"template.commentsTextarea.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/components/commentsTextarea/template.commentsTextarea.js                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("commentsTextarea");                                                                             // 2
Template["commentsTextarea"] = new Template("Template.commentsTextarea", (function() {                                // 3
  var view = this;                                                                                                    // 4
  return Blaze.If(function() {                                                                                        // 5
    return Spacebars.call(view.lookup("customTextareaTemplate"));                                                     // 6
  }, function() {                                                                                                     // 7
    return [ "\n    ", Spacebars.include(view.lookupTemplate("customTextareaTemplate")), "\n  " ];                    // 8
  }, function() {                                                                                                     // 9
    return [ "\n  ", Blaze.If(function() {                                                                            // 10
      return Spacebars.dataMustache(view.lookup("templateIs"), "semantic-ui");                                        // 11
    }, function() {                                                                                                   // 12
      return [ "\n    ", HTML.FORM({                                                                                  // 13
        class: function() {                                                                                           // 14
          return [ "ui reply form ", Blaze.If(function() {                                                            // 15
            return Spacebars.call(view.lookup("reply"));                                                              // 16
          }, function() {                                                                                             // 17
            return "reply-form";                                                                                      // 18
          }, function() {                                                                                             // 19
            return "comment-form";                                                                                    // 20
          }) ];                                                                                                       // 21
        }                                                                                                             // 22
      }, "\n      ", HTML.DIV({                                                                                       // 23
        class: "field"                                                                                                // 24
      }, "\n                  ", HTML.TEXTAREA({                                                                      // 25
        placeholder: function() {                                                                                     // 26
          return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                               // 27
            key: "placeholder-textarea",                                                                              // 28
            default: "Join the discussion"                                                                            // 29
          }));                                                                                                        // 30
        },                                                                                                            // 31
        class: function() {                                                                                           // 32
          return Blaze.If(function() {                                                                                // 33
            return Spacebars.call(view.lookup("reply"));                                                              // 34
          }, function() {                                                                                             // 35
            return "create-reply";                                                                                    // 36
          }, function() {                                                                                             // 37
            return "create-comment";                                                                                  // 38
          });                                                                                                         // 39
        }                                                                                                             // 40
      }), "\n      "), "\n      ", Blaze.If(function() {                                                              // 41
        return Spacebars.call(view.lookup("showAnonymousInput"));                                                     // 42
      }, function() {                                                                                                 // 43
        return [ "\n        ", HTML.DIV({                                                                             // 44
          class: "two fields"                                                                                         // 45
        }, "\n          ", HTML.DIV({                                                                                 // 46
          class: "field"                                                                                              // 47
        }, "\n            ", HTML.INPUT({                                                                             // 48
          required: "",                                                                                               // 49
          type: "text",                                                                                               // 50
          class: "ui input anon-username",                                                                            // 51
          value: function() {                                                                                         // 52
            return Spacebars.mustache(Spacebars.dot(view.lookup("anonymousData"), "username"));                       // 53
          },                                                                                                          // 54
          placeholder: "Your name"                                                                                    // 55
        }), "\n          "), "\n          ", HTML.DIV({                                                               // 56
          class: "field"                                                                                              // 57
        }, "\n            ", HTML.INPUT({                                                                             // 58
          required: "",                                                                                               // 59
          type: "email",                                                                                              // 60
          class: "ui input anon-email",                                                                               // 61
          value: function() {                                                                                         // 62
            return Spacebars.mustache(Spacebars.dot(view.lookup("anonymousData"), "email"));                          // 63
          },                                                                                                          // 64
          placeholder: "Your email"                                                                                   // 65
        }), "\n          "), "\n        "), "\n      " ];                                                             // 66
      }), "\n      ", HTML.BUTTON({                                                                                   // 67
        type: "submit",                                                                                               // 68
        class: "ui blue labeled submit icon button"                                                                   // 69
      }, "\n        ", HTML.I({                                                                                       // 70
        class: "icon edit"                                                                                            // 71
      }), " ", Blaze.View("lookup:take", function() {                                                                 // 72
        return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                                 // 73
          key: view.lookup("addButtonKey"),                                                                           // 74
          default: view.lookup("defaultAddButtonText")                                                                // 75
        }));                                                                                                          // 76
      }), "\n      "), "\n    "), "\n  " ];                                                                           // 77
    }), "\n\n  ", Blaze.If(function() {                                                                               // 78
      return Spacebars.dataMustache(view.lookup("templateIs"), "bootstrap");                                          // 79
    }, function() {                                                                                                   // 80
      return [ "\n    ", HTML.FORM({                                                                                  // 81
        class: function() {                                                                                           // 82
          return Blaze.If(function() {                                                                                // 83
            return Spacebars.call(view.lookup("reply"));                                                              // 84
          }, function() {                                                                                             // 85
            return "reply-form";                                                                                      // 86
          }, function() {                                                                                             // 87
            return "comment-form";                                                                                    // 88
          });                                                                                                         // 89
        },                                                                                                            // 90
        role: "form",                                                                                                 // 91
        action: ""                                                                                                    // 92
      }, "\n      ", HTML.DIV({                                                                                       // 93
        class: "form-group"                                                                                           // 94
      }, "\n                  ", HTML.TEXTAREA({                                                                      // 95
        placeholder: function() {                                                                                     // 96
          return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                               // 97
            key: "placeholder-textarea",                                                                              // 98
            default: "Join the discussion"                                                                            // 99
          }));                                                                                                        // 100
        },                                                                                                            // 101
        class: function() {                                                                                           // 102
          return [ "form-control ", Blaze.If(function() {                                                             // 103
            return Spacebars.call(view.lookup("reply"));                                                              // 104
          }, function() {                                                                                             // 105
            return "create-reply";                                                                                    // 106
          }, function() {                                                                                             // 107
            return "create-comment";                                                                                  // 108
          }) ];                                                                                                       // 109
        },                                                                                                            // 110
        rows: "3"                                                                                                     // 111
      }), "\n      "), "\n      ", Blaze.If(function() {                                                              // 112
        return Spacebars.call(view.lookup("showAnonymousInput"));                                                     // 113
      }, function() {                                                                                                 // 114
        return [ "\n        ", HTML.DIV({                                                                             // 115
          class: "form-group"                                                                                         // 116
        }, "\n          ", HTML.DIV({                                                                                 // 117
          class: "row"                                                                                                // 118
        }, "\n            ", HTML.DIV({                                                                               // 119
          class: "col-md-6"                                                                                           // 120
        }, "\n              ", HTML.INPUT({                                                                           // 121
          required: "",                                                                                               // 122
          type: "text",                                                                                               // 123
          class: "form-control anon-username",                                                                        // 124
          value: function() {                                                                                         // 125
            return Spacebars.mustache(Spacebars.dot(view.lookup("anonymousData"), "username"));                       // 126
          },                                                                                                          // 127
          placeholder: "Your name"                                                                                    // 128
        }), "\n            "), "\n            ", HTML.DIV({                                                           // 129
          class: "col-md-6"                                                                                           // 130
        }, "\n              ", HTML.INPUT({                                                                           // 131
          required: "",                                                                                               // 132
          type: "email",                                                                                              // 133
          class: "form-control anon-email",                                                                           // 134
          value: function() {                                                                                         // 135
            return Spacebars.mustache(Spacebars.dot(view.lookup("anonymousData"), "email"));                          // 136
          },                                                                                                          // 137
          placeholder: "Your email"                                                                                   // 138
        }), "\n            "), "\n          "), "\n        "), "\n      " ];                                          // 139
      }), "\n      ", HTML.BUTTON({                                                                                   // 140
        type: "submit",                                                                                               // 141
        class: "btn btn-primary"                                                                                      // 142
      }, Blaze.View("lookup:take", function() {                                                                       // 143
        return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                                 // 144
          key: view.lookup("addButtonKey"),                                                                           // 145
          default: view.lookup("defaultAddButtonText")                                                                // 146
        }));                                                                                                          // 147
      })), "\n    "), "\n  " ];                                                                                       // 148
    }), "\n\n  ", Blaze.If(function() {                                                                               // 149
      return Spacebars.dataMustache(view.lookup("templateIs"), "ionic");                                              // 150
    }, function() {                                                                                                   // 151
      return [ "\n    ", HTML.FORM({                                                                                  // 152
        class: function() {                                                                                           // 153
          return Blaze.If(function() {                                                                                // 154
            return Spacebars.call(view.lookup("reply"));                                                              // 155
          }, function() {                                                                                             // 156
            return "reply-form";                                                                                      // 157
          }, function() {                                                                                             // 158
            return "comment-form";                                                                                    // 159
          });                                                                                                         // 160
        },                                                                                                            // 161
        role: "form",                                                                                                 // 162
        action: ""                                                                                                    // 163
      }, "\n      ", HTML.DIV({                                                                                       // 164
        class: "list list-inset"                                                                                      // 165
      }, "\n        ", HTML.LABEL({                                                                                   // 166
        class: "item item-input"                                                                                      // 167
      }, "\n                      ", HTML.TEXTAREA({                                                                  // 168
        placeholder: function() {                                                                                     // 169
          return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                               // 170
            key: "placeholder-textarea",                                                                              // 171
            default: "Join the discussion"                                                                            // 172
          }));                                                                                                        // 173
        },                                                                                                            // 174
        class: function() {                                                                                           // 175
          return [ "form-control ", Blaze.If(function() {                                                             // 176
            return Spacebars.call(view.lookup("reply"));                                                              // 177
          }, function() {                                                                                             // 178
            return "create-reply";                                                                                    // 179
          }, function() {                                                                                             // 180
            return "create-comment";                                                                                  // 181
          }) ];                                                                                                       // 182
        },                                                                                                            // 183
        rows: "3"                                                                                                     // 184
      }), "\n        "), "\n        ", Blaze.If(function() {                                                          // 185
        return Spacebars.call(view.lookup("showAnonymousInput"));                                                     // 186
      }, function() {                                                                                                 // 187
        return [ "\n          ", HTML.LABEL({                                                                         // 188
          class: "item item-input"                                                                                    // 189
        }, "\n            ", HTML.INPUT({                                                                             // 190
          required: "",                                                                                               // 191
          type: "text",                                                                                               // 192
          class: "form-control anon-username",                                                                        // 193
          value: function() {                                                                                         // 194
            return Spacebars.mustache(Spacebars.dot(view.lookup("anonymousData"), "username"));                       // 195
          },                                                                                                          // 196
          placeholder: "Your name"                                                                                    // 197
        }), "\n          "), "\n          ", HTML.LABEL({                                                             // 198
          class: "item item-input"                                                                                    // 199
        }, "\n            ", HTML.INPUT({                                                                             // 200
          required: "",                                                                                               // 201
          type: "email",                                                                                              // 202
          class: "form-control anon-email",                                                                           // 203
          value: function() {                                                                                         // 204
            return Spacebars.mustache(Spacebars.dot(view.lookup("anonymousData"), "email"));                          // 205
          },                                                                                                          // 206
          placeholder: "Your email"                                                                                   // 207
        }), "\n          "), "\n        " ];                                                                          // 208
      }), "\n      "), "\n      ", HTML.DIV({                                                                         // 209
        class: "padding"                                                                                              // 210
      }, "\n        ", HTML.BUTTON({                                                                                  // 211
        type: "submit",                                                                                               // 212
        class: "button button-block button-positive"                                                                  // 213
      }, Blaze.View("lookup:take", function() {                                                                       // 214
        return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                                 // 215
          key: view.lookup("addButtonKey"),                                                                           // 216
          default: view.lookup("defaultAddButtonText")                                                                // 217
        }));                                                                                                          // 218
      })), "\n      "), "\n    "), "\n  " ];                                                                          // 219
    }), "\n  " ];                                                                                                     // 220
  });                                                                                                                 // 221
}));                                                                                                                  // 222
                                                                                                                      // 223
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"commentsTextarea.js":["../../services/user",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/components/commentsTextarea/commentsTextarea.js                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var userService;module.import('../../services/user',{"default":function(v){userService=v}});                          // 1
                                                                                                                      //
Template.commentsTextarea.helpers(_.extend(defaultCommentHelpers, {                                                   // 3
  customTextareaTemplate: function () {                                                                               // 4
    function customTextareaTemplate() {                                                                               // 3
      return defaultCommentHelpers.getCustomTemplate('textareaTemplate', 'commentsTextarea', this);                   // 5
    }                                                                                                                 // 6
                                                                                                                      //
    return customTextareaTemplate;                                                                                    // 3
  }(),                                                                                                                // 3
  addButtonKey: function () {                                                                                         // 7
    function addButtonKey() {                                                                                         // 3
      return this.reply ? 'add-button-reply' : 'add-button';                                                          // 8
    }                                                                                                                 // 9
                                                                                                                      //
    return addButtonKey;                                                                                              // 3
  }(),                                                                                                                // 3
  defaultAddButtonText: function () {                                                                                 // 10
    function defaultAddButtonText() {                                                                                 // 3
      return this.reply ? 'Add reply' : 'Add comment';                                                                // 11
    }                                                                                                                 // 12
                                                                                                                      //
    return defaultAddButtonText;                                                                                      // 3
  }(),                                                                                                                // 3
  reply: function () {                                                                                                // 13
    function reply() {                                                                                                // 3
      return this.reply;                                                                                              // 14
    }                                                                                                                 // 15
                                                                                                                      //
    return reply;                                                                                                     // 3
  }(),                                                                                                                // 3
                                                                                                                      //
  anonymousData: function () {                                                                                        // 16
    function anonymousData() {                                                                                        // 16
      return userService.getAnonymousUserData(userService.getUserId());                                               // 16
    }                                                                                                                 // 16
                                                                                                                      //
    return anonymousData;                                                                                             // 16
  }()                                                                                                                 // 16
}));                                                                                                                  // 3
                                                                                                                      //
Template.commentsTextarea.onRendered(function () {                                                                    // 19
  if (this.data && this.data.reply) {                                                                                 // 20
    this.$('textarea').focus();                                                                                       // 21
  }                                                                                                                   // 22
});                                                                                                                   // 23
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"commentsSubheader":{"template.commentsSubheader.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/components/commentsSubheader/template.commentsSubheader.js                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("commentsSubheader");                                                                            // 2
Template["commentsSubheader"] = new Template("Template.commentsSubheader", (function() {                              // 3
  var view = this;                                                                                                    // 4
  return Blaze.If(function() {                                                                                        // 5
    return Spacebars.call(view.lookup("customSubheaderTemplate"));                                                    // 6
  }, function() {                                                                                                     // 7
    return [ "\n    ", Spacebars.include(view.lookupTemplate("customSubheaderTemplate")), "\n  " ];                   // 8
  }, function() {                                                                                                     // 9
    return [ "\n  ", Blaze.If(function() {                                                                            // 10
      return Spacebars.dataMustache(view.lookup("templateIs"), "semantic-ui");                                        // 11
    }, function() {                                                                                                   // 12
      return [ "\n    ", HTML.DIV({                                                                                   // 13
        class: "sorting"                                                                                              // 14
      }, "\n      Sort by\n      ", HTML.SELECT({                                                                     // 15
        class: "ui sorting-dropdown dropdown"                                                                         // 16
      }, "\n        ", Blaze.Each(function() {                                                                        // 17
        return Spacebars.call(view.lookup("sortingOption"));                                                          // 18
      }, function() {                                                                                                 // 19
        return [ "\n          ", Blaze.If(function() {                                                                // 20
          return Spacebars.call(view.lookup("currentSortOption"));                                                    // 21
        }, function() {                                                                                               // 22
          return [ "\n            ", HTML.OPTION({                                                                    // 23
            selected: "",                                                                                             // 24
            value: function() {                                                                                       // 25
              return Spacebars.mustache(view.lookup("value"));                                                        // 26
            }                                                                                                         // 27
          }, Blaze.View("lookup:label", function() {                                                                  // 28
            return Spacebars.mustache(view.lookup("label"));                                                          // 29
          })), "\n          " ];                                                                                      // 30
        }, function() {                                                                                               // 31
          return [ "\n            ", HTML.OPTION({                                                                    // 32
            value: function() {                                                                                       // 33
              return Spacebars.mustache(view.lookup("value"));                                                        // 34
            }                                                                                                         // 35
          }, Blaze.View("lookup:label", function() {                                                                  // 36
            return Spacebars.mustache(view.lookup("label"));                                                          // 37
          })), "\n          " ];                                                                                      // 38
        }), "\n        " ];                                                                                           // 39
      }), "\n      "), "\n    "), "\n  " ];                                                                           // 40
    }), "\n  " ];                                                                                                     // 41
  });                                                                                                                 // 42
}));                                                                                                                  // 43
                                                                                                                      // 44
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"commentsSubheader.js":["../../services/user",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/components/commentsSubheader/commentsSubheader.js                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var userService;module.import('../../services/user',{"default":function(v){userService=v}});                          // 1
                                                                                                                      //
Template.commentsSubheader.helpers(_.extend(defaultCommentHelpers, {                                                  // 3
  customSubheaderTemplate: function () {                                                                              // 4
    function customSubheaderTemplate() {                                                                              // 3
      return defaultCommentHelpers.getCustomTemplate('subheaderTemplate', 'commentsSubheader', this);                 // 5
    }                                                                                                                 // 6
                                                                                                                      //
    return customSubheaderTemplate;                                                                                   // 3
  }(),                                                                                                                // 3
  sortingOption: function () {                                                                                        // 7
    function sortingOption() {                                                                                        // 3
      return Comments.config().sortingOptions;                                                                        // 8
    }                                                                                                                 // 9
                                                                                                                      //
    return sortingOption;                                                                                             // 3
  }(),                                                                                                                // 3
  currentSortOption: function () {                                                                                    // 10
    function currentSortOption() {                                                                                    // 3
      return this.value === Comments.session.get(Template.parentData().id + '_sorting');                              // 11
    }                                                                                                                 // 12
                                                                                                                      //
    return currentSortOption;                                                                                         // 3
  }()                                                                                                                 // 3
}));                                                                                                                  // 3
                                                                                                                      //
Template.commentsSubheader.onRendered(function () {                                                                   // 15
  var dropdown = $('.ui.dropdown');                                                                                   // 16
                                                                                                                      //
  if (dropdown.dropdown) {                                                                                            // 18
    dropdown.dropdown();                                                                                              // 19
  }                                                                                                                   // 20
});                                                                                                                   // 21
                                                                                                                      //
Template.commentsSubheader.events({                                                                                   // 23
  'change .sorting-dropdown': function () {                                                                           // 24
    function changeSortingDropdown(e) {                                                                               // 24
      Comments.ui.clearHandles();                                                                                     // 25
      Comments.session.set(this.id + '_sorting', $(e.target).val());                                                  // 26
    }                                                                                                                 // 27
                                                                                                                      //
    return changeSortingDropdown;                                                                                     // 24
  }()                                                                                                                 // 24
});                                                                                                                   // 23
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"commentsList":{"template.commentsList.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/components/commentsList/template.commentsList.js                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
Template.__checkName("commentsList");                                                                                 // 2
Template["commentsList"] = new Template("Template.commentsList", (function() {                                        // 3
  var view = this;                                                                                                    // 4
  return Blaze.If(function() {                                                                                        // 5
    return Spacebars.call(view.templateInstance().subscriptionsReady());                                              // 6
  }, function() {                                                                                                     // 7
    return [ "\n    ", Blaze.If(function() {                                                                          // 8
      return Spacebars.call(view.lookup("customListTemplate"));                                                       // 9
    }, function() {                                                                                                   // 10
      return [ "\n      ", Spacebars.include(view.lookupTemplate("customListTemplate")), "\n    " ];                  // 11
    }, function() {                                                                                                   // 12
      return [ "\n      ", Blaze.If(function() {                                                                      // 13
        return Spacebars.dataMustache(view.lookup("templateIs"), "semantic-ui");                                      // 14
      }, function() {                                                                                                 // 15
        return [ "\n        ", Blaze.Each(function() {                                                                // 16
          return Spacebars.call(view.lookup("comment"));                                                              // 17
        }, function() {                                                                                               // 18
          return [ "\n          ", Spacebars.include(view.lookupTemplate("commentsSingleComment")), "\n        " ];   // 19
        }), "\n\n        ", Blaze.If(function() {                                                                     // 20
          return Spacebars.call(view.lookup("hasMoreComments"));                                                      // 21
        }, function() {                                                                                               // 22
          return [ "\n          ", HTML.DIV({                                                                         // 23
            class: "ui fluid green loadmore-action button"                                                            // 24
          }, Blaze.View("lookup:take", function() {                                                                   // 25
            return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                             // 26
              key: "load-more",                                                                                       // 27
              default: "Load more comments"                                                                           // 28
            }));                                                                                                      // 29
          })), "\n        " ];                                                                                        // 30
        }), "\n      " ];                                                                                             // 31
      }), "\n\n      ", Blaze.If(function() {                                                                         // 32
        return Spacebars.dataMustache(view.lookup("templateIs"), "bootstrap");                                        // 33
      }, function() {                                                                                                 // 34
        return [ "\n        ", HTML.DIV({                                                                             // 35
          class: "media-list comments"                                                                                // 36
        }, "\n          ", Blaze.Each(function() {                                                                    // 37
          return Spacebars.call(view.lookup("comment"));                                                              // 38
        }, function() {                                                                                               // 39
          return [ "\n            ", Spacebars.include(view.lookupTemplate("commentsSingleComment")), "\n          " ];
        }), "\n        "), "\n\n        ", Blaze.If(function() {                                                      // 41
          return Spacebars.call(view.lookup("hasMoreComments"));                                                      // 42
        }, function() {                                                                                               // 43
          return [ "\n          ", HTML.BUTTON({                                                                      // 44
            type: "button",                                                                                           // 45
            class: "btn btn-success btn-lg btn-block loadmore-action"                                                 // 46
          }, Blaze.View("lookup:take", function() {                                                                   // 47
            return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                             // 48
              key: "load-more",                                                                                       // 49
              default: "Load more comments"                                                                           // 50
            }));                                                                                                      // 51
          })), "\n        " ];                                                                                        // 52
        }), "\n      " ];                                                                                             // 53
      }), "\n\n      ", Blaze.If(function() {                                                                         // 54
        return Spacebars.dataMustache(view.lookup("templateIs"), "ionic");                                            // 55
      }, function() {                                                                                                 // 56
        return [ "\n        ", Blaze.Each(function() {                                                                // 57
          return Spacebars.call(view.lookup("comment"));                                                              // 58
        }, function() {                                                                                               // 59
          return [ "\n          ", Spacebars.include(view.lookupTemplate("commentsSingleComment")), "\n        " ];   // 60
        }), "\n\n        ", Blaze.If(function() {                                                                     // 61
          return Spacebars.call(view.lookup("hasMoreComments"));                                                      // 62
        }, function() {                                                                                               // 63
          return [ "\n          ", HTML.BUTTON({                                                                      // 64
            type: "button",                                                                                           // 65
            class: "button button-block button-positive loadmore-action"                                              // 66
          }, Blaze.View("lookup:take", function() {                                                                   // 67
            return Spacebars.mustache(view.lookup("take"), Spacebars.kw({                                             // 68
              key: "load-more",                                                                                       // 69
              default: "Load more comments"                                                                           // 70
            }));                                                                                                      // 71
          })), "\n        " ];                                                                                        // 72
        }), "\n      " ];                                                                                             // 73
      }), "\n    " ];                                                                                                 // 74
    }), "\n  " ];                                                                                                     // 75
  }, function() {                                                                                                     // 76
    return [ "\n    ", Blaze.If(function() {                                                                          // 77
      return Spacebars.call(view.lookup("customLoadingTemplate"));                                                    // 78
    }, function() {                                                                                                   // 79
      return [ "\n      ", Spacebars.include(view.lookupTemplate("customLoadingTemplate")), "\n    " ];               // 80
    }), "\n  " ];                                                                                                     // 81
  });                                                                                                                 // 82
}));                                                                                                                  // 83
                                                                                                                      // 84
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"commentsList.js":["../../services/user",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/components/commentsList/commentsList.js                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var userService;module.import('../../services/user',{"default":function(v){userService=v}});                          // 1
                                                                                                                      //
Template.commentsList.helpers(_.extend(defaultCommentHelpers, {                                                       // 3
  comment: function () {                                                                                              // 4
    function comment() {                                                                                              // 3
      return Comments.get(this.id, Comments.getSortOption(Comments.ui.getSorting(this.id)));                          // 5
    }                                                                                                                 // 6
                                                                                                                      //
    return comment;                                                                                                   // 3
  }(),                                                                                                                // 3
  customLoadingTemplate: function () {                                                                                // 7
    function customLoadingTemplate() {                                                                                // 3
      return defaultCommentHelpers.getCustomTemplate('loadingTemplate', 'commentsList', this);                        // 8
    }                                                                                                                 // 9
                                                                                                                      //
    return customLoadingTemplate;                                                                                     // 3
  }(),                                                                                                                // 3
  customListTemplate: function () {                                                                                   // 10
    function customListTemplate() {                                                                                   // 3
      return defaultCommentHelpers.getCustomTemplate('commentListTemplate', 'commentsList', this);                    // 11
    }                                                                                                                 // 12
                                                                                                                      //
    return customListTemplate;                                                                                        // 3
  }()                                                                                                                 // 3
}));                                                                                                                  // 3
                                                                                                                      //
Template.commentsList.onCreated(function () {                                                                         // 15
  var _this = this;                                                                                                   // 15
                                                                                                                      //
  this.autorun(function () {                                                                                          // 16
    _this.subscribe('comments/reference', _this.data.id, Comments.ui.getSorting(_this.data.id), Comments.ui.config().limit);
  });                                                                                                                 // 23
});                                                                                                                   // 24
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"helpers.js":["../services/user","../services/comment",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/components/helpers.js                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var userService;module.import('../services/user',{"default":function(v){userService=v}});var commentService;module.import('../services/comment',{"default":function(v){commentService=v}});
                                                                                                                      // 2
                                                                                                                      //
defaultCommentHelpers = {                                                                                             // 4
  take: function () {                                                                                                 // 5
    function take(params) {                                                                                           // 5
      var content = Comments.session.get('content');                                                                  // 6
                                                                                                                      //
      if (content && content[params.hash.key]) {                                                                      // 8
        return content[params.hash.key];                                                                              // 9
      }                                                                                                               // 10
                                                                                                                      //
      return params.hash['default'];                                                                                  // 12
    }                                                                                                                 // 13
                                                                                                                      //
    return take;                                                                                                      // 5
  }(),                                                                                                                // 5
  /**                                                                                                                 // 14
   * Return custom templates with helpers from commentsBox                                                            //
   *                                                                                                                  //
   * @param {String} templateName                                                                                     //
   * @param {String} originalTemplate                                                                                 //
   * @param {Object} templateScope                                                                                    //
   *                                                                                                                  //
   * @returns {Object}                                                                                                //
   */                                                                                                                 //
  getCustomTemplate: function () {                                                                                    // 23
    function getCustomTemplate(templateName, originalTemplate, templateScope) {                                       // 23
      if (_.isString(templateScope[templateName])) {                                                                  // 24
        Template[templateScope[templateName]].inheritsHelpersFrom(originalTemplate);                                  // 25
        return Template[templateScope[templateName]];                                                                 // 26
      }                                                                                                               // 27
    }                                                                                                                 // 28
                                                                                                                      //
    return getCustomTemplate;                                                                                         // 23
  }(),                                                                                                                // 23
  hasMoreComments: function () {                                                                                      // 29
    function hasMoreComments() {                                                                                      // 29
      return Comments.get(this.id).count() < Comments.session.get(this.id + '_count');                                // 30
    }                                                                                                                 // 31
                                                                                                                      //
    return hasMoreComments;                                                                                           // 29
  }(),                                                                                                                // 29
  commentId: function () {                                                                                            // 32
    function commentId() {                                                                                            // 32
      return this._id || this.replyId;                                                                                // 33
    }                                                                                                                 // 34
                                                                                                                      //
    return commentId;                                                                                                 // 32
  }(),                                                                                                                // 32
  showAnonymousInput: function () {                                                                                   // 35
    function showAnonymousInput(isReply) {                                                                            // 35
      return userService.isAnonymous() && !isReply;                                                                   // 35
    }                                                                                                                 // 35
                                                                                                                      //
    return showAnonymousInput;                                                                                        // 35
  }(),                                                                                                                // 35
  configGet: function () {                                                                                            // 36
    function configGet(key) {                                                                                         // 36
      return Comments.config()[key];                                                                                  // 36
    }                                                                                                                 // 36
                                                                                                                      //
    return configGet;                                                                                                 // 36
  }(),                                                                                                                // 36
  allowReplies: function () {                                                                                         // 37
    function allowReplies(documentId) {                                                                               // 37
      var config = Comments.config();                                                                                 // 38
                                                                                                                      //
      if (commentService.denyReply(this)) {                                                                           // 40
        return false;                                                                                                 // 41
      }                                                                                                               // 42
                                                                                                                      //
      return config.allowReplies ? config.allowReplies(documentId) : config.replies;                                  // 44
    }                                                                                                                 // 45
                                                                                                                      //
    return allowReplies;                                                                                              // 37
  }(),                                                                                                                // 37
  uiConfigGet: function () {                                                                                          // 46
    function uiConfigGet(key) {                                                                                       // 46
      return Comments.ui.config()[key];                                                                               // 46
    }                                                                                                                 // 46
                                                                                                                      //
    return uiConfigGet;                                                                                               // 46
  }(),                                                                                                                // 46
  sessionGet: function () {                                                                                           // 47
    function sessionGet(key) {                                                                                        // 47
      return Comments.session.get(key);                                                                               // 47
    }                                                                                                                 // 47
                                                                                                                      //
    return sessionGet;                                                                                                // 47
  }(),                                                                                                                // 47
  templateIs: function () {                                                                                           // 48
    function templateIs(name) {                                                                                       // 48
      return name === Comments.ui.config().template;                                                                  // 48
    }                                                                                                                 // 48
                                                                                                                      //
    return templateIs;                                                                                                // 48
  }(),                                                                                                                // 48
  textarea: function () {                                                                                             // 49
    function textarea() {                                                                                             // 49
      return Template.commentsTextarea;                                                                               // 49
    }                                                                                                                 // 49
                                                                                                                      //
    return textarea;                                                                                                  // 49
  }()                                                                                                                 // 49
};                                                                                                                    // 4
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"api.js":["./services/media","./services/media-analyzers/image","./services/media-analyzers/youtube","./services/user",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/arkham_comments-ui/lib/api.js                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var mediaService;module.import('./services/media',{"default":function(v){mediaService=v}});var imageAnalyzer;module.import('./services/media-analyzers/image',{"default":function(v){imageAnalyzer=v}});var youtubeAnalyzer;module.import('./services/media-analyzers/youtube',{"default":function(v){youtubeAnalyzer=v}});var userService;module.import('./services/user',{"default":function(v){userService=v}});
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      //
var _CommentsCollection$m = CommentsCollection.methods;                                                               //
var add = _CommentsCollection$m.add;                                                                                  //
var reply = _CommentsCollection$m.reply;                                                                              //
var remove = _CommentsCollection$m.remove;                                                                            //
var removeReply = _CommentsCollection$m.removeReply;                                                                  //
var edit = _CommentsCollection$m.edit;                                                                                //
var editReply = _CommentsCollection$m.editReply;                                                                      //
var like = _CommentsCollection$m.like;                                                                                //
var likeReply = _CommentsCollection$m.likeReply;                                                                      //
var dislike = _CommentsCollection$m.dislike;                                                                          //
var dislikeReply = _CommentsCollection$m.dislikeReply;                                                                //
var star = _CommentsCollection$m.star;                                                                                //
var starReply = _CommentsCollection$m.starReply;                                                                      //
                                                                                                                      //
                                                                                                                      //
Comments = {                                                                                                          // 21
  config: function () {                                                                                               // 22
    var config = {                                                                                                    // 23
      replies: true,                                                                                                  // 24
      anonymous: false,                                                                                               // 25
      rating: 'likes',                                                                                                // 26
      anonymousSalt: 'changeMe',                                                                                      // 27
      mediaAnalyzers: [imageAnalyzer, youtubeAnalyzer],                                                               // 28
      publishUserFields: { profile: 1, emails: 1, username: 1 },                                                      // 29
      onEvent: function () {                                                                                          // 30
        function onEvent() {}                                                                                         // 30
                                                                                                                      //
        return onEvent;                                                                                               // 30
      }(),                                                                                                            // 30
      sortingOptions: [{ value: 'newest', label: 'Newest', sortSpecifier: { createdAt: -1 } }, { value: 'oldest', label: 'Oldest', sortSpecifier: { createdAt: 1 } }, { value: 'rating', label: 'Best rating', sortSpecifier: { ratingScore: -1 } }]
    };                                                                                                                // 23
                                                                                                                      //
    return function (newConfig) {                                                                                     // 38
      if (!newConfig) {                                                                                               // 39
        return config;                                                                                                // 40
      }                                                                                                               // 41
                                                                                                                      //
      config = _.extend(config, newConfig);                                                                           // 43
    };                                                                                                                // 44
  }(),                                                                                                                // 45
  get: function () {                                                                                                  // 46
    function get(id) {                                                                                                // 46
      var sorting = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;                         // 46
                                                                                                                      //
      if (!sorting) {                                                                                                 // 47
        sorting = { createdAt: -1 };                                                                                  // 48
      }                                                                                                               // 49
                                                                                                                      //
      return CommentsCollection.find({ referenceId: id }, { sort: sorting });                                         // 51
    }                                                                                                                 // 52
                                                                                                                      //
    return get;                                                                                                       // 46
  }(),                                                                                                                // 46
  getOne: function () {                                                                                               // 53
    function getOne(id) {                                                                                             // 53
      return CommentsCollection.findOne({ _id: id });                                                                 // 53
    }                                                                                                                 // 53
                                                                                                                      //
    return getOne;                                                                                                    // 53
  }(),                                                                                                                // 53
  getAll: function () {                                                                                               // 54
    function getAll() {                                                                                               // 54
      return CommentsCollection.find({}, { sort: { createdAt: -1 } });                                                // 54
    }                                                                                                                 // 54
                                                                                                                      //
    return getAll;                                                                                                    // 54
  }(),                                                                                                                // 54
  add: add,                                                                                                           // 55
  reply: reply,                                                                                                       // 56
  remove: remove,                                                                                                     // 57
  removeReply: removeReply,                                                                                           // 58
  edit: edit,                                                                                                         // 59
  editReply: editReply,                                                                                               // 60
  like: like,                                                                                                         // 61
  likeReply: likeReply,                                                                                               // 62
  dislike: dislike,                                                                                                   // 63
  dislikeReply: dislikeReply,                                                                                         // 64
  star: star,                                                                                                         // 65
  starReply: starReply,                                                                                               // 66
  session: new ReactiveDict('commentsUi'),                                                                            // 67
  changeSchema: function () {                                                                                         // 68
    function changeSchema(cb) {                                                                                       // 68
      var currentSchema = CommentsCollection.simpleSchema().schema(),                                                 // 69
          callbackResult = cb(currentSchema),                                                                         // 69
          newSchema;                                                                                                  // 69
                                                                                                                      //
      newSchema = callbackResult ? callbackResult : currentSchema;                                                    // 73
      !!newSchema && CommentsCollection.attachSchema(newSchema, { replace: true });                                   // 74
    }                                                                                                                 // 75
                                                                                                                      //
    return changeSchema;                                                                                              // 68
  }(),                                                                                                                // 68
  getCount: function () {                                                                                             // 76
    function getCount(id, cb) {                                                                                       // 76
      return Meteor.call('comments/count', id, cb);                                                                   // 76
    }                                                                                                                 // 76
                                                                                                                      //
    return getCount;                                                                                                  // 76
  }(),                                                                                                                // 76
  analyzers: {                                                                                                        // 77
    image: imageAnalyzer,                                                                                             // 78
    youtube: youtubeAnalyzer                                                                                          // 79
  },                                                                                                                  // 77
  getCollection: function () {                                                                                        // 81
    function getCollection() {                                                                                        // 81
      return CommentsCollection;                                                                                      // 81
    }                                                                                                                 // 81
                                                                                                                      //
    return getCollection;                                                                                             // 81
  }(),                                                                                                                // 81
  getSortOption: function () {                                                                                        // 82
    function getSortOption(sorting) {                                                                                 // 82
      var options = _.filter(Comments.config().sortingOptions, function (option) {                                    // 83
        return option.value === sorting;                                                                              // 83
      });                                                                                                             // 83
                                                                                                                      //
      if (0 === options.length) {                                                                                     // 85
        throw new Meteor.Error('Invalid sorting specified');                                                          // 86
      }                                                                                                               // 87
                                                                                                                      //
      return options[0].sortSpecifier;                                                                                // 89
    }                                                                                                                 // 90
                                                                                                                      //
    return getSortOption;                                                                                             // 82
  }(),                                                                                                                // 82
  _collection: CommentsCollection,                                                                                    // 91
  _anonymousCollection: AnonymousUserCollection,                                                                      // 92
  _mediaService: mediaService                                                                                         // 93
};                                                                                                                    // 21
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 96
  Comments.ui = function () {                                                                                         // 97
    var _config = {                                                                                                   // 98
      limit: 5,                                                                                                       // 99
      loadMoreCount: 10,                                                                                              // 100
      template: 'semantic-ui',                                                                                        // 101
      defaultAvatar: 'http://s3.amazonaws.com/37assets/svn/765-default-avatar.png',                                   // 102
      markdown: false,                                                                                                // 103
      commentActions: []                                                                                              // 104
    };                                                                                                                // 98
                                                                                                                      //
    return {                                                                                                          // 107
      config: function () {                                                                                           // 108
        function config(newConfig) {                                                                                  // 108
          if (!newConfig) {                                                                                           // 109
            return _config;                                                                                           // 110
          }                                                                                                           // 111
                                                                                                                      //
          _config = _.extend(_config, newConfig);                                                                     // 113
        }                                                                                                             // 114
                                                                                                                      //
        return config;                                                                                                // 108
      }(),                                                                                                            // 108
      setContent: function () {                                                                                       // 115
        function setContent(content) {                                                                                // 115
          return Comments.session.set('content', content);                                                            // 115
        }                                                                                                             // 115
                                                                                                                      //
        return setContent;                                                                                            // 115
      }(),                                                                                                            // 115
      callIfLoggedIn: function () {                                                                                   // 116
        function callIfLoggedIn(action, cb) {                                                                         // 116
          if (!userService.getUserId()) {                                                                             // 117
            Comments.session.set('loginAction', action);                                                              // 118
          } else {                                                                                                    // 119
            return cb();                                                                                              // 120
          }                                                                                                           // 121
        }                                                                                                             // 122
                                                                                                                      //
        return callIfLoggedIn;                                                                                        // 116
      }(),                                                                                                            // 116
      getSorting: function () {                                                                                       // 123
        function getSorting(id) {                                                                                     // 123
          return Comments.session.get(id + '_sorting');                                                               // 124
        }                                                                                                             // 125
                                                                                                                      //
        return getSorting;                                                                                            // 123
      }()                                                                                                             // 123
    };                                                                                                                // 107
  }();                                                                                                                // 127
}                                                                                                                     // 128
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"node_modules":{"linkifyjs":{"string.js":["./lib/linkify-string",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/string.js                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.exports = require('./lib/linkify-string').default;                                                             // 1
                                                                                                                      // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"lib":{"linkify-string.js":["./linkify",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/lib/linkify-string.js                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';                                                                                                         // 1
                                                                                                                      // 2
exports.__esModule = true;                                                                                            // 3
                                                                                                                      // 4
var _linkify = require('./linkify');                                                                                  // 5
                                                                                                                      // 6
var linkify = _interopRequireWildcard(_linkify);                                                                      // 7
                                                                                                                      // 8
function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
                                                                                                                      // 10
var tokenize = linkify.tokenize; /**                                                                                  // 11
                                 	Convert strings of text into linkable HTML text                                     // 12
                                 */                                                                                   // 13
                                                                                                                      // 14
var options = linkify.options;                                                                                        // 15
                                                                                                                      // 16
function escapeText(text) {                                                                                           // 17
	return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');                                      // 18
}                                                                                                                     // 19
                                                                                                                      // 20
function escapeAttr(href) {                                                                                           // 21
	return href.replace(/"/g, '&quot;');                                                                                 // 22
}                                                                                                                     // 23
                                                                                                                      // 24
function attributesToString(attributes) {                                                                             // 25
                                                                                                                      // 26
	if (!attributes) return '';                                                                                          // 27
	var result = [];                                                                                                     // 28
                                                                                                                      // 29
	for (var attr in attributes) {                                                                                       // 30
		var val = (attributes[attr] + '').replace(/"/g, '&quot;');                                                          // 31
		result.push(attr + '="' + escapeAttr(val) + '"');                                                                   // 32
	}                                                                                                                    // 33
	return result.join(' ');                                                                                             // 34
}                                                                                                                     // 35
                                                                                                                      // 36
function linkifyStr(str) {                                                                                            // 37
	var opts = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];                                  // 38
                                                                                                                      // 39
                                                                                                                      // 40
	opts = options.normalize(opts);                                                                                      // 41
                                                                                                                      // 42
	var tokens = tokenize(str),                                                                                          // 43
	    result = [];                                                                                                     // 44
                                                                                                                      // 45
	for (var i = 0; i < tokens.length; i++) {                                                                            // 46
		var token = tokens[i];                                                                                              // 47
		var validated = token.isLink && options.resolve(opts.validate, token.toString(), token.type);                       // 48
                                                                                                                      // 49
		if (token.isLink && validated) {                                                                                    // 50
                                                                                                                      // 51
			var href = token.toHref(opts.defaultProtocol),                                                                     // 52
			    formatted = options.resolve(opts.format, token.toString(), token.type),                                        // 53
			    formattedHref = options.resolve(opts.formatHref, href, token.type),                                            // 54
			    attributesHash = options.resolve(opts.attributes, href, token.type),                                           // 55
			    tagName = options.resolve(opts.tagName, href, token.type),                                                     // 56
			    linkClass = options.resolve(opts.linkClass, href, token.type),                                                 // 57
			    target = options.resolve(opts.target, href, token.type);                                                       // 58
                                                                                                                      // 59
			var link = '<' + tagName + ' href="' + escapeAttr(formattedHref) + '" class="' + escapeAttr(linkClass) + '"';      // 60
			if (target) {                                                                                                      // 61
				link += ' target="' + escapeAttr(target) + '"';                                                                   // 62
			}                                                                                                                  // 63
                                                                                                                      // 64
			if (attributesHash) {                                                                                              // 65
				link += ' ' + attributesToString(attributesHash);                                                                 // 66
			}                                                                                                                  // 67
                                                                                                                      // 68
			link += '>' + escapeText(formatted) + '</' + tagName + '>';                                                        // 69
			result.push(link);                                                                                                 // 70
		} else if (token.type === 'nl' && opts.nl2br) {                                                                     // 71
			if (opts.newLine) {                                                                                                // 72
				result.push(opts.newLine);                                                                                        // 73
			} else {                                                                                                           // 74
				result.push('<br>\n');                                                                                            // 75
			}                                                                                                                  // 76
		} else {                                                                                                            // 77
			result.push(escapeText(token.toString()));                                                                         // 78
		}                                                                                                                   // 79
	}                                                                                                                    // 80
                                                                                                                      // 81
	return result.join('');                                                                                              // 82
}                                                                                                                     // 83
                                                                                                                      // 84
if (!String.prototype.linkify) {                                                                                      // 85
	String.prototype.linkify = function (options) {                                                                      // 86
		return linkifyStr(this, options);                                                                                   // 87
	};                                                                                                                   // 88
}                                                                                                                     // 89
                                                                                                                      // 90
exports.default = linkifyStr;                                                                                         // 91
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"linkify.js":["./linkify/utils/options","./linkify/core/scanner","./linkify/core/parser",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/lib/linkify.js                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';                                                                                                         // 1
                                                                                                                      // 2
exports.__esModule = true;                                                                                            // 3
exports.tokenize = exports.test = exports.scanner = exports.parser = exports.options = exports.find = undefined;      // 4
                                                                                                                      // 5
var _options = require('./linkify/utils/options');                                                                    // 6
                                                                                                                      // 7
var options = _interopRequireWildcard(_options);                                                                      // 8
                                                                                                                      // 9
var _scanner = require('./linkify/core/scanner');                                                                     // 10
                                                                                                                      // 11
var scanner = _interopRequireWildcard(_scanner);                                                                      // 12
                                                                                                                      // 13
var _parser = require('./linkify/core/parser');                                                                       // 14
                                                                                                                      // 15
var parser = _interopRequireWildcard(_parser);                                                                        // 16
                                                                                                                      // 17
function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
                                                                                                                      // 19
if (!Array.isArray) {                                                                                                 // 20
	Array.isArray = function (arg) {                                                                                     // 21
		return Object.prototype.toString.call(arg) === '[object Array]';                                                    // 22
	};                                                                                                                   // 23
}                                                                                                                     // 24
                                                                                                                      // 25
/**                                                                                                                   // 26
	Converts a string into tokens that represent linkable and non-linkable bits                                          // 27
	@method tokenize                                                                                                     // 28
	@param {String} str                                                                                                  // 29
	@return {Array} tokens                                                                                               // 30
*/                                                                                                                    // 31
var tokenize = function tokenize(str) {                                                                               // 32
	return parser.run(scanner.run(str));                                                                                 // 33
};                                                                                                                    // 34
                                                                                                                      // 35
/**                                                                                                                   // 36
	Returns a list of linkable items in the given string.                                                                // 37
*/                                                                                                                    // 38
var find = function find(str) {                                                                                       // 39
	var type = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];                                // 40
                                                                                                                      // 41
                                                                                                                      // 42
	var tokens = tokenize(str),                                                                                          // 43
	    filtered = [];                                                                                                   // 44
                                                                                                                      // 45
	for (var i = 0; i < tokens.length; i++) {                                                                            // 46
		if (tokens[i].isLink && (!type || tokens[i].type === type)) {                                                       // 47
			filtered.push(tokens[i].toObject());                                                                               // 48
		}                                                                                                                   // 49
	}                                                                                                                    // 50
                                                                                                                      // 51
	return filtered;                                                                                                     // 52
};                                                                                                                    // 53
                                                                                                                      // 54
/**                                                                                                                   // 55
	Is the given string valid linkable text of some sort                                                                 // 56
	Note that this does not trim the text for you.                                                                       // 57
                                                                                                                      // 58
	Optionally pass in a second `type` param, which is the type of link to test                                          // 59
	for.                                                                                                                 // 60
                                                                                                                      // 61
	For example,                                                                                                         // 62
                                                                                                                      // 63
		test(str, 'email');                                                                                                 // 64
                                                                                                                      // 65
	Will return `true` if str is a valid email.                                                                          // 66
*/                                                                                                                    // 67
var test = function test(str) {                                                                                       // 68
	var type = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];                                // 69
                                                                                                                      // 70
	var tokens = tokenize(str);                                                                                          // 71
	return tokens.length === 1 && tokens[0].isLink && (!type || tokens[0].type === type);                                // 72
};                                                                                                                    // 73
                                                                                                                      // 74
// Scanner and parser provide states and tokens for the lexicographic stage                                           // 75
// (will be used to add additional link types)                                                                        // 76
exports.find = find;                                                                                                  // 77
exports.options = options;                                                                                            // 78
exports.parser = parser;                                                                                              // 79
exports.scanner = scanner;                                                                                            // 80
exports.test = test;                                                                                                  // 81
exports.tokenize = tokenize;                                                                                          // 82
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"linkify":{"utils":{"options.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/lib/linkify/utils/options.js                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';                                                                                                         // 1
                                                                                                                      // 2
exports.__esModule = true;                                                                                            // 3
exports.normalize = normalize;                                                                                        // 4
exports.resolve = resolve;                                                                                            // 5
exports.contains = contains;                                                                                          // 6
/**                                                                                                                   // 7
 * Convert set of options into objects including all the defaults                                                     // 8
 */                                                                                                                   // 9
function normalize(opts) {                                                                                            // 10
	opts = opts || {};                                                                                                   // 11
	var newLine = opts.newLine || false; // deprecated                                                                   // 12
	var ignoreTags = opts.ignoreTags || [];                                                                              // 13
                                                                                                                      // 14
	// Make all tags names upper case                                                                                    // 15
	for (var i = 0; i < ignoreTags.length; i++) {                                                                        // 16
		ignoreTags[i] = ignoreTags[i].toUpperCase();                                                                        // 17
	}                                                                                                                    // 18
                                                                                                                      // 19
	return {                                                                                                             // 20
		attributes: opts.linkAttributes || null,                                                                            // 21
		defaultProtocol: opts.defaultProtocol || 'http',                                                                    // 22
		events: opts.events || null,                                                                                        // 23
		format: opts.format || noop,                                                                                        // 24
		validate: opts.validate || yes,                                                                                     // 25
		formatHref: opts.formatHref || noop,                                                                                // 26
		newLine: opts.newLine || false, // deprecated                                                                       // 27
		nl2br: !!newLine || opts.nl2br || false,                                                                            // 28
		tagName: opts.tagName || 'a',                                                                                       // 29
		target: opts.target || typeToTarget,                                                                                // 30
		linkClass: opts.linkClass || 'linkified',                                                                           // 31
		ignoreTags: ignoreTags                                                                                              // 32
	};                                                                                                                   // 33
}                                                                                                                     // 34
                                                                                                                      // 35
/**                                                                                                                   // 36
 * Resolve an option's value based on the value of the option and the given                                           // 37
 * params                                                                                                             // 38
 */                                                                                                                   // 39
function resolve(value) {                                                                                             // 40
	for (var _len = arguments.length, params = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {          // 41
		params[_key - 1] = arguments[_key];                                                                                 // 42
	}                                                                                                                    // 43
                                                                                                                      // 44
	return typeof value === 'function' ? value.apply(undefined, params) : value;                                         // 45
}                                                                                                                     // 46
                                                                                                                      // 47
/**                                                                                                                   // 48
 * Quick indexOf replacement for checking the ignoreTags option                                                       // 49
 */                                                                                                                   // 50
function contains(arr, value) {                                                                                       // 51
	for (var i = 0; i < arr.length; i++) {                                                                               // 52
		if (arr[i] == value) {                                                                                              // 53
			return true;                                                                                                       // 54
		}                                                                                                                   // 55
	}                                                                                                                    // 56
	return false;                                                                                                        // 57
}                                                                                                                     // 58
                                                                                                                      // 59
function noop(val) {                                                                                                  // 60
	return val;                                                                                                          // 61
}                                                                                                                     // 62
                                                                                                                      // 63
function yes(val) {                                                                                                   // 64
	return true;                                                                                                         // 65
}                                                                                                                     // 66
                                                                                                                      // 67
function typeToTarget(href, type) {                                                                                   // 68
	return type === 'url' ? '_blank' : null;                                                                             // 69
}                                                                                                                     // 70
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"core":{"scanner.js":["./tokens","./state",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/lib/linkify/core/scanner.js                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';                                                                                                         // 1
                                                                                                                      // 2
exports.__esModule = true;                                                                                            // 3
exports.start = exports.run = exports.TOKENS = exports.State = undefined;                                             // 4
                                                                                                                      // 5
var _tokens = require('./tokens');                                                                                    // 6
                                                                                                                      // 7
var _state = require('./state');                                                                                      // 8
                                                                                                                      // 9
/**                                                                                                                   // 10
	The scanner provides an interface that takes a string of text as input, and                                          // 11
	outputs an array of tokens instances that can be used for easy URL parsing.                                          // 12
                                                                                                                      // 13
	@module linkify                                                                                                      // 14
	@submodule scanner                                                                                                   // 15
	@main scanner                                                                                                        // 16
*/                                                                                                                    // 17
                                                                                                                      // 18
var tlds = 'abogado|ac|academy|accountants|active|actor|ad|adult|ae|aero|af|ag|agency|ai|airforce|al|allfinanz|alsace|am|an|android|ao|aq|aquarelle|ar|archi|army|arpa|as|asia|associates|at|attorney|au|auction|audio|autos|aw|ax|axa|az|ba|band|bar|bargains|bayern|bb|bd|be|beer|berlin|best|bf|bg|bh|bi|bid|bike|bio|biz|bj|black|blackfriday|bloomberg|blue|bm|bmw|bn|bnpparibas|bo|boo|boutique|br|brussels|bs|bt|budapest|build|builders|business|buzz|bv|bw|by|bz|bzh|ca|cab|cal|camera|camp|cancerresearch|capetown|capital|caravan|cards|care|career|careers|casa|cash|cat|catering|cc|cd|center|ceo|cern|cf|cg|ch|channel|cheap|christmas|chrome|church|ci|citic|city|ck|cl|claims|cleaning|click|clinic|clothing|club|cm|cn|co|coach|codes|coffee|college|cologne|com|community|company|computer|condos|construction|consulting|contractors|cooking|cool|coop|country|cr|credit|creditcard|cricket|crs|cruises|cu|cuisinella|cv|cw|cx|cy|cymru|cz|dad|dance|dating|day|de|deals|degree|delivery|democrat|dental|dentist|desi|diamonds|diet|digital|direct|directory|discount|dj|dk|dm|dnp|do|domains|durban|dvag|dz|eat|ec|edu|education|ee|eg|email|emerck|energy|engineer|engineering|enterprises|equipment|er|es|esq|estate|et|eu|eurovision|eus|events|everbank|exchange|expert|exposed|fail|farm|fashion|feedback|fi|finance|financial|firmdale|fish|fishing|fitness|fj|fk|flights|florist|flsmidth|fly|fm|fo|foo|forsale|foundation|fr|frl|frogans|fund|furniture|futbol|ga|gal|gallery|gb|gbiz|gd|ge|gent|gf|gg|gh|gi|gift|gifts|gives|gl|glass|gle|global|globo|gm|gmail|gmo|gmx|gn|google|gop|gov|gp|gq|gr|graphics|gratis|green|gripe|gs|gt|gu|guide|guitars|guru|gw|gy|hamburg|haus|healthcare|help|here|hiphop|hiv|hk|hm|hn|holdings|holiday|homes|horse|host|hosting|house|how|hr|ht|hu|ibm|id|ie|il|im|immo|immobilien|in|industries|info|ing|ink|institute|insure|int|international|investments|io|iq|ir|irish|is|it|je|jetzt|jm|jo|jobs|joburg|jp|juegos|kaufen|ke|kg|kh|ki|kim|kitchen|kiwi|km|kn|koeln|kp|kr|krd|kred|kw|ky|kz|la|lacaixa|land|latrobe|lawyer|lb|lc|lds|lease|legal|lgbt|li|life|lighting|limited|limo|link|lk|loans|local|london|lotto|lr|ls|lt|ltda|lu|luxe|luxury|lv|ly|ma|madrid|maison|management|mango|market|marketing|mc|md|me|media|meet|melbourne|meme|memorial|menu|mg|mh|miami|mil|mini|mk|ml|mm|mn|mo|mobi|moda|moe|monash|money|mormon|mortgage|moscow|motorcycles|mov|mp|mq|mr|ms|mt|mu|museum|mv|mw|mx|my|mz|na|nagoya|name|navy|nc|ne|net|network|neustar|new|nexus|nf|ng|ngo|nhk|ni|ninja|nl|no|np|nr|nra|nrw|nu|nyc|nz|okinawa|om|ong|onl|ooo|org|organic|otsuka|ovh|pa|paris|partners|parts|party|pe|pf|pg|ph|pharmacy|photo|photography|photos|physio|pics|pictures|pink|pizza|pk|pl|place|plumbing|pm|pn|pohl|poker|porn|post|pr|praxi|press|pro|prod|productions|prof|properties|property|ps|pt|pub|pw|py|qa|qpon|quebec|re|realtor|recipes|red|rehab|reise|reisen|reit|ren|rentals|repair|report|republican|rest|restaurant|reviews|rich|rio|rip|ro|rocks|rodeo|rs|rsvp|ru|ruhr|rw|ryukyu|sa|saarland|sarl|sb|sc|sca|scb|schmidt|schule|science|scot|sd|se|services|sexy|sg|sh|shiksha|shoes|si|singles|sj|sk|sl|sm|sn|so|social|software|sohu|solar|solutions|soy|space|spiegel|sr|st|su|supplies|supply|support|surf|surgery|suzuki|sv|sx|sy|sydney|systems|sz|taipei|tatar|tattoo|tax|tc|td|technology|tel|tf|tg|th|tienda|tips|tirol|tj|tk|tl|tm|tn|to|today|tokyo|tools|top|town|toys|tp|tr|trade|training|travel|trust|tt|tui|tv|tw|tz|ua|ug|uk|university|uno|uol|us|uy|uz|va|vacations|vc|ve|vegas|ventures|versicherung|vet|vg|vi|viajes|villas|vision|vlaanderen|vn|vodka|vote|voting|voto|voyage|vu|wales|wang|watch|webcam|website|wed|wedding|wf|whoswho|wien|wiki|williamhill|wme|work|works|world|ws|wtc|wtf|xxx|xyz|yachts|yandex|ye|yoga|yokohama|youtube|yt|za|zip|zm|zone|zw'.split('|'); // macro, see gulpfile.js
                                                                                                                      // 20
var REGEXP_NUM = /[0-9]/,                                                                                             // 21
    REGEXP_ALPHANUM = /[a-z0-9]/,                                                                                     // 22
    COLON = ':';                                                                                                      // 23
                                                                                                                      // 24
var domainStates = [],                                                                                                // 25
    // states that jump to DOMAIN on /[a-z0-9]/                                                                       // 26
makeState = function makeState(tokenClass) {                                                                          // 27
	return new _state.CharacterState(tokenClass);                                                                        // 28
};                                                                                                                    // 29
                                                                                                                      // 30
var // Frequently used tokens                                                                                         // 31
T_DOMAIN = _tokens.text.DOMAIN,                                                                                       // 32
    T_LOCALHOST = _tokens.text.LOCALHOST,                                                                             // 33
    T_NUM = _tokens.text.NUM,                                                                                         // 34
    T_PROTOCOL = _tokens.text.PROTOCOL,                                                                               // 35
    T_TLD = _tokens.text.TLD,                                                                                         // 36
    T_WS = _tokens.text.WS;                                                                                           // 37
                                                                                                                      // 38
var // Frequently used states                                                                                         // 39
S_START = makeState(),                                                                                                // 40
    // start state                                                                                                    // 41
S_NUM = makeState(T_NUM),                                                                                             // 42
    S_DOMAIN = makeState(T_DOMAIN),                                                                                   // 43
    S_DOMAIN_HYPHEN = makeState(),                                                                                    // 44
    // domain followed by 1 or more hyphen characters                                                                 // 45
S_WS = makeState(T_WS);                                                                                               // 46
                                                                                                                      // 47
// States for special URL symbols                                                                                     // 48
S_START.on('@', makeState(_tokens.text.AT)).on('.', makeState(_tokens.text.DOT)).on('+', makeState(_tokens.text.PLUS)).on('#', makeState(_tokens.text.POUND)).on('?', makeState(_tokens.text.QUERY)).on('/', makeState(_tokens.text.SLASH)).on(COLON, makeState(_tokens.text.COLON)).on('{', makeState(_tokens.text.OPENBRACE)).on('[', makeState(_tokens.text.OPENBRACKET)).on('(', makeState(_tokens.text.OPENPAREN)).on('}', makeState(_tokens.text.CLOSEBRACE)).on(']', makeState(_tokens.text.CLOSEBRACKET)).on(')', makeState(_tokens.text.CLOSEPAREN)).on(/[,;!]/, makeState(_tokens.text.PUNCTUATION));
                                                                                                                      // 50
// Whitespace jumps                                                                                                   // 51
// Tokens of only non-newline whitespace are arbitrarily long                                                         // 52
S_START.on(/\n/, makeState(_tokens.text.NL)).on(/\s/, S_WS);                                                          // 53
                                                                                                                      // 54
// If any whitespace except newline, more whitespace!                                                                 // 55
S_WS.on(/[^\S\n]/, S_WS);                                                                                             // 56
                                                                                                                      // 57
// Generates states for top-level domains                                                                             // 58
// Note that this is most accurate when tlds are in alphabetical order                                                // 59
for (var i = 0; i < tlds.length; i++) {                                                                               // 60
	var newStates = (0, _state.stateify)(tlds[i], S_START, T_TLD, T_DOMAIN);                                             // 61
	domainStates.push.apply(domainStates, newStates);                                                                    // 62
}                                                                                                                     // 63
                                                                                                                      // 64
// Collect the states generated by different protocls                                                                 // 65
var partialProtocolFileStates = (0, _state.stateify)('file', S_START, T_DOMAIN, T_DOMAIN),                            // 66
    partialProtocolFtpStates = (0, _state.stateify)('ftp', S_START, T_DOMAIN, T_DOMAIN),                              // 67
    partialProtocolHttpStates = (0, _state.stateify)('http', S_START, T_DOMAIN, T_DOMAIN);                            // 68
                                                                                                                      // 69
// Add the states to the array of DOMAINeric states                                                                   // 70
domainStates.push.apply(domainStates, partialProtocolFileStates);                                                     // 71
domainStates.push.apply(domainStates, partialProtocolFtpStates);                                                      // 72
domainStates.push.apply(domainStates, partialProtocolHttpStates);                                                     // 73
                                                                                                                      // 74
var // Protocol states                                                                                                // 75
S_PROTOCOL_FILE = partialProtocolFileStates.pop(),                                                                    // 76
    S_PROTOCOL_FTP = partialProtocolFtpStates.pop(),                                                                  // 77
    S_PROTOCOL_HTTP = partialProtocolHttpStates.pop(),                                                                // 78
    S_PROTOCOL_SECURE = makeState(T_DOMAIN),                                                                          // 79
    S_FULL_PROTOCOL = makeState(T_PROTOCOL); // Full protocol ends with COLON                                         // 80
                                                                                                                      // 81
// Secure protocols (end with 's')                                                                                    // 82
S_PROTOCOL_FTP.on('s', S_PROTOCOL_SECURE).on(COLON, S_FULL_PROTOCOL);                                                 // 83
                                                                                                                      // 84
S_PROTOCOL_HTTP.on('s', S_PROTOCOL_SECURE).on(COLON, S_FULL_PROTOCOL);                                                // 85
                                                                                                                      // 86
domainStates.push(S_PROTOCOL_SECURE);                                                                                 // 87
                                                                                                                      // 88
// Become protocol tokens after a COLON                                                                               // 89
S_PROTOCOL_FILE.on(COLON, S_FULL_PROTOCOL);                                                                           // 90
S_PROTOCOL_SECURE.on(COLON, S_FULL_PROTOCOL);                                                                         // 91
                                                                                                                      // 92
// Localhost                                                                                                          // 93
var partialLocalhostStates = (0, _state.stateify)('localhost', S_START, T_LOCALHOST, T_DOMAIN);                       // 94
domainStates.push.apply(domainStates, partialLocalhostStates);                                                        // 95
                                                                                                                      // 96
// Everything else                                                                                                    // 97
// DOMAINs make more DOMAINs                                                                                          // 98
// Number and character transitions                                                                                   // 99
S_START.on(REGEXP_NUM, S_NUM);                                                                                        // 100
S_NUM.on('-', S_DOMAIN_HYPHEN).on(REGEXP_NUM, S_NUM).on(REGEXP_ALPHANUM, S_DOMAIN); // number becomes DOMAIN          // 101
                                                                                                                      // 102
S_DOMAIN.on('-', S_DOMAIN_HYPHEN).on(REGEXP_ALPHANUM, S_DOMAIN);                                                      // 103
                                                                                                                      // 104
// All the generated states should have a jump to DOMAIN                                                              // 105
for (var _i = 0; _i < domainStates.length; _i++) {                                                                    // 106
	domainStates[_i].on('-', S_DOMAIN_HYPHEN).on(REGEXP_ALPHANUM, S_DOMAIN);                                             // 107
}                                                                                                                     // 108
                                                                                                                      // 109
S_DOMAIN_HYPHEN.on('-', S_DOMAIN_HYPHEN).on(REGEXP_NUM, S_DOMAIN).on(REGEXP_ALPHANUM, S_DOMAIN);                      // 110
                                                                                                                      // 111
// Any other character is considered a single symbol token                                                            // 112
S_START.on(/./, makeState(_tokens.text.SYM));                                                                         // 113
                                                                                                                      // 114
/**                                                                                                                   // 115
	Given a string, returns an array of TOKEN instances representing the                                                 // 116
	composition of that string.                                                                                          // 117
                                                                                                                      // 118
	@method run                                                                                                          // 119
	@param {String} str Input string to scan                                                                             // 120
	@return {Array} Array of TOKEN instances                                                                             // 121
*/                                                                                                                    // 122
var run = function run(str) {                                                                                         // 123
                                                                                                                      // 124
	// The state machine only looks at lowercase strings.                                                                // 125
	// This selective `toLowerCase` is used because lowercasing the entire                                               // 126
	// string causes the length and character position to vary in some in some                                           // 127
	// non-English strings. This happens only on V8-based runtimes.                                                      // 128
	var lowerStr = str.replace(/[A-Z]/g, function (c) {                                                                  // 129
		return c.toLowerCase();                                                                                             // 130
	});                                                                                                                  // 131
	var len = str.length;                                                                                                // 132
	var tokens = []; // return value                                                                                     // 133
                                                                                                                      // 134
	var cursor = 0;                                                                                                      // 135
                                                                                                                      // 136
	// Tokenize the string                                                                                               // 137
	while (cursor < len) {                                                                                               // 138
                                                                                                                      // 139
		var state = S_START,                                                                                                // 140
		    secondState = null,                                                                                             // 141
		    nextState = null,                                                                                               // 142
		    tokenLength = 0,                                                                                                // 143
		    latestAccepting = null,                                                                                         // 144
		    sinceAccepts = -1;                                                                                              // 145
                                                                                                                      // 146
		while (cursor < len && (nextState = state.next(lowerStr[cursor]))) {                                                // 147
			secondState = null;                                                                                                // 148
			state = nextState;                                                                                                 // 149
                                                                                                                      // 150
			// Keep track of the latest accepting state                                                                        // 151
			if (state.accepts()) {                                                                                             // 152
				sinceAccepts = 0;                                                                                                 // 153
				latestAccepting = state;                                                                                          // 154
			} else if (sinceAccepts >= 0) {                                                                                    // 155
				sinceAccepts++;                                                                                                   // 156
			}                                                                                                                  // 157
                                                                                                                      // 158
			tokenLength++;                                                                                                     // 159
			cursor++;                                                                                                          // 160
		}                                                                                                                   // 161
                                                                                                                      // 162
		if (sinceAccepts < 0) continue; // Should never happen                                                              // 163
                                                                                                                      // 164
		// Roll back to the latest accepting state                                                                          // 165
		cursor -= sinceAccepts;                                                                                             // 166
		tokenLength -= sinceAccepts;                                                                                        // 167
                                                                                                                      // 168
		// Get the class for the new token                                                                                  // 169
		var TOKEN = latestAccepting.emit(); // Current token class                                                          // 170
                                                                                                                      // 171
		// No more jumps, just make a new token                                                                             // 172
		tokens.push(new TOKEN(str.substr(cursor - tokenLength, tokenLength)));                                              // 173
	}                                                                                                                    // 174
                                                                                                                      // 175
	return tokens;                                                                                                       // 176
};                                                                                                                    // 177
                                                                                                                      // 178
var start = S_START;                                                                                                  // 179
exports.State = _state.CharacterState;                                                                                // 180
exports.TOKENS = _tokens.text;                                                                                        // 181
exports.run = run;                                                                                                    // 182
exports.start = start;                                                                                                // 183
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"tokens.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/lib/linkify/core/tokens.js                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';                                                                                                         // 1
                                                                                                                      // 2
exports.__esModule = true;                                                                                            // 3
                                                                                                                      // 4
function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
                                                                                                                      // 6
function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
                                                                                                                      // 8
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
                                                                                                                      // 10
/******************************************************************************                                       // 11
	Text Tokens                                                                                                          // 12
	Tokens composed of strings                                                                                           // 13
******************************************************************************/                                       // 14
                                                                                                                      // 15
/**                                                                                                                   // 16
	Abstract class used for manufacturing text tokens.                                                                   // 17
	Pass in the value this token represents                                                                              // 18
                                                                                                                      // 19
	@class TextToken                                                                                                     // 20
	@abstract                                                                                                            // 21
*/                                                                                                                    // 22
                                                                                                                      // 23
var TextToken = function () {                                                                                         // 24
	/**                                                                                                                  // 25
 	@method constructor                                                                                                 // 26
 	@param {String} value The string of characters representing this particular Token                                   // 27
 */                                                                                                                   // 28
                                                                                                                      // 29
	function TextToken(value) {                                                                                          // 30
		_classCallCheck(this, TextToken);                                                                                   // 31
                                                                                                                      // 32
		this.v = value;                                                                                                     // 33
	}                                                                                                                    // 34
                                                                                                                      // 35
	/**                                                                                                                  // 36
 	String representing the type for this token                                                                         // 37
 	@property type                                                                                                      // 38
 	@default 'TOKEN'                                                                                                    // 39
 */                                                                                                                   // 40
                                                                                                                      // 41
	TextToken.prototype.toString = function toString() {                                                                 // 42
		return this.v + '';                                                                                                 // 43
	};                                                                                                                   // 44
                                                                                                                      // 45
	return TextToken;                                                                                                    // 46
}();                                                                                                                  // 47
                                                                                                                      // 48
/**                                                                                                                   // 49
	A valid domain token                                                                                                 // 50
	@class DOMAIN                                                                                                        // 51
	@extends TextToken                                                                                                   // 52
*/                                                                                                                    // 53
                                                                                                                      // 54
                                                                                                                      // 55
var DOMAIN = function (_TextToken) {                                                                                  // 56
	_inherits(DOMAIN, _TextToken);                                                                                       // 57
                                                                                                                      // 58
	function DOMAIN() {                                                                                                  // 59
		_classCallCheck(this, DOMAIN);                                                                                      // 60
                                                                                                                      // 61
		return _possibleConstructorReturn(this, _TextToken.apply(this, arguments));                                         // 62
	}                                                                                                                    // 63
                                                                                                                      // 64
	return DOMAIN;                                                                                                       // 65
}(TextToken);                                                                                                         // 66
                                                                                                                      // 67
/**                                                                                                                   // 68
	@class AT                                                                                                            // 69
	@extends TextToken                                                                                                   // 70
*/                                                                                                                    // 71
                                                                                                                      // 72
                                                                                                                      // 73
var AT = function (_TextToken2) {                                                                                     // 74
	_inherits(AT, _TextToken2);                                                                                          // 75
                                                                                                                      // 76
	function AT() {                                                                                                      // 77
		_classCallCheck(this, AT);                                                                                          // 78
                                                                                                                      // 79
		return _possibleConstructorReturn(this, _TextToken2.call(this, '@'));                                               // 80
	}                                                                                                                    // 81
                                                                                                                      // 82
	return AT;                                                                                                           // 83
}(TextToken);                                                                                                         // 84
                                                                                                                      // 85
/**                                                                                                                   // 86
	Represents a single colon `:` character                                                                              // 87
                                                                                                                      // 88
	@class COLON                                                                                                         // 89
	@extends TextToken                                                                                                   // 90
*/                                                                                                                    // 91
                                                                                                                      // 92
                                                                                                                      // 93
var COLON = function (_TextToken3) {                                                                                  // 94
	_inherits(COLON, _TextToken3);                                                                                       // 95
                                                                                                                      // 96
	function COLON() {                                                                                                   // 97
		_classCallCheck(this, COLON);                                                                                       // 98
                                                                                                                      // 99
		return _possibleConstructorReturn(this, _TextToken3.call(this, ':'));                                               // 100
	}                                                                                                                    // 101
                                                                                                                      // 102
	return COLON;                                                                                                        // 103
}(TextToken);                                                                                                         // 104
                                                                                                                      // 105
/**                                                                                                                   // 106
	@class DOT                                                                                                           // 107
	@extends TextToken                                                                                                   // 108
*/                                                                                                                    // 109
                                                                                                                      // 110
                                                                                                                      // 111
var DOT = function (_TextToken4) {                                                                                    // 112
	_inherits(DOT, _TextToken4);                                                                                         // 113
                                                                                                                      // 114
	function DOT() {                                                                                                     // 115
		_classCallCheck(this, DOT);                                                                                         // 116
                                                                                                                      // 117
		return _possibleConstructorReturn(this, _TextToken4.call(this, '.'));                                               // 118
	}                                                                                                                    // 119
                                                                                                                      // 120
	return DOT;                                                                                                          // 121
}(TextToken);                                                                                                         // 122
                                                                                                                      // 123
/**                                                                                                                   // 124
	A character class that can surround the URL, but which the URL cannot begin                                          // 125
	or end with. Does not include certain English punctuation like parentheses.                                          // 126
                                                                                                                      // 127
	@class PUNCTUATION                                                                                                   // 128
	@extends TextToken                                                                                                   // 129
*/                                                                                                                    // 130
                                                                                                                      // 131
                                                                                                                      // 132
var PUNCTUATION = function (_TextToken5) {                                                                            // 133
	_inherits(PUNCTUATION, _TextToken5);                                                                                 // 134
                                                                                                                      // 135
	function PUNCTUATION() {                                                                                             // 136
		_classCallCheck(this, PUNCTUATION);                                                                                 // 137
                                                                                                                      // 138
		return _possibleConstructorReturn(this, _TextToken5.apply(this, arguments));                                        // 139
	}                                                                                                                    // 140
                                                                                                                      // 141
	return PUNCTUATION;                                                                                                  // 142
}(TextToken);                                                                                                         // 143
                                                                                                                      // 144
/**                                                                                                                   // 145
	The word localhost (by itself)                                                                                       // 146
	@class LOCALHOST                                                                                                     // 147
	@extends TextToken                                                                                                   // 148
*/                                                                                                                    // 149
                                                                                                                      // 150
                                                                                                                      // 151
var LOCALHOST = function (_TextToken6) {                                                                              // 152
	_inherits(LOCALHOST, _TextToken6);                                                                                   // 153
                                                                                                                      // 154
	function LOCALHOST() {                                                                                               // 155
		_classCallCheck(this, LOCALHOST);                                                                                   // 156
                                                                                                                      // 157
		return _possibleConstructorReturn(this, _TextToken6.apply(this, arguments));                                        // 158
	}                                                                                                                    // 159
                                                                                                                      // 160
	return LOCALHOST;                                                                                                    // 161
}(TextToken);                                                                                                         // 162
                                                                                                                      // 163
/**                                                                                                                   // 164
	Newline token                                                                                                        // 165
	@class TNL                                                                                                           // 166
	@extends TextToken                                                                                                   // 167
*/                                                                                                                    // 168
                                                                                                                      // 169
                                                                                                                      // 170
var TNL = function (_TextToken7) {                                                                                    // 171
	_inherits(TNL, _TextToken7);                                                                                         // 172
                                                                                                                      // 173
	function TNL() {                                                                                                     // 174
		_classCallCheck(this, TNL);                                                                                         // 175
                                                                                                                      // 176
		return _possibleConstructorReturn(this, _TextToken7.call(this, '\n'));                                              // 177
	}                                                                                                                    // 178
                                                                                                                      // 179
	return TNL;                                                                                                          // 180
}(TextToken);                                                                                                         // 181
                                                                                                                      // 182
/**                                                                                                                   // 183
	@class NUM                                                                                                           // 184
	@extends TextToken                                                                                                   // 185
*/                                                                                                                    // 186
                                                                                                                      // 187
                                                                                                                      // 188
var NUM = function (_TextToken8) {                                                                                    // 189
	_inherits(NUM, _TextToken8);                                                                                         // 190
                                                                                                                      // 191
	function NUM() {                                                                                                     // 192
		_classCallCheck(this, NUM);                                                                                         // 193
                                                                                                                      // 194
		return _possibleConstructorReturn(this, _TextToken8.apply(this, arguments));                                        // 195
	}                                                                                                                    // 196
                                                                                                                      // 197
	return NUM;                                                                                                          // 198
}(TextToken);                                                                                                         // 199
                                                                                                                      // 200
/**                                                                                                                   // 201
	@class PLUS                                                                                                          // 202
	@extends TextToken                                                                                                   // 203
*/                                                                                                                    // 204
                                                                                                                      // 205
                                                                                                                      // 206
var PLUS = function (_TextToken9) {                                                                                   // 207
	_inherits(PLUS, _TextToken9);                                                                                        // 208
                                                                                                                      // 209
	function PLUS() {                                                                                                    // 210
		_classCallCheck(this, PLUS);                                                                                        // 211
                                                                                                                      // 212
		return _possibleConstructorReturn(this, _TextToken9.call(this, '+'));                                               // 213
	}                                                                                                                    // 214
                                                                                                                      // 215
	return PLUS;                                                                                                         // 216
}(TextToken);                                                                                                         // 217
                                                                                                                      // 218
/**                                                                                                                   // 219
	@class POUND                                                                                                         // 220
	@extends TextToken                                                                                                   // 221
*/                                                                                                                    // 222
                                                                                                                      // 223
                                                                                                                      // 224
var POUND = function (_TextToken10) {                                                                                 // 225
	_inherits(POUND, _TextToken10);                                                                                      // 226
                                                                                                                      // 227
	function POUND() {                                                                                                   // 228
		_classCallCheck(this, POUND);                                                                                       // 229
                                                                                                                      // 230
		return _possibleConstructorReturn(this, _TextToken10.call(this, '#'));                                              // 231
	}                                                                                                                    // 232
                                                                                                                      // 233
	return POUND;                                                                                                        // 234
}(TextToken);                                                                                                         // 235
                                                                                                                      // 236
/**                                                                                                                   // 237
	Represents a web URL protocol. Supported types include                                                               // 238
                                                                                                                      // 239
	* `http:`                                                                                                            // 240
	* `https:`                                                                                                           // 241
	* `ftp:`                                                                                                             // 242
	* `ftps:`                                                                                                            // 243
	* There's Another super weird one                                                                                    // 244
                                                                                                                      // 245
	@class PROTOCOL                                                                                                      // 246
	@extends TextToken                                                                                                   // 247
*/                                                                                                                    // 248
                                                                                                                      // 249
                                                                                                                      // 250
var PROTOCOL = function (_TextToken11) {                                                                              // 251
	_inherits(PROTOCOL, _TextToken11);                                                                                   // 252
                                                                                                                      // 253
	function PROTOCOL() {                                                                                                // 254
		_classCallCheck(this, PROTOCOL);                                                                                    // 255
                                                                                                                      // 256
		return _possibleConstructorReturn(this, _TextToken11.apply(this, arguments));                                       // 257
	}                                                                                                                    // 258
                                                                                                                      // 259
	return PROTOCOL;                                                                                                     // 260
}(TextToken);                                                                                                         // 261
                                                                                                                      // 262
/**                                                                                                                   // 263
	@class QUERY                                                                                                         // 264
	@extends TextToken                                                                                                   // 265
*/                                                                                                                    // 266
                                                                                                                      // 267
                                                                                                                      // 268
var QUERY = function (_TextToken12) {                                                                                 // 269
	_inherits(QUERY, _TextToken12);                                                                                      // 270
                                                                                                                      // 271
	function QUERY() {                                                                                                   // 272
		_classCallCheck(this, QUERY);                                                                                       // 273
                                                                                                                      // 274
		return _possibleConstructorReturn(this, _TextToken12.call(this, '?'));                                              // 275
	}                                                                                                                    // 276
                                                                                                                      // 277
	return QUERY;                                                                                                        // 278
}(TextToken);                                                                                                         // 279
                                                                                                                      // 280
/**                                                                                                                   // 281
	@class SLASH                                                                                                         // 282
	@extends TextToken                                                                                                   // 283
*/                                                                                                                    // 284
                                                                                                                      // 285
                                                                                                                      // 286
var SLASH = function (_TextToken13) {                                                                                 // 287
	_inherits(SLASH, _TextToken13);                                                                                      // 288
                                                                                                                      // 289
	function SLASH() {                                                                                                   // 290
		_classCallCheck(this, SLASH);                                                                                       // 291
                                                                                                                      // 292
		return _possibleConstructorReturn(this, _TextToken13.call(this, '/'));                                              // 293
	}                                                                                                                    // 294
                                                                                                                      // 295
	return SLASH;                                                                                                        // 296
}(TextToken);                                                                                                         // 297
                                                                                                                      // 298
/**                                                                                                                   // 299
	One ore more non-whitespace symbol.                                                                                  // 300
	@class SYM                                                                                                           // 301
	@extends TextToken                                                                                                   // 302
*/                                                                                                                    // 303
                                                                                                                      // 304
                                                                                                                      // 305
var SYM = function (_TextToken14) {                                                                                   // 306
	_inherits(SYM, _TextToken14);                                                                                        // 307
                                                                                                                      // 308
	function SYM() {                                                                                                     // 309
		_classCallCheck(this, SYM);                                                                                         // 310
                                                                                                                      // 311
		return _possibleConstructorReturn(this, _TextToken14.apply(this, arguments));                                       // 312
	}                                                                                                                    // 313
                                                                                                                      // 314
	return SYM;                                                                                                          // 315
}(TextToken);                                                                                                         // 316
                                                                                                                      // 317
/**                                                                                                                   // 318
	@class TLD                                                                                                           // 319
	@extends TextToken                                                                                                   // 320
*/                                                                                                                    // 321
                                                                                                                      // 322
                                                                                                                      // 323
var TLD = function (_TextToken15) {                                                                                   // 324
	_inherits(TLD, _TextToken15);                                                                                        // 325
                                                                                                                      // 326
	function TLD() {                                                                                                     // 327
		_classCallCheck(this, TLD);                                                                                         // 328
                                                                                                                      // 329
		return _possibleConstructorReturn(this, _TextToken15.apply(this, arguments));                                       // 330
	}                                                                                                                    // 331
                                                                                                                      // 332
	return TLD;                                                                                                          // 333
}(TextToken);                                                                                                         // 334
                                                                                                                      // 335
/**                                                                                                                   // 336
	Represents a string of consecutive whitespace characters                                                             // 337
                                                                                                                      // 338
	@class WS                                                                                                            // 339
	@extends TextToken                                                                                                   // 340
*/                                                                                                                    // 341
                                                                                                                      // 342
                                                                                                                      // 343
var WS = function (_TextToken16) {                                                                                    // 344
	_inherits(WS, _TextToken16);                                                                                         // 345
                                                                                                                      // 346
	function WS() {                                                                                                      // 347
		_classCallCheck(this, WS);                                                                                          // 348
                                                                                                                      // 349
		return _possibleConstructorReturn(this, _TextToken16.apply(this, arguments));                                       // 350
	}                                                                                                                    // 351
                                                                                                                      // 352
	return WS;                                                                                                           // 353
}(TextToken);                                                                                                         // 354
                                                                                                                      // 355
/**                                                                                                                   // 356
	Opening/closing bracket classes                                                                                      // 357
*/                                                                                                                    // 358
                                                                                                                      // 359
var OPENBRACE = function (_TextToken17) {                                                                             // 360
	_inherits(OPENBRACE, _TextToken17);                                                                                  // 361
                                                                                                                      // 362
	function OPENBRACE() {                                                                                               // 363
		_classCallCheck(this, OPENBRACE);                                                                                   // 364
                                                                                                                      // 365
		return _possibleConstructorReturn(this, _TextToken17.call(this, '{'));                                              // 366
	}                                                                                                                    // 367
                                                                                                                      // 368
	return OPENBRACE;                                                                                                    // 369
}(TextToken);                                                                                                         // 370
                                                                                                                      // 371
var OPENBRACKET = function (_TextToken18) {                                                                           // 372
	_inherits(OPENBRACKET, _TextToken18);                                                                                // 373
                                                                                                                      // 374
	function OPENBRACKET() {                                                                                             // 375
		_classCallCheck(this, OPENBRACKET);                                                                                 // 376
                                                                                                                      // 377
		return _possibleConstructorReturn(this, _TextToken18.call(this, '['));                                              // 378
	}                                                                                                                    // 379
                                                                                                                      // 380
	return OPENBRACKET;                                                                                                  // 381
}(TextToken);                                                                                                         // 382
                                                                                                                      // 383
var OPENPAREN = function (_TextToken19) {                                                                             // 384
	_inherits(OPENPAREN, _TextToken19);                                                                                  // 385
                                                                                                                      // 386
	function OPENPAREN() {                                                                                               // 387
		_classCallCheck(this, OPENPAREN);                                                                                   // 388
                                                                                                                      // 389
		return _possibleConstructorReturn(this, _TextToken19.call(this, '('));                                              // 390
	}                                                                                                                    // 391
                                                                                                                      // 392
	return OPENPAREN;                                                                                                    // 393
}(TextToken);                                                                                                         // 394
                                                                                                                      // 395
var CLOSEBRACE = function (_TextToken20) {                                                                            // 396
	_inherits(CLOSEBRACE, _TextToken20);                                                                                 // 397
                                                                                                                      // 398
	function CLOSEBRACE() {                                                                                              // 399
		_classCallCheck(this, CLOSEBRACE);                                                                                  // 400
                                                                                                                      // 401
		return _possibleConstructorReturn(this, _TextToken20.call(this, '}'));                                              // 402
	}                                                                                                                    // 403
                                                                                                                      // 404
	return CLOSEBRACE;                                                                                                   // 405
}(TextToken);                                                                                                         // 406
                                                                                                                      // 407
var CLOSEBRACKET = function (_TextToken21) {                                                                          // 408
	_inherits(CLOSEBRACKET, _TextToken21);                                                                               // 409
                                                                                                                      // 410
	function CLOSEBRACKET() {                                                                                            // 411
		_classCallCheck(this, CLOSEBRACKET);                                                                                // 412
                                                                                                                      // 413
		return _possibleConstructorReturn(this, _TextToken21.call(this, ']'));                                              // 414
	}                                                                                                                    // 415
                                                                                                                      // 416
	return CLOSEBRACKET;                                                                                                 // 417
}(TextToken);                                                                                                         // 418
                                                                                                                      // 419
var CLOSEPAREN = function (_TextToken22) {                                                                            // 420
	_inherits(CLOSEPAREN, _TextToken22);                                                                                 // 421
                                                                                                                      // 422
	function CLOSEPAREN() {                                                                                              // 423
		_classCallCheck(this, CLOSEPAREN);                                                                                  // 424
                                                                                                                      // 425
		return _possibleConstructorReturn(this, _TextToken22.call(this, ')'));                                              // 426
	}                                                                                                                    // 427
                                                                                                                      // 428
	return CLOSEPAREN;                                                                                                   // 429
}(TextToken);                                                                                                         // 430
                                                                                                                      // 431
var text = {                                                                                                          // 432
	Base: TextToken,                                                                                                     // 433
	DOMAIN: DOMAIN,                                                                                                      // 434
	AT: AT,                                                                                                              // 435
	COLON: COLON,                                                                                                        // 436
	DOT: DOT,                                                                                                            // 437
	PUNCTUATION: PUNCTUATION,                                                                                            // 438
	LOCALHOST: LOCALHOST,                                                                                                // 439
	NL: TNL,                                                                                                             // 440
	NUM: NUM,                                                                                                            // 441
	PLUS: PLUS,                                                                                                          // 442
	POUND: POUND,                                                                                                        // 443
	QUERY: QUERY,                                                                                                        // 444
	PROTOCOL: PROTOCOL,                                                                                                  // 445
	SLASH: SLASH,                                                                                                        // 446
	SYM: SYM,                                                                                                            // 447
	TLD: TLD,                                                                                                            // 448
	WS: WS,                                                                                                              // 449
	OPENBRACE: OPENBRACE,                                                                                                // 450
	OPENBRACKET: OPENBRACKET,                                                                                            // 451
	OPENPAREN: OPENPAREN,                                                                                                // 452
	CLOSEBRACE: CLOSEBRACE,                                                                                              // 453
	CLOSEBRACKET: CLOSEBRACKET,                                                                                          // 454
	CLOSEPAREN: CLOSEPAREN                                                                                               // 455
};                                                                                                                    // 456
                                                                                                                      // 457
/******************************************************************************                                       // 458
	Multi-Tokens                                                                                                         // 459
	Tokens composed of arrays of TextTokens                                                                              // 460
******************************************************************************/                                       // 461
                                                                                                                      // 462
// Is the given token a valid domain token?                                                                           // 463
// Should nums be included here?                                                                                      // 464
function isDomainToken(token) {                                                                                       // 465
	return token instanceof DOMAIN || token instanceof TLD;                                                              // 466
}                                                                                                                     // 467
                                                                                                                      // 468
/**                                                                                                                   // 469
	Abstract class used for manufacturing tokens of text tokens. That is rather                                          // 470
	than the value for a token being a small string of text, it's value an array                                         // 471
	of text tokens.                                                                                                      // 472
                                                                                                                      // 473
	Used for grouping together URLs, emails, hashtags, and other potential                                               // 474
	creations.                                                                                                           // 475
                                                                                                                      // 476
	@class MultiToken                                                                                                    // 477
	@abstract                                                                                                            // 478
*/                                                                                                                    // 479
                                                                                                                      // 480
var MultiToken = function () {                                                                                        // 481
	/**                                                                                                                  // 482
 	@method constructor                                                                                                 // 483
 	@param {Array} value The array of `TextToken`s representing this                                                    // 484
 	particular MultiToken                                                                                               // 485
 */                                                                                                                   // 486
                                                                                                                      // 487
	function MultiToken(value) {                                                                                         // 488
		_classCallCheck(this, MultiToken);                                                                                  // 489
                                                                                                                      // 490
		this.v = value;                                                                                                     // 491
                                                                                                                      // 492
		/**                                                                                                                 // 493
  	String representing the type for this token                                                                        // 494
  	@property type                                                                                                     // 495
  	@default 'TOKEN'                                                                                                   // 496
  */                                                                                                                  // 497
		this.type = 'token';                                                                                                // 498
                                                                                                                      // 499
		/**                                                                                                                 // 500
  	Is this multitoken a link?                                                                                         // 501
  	@property isLink                                                                                                   // 502
  	@default false                                                                                                     // 503
  */                                                                                                                  // 504
		this.isLink = false;                                                                                                // 505
	}                                                                                                                    // 506
                                                                                                                      // 507
	/**                                                                                                                  // 508
 	Return the string this token represents.                                                                            // 509
 	@method toString                                                                                                    // 510
 	@return {String}                                                                                                    // 511
 */                                                                                                                   // 512
                                                                                                                      // 513
                                                                                                                      // 514
	MultiToken.prototype.toString = function toString() {                                                                // 515
		var result = [];                                                                                                    // 516
		for (var i = 0; i < this.v.length; i++) {                                                                           // 517
			result.push(this.v[i].toString());                                                                                 // 518
		}                                                                                                                   // 519
		return result.join('');                                                                                             // 520
	};                                                                                                                   // 521
                                                                                                                      // 522
	/**                                                                                                                  // 523
 	What should the value for this token be in the `href` HTML attribute?                                               // 524
 	Returns the `.toString` value by default.                                                                           // 525
 		@method toHref                                                                                                     // 526
 	@return {String}                                                                                                    // 527
 */                                                                                                                   // 528
                                                                                                                      // 529
                                                                                                                      // 530
	MultiToken.prototype.toHref = function toHref() {                                                                    // 531
		return this.toString();                                                                                             // 532
	};                                                                                                                   // 533
                                                                                                                      // 534
	/**                                                                                                                  // 535
 	Returns a hash of relevant values for this token, which includes keys                                               // 536
 	* type - Kind of token ('url', 'email', etc.)                                                                       // 537
 	* value - Original text                                                                                             // 538
 	* href - The value that should be added to the anchor tag's href                                                    // 539
 		attribute                                                                                                          // 540
 		@method toObject                                                                                                   // 541
 	@param {String} [protocol] `'http'` by default                                                                      // 542
 	@return {Object}                                                                                                    // 543
 */                                                                                                                   // 544
                                                                                                                      // 545
                                                                                                                      // 546
	MultiToken.prototype.toObject = function toObject() {                                                                // 547
		var protocol = arguments.length <= 0 || arguments[0] === undefined ? 'http' : arguments[0];                         // 548
                                                                                                                      // 549
		return {                                                                                                            // 550
			type: this.type,                                                                                                   // 551
			value: this.toString(),                                                                                            // 552
			href: this.toHref(protocol)                                                                                        // 553
		};                                                                                                                  // 554
	};                                                                                                                   // 555
                                                                                                                      // 556
	return MultiToken;                                                                                                   // 557
}();                                                                                                                  // 558
                                                                                                                      // 559
/**                                                                                                                   // 560
	Represents a list of tokens making up a valid email address                                                          // 561
	@class EMAIL                                                                                                         // 562
	@extends MultiToken                                                                                                  // 563
*/                                                                                                                    // 564
                                                                                                                      // 565
                                                                                                                      // 566
var EMAIL = function (_MultiToken) {                                                                                  // 567
	_inherits(EMAIL, _MultiToken);                                                                                       // 568
                                                                                                                      // 569
	function EMAIL(value) {                                                                                              // 570
		_classCallCheck(this, EMAIL);                                                                                       // 571
                                                                                                                      // 572
		var _this23 = _possibleConstructorReturn(this, _MultiToken.call(this, value));                                      // 573
                                                                                                                      // 574
		_this23.type = 'email';                                                                                             // 575
		_this23.isLink = true;                                                                                              // 576
		return _this23;                                                                                                     // 577
	}                                                                                                                    // 578
                                                                                                                      // 579
	EMAIL.prototype.toHref = function toHref() {                                                                         // 580
		return 'mailto:' + this.toString();                                                                                 // 581
	};                                                                                                                   // 582
                                                                                                                      // 583
	return EMAIL;                                                                                                        // 584
}(MultiToken);                                                                                                        // 585
                                                                                                                      // 586
/**                                                                                                                   // 587
	Represents some plain text                                                                                           // 588
	@class TEXT                                                                                                          // 589
	@extends MultiToken                                                                                                  // 590
*/                                                                                                                    // 591
                                                                                                                      // 592
                                                                                                                      // 593
var TEXT = function (_MultiToken2) {                                                                                  // 594
	_inherits(TEXT, _MultiToken2);                                                                                       // 595
                                                                                                                      // 596
	function TEXT(value) {                                                                                               // 597
		_classCallCheck(this, TEXT);                                                                                        // 598
                                                                                                                      // 599
		var _this24 = _possibleConstructorReturn(this, _MultiToken2.call(this, value));                                     // 600
                                                                                                                      // 601
		_this24.type = 'text';                                                                                              // 602
		return _this24;                                                                                                     // 603
	}                                                                                                                    // 604
                                                                                                                      // 605
	return TEXT;                                                                                                         // 606
}(MultiToken);                                                                                                        // 607
                                                                                                                      // 608
/**                                                                                                                   // 609
	Multi-linebreak token - represents a line break                                                                      // 610
	@class MNL                                                                                                           // 611
	@extends MultiToken                                                                                                  // 612
*/                                                                                                                    // 613
                                                                                                                      // 614
                                                                                                                      // 615
var MNL = function (_MultiToken3) {                                                                                   // 616
	_inherits(MNL, _MultiToken3);                                                                                        // 617
                                                                                                                      // 618
	function MNL(value) {                                                                                                // 619
		_classCallCheck(this, MNL);                                                                                         // 620
                                                                                                                      // 621
		var _this25 = _possibleConstructorReturn(this, _MultiToken3.call(this, value));                                     // 622
                                                                                                                      // 623
		_this25.type = 'nl';                                                                                                // 624
		return _this25;                                                                                                     // 625
	}                                                                                                                    // 626
                                                                                                                      // 627
	return MNL;                                                                                                          // 628
}(MultiToken);                                                                                                        // 629
                                                                                                                      // 630
/**                                                                                                                   // 631
	Represents a list of tokens making up a valid URL                                                                    // 632
	@class URL                                                                                                           // 633
	@extends MultiToken                                                                                                  // 634
*/                                                                                                                    // 635
                                                                                                                      // 636
                                                                                                                      // 637
var URL = function (_MultiToken4) {                                                                                   // 638
	_inherits(URL, _MultiToken4);                                                                                        // 639
                                                                                                                      // 640
	function URL(value) {                                                                                                // 641
		_classCallCheck(this, URL);                                                                                         // 642
                                                                                                                      // 643
		var _this26 = _possibleConstructorReturn(this, _MultiToken4.call(this, value));                                     // 644
                                                                                                                      // 645
		_this26.type = 'url';                                                                                               // 646
		_this26.isLink = true;                                                                                              // 647
		return _this26;                                                                                                     // 648
	}                                                                                                                    // 649
                                                                                                                      // 650
	/**                                                                                                                  // 651
 	Lowercases relevant parts of the domain and adds the protocol if                                                    // 652
 	required. Note that this will not escape unsafe HTML characters in the                                              // 653
 	URL.                                                                                                                // 654
 		@method href                                                                                                       // 655
 	@param {String} protocol                                                                                            // 656
 	@return {String}                                                                                                    // 657
 */                                                                                                                   // 658
                                                                                                                      // 659
                                                                                                                      // 660
	URL.prototype.toHref = function toHref() {                                                                           // 661
		var protocol = arguments.length <= 0 || arguments[0] === undefined ? 'http' : arguments[0];                         // 662
                                                                                                                      // 663
		var hasProtocol = false,                                                                                            // 664
		    hasSlashSlash = false,                                                                                          // 665
		    tokens = this.v,                                                                                                // 666
		    result = [],                                                                                                    // 667
		    i = 0;                                                                                                          // 668
                                                                                                                      // 669
		// Make the first part of the domain lowercase                                                                      // 670
		// Lowercase protocol                                                                                               // 671
		while (tokens[i] instanceof PROTOCOL) {                                                                             // 672
			hasProtocol = true;                                                                                                // 673
			result.push(tokens[i].toString().toLowerCase());                                                                   // 674
			i++;                                                                                                               // 675
		}                                                                                                                   // 676
                                                                                                                      // 677
		// Skip slash-slash                                                                                                 // 678
		while (tokens[i] instanceof SLASH) {                                                                                // 679
			hasSlashSlash = true;                                                                                              // 680
			result.push(tokens[i].toString());                                                                                 // 681
			i++;                                                                                                               // 682
		}                                                                                                                   // 683
                                                                                                                      // 684
		// Lowercase all other characters in the domain                                                                     // 685
		while (isDomainToken(tokens[i])) {                                                                                  // 686
			result.push(tokens[i].toString().toLowerCase());                                                                   // 687
			i++;                                                                                                               // 688
		}                                                                                                                   // 689
                                                                                                                      // 690
		// Leave all other characters as they were written                                                                  // 691
		for (; i < tokens.length; i++) {                                                                                    // 692
			result.push(tokens[i].toString());                                                                                 // 693
		}                                                                                                                   // 694
                                                                                                                      // 695
		result = result.join('');                                                                                           // 696
                                                                                                                      // 697
		if (!(hasProtocol || hasSlashSlash)) {                                                                              // 698
			result = protocol + '://' + result;                                                                                // 699
		}                                                                                                                   // 700
                                                                                                                      // 701
		return result;                                                                                                      // 702
	};                                                                                                                   // 703
                                                                                                                      // 704
	URL.prototype.hasProtocol = function hasProtocol() {                                                                 // 705
		return this.v[0] instanceof PROTOCOL;                                                                               // 706
	};                                                                                                                   // 707
                                                                                                                      // 708
	return URL;                                                                                                          // 709
}(MultiToken);                                                                                                        // 710
                                                                                                                      // 711
var multi = {                                                                                                         // 712
	Base: MultiToken,                                                                                                    // 713
	EMAIL: EMAIL,                                                                                                        // 714
	NL: MNL,                                                                                                             // 715
	TEXT: TEXT,                                                                                                          // 716
	URL: URL                                                                                                             // 717
};                                                                                                                    // 718
                                                                                                                      // 719
exports.text = text;                                                                                                  // 720
exports.multi = multi;                                                                                                // 721
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"state.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/lib/linkify/core/state.js                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
"use strict";                                                                                                         // 1
                                                                                                                      // 2
exports.__esModule = true;                                                                                            // 3
                                                                                                                      // 4
function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
                                                                                                                      // 6
function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
                                                                                                                      // 8
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
                                                                                                                      // 10
/**                                                                                                                   // 11
	A simple state machine that can emit token classes                                                                   // 12
                                                                                                                      // 13
	The `j` property in this class refers to state jumps. It's a                                                         // 14
	multidimensional array where for each element:                                                                       // 15
                                                                                                                      // 16
	* index [0] is a symbol or class of symbols to transition to.                                                        // 17
	* index [1] is a State instance which matches                                                                        // 18
                                                                                                                      // 19
	The type of symbol will depend on the target implementation for this class.                                          // 20
	In Linkify, we have a two-stage scanner. Each stage uses this state machine                                          // 21
	but with a slighly different (polymorphic) implementation.                                                           // 22
                                                                                                                      // 23
	The `T` property refers to the token class.                                                                          // 24
                                                                                                                      // 25
	TODO: Can the `on` and `next` methods be combined?                                                                   // 26
                                                                                                                      // 27
	@class BaseState                                                                                                     // 28
*/                                                                                                                    // 29
                                                                                                                      // 30
var BaseState = function () {                                                                                         // 31
                                                                                                                      // 32
	/**                                                                                                                  // 33
 	@method constructor                                                                                                 // 34
 	@param {Class} tClass Pass in the kind of token to emit if there are                                                // 35
 		no jumps after this state and the state is accepting.                                                              // 36
 */                                                                                                                   // 37
                                                                                                                      // 38
	function BaseState(tClass) {                                                                                         // 39
		_classCallCheck(this, BaseState);                                                                                   // 40
                                                                                                                      // 41
		this.j = [];                                                                                                        // 42
		this.T = tClass || null;                                                                                            // 43
	}                                                                                                                    // 44
                                                                                                                      // 45
	/**                                                                                                                  // 46
 	On the given symbol(s), this machine should go to the given state                                                   // 47
 		@method on                                                                                                         // 48
 	@param {Array|Mixed} symbol                                                                                         // 49
 	@param {BaseState} state Note that the type of this state should be the                                             // 50
 		same as the current instance (i.e., don't pass in a different                                                      // 51
 		subclass)                                                                                                          // 52
 */                                                                                                                   // 53
                                                                                                                      // 54
                                                                                                                      // 55
	BaseState.prototype.on = function on(symbol, state) {                                                                // 56
		if (symbol instanceof Array) {                                                                                      // 57
			for (var i = 0; i < symbol.length; i++) {                                                                          // 58
				this.j.push([symbol[i], state]);                                                                                  // 59
			}                                                                                                                  // 60
			return this;                                                                                                       // 61
		}                                                                                                                   // 62
		this.j.push([symbol, state]);                                                                                       // 63
		return this;                                                                                                        // 64
	};                                                                                                                   // 65
                                                                                                                      // 66
	/**                                                                                                                  // 67
 	Given the next item, returns next state for that item                                                               // 68
 	@method next                                                                                                        // 69
 	@param {Mixed} item Should be an instance of the symbols handled by                                                 // 70
 		this particular machine.                                                                                           // 71
 	@return {State} state Returns false if no jumps are available                                                       // 72
 */                                                                                                                   // 73
                                                                                                                      // 74
                                                                                                                      // 75
	BaseState.prototype.next = function next(item) {                                                                     // 76
                                                                                                                      // 77
		for (var i = 0; i < this.j.length; i++) {                                                                           // 78
                                                                                                                      // 79
			var jump = this.j[i],                                                                                              // 80
			    symbol = jump[0],                                                                                              // 81
			    // Next item to check for                                                                                      // 82
			state = jump[1]; // State to jump to if items match                                                                // 83
                                                                                                                      // 84
			// compare item with symbol                                                                                        // 85
			if (this.test(item, symbol)) return state;                                                                         // 86
		}                                                                                                                   // 87
                                                                                                                      // 88
		// Nowhere left to jump!                                                                                            // 89
		return false;                                                                                                       // 90
	};                                                                                                                   // 91
                                                                                                                      // 92
	/**                                                                                                                  // 93
 	Does this state accept?                                                                                             // 94
 	`true` only of `this.T` exists                                                                                      // 95
 		@method accepts                                                                                                    // 96
 	@return {Boolean}                                                                                                   // 97
 */                                                                                                                   // 98
                                                                                                                      // 99
                                                                                                                      // 100
	BaseState.prototype.accepts = function accepts() {                                                                   // 101
		return !!this.T;                                                                                                    // 102
	};                                                                                                                   // 103
                                                                                                                      // 104
	/**                                                                                                                  // 105
 	Determine whether a given item "symbolizes" the symbol, where symbol is                                             // 106
 	a class of items handled by this state machine.                                                                     // 107
 		This method should be overriden in extended classes.                                                               // 108
 		@method test                                                                                                       // 109
 	@param {Mixed} item Does this item match the given symbol?                                                          // 110
 	@param {Mixed} symbol                                                                                               // 111
 	@return {Boolean}                                                                                                   // 112
 */                                                                                                                   // 113
                                                                                                                      // 114
                                                                                                                      // 115
	BaseState.prototype.test = function test(item, symbol) {                                                             // 116
		return item === symbol;                                                                                             // 117
	};                                                                                                                   // 118
                                                                                                                      // 119
	/**                                                                                                                  // 120
 	Emit the token for this State (just return it in this case)                                                         // 121
 	If this emits a token, this instance is an accepting state                                                          // 122
 	@method emit                                                                                                        // 123
 	@return {Class} T                                                                                                   // 124
 */                                                                                                                   // 125
                                                                                                                      // 126
                                                                                                                      // 127
	BaseState.prototype.emit = function emit() {                                                                         // 128
		return this.T;                                                                                                      // 129
	};                                                                                                                   // 130
                                                                                                                      // 131
	return BaseState;                                                                                                    // 132
}();                                                                                                                  // 133
                                                                                                                      // 134
/**                                                                                                                   // 135
	State machine for string-based input                                                                                 // 136
                                                                                                                      // 137
	@class CharacterState                                                                                                // 138
	@extends BaseState                                                                                                   // 139
*/                                                                                                                    // 140
                                                                                                                      // 141
                                                                                                                      // 142
var CharacterState = function (_BaseState) {                                                                          // 143
	_inherits(CharacterState, _BaseState);                                                                               // 144
                                                                                                                      // 145
	function CharacterState() {                                                                                          // 146
		_classCallCheck(this, CharacterState);                                                                              // 147
                                                                                                                      // 148
		return _possibleConstructorReturn(this, _BaseState.apply(this, arguments));                                         // 149
	}                                                                                                                    // 150
                                                                                                                      // 151
	/**                                                                                                                  // 152
 	Does the given character match the given character or regular                                                       // 153
 	expression?                                                                                                         // 154
 		@method test                                                                                                       // 155
 	@param {String} char                                                                                                // 156
 	@param {String|RegExp} charOrRegExp                                                                                 // 157
 	@return {Boolean}                                                                                                   // 158
 */                                                                                                                   // 159
                                                                                                                      // 160
	CharacterState.prototype.test = function test(character, charOrRegExp) {                                             // 161
		return character === charOrRegExp || charOrRegExp instanceof RegExp && charOrRegExp.test(character);                // 162
	};                                                                                                                   // 163
                                                                                                                      // 164
	return CharacterState;                                                                                               // 165
}(BaseState);                                                                                                         // 166
                                                                                                                      // 167
/**                                                                                                                   // 168
	State machine for input in the form of TextTokens                                                                    // 169
                                                                                                                      // 170
	@class TokenState                                                                                                    // 171
	@extends BaseState                                                                                                   // 172
*/                                                                                                                    // 173
                                                                                                                      // 174
                                                                                                                      // 175
var TokenState = function (_BaseState2) {                                                                             // 176
	_inherits(TokenState, _BaseState2);                                                                                  // 177
                                                                                                                      // 178
	function TokenState() {                                                                                              // 179
		_classCallCheck(this, TokenState);                                                                                  // 180
                                                                                                                      // 181
		return _possibleConstructorReturn(this, _BaseState2.apply(this, arguments));                                        // 182
	}                                                                                                                    // 183
                                                                                                                      // 184
	/**                                                                                                                  // 185
 	Is the given token an instance of the given token class?                                                            // 186
 		@method test                                                                                                       // 187
 	@param {TextToken} token                                                                                            // 188
 	@param {Class} tokenClass                                                                                           // 189
 	@return {Boolean}                                                                                                   // 190
 */                                                                                                                   // 191
                                                                                                                      // 192
	TokenState.prototype.test = function test(token, tokenClass) {                                                       // 193
		return token instanceof tokenClass;                                                                                 // 194
	};                                                                                                                   // 195
                                                                                                                      // 196
	return TokenState;                                                                                                   // 197
}(BaseState);                                                                                                         // 198
                                                                                                                      // 199
/**                                                                                                                   // 200
	Given a non-empty target string, generates states (if required) for each                                             // 201
	consecutive substring of characters in str starting from the beginning of                                            // 202
	the string. The final state will have a special value, as specified in                                               // 203
	options. All other "in between" substrings will have a default end state.                                            // 204
                                                                                                                      // 205
	This turns the state machine into a Trie-like data structure (rather than a                                          // 206
	intelligently-designed DFA).                                                                                         // 207
                                                                                                                      // 208
	Note that I haven't really tried these with any strings other than                                                   // 209
	DOMAIN.                                                                                                              // 210
                                                                                                                      // 211
	@param {String} str                                                                                                  // 212
	@param {CharacterState} start State to jump from the first character                                                 // 213
	@param {Class} endToken Token class to emit when the given string has been                                           // 214
		matched and no more jumps exist.                                                                                    // 215
	@param {Class} defaultToken "Filler token", or which token type to emit when                                         // 216
		we don't have a full match                                                                                          // 217
	@return {Array} list of newly-created states                                                                         // 218
*/                                                                                                                    // 219
                                                                                                                      // 220
                                                                                                                      // 221
function stateify(str, start, endToken, defaultToken) {                                                               // 222
                                                                                                                      // 223
	var i = 0,                                                                                                           // 224
	    len = str.length,                                                                                                // 225
	    state = start,                                                                                                   // 226
	    newStates = [],                                                                                                  // 227
	    nextState = void 0;                                                                                              // 228
                                                                                                                      // 229
	// Find the next state without a jump to the next character                                                          // 230
	while (i < len && (nextState = state.next(str[i]))) {                                                                // 231
		state = nextState;                                                                                                  // 232
		i++;                                                                                                                // 233
	}                                                                                                                    // 234
                                                                                                                      // 235
	if (i >= len) return []; // no new tokens were added                                                                 // 236
                                                                                                                      // 237
	while (i < len - 1) {                                                                                                // 238
		nextState = new CharacterState(defaultToken);                                                                       // 239
		newStates.push(nextState);                                                                                          // 240
		state.on(str[i], nextState);                                                                                        // 241
		state = nextState;                                                                                                  // 242
		i++;                                                                                                                // 243
	}                                                                                                                    // 244
                                                                                                                      // 245
	nextState = new CharacterState(endToken);                                                                            // 246
	newStates.push(nextState);                                                                                           // 247
	state.on(str[len - 1], nextState);                                                                                   // 248
                                                                                                                      // 249
	return newStates;                                                                                                    // 250
}                                                                                                                     // 251
                                                                                                                      // 252
exports.CharacterState = CharacterState;                                                                              // 253
exports.TokenState = TokenState;                                                                                      // 254
exports.stateify = stateify;                                                                                          // 255
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"parser.js":["./tokens","./state",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/arkham:comments-ui/node_modules/linkifyjs/lib/linkify/core/parser.js                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
'use strict';                                                                                                         // 1
                                                                                                                      // 2
exports.__esModule = true;                                                                                            // 3
exports.start = exports.run = exports.TOKENS = exports.State = undefined;                                             // 4
                                                                                                                      // 5
var _tokens = require('./tokens');                                                                                    // 6
                                                                                                                      // 7
var _state = require('./state');                                                                                      // 8
                                                                                                                      // 9
/**                                                                                                                   // 10
	Not exactly parser, more like the second-stage scanner (although we can                                              // 11
	theoretically hotswap the code here with a real parser in the future... but                                          // 12
	for a little URL-finding utility abstract syntax trees may be a little                                               // 13
	overkill).                                                                                                           // 14
                                                                                                                      // 15
	URL format: http://en.wikipedia.org/wiki/URI_scheme                                                                  // 16
	Email format: http://en.wikipedia.org/wiki/Email_address (links to RFC in                                            // 17
	reference)                                                                                                           // 18
                                                                                                                      // 19
	@module linkify                                                                                                      // 20
	@submodule parser                                                                                                    // 21
	@main parser                                                                                                         // 22
*/                                                                                                                    // 23
                                                                                                                      // 24
var makeState = function makeState(tokenClass) {                                                                      // 25
	return new _state.TokenState(tokenClass);                                                                            // 26
};                                                                                                                    // 27
                                                                                                                      // 28
var TT_DOMAIN = _tokens.text.DOMAIN,                                                                                  // 29
    TT_AT = _tokens.text.AT,                                                                                          // 30
    TT_COLON = _tokens.text.COLON,                                                                                    // 31
    TT_DOT = _tokens.text.DOT,                                                                                        // 32
    TT_PUNCTUATION = _tokens.text.PUNCTUATION,                                                                        // 33
    TT_LOCALHOST = _tokens.text.LOCALHOST,                                                                            // 34
    TT_NL = _tokens.text.NL,                                                                                          // 35
    TT_NUM = _tokens.text.NUM,                                                                                        // 36
    TT_PLUS = _tokens.text.PLUS,                                                                                      // 37
    TT_POUND = _tokens.text.POUND,                                                                                    // 38
    TT_PROTOCOL = _tokens.text.PROTOCOL,                                                                              // 39
    TT_QUERY = _tokens.text.QUERY,                                                                                    // 40
    TT_SLASH = _tokens.text.SLASH,                                                                                    // 41
    TT_SYM = _tokens.text.SYM,                                                                                        // 42
    TT_TLD = _tokens.text.TLD,                                                                                        // 43
    TT_OPENBRACE = _tokens.text.OPENBRACE,                                                                            // 44
    TT_OPENBRACKET = _tokens.text.OPENBRACKET,                                                                        // 45
    TT_OPENPAREN = _tokens.text.OPENPAREN,                                                                            // 46
    TT_CLOSEBRACE = _tokens.text.CLOSEBRACE,                                                                          // 47
    TT_CLOSEBRACKET = _tokens.text.CLOSEBRACKET,                                                                      // 48
    TT_CLOSEPAREN = _tokens.text.CLOSEPAREN;                                                                          // 49
                                                                                                                      // 50
// TT_WS 			= TEXT_TOKENS.WS;                                                                                         // 51
                                                                                                                      // 52
var T_EMAIL = _tokens.multi.EMAIL,                                                                                    // 53
    T_NL = _tokens.multi.NL,                                                                                          // 54
    T_TEXT = _tokens.multi.TEXT,                                                                                      // 55
    T_URL = _tokens.multi.URL;                                                                                        // 56
                                                                                                                      // 57
// The universal starting state.                                                                                      // 58
var S_START = makeState();                                                                                            // 59
                                                                                                                      // 60
// Intermediate states for URLs. Note that domains that begin with a protocol                                         // 61
// are treated slighly differently from those that don't.                                                             // 62
var S_PROTOCOL = makeState(),                                                                                         // 63
    // e.g., 'http:'                                                                                                  // 64
S_PROTOCOL_SLASH = makeState(),                                                                                       // 65
    // e.g., '/', 'http:/''                                                                                           // 66
S_PROTOCOL_SLASH_SLASH = makeState(),                                                                                 // 67
    // e.g., '//', 'http://'                                                                                          // 68
S_DOMAIN = makeState(),                                                                                               // 69
    // parsed string ends with a potential domain name (A)                                                            // 70
S_DOMAIN_DOT = makeState(),                                                                                           // 71
    // (A) domain followed by DOT                                                                                     // 72
S_TLD = makeState(T_URL),                                                                                             // 73
    // (A) Simplest possible URL with no query string                                                                 // 74
S_TLD_COLON = makeState(),                                                                                            // 75
    // (A) URL followed by colon (potential port number here)                                                         // 76
S_TLD_PORT = makeState(T_URL),                                                                                        // 77
    // TLD followed by a port number                                                                                  // 78
S_URL = makeState(T_URL),                                                                                             // 79
    // Long URL with optional port and maybe query string                                                             // 80
S_URL_SYMS = makeState(),                                                                                             // 81
    // URL followed by some symbols (will not be part of the final URL)                                               // 82
S_URL_OPENBRACE = makeState(),                                                                                        // 83
    // URL followed by {                                                                                              // 84
S_URL_OPENBRACKET = makeState(),                                                                                      // 85
    // URL followed by [                                                                                              // 86
S_URL_OPENPAREN = makeState(),                                                                                        // 87
    // URL followed by (                                                                                              // 88
S_URL_OPENBRACE_Q = makeState(T_URL),                                                                                 // 89
    // URL followed by { and some symbols that the URL can end it                                                     // 90
S_URL_OPENBRACKET_Q = makeState(T_URL),                                                                               // 91
    // URL followed by [ and some symbols that the URL can end it                                                     // 92
S_URL_OPENPAREN_Q = makeState(T_URL),                                                                                 // 93
    // URL followed by ( and some symbols that the URL can end it                                                     // 94
S_URL_OPENBRACE_SYMS = makeState(),                                                                                   // 95
    // S_URL_OPENBRACE_Q followed by some symbols it cannot end it                                                    // 96
S_URL_OPENBRACKET_SYMS = makeState(),                                                                                 // 97
    // S_URL_OPENBRACKET_Q followed by some symbols it cannot end it                                                  // 98
S_URL_OPENPAREN_SYMS = makeState(),                                                                                   // 99
    // S_URL_OPENPAREN_Q followed by some symbols it cannot end it                                                    // 100
S_EMAIL_DOMAIN = makeState(),                                                                                         // 101
    // parsed string starts with local email info + @ with a potential domain name (C)                                // 102
S_EMAIL_DOMAIN_DOT = makeState(),                                                                                     // 103
    // (C) domain followed by DOT                                                                                     // 104
S_EMAIL = makeState(T_EMAIL),                                                                                         // 105
    // (C) Possible email address (could have more tlds)                                                              // 106
S_EMAIL_COLON = makeState(),                                                                                          // 107
    // (C) URL followed by colon (potential port number here)                                                         // 108
S_EMAIL_PORT = makeState(T_EMAIL),                                                                                    // 109
    // (C) Email address with a port                                                                                  // 110
S_LOCALPART = makeState(),                                                                                            // 111
    // Local part of the email address                                                                                // 112
S_LOCALPART_AT = makeState(),                                                                                         // 113
    // Local part of the email address plus @                                                                         // 114
S_LOCALPART_DOT = makeState(),                                                                                        // 115
    // Local part of the email address plus '.' (localpart cannot end in .)                                           // 116
S_NL = makeState(T_NL); // single new line                                                                            // 117
                                                                                                                      // 118
// Make path from start to protocol (with '//')                                                                       // 119
S_START.on(TT_NL, S_NL).on(TT_PROTOCOL, S_PROTOCOL).on(TT_SLASH, S_PROTOCOL_SLASH);                                   // 120
                                                                                                                      // 121
S_PROTOCOL.on(TT_SLASH, S_PROTOCOL_SLASH);                                                                            // 122
S_PROTOCOL_SLASH.on(TT_SLASH, S_PROTOCOL_SLASH_SLASH);                                                                // 123
                                                                                                                      // 124
// The very first potential domain name                                                                               // 125
S_START.on(TT_TLD, S_DOMAIN).on(TT_DOMAIN, S_DOMAIN).on(TT_LOCALHOST, S_TLD).on(TT_NUM, S_DOMAIN);                    // 126
                                                                                                                      // 127
// Force URL for anything sane followed by protocol                                                                   // 128
S_PROTOCOL_SLASH_SLASH.on(TT_TLD, S_URL).on(TT_DOMAIN, S_URL).on(TT_NUM, S_URL).on(TT_LOCALHOST, S_URL);              // 129
                                                                                                                      // 130
// Account for dots and hyphens                                                                                       // 131
// hyphens are usually parts of domain names                                                                          // 132
S_DOMAIN.on(TT_DOT, S_DOMAIN_DOT);                                                                                    // 133
S_EMAIL_DOMAIN.on(TT_DOT, S_EMAIL_DOMAIN_DOT);                                                                        // 134
                                                                                                                      // 135
// Hyphen can jump back to a domain name                                                                              // 136
                                                                                                                      // 137
// After the first domain and a dot, we can find either a URL or another domain                                       // 138
S_DOMAIN_DOT.on(TT_TLD, S_TLD).on(TT_DOMAIN, S_DOMAIN).on(TT_NUM, S_DOMAIN).on(TT_LOCALHOST, S_DOMAIN);               // 139
                                                                                                                      // 140
S_EMAIL_DOMAIN_DOT.on(TT_TLD, S_EMAIL).on(TT_DOMAIN, S_EMAIL_DOMAIN).on(TT_NUM, S_EMAIL_DOMAIN).on(TT_LOCALHOST, S_EMAIL_DOMAIN);
                                                                                                                      // 142
// S_TLD accepts! But the URL could be longer, try to find a match greedily                                           // 143
// The `run` function should be able to "rollback" to the accepting state                                             // 144
S_TLD.on(TT_DOT, S_DOMAIN_DOT);                                                                                       // 145
S_EMAIL.on(TT_DOT, S_EMAIL_DOMAIN_DOT);                                                                               // 146
                                                                                                                      // 147
// Become real URLs after `SLASH` or `COLON NUM SLASH`                                                                // 148
// Here PSS and non-PSS converge                                                                                      // 149
S_TLD.on(TT_COLON, S_TLD_COLON).on(TT_SLASH, S_URL);                                                                  // 150
S_TLD_COLON.on(TT_NUM, S_TLD_PORT);                                                                                   // 151
S_TLD_PORT.on(TT_SLASH, S_URL);                                                                                       // 152
S_EMAIL.on(TT_COLON, S_EMAIL_COLON);                                                                                  // 153
S_EMAIL_COLON.on(TT_NUM, S_EMAIL_PORT);                                                                               // 154
                                                                                                                      // 155
// Types of characters the URL can definitely end in                                                                  // 156
var qsAccepting = [TT_DOMAIN, TT_AT, TT_LOCALHOST, TT_NUM, TT_PLUS, TT_POUND, TT_PROTOCOL, TT_SLASH, TT_TLD];         // 157
                                                                                                                      // 158
// Types of tokens that can follow a URL and be part of the query string                                              // 159
// but cannot be the very last characters                                                                             // 160
// Characters that cannot appear in the URL at all should be excluded                                                 // 161
var qsNonAccepting = [TT_COLON, TT_DOT, TT_QUERY, TT_PUNCTUATION, TT_CLOSEBRACE, TT_CLOSEBRACKET, TT_CLOSEPAREN, TT_OPENBRACE, TT_OPENBRACKET, TT_OPENPAREN, TT_SYM];
                                                                                                                      // 163
// These states are responsible primarily for determining whether or not to                                           // 164
// include the final round bracket.                                                                                   // 165
                                                                                                                      // 166
// URL, followed by an opening bracket                                                                                // 167
S_URL.on(TT_OPENBRACE, S_URL_OPENBRACE).on(TT_OPENBRACKET, S_URL_OPENBRACKET).on(TT_OPENPAREN, S_URL_OPENPAREN);      // 168
                                                                                                                      // 169
// URL with extra symbols at the end, followed by an opening bracket                                                  // 170
S_URL_SYMS.on(TT_OPENBRACE, S_URL_OPENBRACE).on(TT_OPENBRACKET, S_URL_OPENBRACKET).on(TT_OPENPAREN, S_URL_OPENPAREN);
                                                                                                                      // 172
// Closing bracket component. This character WILL be included in the URL                                              // 173
S_URL_OPENBRACE.on(TT_CLOSEBRACE, S_URL);                                                                             // 174
S_URL_OPENBRACKET.on(TT_CLOSEBRACKET, S_URL);                                                                         // 175
S_URL_OPENPAREN.on(TT_CLOSEPAREN, S_URL);                                                                             // 176
S_URL_OPENBRACE_Q.on(TT_CLOSEBRACE, S_URL);                                                                           // 177
S_URL_OPENBRACKET_Q.on(TT_CLOSEBRACKET, S_URL);                                                                       // 178
S_URL_OPENPAREN_Q.on(TT_CLOSEPAREN, S_URL);                                                                           // 179
S_URL_OPENBRACE_SYMS.on(TT_CLOSEBRACE, S_URL);                                                                        // 180
S_URL_OPENBRACKET_SYMS.on(TT_CLOSEBRACKET, S_URL);                                                                    // 181
S_URL_OPENPAREN_SYMS.on(TT_CLOSEPAREN, S_URL);                                                                        // 182
                                                                                                                      // 183
// URL that beings with an opening bracket, followed by a symbols.                                                    // 184
// Note that the final state can still be `S_URL_OPENBRACE_Q` (if the URL only                                        // 185
// has a single opening bracket for some reason).                                                                     // 186
S_URL_OPENBRACE.on(qsAccepting, S_URL_OPENBRACE_Q);                                                                   // 187
S_URL_OPENBRACKET.on(qsAccepting, S_URL_OPENBRACKET_Q);                                                               // 188
S_URL_OPENPAREN.on(qsAccepting, S_URL_OPENPAREN_Q);                                                                   // 189
S_URL_OPENBRACE.on(qsNonAccepting, S_URL_OPENBRACE_SYMS);                                                             // 190
S_URL_OPENBRACKET.on(qsNonAccepting, S_URL_OPENBRACKET_SYMS);                                                         // 191
S_URL_OPENPAREN.on(qsNonAccepting, S_URL_OPENPAREN_SYMS);                                                             // 192
                                                                                                                      // 193
// URL that begins with an opening bracket, followed by some symbols                                                  // 194
S_URL_OPENBRACE_Q.on(qsAccepting, S_URL_OPENBRACE_Q);                                                                 // 195
S_URL_OPENBRACKET_Q.on(qsAccepting, S_URL_OPENBRACKET_Q);                                                             // 196
S_URL_OPENPAREN_Q.on(qsAccepting, S_URL_OPENPAREN_Q);                                                                 // 197
S_URL_OPENBRACE_Q.on(qsNonAccepting, S_URL_OPENBRACE_Q);                                                              // 198
S_URL_OPENBRACKET_Q.on(qsNonAccepting, S_URL_OPENBRACKET_Q);                                                          // 199
S_URL_OPENPAREN_Q.on(qsNonAccepting, S_URL_OPENPAREN_Q);                                                              // 200
                                                                                                                      // 201
S_URL_OPENBRACE_SYMS.on(qsAccepting, S_URL_OPENBRACE_Q);                                                              // 202
S_URL_OPENBRACKET_SYMS.on(qsAccepting, S_URL_OPENBRACKET_Q);                                                          // 203
S_URL_OPENPAREN_SYMS.on(qsAccepting, S_URL_OPENPAREN_Q);                                                              // 204
S_URL_OPENBRACE_SYMS.on(qsNonAccepting, S_URL_OPENBRACE_SYMS);                                                        // 205
S_URL_OPENBRACKET_SYMS.on(qsNonAccepting, S_URL_OPENBRACKET_SYMS);                                                    // 206
S_URL_OPENPAREN_SYMS.on(qsNonAccepting, S_URL_OPENPAREN_SYMS);                                                        // 207
                                                                                                                      // 208
// Account for the query string                                                                                       // 209
S_URL.on(qsAccepting, S_URL);                                                                                         // 210
S_URL_SYMS.on(qsAccepting, S_URL);                                                                                    // 211
                                                                                                                      // 212
S_URL.on(qsNonAccepting, S_URL_SYMS);                                                                                 // 213
S_URL_SYMS.on(qsNonAccepting, S_URL_SYMS);                                                                            // 214
                                                                                                                      // 215
// Email address-specific state definitions                                                                           // 216
// Note: We are not allowing '/' in email addresses since this would interfere                                        // 217
// with real URLs                                                                                                     // 218
                                                                                                                      // 219
// Tokens allowed in the localpart of the email                                                                       // 220
var localpartAccepting = [TT_DOMAIN, TT_NUM, TT_PLUS, TT_POUND, TT_QUERY, TT_SYM, TT_TLD];                            // 221
                                                                                                                      // 222
// Some of the tokens in `localpartAccepting` are already accounted for here and                                      // 223
// will not be overwritten (don't worry)                                                                              // 224
S_DOMAIN.on(localpartAccepting, S_LOCALPART).on(TT_AT, S_LOCALPART_AT);                                               // 225
S_TLD.on(localpartAccepting, S_LOCALPART).on(TT_AT, S_LOCALPART_AT);                                                  // 226
S_DOMAIN_DOT.on(localpartAccepting, S_LOCALPART);                                                                     // 227
                                                                                                                      // 228
// Okay we're on a localpart. Now what?                                                                               // 229
// TODO: IP addresses and what if the email starts with numbers?                                                      // 230
S_LOCALPART.on(localpartAccepting, S_LOCALPART).on(TT_AT, S_LOCALPART_AT) // close to an email address now            // 231
.on(TT_DOT, S_LOCALPART_DOT);                                                                                         // 232
S_LOCALPART_DOT.on(localpartAccepting, S_LOCALPART);                                                                  // 233
S_LOCALPART_AT.on(TT_TLD, S_EMAIL_DOMAIN).on(TT_DOMAIN, S_EMAIL_DOMAIN).on(TT_LOCALHOST, S_EMAIL);                    // 234
// States following `@` defined above                                                                                 // 235
                                                                                                                      // 236
var run = function run(tokens) {                                                                                      // 237
	var len = tokens.length,                                                                                             // 238
	    cursor = 0,                                                                                                      // 239
	    multis = [],                                                                                                     // 240
	    textTokens = [];                                                                                                 // 241
                                                                                                                      // 242
	while (cursor < len) {                                                                                               // 243
                                                                                                                      // 244
		var state = S_START,                                                                                                // 245
		    secondState = null,                                                                                             // 246
		    nextState = null,                                                                                               // 247
		    multiLength = 0,                                                                                                // 248
		    latestAccepting = null,                                                                                         // 249
		    sinceAccepts = -1;                                                                                              // 250
                                                                                                                      // 251
		while (cursor < len && !(secondState = state.next(tokens[cursor]))) {                                               // 252
			// Starting tokens with nowhere to jump to.                                                                        // 253
			// Consider these to be just plain text                                                                            // 254
			textTokens.push(tokens[cursor++]);                                                                                 // 255
		}                                                                                                                   // 256
                                                                                                                      // 257
		while (cursor < len && (nextState = secondState || state.next(tokens[cursor]))) {                                   // 258
                                                                                                                      // 259
			// Get the next state                                                                                              // 260
			secondState = null;                                                                                                // 261
			state = nextState;                                                                                                 // 262
                                                                                                                      // 263
			// Keep track of the latest accepting state                                                                        // 264
			if (state.accepts()) {                                                                                             // 265
				sinceAccepts = 0;                                                                                                 // 266
				latestAccepting = state;                                                                                          // 267
			} else if (sinceAccepts >= 0) {                                                                                    // 268
				sinceAccepts++;                                                                                                   // 269
			}                                                                                                                  // 270
                                                                                                                      // 271
			cursor++;                                                                                                          // 272
			multiLength++;                                                                                                     // 273
		}                                                                                                                   // 274
                                                                                                                      // 275
		if (sinceAccepts < 0) {                                                                                             // 276
                                                                                                                      // 277
			// No accepting state was found, part of a regular text token                                                      // 278
			// Add all the tokens we looked at to the text tokens array                                                        // 279
			for (var i = cursor - multiLength; i < cursor; i++) {                                                              // 280
				textTokens.push(tokens[i]);                                                                                       // 281
			}                                                                                                                  // 282
		} else {                                                                                                            // 283
                                                                                                                      // 284
			// Accepting state!                                                                                                // 285
                                                                                                                      // 286
			// First close off the textTokens (if available)                                                                   // 287
			if (textTokens.length > 0) {                                                                                       // 288
				multis.push(new T_TEXT(textTokens));                                                                              // 289
				textTokens = [];                                                                                                  // 290
			}                                                                                                                  // 291
                                                                                                                      // 292
			// Roll back to the latest accepting state                                                                         // 293
			cursor -= sinceAccepts;                                                                                            // 294
			multiLength -= sinceAccepts;                                                                                       // 295
                                                                                                                      // 296
			// Create a new multitoken                                                                                         // 297
			var MULTI = latestAccepting.emit();                                                                                // 298
			multis.push(new MULTI(tokens.slice(cursor - multiLength, cursor)));                                                // 299
		}                                                                                                                   // 300
	}                                                                                                                    // 301
                                                                                                                      // 302
	// Finally close off the textTokens (if available)                                                                   // 303
	if (textTokens.length > 0) {                                                                                         // 304
		multis.push(new T_TEXT(textTokens));                                                                                // 305
	}                                                                                                                    // 306
                                                                                                                      // 307
	return multis;                                                                                                       // 308
};                                                                                                                    // 309
                                                                                                                      // 310
var TOKENS = _tokens.multi,                                                                                           // 311
    start = S_START;                                                                                                  // 312
exports.State = _state.TokenState;                                                                                    // 313
exports.TOKENS = TOKENS;                                                                                              // 314
exports.run = run;                                                                                                    // 315
exports.start = start;                                                                                                // 316
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}}}}}}}},{"extensions":[".js",".json",".html",".less"]});
require("./node_modules/meteor/arkham:comments-ui/lib/collections/anonymous-user.js");
require("./node_modules/meteor/arkham:comments-ui/lib/collections/comments.js");
require("./node_modules/meteor/arkham:comments-ui/lib/collections/methods/anonymous-user.js");
require("./node_modules/meteor/arkham:comments-ui/lib/collections/methods/comments.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/media-analyzers/image.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/media-analyzers/youtube.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/user.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/time-tick.js");
require("./node_modules/meteor/arkham:comments-ui/lib/services/media.js");
require("./node_modules/meteor/arkham:comments-ui/lib/components/commentsBox/template.commentsBox.js");
require("./node_modules/meteor/arkham:comments-ui/lib/components/commentsSingleComment/template.commentsSingleComment.js");
require("./node_modules/meteor/arkham:comments-ui/lib/components/commentsTextarea/template.commentsTextarea.js");
require("./node_modules/meteor/arkham:comments-ui/lib/components/commentsSubheader/template.commentsSubheader.js");
require("./node_modules/meteor/arkham:comments-ui/lib/components/commentsList/template.commentsList.js");
require("./node_modules/meteor/arkham:comments-ui/lib/api.js");
require("./node_modules/meteor/arkham:comments-ui/lib/components/helpers.js");
require("./node_modules/meteor/arkham:comments-ui/lib/components/commentsBox/commentsBox.js");
require("./node_modules/meteor/arkham:comments-ui/lib/components/commentsSingleComment/commentsSingleComment.js");
require("./node_modules/meteor/arkham:comments-ui/lib/components/commentsTextarea/commentsTextarea.js");
require("./node_modules/meteor/arkham:comments-ui/lib/components/commentsSubheader/commentsSubheader.js");
require("./node_modules/meteor/arkham:comments-ui/lib/components/commentsList/commentsList.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['arkham:comments-ui'] = {}, {
  Comments: Comments
});

})();
