//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
// Source maps are supported by all recent versions of Chrome, Safari,  //
// and Firefox, and by Internet Explorer 11.                            //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var $ = Package.jquery.$;
var jQuery = Package.jquery.jQuery;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var Template = Package['templating-runtime'].Template;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var Random = Package.random.Random;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var Mongo = Package.mongo.Mongo;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var EditableText, sanitizeHtml, callbackMutatedDoc;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/babrahams_editable-text/lib/template.editable_text.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("editableText");                                                                                  // 2
Template["editableText"] = new Template("Template.editableText", (function() {                                         // 3
  var view = this;                                                                                                     // 4
  return Blaze._TemplateWith(function() {                                                                              // 5
    return {                                                                                                           // 6
      context: Spacebars.call(view.lookup("context")),                                                                 // 7
      collection: Spacebars.call(view.lookup("collection")),                                                           // 8
      field: Spacebars.call(view.lookup("field")),                                                                     // 9
      value: Spacebars.call(view.lookup("value")),                                                                     // 10
      editingValue: Spacebars.call(view.lookup("editingValue")),                                                       // 11
      textarea: Spacebars.call(view.lookup("textarea")),                                                               // 12
      wysiwyg: Spacebars.call(view.lookup("wysiwyg")),                                                                 // 13
      acceptEmpty: Spacebars.call(view.lookup("acceptEmpty")),                                                         // 14
      unsetEmpty: Spacebars.call(view.lookup("unsetEmpty")),                                                           // 15
      removeEmpty: Spacebars.call(view.lookup("removeEmpty")),                                                         // 16
      eventType: Spacebars.call(view.lookup("eventType")),                                                             // 17
      type: Spacebars.call(view.lookup("type")),                                                                       // 18
      objectTypeText: Spacebars.call(view.lookup("objectTypeText")),                                                   // 19
      class: Spacebars.call(view.lookup("class")),                                                                     // 20
      inputClass: Spacebars.call(view.lookup("inputClass")),                                                           // 21
      autoInsert: Spacebars.call(view.lookup("autoInsert")),                                                           // 22
      beforeInsert: Spacebars.call(view.lookup("beforeInsert")),                                                       // 23
      afterInsert: Spacebars.call(view.lookup("afterInsert")),                                                         // 24
      wysiwygStyle: Spacebars.call(view.lookup("wysiwygStyle")),                                                       // 25
      style: Spacebars.call(view.lookup("style")),                                                                     // 26
      inputStyle: Spacebars.call(view.lookup("inputStyle")),                                                           // 27
      substitute: Spacebars.call(view.lookup("substitute")),                                                           // 28
      title: Spacebars.call(view.lookup("title")),                                                                     // 29
      userCanEdit: Spacebars.call(view.lookup("userCanEdit")),                                                         // 30
      useTransaction: Spacebars.call(view.lookup("useTransaction")),                                                   // 31
      useExistingTransaction: Spacebars.call(view.lookup("useExistingTransaction")),                                   // 32
      beforeUpdate: Spacebars.call(view.lookup("beforeUpdate")),                                                       // 33
      afterUpdate: Spacebars.call(view.lookup("afterUpdate")),                                                         // 34
      beforeRemove: Spacebars.call(view.lookup("beforeRemove")),                                                       // 35
      afterRemove: Spacebars.call(view.lookup("afterRemove")),                                                         // 36
      onStartEditing: Spacebars.call(view.lookup("onStartEditing")),                                                   // 37
      onStopEditing: Spacebars.call(view.lookup("onStopEditing")),                                                     // 38
      onShowToolbar: Spacebars.call(view.lookup("onShowToolbar")),                                                     // 39
      onHideToolbar: Spacebars.call(view.lookup("onHideToolbar")),                                                     // 40
      placeholder: Spacebars.call(view.lookup("placeholder")),                                                         // 41
      saveOnFocusout: Spacebars.call(view.lookup("saveOnFocusout")),                                                   // 42
      removeOnFocusout: Spacebars.call(view.lookup("removeOnFocusout")),                                               // 43
      noSaveOnReturn: Spacebars.call(view.lookup("noSaveOnReturn")),                                                   // 44
      dontSelectAll: Spacebars.call(view.lookup("dontSelectAll")),                                                     // 45
      showSaveButton: Spacebars.call(view.lookup("showSaveButton")),                                                   // 46
      trustHtml: Spacebars.call(view.lookup("trustHtml")),                                                             // 47
      useMethod: Spacebars.call(view.lookup("useMethod")),                                                             // 48
      toolbarPosition: Spacebars.call(view.lookup("toolbarPosition")),                                                 // 49
      options: Spacebars.call(view.lookup("options")),                                                                 // 50
      autoResize: Spacebars.call(view.lookup("autoResize")),                                                           // 51
      emptyText: Spacebars.call(view.lookup("emptyText")),                                                             // 52
      showToolbar: Spacebars.call(view.lookup("showToolbar")),                                                         // 53
      derivedOptions: Spacebars.call(view.lookup("derivedOptions")),                                                   // 54
      template: Spacebars.call(view.lookup("template")),                                                               // 55
      stopPropagation: Spacebars.call(view.lookup("stopPropagation")),                                                 // 56
      editor: Spacebars.call(view.lookup("editor")),                                                                   // 57
      editorOptions: Spacebars.call(view.lookup("editorOptions")),                                                     // 58
      data: Spacebars.call(view.lookup("data")),                                                                       // 59
      transactionInsertText: Spacebars.call(view.lookup("transactionInsertText")),                                     // 60
      transactionUpdateText: Spacebars.call(view.lookup("transactionUpdateText")),                                     // 61
      transactionRemoveText: Spacebars.call(view.lookup("transactionRemoveText"))                                      // 62
    };                                                                                                                 // 63
  }, function() {                                                                                                      // 64
    return Spacebars.include(view.lookupTemplate("editable_text_widget"));                                             // 65
  });                                                                                                                  // 66
}));                                                                                                                   // 67
                                                                                                                       // 68
Template.__checkName("editable_text_widget");                                                                          // 69
Template["editable_text_widget"] = new Template("Template.editable_text_widget", (function() {                         // 70
  var view = this;                                                                                                     // 71
  return Spacebars.With(function() {                                                                                   // 72
    return Spacebars.call(view.lookup("initOptions"));                                                                 // 73
  }, function() {                                                                                                      // 74
    return Blaze.If(function() {                                                                                       // 75
      return Spacebars.call(view.lookup("controlTemplate"));                                                           // 76
    }, function() {                                                                                                    // 77
      return Blaze._TemplateWith(function() {                                                                          // 78
        return {                                                                                                       // 79
          template: Spacebars.call(view.lookup("controlTemplate")),                                                    // 80
          data: Spacebars.call(view.lookup("controlData"))                                                             // 81
        };                                                                                                             // 82
      }, function() {                                                                                                  // 83
        return Spacebars.include(function() {                                                                          // 84
          return Spacebars.call(Template.__dynamic);                                                                   // 85
        });                                                                                                            // 86
      });                                                                                                              // 87
    }, function() {                                                                                                    // 88
      return Blaze.If(function() {                                                                                     // 89
        return Spacebars.call(view.lookup("editing"));                                                                 // 90
      }, function() {                                                                                                  // 91
        return Blaze.If(function() {                                                                                   // 92
          return Spacebars.call(view.lookup("textarea"));                                                              // 93
        }, function() {                                                                                                // 94
          return [ Blaze.If(function() {                                                                               // 95
            return Spacebars.call(view.lookup("showSaveButton"));                                                      // 96
          }, function() {                                                                                              // 97
            return HTML.BUTTON({                                                                                       // 98
              class: "editable-text-save-button"                                                                       // 99
            }, "Save");                                                                                                // 100
          }), HTML.TEXTAREA({                                                                                          // 101
            class: function() {                                                                                        // 102
              return [ "text-area-edit ", Spacebars.mustache(view.lookup("inputClass")) ];                             // 103
            },                                                                                                         // 104
            placeholder: function() {                                                                                  // 105
              return Spacebars.mustache(view.lookup("placeholder"));                                                   // 106
            },                                                                                                         // 107
            title: function() {                                                                                        // 108
              return Blaze.If(function() {                                                                             // 109
                return Spacebars.call(view.lookup("trustHtml"));                                                       // 110
              }, function() {                                                                                          // 111
                return "Hold SHIFT and press ENTER for a new line";                                                    // 112
              });                                                                                                      // 113
            },                                                                                                         // 114
            style: function() {                                                                                        // 115
              return Spacebars.mustache(view.lookup("inputStyle"));                                                    // 116
            },                                                                                                         // 117
            value: function() {                                                                                        // 118
              return Spacebars.mustache(view.lookup("value"));                                                         // 119
            }                                                                                                          // 120
          }) ];                                                                                                        // 121
        }, function() {                                                                                                // 122
          return Blaze.If(function() {                                                                                 // 123
            return Spacebars.call(view.lookup("isWysiwyg"));                                                           // 124
          }, function() {                                                                                              // 125
            return HTML.DIV({                                                                                          // 126
              class: "wysiwyg-container"                                                                               // 127
            }, Blaze.If(function() {                                                                                   // 128
              return Spacebars.dataMustache(view.lookup("toolsPosition"), "top");                                      // 129
            }, function() {                                                                                            // 130
              return Spacebars.include(view.lookupTemplate("wysiwyg"));                                                // 131
            }), HTML.DIV({                                                                                             // 132
              class: function() {                                                                                      // 133
                return [ "wysiwyg ", Spacebars.mustache(view.lookup("inputClass")) ];                                  // 134
              },                                                                                                       // 135
              style: function() {                                                                                      // 136
                return Spacebars.mustache(view.lookup("inputStyle"));                                                  // 137
              }                                                                                                        // 138
            }, Blaze.View("lookup:wysiwygContent", function() {                                                        // 139
              return Spacebars.mustache(view.lookup("wysiwygContent"));                                                // 140
            })), Blaze.Unless(function() {                                                                             // 141
              return Spacebars.dataMustache(view.lookup("toolsPosition"), "top");                                      // 142
            }, function() {                                                                                            // 143
              return Spacebars.include(view.lookupTemplate("wysiwyg"));                                                // 144
            }));                                                                                                       // 145
          }, function() {                                                                                              // 146
            return HTML.INPUT({                                                                                        // 147
              class: function() {                                                                                      // 148
                return [ "wide-text-edit ", Spacebars.mustache(view.lookup("inputClass")) ];                           // 149
              },                                                                                                       // 150
              type: "text",                                                                                            // 151
              value: function() {                                                                                      // 152
                return Spacebars.mustache(view.lookup("inputValue"));                                                  // 153
              },                                                                                                       // 154
              placeholder: function() {                                                                                // 155
                return Spacebars.mustache(view.lookup("placeholder"));                                                 // 156
              },                                                                                                       // 157
              style: function() {                                                                                      // 158
                return Spacebars.mustache(view.lookup("inputStyle"));                                                  // 159
              }                                                                                                        // 160
            });                                                                                                        // 161
          });                                                                                                          // 162
        });                                                                                                            // 163
      }, function() {                                                                                                  // 164
        return Blaze.If(function() {                                                                                   // 165
          return Spacebars.call(view.lookup("canEditText"));                                                           // 166
        }, function() {                                                                                                // 167
          return Blaze.If(function() {                                                                                 // 168
            return Spacebars.call(view.lookup("substitute"));                                                          // 169
          }, function() {                                                                                              // 170
            return HTML.SPAN({                                                                                         // 171
              title: function() {                                                                                      // 172
                return Spacebars.mustache(view.lookup("title"));                                                       // 173
              },                                                                                                       // 174
              class: function() {                                                                                      // 175
                return [ "editable-text ", Spacebars.mustache(view.lookup("class")), " et-", Spacebars.mustache(Spacebars.dot(view.lookup("context"), "_id")) ];
              }                                                                                                        // 177
            }, Blaze.View("lookup:substitute", function() {                                                            // 178
              return Spacebars.mustache(view.lookup("substitute"));                                                    // 179
            }));                                                                                                       // 180
          }, function() {                                                                                              // 181
            return Blaze.If(function() {                                                                               // 182
              return Spacebars.call(view.lookup("isWysiwyg"));                                                         // 183
            }, function() {                                                                                            // 184
              return HTML.DIV({                                                                                        // 185
                class: "wysiwyg-content"                                                                               // 186
              }, HTML.DIV({                                                                                            // 187
                class: function() {                                                                                    // 188
                  return [ "editable-text ", Spacebars.mustache(view.lookup("class")), " et-", Spacebars.mustache(Spacebars.dot(view.lookup("context"), "_id")) ];
                },                                                                                                     // 190
                title: function() {                                                                                    // 191
                  return Spacebars.mustache(view.lookup("title"));                                                     // 192
                },                                                                                                     // 193
                style: function() {                                                                                    // 194
                  return Spacebars.mustache(view.lookup("style"));                                                     // 195
                }                                                                                                      // 196
              }, Blaze.View("lookup:wysiwygContent", function() {                                                      // 197
                return Spacebars.mustache(view.lookup("wysiwygContent"));                                              // 198
              })));                                                                                                    // 199
            }, function() {                                                                                            // 200
              return HTML.SPAN({                                                                                       // 201
                class: function() {                                                                                    // 202
                  return [ "editable-text ", Spacebars.mustache(view.lookup("class")), " et-", Spacebars.mustache(Spacebars.dot(view.lookup("context"), "_id")) ];
                },                                                                                                     // 204
                title: function() {                                                                                    // 205
                  return Spacebars.mustache(view.lookup("title"));                                                     // 206
                }                                                                                                      // 207
              }, Blaze.View("lookup:content", function() {                                                             // 208
                return Spacebars.mustache(view.lookup("content"));                                                     // 209
              }));                                                                                                     // 210
            });                                                                                                        // 211
          });                                                                                                          // 212
        }, function() {                                                                                                // 213
          return Spacebars.With(function() {                                                                           // 214
            return Spacebars.dataMustache(view.lookup("substitute"), true);                                            // 215
          }, function() {                                                                                              // 216
            return Blaze.View("lookup:.", function() {                                                                 // 217
              return Spacebars.mustache(view.lookup("."));                                                             // 218
            });                                                                                                        // 219
          }, function() {                                                                                              // 220
            return Blaze.If(function() {                                                                               // 221
              return Spacebars.call(view.lookup("isWysiwyg"));                                                         // 222
            }, function() {                                                                                            // 223
              return Blaze.View("lookup:wysiwygContent", function() {                                                  // 224
                return Spacebars.mustache(view.lookup("wysiwygContent"));                                              // 225
              });                                                                                                      // 226
            }, function() {                                                                                            // 227
              return Blaze.View("lookup:content", function() {                                                         // 228
                return Spacebars.mustache(view.lookup("content"));                                                     // 229
              });                                                                                                      // 230
            });                                                                                                        // 231
          });                                                                                                          // 232
        });                                                                                                            // 233
      });                                                                                                              // 234
    });                                                                                                                // 235
  });                                                                                                                  // 236
}));                                                                                                                   // 237
                                                                                                                       // 238
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/babrahams_editable-text/lib/editable_text.js                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
EditableText = {};                                                                                                     // 1
                                                                                                                       // 2
// *******************************                                                                                     // 3
// CONFIG that only affects CLIENT                                                                                     // 4
// *******************************                                                                                     // 5
                                                                                                                       // 6
EditableText.saveOnFocusout = true;                                                                                    // 7
EditableText.trustHtml = false;                                                                                        // 8
EditableText.useMethods = true; // only set this to false if you really know what you're doing and have taken appropriate measures to thwart XSS attacks
EditableText.editors = {}; // where other packages register different editors that can supplant the UI functionality of this package, while using the mutator methods it makes available
EditableText.isTouchDevice = ('ontouchstart' in document.documentElement);                                             // 11
                                                                                                                       // 12
// The `EditableText.insert`, `EditableText.update`, `EditableText.remove` functions can be optionally overwritten if necessary
// Not recommended, though. It's a lot of work to get the same functionality that the package provides by default      // 14
                                                                                                                       // 15
EditableText.insert = function (Collection, doc) {                                                                     // 16
  var self = _.clone(this); // Don't want to update the original                                                       // 17
  if (EditableText.useMethods && this.useMethod !== false || this.useMethod) {                                         // 18
    var objId = Random.id();                                                                                           // 19
    self.context = _.clone(self.context); // need to clone this field again because this.context is an object and _.clone isn't a deep clone
    self.context._id = objId;                                                                                          // 21
    Meteor.call('_editableTextWrite', 'insert', self, null, EditableText._useTransaction(this), function (err, res) {  // 22
      if (err) {                                                                                                       // 23
        console.log(err);                                                                                              // 24
        return;                                                                                                        // 25
      }                                                                                                                // 26
      // Just in case it didn't get into the DOM in time                                                               // 27
      /*Tracker.flush();                                                                                               // 28
      var elem = $('.et-' + objId);                                                                                    // 29
      if (elem.length) {                                                                                               // 30
        elem.eq(0).trigger((EditableText.wysiwyg && self.wysiwyg) ? 'mousedown' : 'click');                            // 31
      }*/                                                                                                              // 32
    });                                                                                                                // 33
    // TODO -- this new object needs to get `selected` set in its template instance (and the corresponding element needs to gain focus) wherever it lands in the DOM
    // However, we have no easy way of getting its template instance, other than iterating over                        // 35
    // all template instances, looking for the one where the context._id matches the object_id value                   // 36
    // Unfortunately, I have no idea where the template instances are stored                                           // 37
    // So using a filthy hack instead ...                                                                              // 38
    // Getting the element(s) in the DOM with the right class and firing click event on the first one                  // 39
    // Too bad if this wasn't the element we really wanted to be editing                                               // 40
    // Note: we can't fire events on them all as, if there are (even temporarily) duplicates in the DOM and removeEmpty=true, this could cause unwanted side effects (e.g. instant deletion after creation)
    // This means that in cases when the newly inserted document field is available in multiple places on the screen, the wrong one might be selected for editing (i.e. one that wasn't where the user clicked)
    // This is probably rare enough that we'll ignore it until it becomes a serious problem, at which time we'll come up with another hack
    Tracker.flush(); // Put this here rather than in the callback to maintain latency compensation                     // 44
    var elem = $('.et-' + objId);                                                                                      // 45
    if (elem.length) {                                                                                                 // 46
      elem.eq(0).trigger((EditableText.wysiwyg && self.wysiwyg) ? 'mousedown' : 'click');                              // 47
    }                                                                                                                  // 48
    return;                                                                                                            // 49
  }                                                                                                                    // 50
  if (EditableText._useTransaction(this)) {                                                                            // 51
    if (this.transactionInsertText || this.objectTypeText) {                                                           // 52
      tx.start(this.transactionInsertText || 'add ' + this.objectTypeText, EditableText._transactionOptions(this));    // 53
    }                                                                                                                  // 54
    EditableText._callback.call(self, 'beforeInsert', self.context);                                                   // 55
    var new_id = tx.insert(Collection, doc, {instant: true});                                                          // 56
    EditableText._callback.call(self, 'afterInsert', Collection.findOne({_id: new_id}));                               // 57
    if (this.transactionInsertText || this.objectTypeText) {                                                           // 58
      tx.commit();                                                                                                     // 59
    }                                                                                                                  // 60
  }                                                                                                                    // 61
  else {                                                                                                               // 62
    doc = EditableText._callback.call(self, 'beforeInsert', self.context);                                             // 63
    var new_id = Collection.insert(doc);                                                                               // 64
    EditableText._callback.call(self, 'afterInsert', Collection.findOne({_id: new_id}));                               // 65
  }                                                                                                                    // 66
  // see above                                                                                                         // 67
  Tracker.flush();                                                                                                     // 68
  $('.et-' + new_id).eq(0).trigger((EditableText.wysiwyg && this.wysiwyg) ? 'mousedown' : 'click');                    // 69
  return new_id;                                                                                                       // 70
}                                                                                                                      // 71
                                                                                                                       // 72
EditableText.update = function (Collection, doc, modifier) {                                                           // 73
  var self = this;                                                                                                     // 74
  if (EditableText.useMethods && this.useMethod !== false || this.useMethod) {                                         // 75
    Meteor.call('_editableTextWrite', 'update', this, modifier, EditableText._useTransaction(this), function (err, res) {
      if (err) {                                                                                                       // 77
        console.log(err);                                                                                              // 78
      }                                                                                                                // 79
    });                                                                                                                // 80
    return;                                                                                                            // 81
  }                                                                                                                    // 82
  if (EditableText._useTransaction(this)) {                                                                            // 83
    if (this.objectTypeText || this.transactionUpdateText) {                                                           // 84
      tx.start(this.transactionUpdateText || 'update ' + this.objectTypeText, EditableText._transactionOptions(this));  
    }                                                                                                                  // 86
    EditableText._callback.call(self, 'beforeUpdate', doc);                                                            // 87
    // Important to send the id only, not the whole document ("self"),                                                 // 88
    // as this update is fired from all sorts of contexts, some of which are incomplete --                             // 89
    // this will force the transaction script to find the relevant document with its full context from the database    // 90
    tx.update(Collection, doc._id, modifier, {instant: true});                                                         // 91
    EditableText._callback.call(self, 'afterUpdate', Collection.findOne({_id: doc._id}));                              // 92
    if (this.objectTypeText || this.transactionUpdateText) {                                                           // 93
      tx.commit();                                                                                                     // 94
    }                                                                                                                  // 95
  }                                                                                                                    // 96
  else {                                                                                                               // 97
    EditableText._callback.call(self, 'beforeUpdate', doc);                                                            // 98
    Collection.update({_id: doc._id}, modifier);                                                                       // 99
    EditableText._callback.call(self, 'afterUpdate', Collection.findOne({_id: doc._id}));                              // 100
  }                                                                                                                    // 101
}                                                                                                                      // 102
                                                                                                                       // 103
EditableText.remove = function (Collection, doc) {                                                                     // 104
  var self = this;                                                                                                     // 105
  if (EditableText.useMethods && this.useMethod !== false || this.useMethod) {                                         // 106
    Meteor.call('_editableTextWrite', 'remove', this, null, EditableText._useTransaction(this), function (err, res) {  // 107
      if (err) {                                                                                                       // 108
        console.log(err);                                                                                              // 109
      }                                                                                                                // 110
    });                                                                                                                // 111
    return;                                                                                                            // 112
  }                                                                                                                    // 113
  if (EditableText._useTransaction(this)) {                                                                            // 114
    if (this.objectTypeText || this.transactionRemoveText) {                                                           // 115
      tx.start(this.transactionRemoveText || 'remove ' + this.objectTypeText, EditableText._transactionOptions(this));  
    }                                                                                                                  // 117
    EditableText._callback.call(self, 'beforeRemove', doc);                                                            // 118
    tx.remove(Collection, doc._id, {instant: true});                                                                   // 119
    EditableText._callback.call(self, 'afterRemove', Collection.findOne({_id: doc._id}));                              // 120
    if (this.objectTypeText || this.transactionRemoveText) {                                                           // 121
      tx.commit();                                                                                                     // 122
    }                                                                                                                  // 123
  }                                                                                                                    // 124
  else {                                                                                                               // 125
    EditableText._callback.call(self, 'beforeRemove', doc);                                                            // 126
    Collection.remove({_id: doc._id});                                                                                 // 127
    EditableText._callback.call(self, 'afterRemove', Collection.findOne({_id: doc._id}));                              // 128
  }                                                                                                                    // 129
}                                                                                                                      // 130
                                                                                                                       // 131
                                                                                                                       // 132
// *********************************                                                                                   // 133
// INTERNAL PROPERTIES AND FUNCTIONS                                                                                   // 134
// *********************************                                                                                   // 135
                                                                                                                       // 136
EditableText._removeEntities = function (html) {                                                                       // 137
  return $.trim(html.replace(/&quot;/g, '"').replace(/&gt;/g, '>').replace(/&lt;/g, '<').replace(/&nbsp;/g, ' '));     // 138
}                                                                                                                      // 139
                                                                                                                       // 140
/*EditableText._linkify = function (text) {                                                                            // 141
  return autolinker.link(text);                                                                                        // 142
}*/                                                                                                                    // 143
                                                                                                                       // 144
EditableText._useTransaction = function (data) {                                                                       // 145
  var useTransaction = data.useTransaction || data.useExistingTransaction;                                             // 146
  return !!(typeof tx !== 'undefined' && ((EditableText.useTransactions && useTransaction !== false) || useTransaction));    
}                                                                                                                      // 148
                                                                                                                       // 149
EditableText.__blockOkayEvent = false;                                                                                 // 150
EditableText.__blockEditEvent = false;                                                                                 // 151
                                                                                                                       // 152
Template.editableText.helpers({                                                                                        // 153
  context : function () {                                                                                              // 154
    return this.context || this.document || this.doc || this.object || this.obj || this.data || this.dataContext || Blaze._parentData(1);
  }                                                                                                                    // 156
});                                                                                                                    // 157
                                                                                                                       // 158
// Returns an event map that handles the "escape" and "return" keys and                                                // 159
// "blur" events on a text input (given by selector) and interprets them                                               // 160
// as "ok" or "cancel".                                                                                                // 161
                                                                                                                       // 162
EditableText._okCancelEvents = function (selector, callbacks, acceptEmpty) {                                           // 163
  var ok = callbacks.ok || function () {};                                                                             // 164
  var cancel = callbacks.cancel || function () {};                                                                     // 165
  var events = {};                                                                                                     // 166
  events['keydown '+selector+', focusout '+selector] =                                                                 // 167
    function (evt, tmpl) {                                                                                             // 168
      evt.stopImmediatePropagation();                                                                                  // 169
      var charCode = evt.which || evt.keyCode;                                                                         // 170
      var value = $.trim(String($(evt.target).val() || ""));                                                           // 171
      if (evt.type === "keydown") {                                                                                    // 172
        switch (charCode) {                                                                                            // 173
          case 27 : // escape = cancel                                                                                 // 174
            cancel.call(this, value, evt, tmpl);                                                                       // 175
            break;                                                                                                     // 176
        }                                                                                                              // 177
      }                                                                                                                // 178
      if (evt.type === "keydown" && (charCode === 13 && !(evt.shiftKey || (typeof this.noSaveOnReturn !== 'undefined' && this.noSaveOnReturn))) || (evt.type === "focusout" && ((typeof this.saveOnFocusout !== 'undefined' && this.saveOnFocusout) || (typeof this.saveOnFocusout === 'undefined' && EditableText.saveOnFocusout)))) {
        evt.preventDefault();                                                                                          // 180
        // blur/return/enter = ok/submit if non-empty                                                                  // 181
        if ((value || (this.type === 'number' && parseInt(value) === 0)) || this.removeEmpty || (this.acceptEmpty || acceptEmpty)) {
          if (!EditableText._blockOkayEvent) {                                                                         // 183
            EditableText._blockOkayEvent = true;                                                                       // 184
            ok.call(this, value, evt, tmpl); // EditableText._linkify(value)                                           // 185
			if (evt.type === "keydown") {                                                                                       // 186
   	          tmpl.$(evt.currentTarget).blur(); // For phones -- to get rid of the keyboard                            // 187
			}                                                                                                                   // 188
            Meteor.defer(function () {                                                                                 // 189
              EditableText._blockOkayEvent = false;                                                                    // 190
            });                                                                                                        // 191
          }                                                                                                            // 192
          else { // In case this value is set to true for some strange reason                                          // 193
            EditableText._blockOkayEvent = false;                                                                      // 194
          }                                                                                                            // 195
        }                                                                                                              // 196
        else {                                                                                                         // 197
          cancel.call(this, value, evt, tmpl);                                                                         // 198
        }                                                                                                              // 199
      }                                                                                                                // 200
    };                                                                                                                 // 201
  return events;                                                                                                       // 202
};                                                                                                                     // 203
                                                                                                                       // 204
EditableText._activateInput = function (input, dontSelect) {                                                           // 205
  if (input !== null) {                                                                                                // 206
    input.focus();                                                                                                     // 207
    if (typeof dontSelect !== 'undefined' && dontSelect) {                                                             // 208
      return;                                                                                                          // 209
    }                                                                                                                  // 210
    input.select();                                                                                                    // 211
  }                                                                                                                    // 212
  else {                                                                                                               // 213
    console.log('Input was null');                                                                                     // 214
  }                                                                                                                    // 215
};                                                                                                                     // 216
                                                                                                                       // 217
EditableText._extractNumber = function (raw) {                                                                         // 218
  if (typeof raw !== 'undefined') {                                                                                    // 219
    var numbers = raw.match(/[0-9]+/);                                                                                 // 220
    if (numbers) {                                                                                                     // 221
      return parseInt(numbers[0], 10);                                                                                 // 222
    }                                                                                                                  // 223
  }                                                                                                                    // 224
  return 0;                                                                                                            // 225
}                                                                                                                      // 226
                                                                                                                       // 227
EditableText._makeUpdate = function (value, isEscape, evtType) {                                                       // 228
  // value has already been trimmed with $.trim()                                                                      // 229
  var currentValue = (this.editingValue || this.value) || EditableText._drillDown(this.context, this.field);           // 230
  if (this.unsetEmpty && value === '' && currentValue !== undefined) {                                                 // 231
    var mod = {};                                                                                                      // 232
    mod[this.field] = 1;                                                                                               // 233
    EditableText.update.call(this, Mongo.Collection.get(this.collection), this.context, {$unset: mod});                // 234
    return;                                                                                                            // 235
  }                                                                                                                    // 236
  var type = this.type || 'string';                                                                                    // 237
  var keepZero = false;                                                                                                // 238
  switch (type) {                                                                                                      // 239
    case 'number' :                                                                                                    // 240
      if (value !== '') {                                                                                              // 241
        var rawNewValue = EditableText._extractNumber(value);                                                          // 242
        var newValue = rawNewValue && parseInt(rawNewValue) || 0;                                                      // 243
        keepZero = true;                                                                                               // 244
      }                                                                                                                // 245
      else {                                                                                                           // 246
        var newValue = 0;                                                                                              // 247
      }                                                                                                                // 248
      if (currentValue !== undefined) {                                                                                // 249
        currentValue = currentValue && parseInt(currentValue) || 0;                                                    // 250
      }                                                                                                                // 251
      break;                                                                                                           // 252
    default :                                                                                                          // 253
      var newValue = value.replace(/mml:/g, ""); // For cleaning up mathml pasted from msword                          // 254
      currentValue = _.isString(currentValue) && currentValue.replace(/<br \/>/g, "<br>") || '';                       // 255
      currentValue = EditableText._removeEntities(currentValue);                                                       // 256
      newValue = EditableText._removeEntities(newValue);                                                               // 257
      break;                                                                                                           // 258
  }                                                                                                                    // 259
  var updatedValue = {};                                                                                               // 260
  updatedValue[this.field] = newValue; // console.log("newValue:",newValue); console.log("currentValue:",currentValue);
  // Sometimes we don't want the actual field's value, we want whatever was passed in to the template as the 'value' keyword to be used to compare against
  if (newValue !== currentValue || (!(newValue || (this.type === 'number' && newValue === 0 && keepZero)) && this.removeEmpty && !(this.acceptEmpty && (evtType === 'focusout' && this.removeOnFocusout === false)))) {
    if (!(newValue || (this.type === 'number' && newValue === 0 && keepZero)) && this.removeEmpty && !(this.acceptEmpty && (evtType === 'focusout' && this.removeOnFocusout === false))) {
      if ((isEscape || (evtType === 'focusout' && this.removeOnFocusout === false)) && (this.acceptEmpty || currentValue)) { // isEscape is an alternative for (isEscape || evtType === 'focusout') if we want to allow focusout to remove an item
        return;                                                                                                        // 266
      }                                                                                                                // 267
      EditableText.remove.call(this, Mongo.Collection.get(this.collection), this.context);                             // 268
    }                                                                                                                  // 269
    else if (!isEscape && (newValue !== currentValue) && ((newValue || (this.type === 'number' && newValue === 0)) || this.acceptEmpty || (this.wysiwyg && this.acceptEmpty !== false))) { // wysiwyg accepts empty by default unless explicitly told not to
      // Make the update                                                                                               // 271
      EditableText.update.call(this, Mongo.Collection.get(this.collection), this.context, {$set: updatedValue});       // 272
    }                                                                                                                  // 273
  }                                                                                                                    // 274
}                                                                                                                      // 275
                                                                                                                       // 276
// *******                                                                                                             // 277
// HELPERS                                                                                                             // 278
// *******                                                                                                             // 279
                                                                                                                       // 280
Template.editable_text_widget.helpers({                                                                                // 281
                                                                                                                       // 282
  value : function () {                                                                                                // 283
    var value = (this.editingValue !== 'undefined') ? this.editingValue : this.value;                                  // 284
    return (this.type === 'number' && value === 0) ? 0 : value || EditableText._drillDown(this.context, this.field);   // 285
  },                                                                                                                   // 286
                                                                                                                       // 287
  editing : function () {                                                                                              // 288
    return Blaze._templateInstance().selected.get();                                                                   // 289
  },                                                                                                                   // 290
                                                                                                                       // 291
  textarea : function () {                                                                                             // 292
    return (this.textarea && !this.wysiwyg) || (this.wysiwyg && !EditableText.wysiwyg);                                // 293
  },                                                                                                                   // 294
                                                                                                                       // 295
  isWysiwyg : function () {                                                                                            // 296
    return EditableText.wysiwyg && this.wysiwyg;                                                                       // 297
  },                                                                                                                   // 298
                                                                                                                       // 299
  wysiwygContent : function () {                                                                                       // 300
    var value = this.value || EditableText._drillDown(this.context, this.field);                                       // 301
    return value && new Spacebars.SafeString(value.replace(/\n/g, '<br>')) || "";                                      // 302
  },                                                                                                                   // 303
                                                                                                                       // 304
  inputValue : function () {                                                                                           // 305
    var val = (this.editingValue !== undefined) ? this.editingValue : this.value;                                      // 306
    var value = (this.type === 'number' && val === 0) ? 0 : val || EditableText._drillDown(this.context, this.field);  // 307
    return (this.type === 'number' && value === 0) ? 0 : value && value.toString() || "";                              // 308
  },                                                                                                                   // 309
                                                                                                                       // 310
  substitute : function (userCanNotEdit) {                                                                             // 311
    var substitute = !(this.value || EditableText._drillDown(this.context,this.field)) && ((userCanNotEdit) ? (this.emptyText && Spacebars.SafeString(this.emptyText.toString())) : (this.substitute && Spacebars.SafeString(this.substitute.toString())));
    return substitute;                                                                                                 // 313
  },                                                                                                                   // 314
                                                                                                                       // 315
  title : function () {                                                                                                // 316
    return this.title || ((this.eventType === 'dblclick') ? 'double click' : 'click') + ' to edit';                    // 317
  },                                                                                                                   // 318
                                                                                                                       // 319
  canEditText : function () {                                                                                          // 320
    var userCanEdit = EditableText.userCanEdit.call(this, this.context, Mongo.Collection.get(this.collection));        // 321
    return (typeof this.userCanEdit !== 'undefined') ? (this.userCanEdit && userCanEdit) : userCanEdit;                // 322
  },                                                                                                                   // 323
                                                                                                                       // 324
  content : function () {                                                                                              // 325
    var value = (typeof this.value !== 'undefined') ? this.value : EditableText._drillDown(this.context, this.field);  // 326
    var val = (_.isString(value)) ? (((typeof this.trustHtml !== 'undefined' && this.trustHtml || EditableText.trustHtml) || (this.wysiwyg && !EditableText.wysiwyg)) && new Spacebars.SafeString(value.replace(/\n/g, '<br>')) || value) : ((value || value === 0) ? value.toString() : "");
    return val;                                                                                                        // 328
  },                                                                                                                   // 329
                                                                                                                       // 330
  trustHtml : function () {                                                                                            // 331
    return typeof this.trustHtml !== 'undefined' && this.trustHtml || EditableText.trustHtml;                          // 332
  },                                                                                                                   // 333
                                                                                                                       // 334
  toolsPosition : function (pos) {                                                                                     // 335
    return this.toolbarPosition === pos;                                                                               // 336
  },                                                                                                                   // 337
                                                                                                                       // 338
  initOptions : function () {                                                                                          // 339
    var data = this;                                                                                                   // 340
    var derivedOptions = (data.derivedOptions) ? EditableText._callback.call(data, 'derivedOptions', data) : {};       // 341
    var opts = _.extend(data.options || {}, _.isObject(derivedOptions) && derivedOptions || {});                       // 342
    if (opts) {                                                                                                        // 343
      _.each(opts, function (value, key) {                                                                             // 344
        if (data[key] === undefined) {                                                                                 // 345
          data[key] = value;                                                                                           // 346
        }                                                                                                              // 347
      });                                                                                                              // 348
      var context = opts.context || opts.doc || opts.document || opts.obj || opts.object || opts.data || opts.dataContext;
      if (context !== undefined) {                                                                                     // 350
        data.context = context;                                                                                        // 351
      }                                                                                                                // 352
    }                                                                                                                  // 353
    return data;                                                                                                       // 354
  },                                                                                                                   // 355
                                                                                                                       // 356
  controlTemplate : function () {                                                                                      // 357
    return this.editor && EditableText.editors[this.editor] && EditableText.editors[this.editor].template;             // 358
  },                                                                                                                   // 359
                                                                                                                       // 360
  controlData : function () {                                                                                          // 361
    return this;                                                                                                       // 362
  }                                                                                                                    // 363
                                                                                                                       // 364
});                                                                                                                    // 365
                                                                                                                       // 366
                                                                                                                       // 367
// ******                                                                                                              // 368
// EVENTS                                                                                                              // 369
// ******                                                                                                              // 370
                                                                                                                       // 371
Template.body.events({                                                                                                 // 372
  'click .editable-text-trigger, mousedown .editable-text-trigger, dblclick .editable-text-trigger' : function (evt) {
    if (!EditableText.__blockEditEvent) {                                                                              // 374
      $(evt.currentTarget).find('.editable-text').trigger(evt.type);                                                   // 375
    }                                                                                                                  // 376
    else {                                                                                                             // 377
      EditableText.__blockEditEvent = false;                                                                           // 378
    }                                                                                                                  // 379
  }                                                                                                                    // 380
});                                                                                                                    // 381
                                                                                                                       // 382
EditableText.okCancelEvents = {};                                                                                      // 383
                                                                                                                       // 384
EditableText.okCancelEvents.ok = function (value, evt, tmpl) {                                                         // 385
  evt.stopImmediatePropagation();                                                                                      // 386
  evt.stopPropagation();                                                                                               // 387
  var isEscape = false;                                                                                                // 388
  EditableText._makeUpdate.call(this, value, isEscape, evt.type);                                                      // 389
  tmpl.selected.set(false);                                                                                            // 390
  EditableText._callback.call(this, 'onStopEditing', tmpl.data.context);                                               // 391
}                                                                                                                      // 392
                                                                                                                       // 393
EditableText.okCancelEvents.cancel = function (value, evt, tmpl) {                                                     // 394
  evt.stopImmediatePropagation();                                                                                      // 395
  // Check for removeEmpty update, in case a document has been auto inserted and user clicks escape                    // 396
  // But set the flag isEscape so regular updates are not made                                                         // 397
  var isEscape = true;                                                                                                 // 398
  EditableText._makeUpdate.call(this, value, isEscape);                                                                // 399
  tmpl.selected.set(false);                                                                                            // 400
  EditableText._callback.call(this, 'onStopEditing', tmpl.data.context);                                               // 401
}                                                                                                                      // 402
                                                                                                                       // 403
EditableText.editing_key_press = function(elem, inputClass) {                                                          // 404
  if (EditableText.editing_key_press.fakeEl === undefined) {                                                           // 405
    EditableText.editing_key_press.fakeEl = $('<span class="' + (inputClass || '') + '">').hide().appendTo(document.body);
  }                                                                                                                    // 407
  var el = $(elem);                                                                                                    // 408
  EditableText.editing_key_press.fakeEl.text(el.val());                                                                // 409
  var width = EditableText.editing_key_press.fakeEl.width() + 20;                                                      // 410
  el.width(width);                                                                                                     // 411
  el.css('min-width', width);                                                                                          // 412
}                                                                                                                      // 413
                                                                                                                       // 414
Template.editable_text_widget.events(EditableText._okCancelEvents('.wide-text-edit', EditableText.okCancelEvents));    // 415
Template.editable_text_widget.events({                                                                                 // 416
  'keyup .wide-text-edit' : function (evt) {                                                                           // 417
    if (this.editor) {                                                                                                 // 418
      return;                                                                                                          // 419
    }                                                                                                                  // 420
    if (this.autoResize) {                                                                                             // 421
      EditableText.editing_key_press(evt.target, this.inputClass);                                                     // 422
    }                                                                                                                  // 423
  }                                                                                                                    // 424
});                                                                                                                    // 425
Template.editable_text_widget.events(EditableText._okCancelEvents('.text-area-edit', EditableText.okCancelEvents));    // 426
Template.editable_text_widget.events({                                                                                 // 427
  'mousedown .editable-text, click .editable-text, dblclick .editable-text' : function (evt, tmpl) {                   // 428
    if (this.editor) {                                                                                                 // 429
      return;                                                                                                          // 430
    }                                                                                                                  // 431
    if (this.stopPropagation) {                                                                                        // 432
      evt.stopImmediatePropagation();                                                                                  // 433
      evt.stopPropagation();                                                                                           // 434
    }                                                                                                                  // 435
    EditableText.__blockEditEvent = true;                                                                              // 436
    // This is the click event that opens the field for editing                                                        // 437
    var eventType = this.eventType || ((EditableText.wysiwyg && this.wysiwyg) ? 'mousedown' : 'click');                // 438
    if (eventType !== evt.type) {                                                                                      // 439
      return;                                                                                                          // 440
    }                                                                                                                  // 441
    var textarea = (this.textarea && !this.wysiwyg) || (this.wysiwyg && !EditableText.wysiwyg);                        // 442
    var wysiwyg = EditableText.wysiwyg && this.wysiwyg;                                                                // 443
    var obj = this.context;                                                                                            // 444
    var Collection = Mongo.Collection.get(this.collection);                                                            // 445
    if (this.autoInsert && obj && !obj._id && _.isObject(obj) && EditableText.userCanEdit.call(this, obj, Collection)) { // This is quite involved -- you need an object with all context info, but no _id field for auto-creation to occur
      if (typeof this.value !== 'undefined' && this.value !== obj[this.field]) {                                       // 447
        obj[this.field] = this.value;                                                                                  // 448
      }                                                                                                                // 449
      // Create an object                                                                                              // 450
      EditableText.insert.call(this, Collection, obj);                                                                 // 451
      EditableText.__blockEditEvent = false;                                                                           // 452
      evt.stopImmediatePropagation();                                                                                  // 453
      evt.stopPropagation();                                                                                           // 454
      return;                                                                                                          // 455
    }                                                                                                                  // 456
    if (obj && !tmpl.selected.get()) {                                                                                 // 457
      if (EditableText.userCanEdit.call(this, obj, Collection)) {                                                      // 458
        // document.activeElement.blur(); // Make sure the focusout event fires first when switching editable text objects, so that the first one gets saved properly
        tmpl.selected.set(true);                                                                                       // 460
        Tracker.flush();                                                                                               // 461
        if (!wysiwyg) {                                                                                                // 462
          EditableText._activateInput(tmpl.$((textarea) ? 'textarea' :  'input'), this.dontSelectAll || false); // textarea
          if (this.autoResize && !textarea) {                                                                          // 464
            EditableText.editing_key_press(tmpl.$('.wide-text-edit'), this.inputClass);                                // 465
          }                                                                                                            // 466
        }                                                                                                              // 467
        EditableText._callback.call(this, 'onStartEditing', tmpl.data.context);                                        // 468
      }                                                                                                                // 469
    }                                                                                                                  // 470
    EditableText.__blockEditEvent = false;                                                                             // 471
  }                                                                                                                    // 472
});                                                                                                                    // 473
                                                                                                                       // 474
Template.editable_text_widget.created = function () {                                                                  // 475
  this.selected = new ReactiveVar();                                                                                   // 476
}                                                                                                                      // 477
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/babrahams_editable-text/lib/editable_text_common.js                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if (typeof EditableText === 'undefined') {                                                                             // 1
  EditableText = {};                                                                                                   // 2
}                                                                                                                      // 3
                                                                                                                       // 4
                                                                                                                       // 5
// ******************************************                                                                          // 6
// CONFIG that affects BOTH CLIENT AND SERVER                                                                          // 7
// ******************************************                                                                          // 8
                                                                                                                       // 9
EditableText.userCanEdit = function(doc,Collection) {                                                                  // 10
  // e.g. return doc.user_id = Meteor.userId();                                                                        // 11
  return true;                                                                                                         // 12
}                                                                                                                      // 13
                                                                                                                       // 14
EditableText.useTransactions = (typeof tx !== 'undefined' && _.isObject(tx.Transactions)) ? true : false;              // 15
EditableText.clientControlsTransactions = false;                                                                       // 16
                                                                                                                       // 17
EditableText.maximumImageSize = 0; // Can't put image data in the editor by default                                    // 18
                                                                                                                       // 19
// This is the set of defaults for sanitizeHtml on the server (as set by the library itself)                           // 20
// Required on the client for consistency of filtering on the paste event                                              // 21
if (Meteor.isClient) {                                                                                                 // 22
  sanitizeHtml = {};                                                                                                   // 23
  sanitizeHtml.defaults = {                                                                                            // 24
    allowedTags: [ 'h3', 'h4', 'h5', 'h6', 'blockquote', 'p', 'a', 'ul', 'ol', 'nl', 'li', 'b', 'i', 'strong', 'em', 'strike', 'code', 'hr', 'br', 'div', 'table', 'thead', 'caption', 'tbody', 'tr', 'th', 'td', 'pre' ],
    allowedAttributes: { a: [ 'href', 'name', 'target' ] },                                                            // 26
    selfClosing: [ 'img', 'br', 'hr', 'area', 'base', 'basefont', 'input', 'link', 'meta' ],                           // 27
    allowedSchemes: [ 'http', 'https', 'ftp', 'mailto' ]                                                               // 28
  };                                                                                                                   // 29
}                                                                                                                      // 30
                                                                                                                       // 31
Meteor.startup(function () {                                                                                           // 32
  // The startup block is to allow apps to overwrite the sanitizeHtml defaults                                         // 33
  EditableText.allowedHtml = {                                                                                         // 34
    allowedTags: sanitizeHtml.defaults.allowedTags.concat(['sub', 'sup', 'font', 'u', 's', 'span']),                   // 35
    allowedAttributes: _.extend(sanitizeHtml.defaults.allowedAttributes, {                                             // 36
      font : ['size', 'face', 'color'],                                                                                // 37
      div : ['align', 'style', 'class'],                                                                               // 38
      span: ['style', 'class'],                                                                                        // 39
      table: ['style', 'class'],                                                                                       // 40
      td : ['rowspan', 'colspan', 'style', 'class'],                                                                   // 41
      a: ['href', 'target', 'class'],                                                                                  // 42
      i: ['class']                                                                                                     // 43
    }),                                                                                                                // 44
    allowedSchemes:['http', 'https', 'ftp', 'mailto']                                                                  // 45
  }                                                                                                                    // 46
});;                                                                                                                   // 47
                                                                                                                       // 48
                                                                                                                       // 49
// ******************************************                                                                          // 50
// Functions that are intended for use in app                                                                          // 51
// ******************************************                                                                          // 52
                                                                                                                       // 53
// Function for setting multiple config variable via a hash                                                            // 54
                                                                                                                       // 55
EditableText.config = function(config) {                                                                               // 56
  if (_.isObject(config)) {                                                                                            // 57
     _.each(config,function(val,key) {                                                                                 // 58
       if (_.contains(['userCanEdit','insert','update','remove'],key)) {                                               // 59
         if (_.isFunction(val)) {                                                                                      // 60
           EditableText[key] = val;                                                                                    // 61
         }                                                                                                             // 62
         else {                                                                                                        // 63
           throw new Meteor.Error(key + ' must be a function');                                                        // 64
         }                                                                                                             // 65
       }                                                                                                               // 66
       if (_.contains(['useTransactions','clientControlsTransactions','saveOnFocusout','trustHtml','useMethods'],key)) {
         if (_.isBoolean(val)) {                                                                                       // 68
           EditableText[key] = val;                                                                                    // 69
         }                                                                                                             // 70
         else {                                                                                                        // 71
           throw new Meteor.Error(key + ' must be a boolean');                                                         // 72
         }                                                                                                             // 73
       }                                                                                                               // 74
       if (_.contains(['collection2Options'], key)) {                                                                  // 75
         if (_.isObject(val)) {                                                                                        // 76
            EditableText[key] = val;                                                                                   // 77
         }                                                                                                             // 78
       }                                                                                                               // 79
     });                                                                                                               // 80
  }                                                                                                                    // 81
  else {                                                                                                               // 82
    throw new Meteor.Error('Editable text config object must be a hash of key value pairs. Config not changed.');      // 83
  }                                                                                                                    // 84
}                                                                                                                      // 85
                                                                                                                       // 86
// Function for registering callbacks                                                                                  // 87
                                                                                                                       // 88
EditableText.registerCallbacks = function(obj) {                                                                       // 89
  if (_.isObject(obj)) {                                                                                               // 90
    _.each(obj,function(val,key) {                                                                                     // 91
      if (_.isFunction(val)) {                                                                                         // 92
        EditableText._callbacks[key] = val;                                                                            // 93
      }                                                                                                                // 94
      else {                                                                                                           // 95
        throw new Meteor.Error('Callbacks need to be functions. You passed a ' + typeof(val) + '.');                   // 96
      }                                                                                                                // 97
    });                                                                                                                // 98
  }                                                                                                                    // 99
  else {                                                                                                               // 100
    throw new Meteor.Error('You must pass an object to register callbacks');                                           // 101
  }                                                                                                                    // 102
}                                                                                                                      // 103
                                                                                                                       // 104
                                                                                                                       // 105
// *********************************                                                                                   // 106
// INTERNAL PROPERTIES AND FUNCTIONS                                                                                   // 107
// *********************************                                                                                   // 108
                                                                                                                       // 109
EditableText._callbacks = {};                                                                                          // 110
                                                                                                                       // 111
EditableText._mutatedDocIsObject = function (mutatedDoc) {                                                             // 112
  return _.isObject(mutatedDoc) && !_.isArray(mutatedDoc) && !_.isDate(mutatedDoc) && !_.isFunction(mutatedDoc); // Just want real key-value pair type objects
}                                                                                                                      // 114
                                                                                                                       // 115
EditableText._callback = function (callback, doc, originalValue) {                                                     // 116
  // Note: 'beforeUpdate' and 'beforeInsertMultiple' callbacks are special-cased to use return values of any type, not just objects
  // originalValue is only set on beforeUpdate and beforeInsertMultiple callbacks. It is of the form { value: <actual original value> }
  // otherwise originalValue should be undefined                                                                       // 119
  callback = String(callback);                                                                                         // 120
  var self = this;                                                                                                     // 121
  var callbackRan = false;                                                                                             // 122
  if (self[callback] && _.isString(self[callback])) {                                                                  // 123
    var mutatedDoc = EditableText._executeCallback(self[callback], self, doc, originalValue);                          // 124
    callbackRan = true;                                                                                                // 125
    var mutatedDocIsObject = EditableText._mutatedDocIsObject(mutatedDoc);                                             // 126
    if (!originalValue && !mutatedDocIsObject) {                                                                       // 127
      throw new Meteor.Error('Wrong type returned', 'Your callback function "' + callback + '" returned a ' + typeof mutatedDoc + '. An object was expected.');    
    }                                                                                                                  // 129
    doc = (originalValue) ? mutatedDoc : mutatedDocIsObject && mutatedDoc || doc;                                      // 130
  }                                                                                                                    // 131
  if (originalValue) {                                                                                                 // 132
    // if the callback hasn't run, then the                                                                            // 133
    // doc is still the whole document,                                                                                // 134
    // not the new value for the field                                                                                 // 135
    if (!callbackRan) {                                                                                                // 136
      doc = originalValue.value;                                                                                       // 137
    }                                                                                                                  // 138
    if (callbackRan && mutatedDocIsObject && (_.has(doc, '$set') || _.has(doc, '$addToSet') || _.has(doc, '$push') || _.has(doc, '$unset'))) {
      return {modifier: doc};                                                                                          // 140
    }                                                                                                                  // 141
    else {                                                                                                             // 142
      return {value: doc};                                                                                             // 143
    }                                                                                                                  // 144
  }                                                                                                                    // 145
  return doc;                                                                                                          // 146
}                                                                                                                      // 147
                                                                                                                       // 148
EditableText._executeCallback = function (callbackFunctionName, self, doc, originalValue) { // originalValue.value is the default to return if no updates have been made
  var mutatedDoc = (originalValue && {value: originalValue.value}) || doc;                                             // 150
  var callbackFunction = EditableText._callbacks[callbackFunctionName];                                                // 151
  if (callbackFunction && _.isFunction(callbackFunction)) {                                                            // 152
    var value = (self.type === 'number' && (originalValue && originalValue.value === 0)) ? 0 : (originalValue && originalValue.value || undefined);
    var modifier =  originalValue && originalValue.modifier || undefined;                                              // 154
    callbackMutatedDoc = callbackFunction.call(self, doc, Mongo.Collection.get(self.collection), value, modifier);     // 155
    if (!_.isUndefined(callbackMutatedDoc)) {                                                                          // 156
      mutatedDoc = callbackMutatedDoc;                                                                                 // 157
    }                                                                                                                  // 158
  }                                                                                                                    // 159
  else {                                                                                                               // 160
    throw new Meteor.Error('Callback not a function', 'Could not execute callback. Reason: ' + ((callbackFunction) ? '"' + callbackFunctionName + '" is not a function, it\'s a ' + typeof(callbackFunction) + '.' : 'no callback function called "' + callbackFunctionName + '" has been registered via EditableText.registerCallbacks.'));    
  }                                                                                                                    // 162
  return mutatedDoc;                                                                                                   // 163
}                                                                                                                      // 164
                                                                                                                       // 165
EditableText._drillDown = function (obj, key) {                                                                        // 166
  return Meteor._get.apply(null, [obj].concat(key.split('.')));                                                        // 167
}                                                                                                                      // 168
                                                                                                                       // 169
EditableText._allowedHtml = function () {                                                                              // 170
  var allowed = EditableText.allowedHtml;                                                                              // 171
  if (EditableText.maximumImageSize && _.isNumber(EditableText.maximumImageSize) && allowed) {                         // 172
    allowed.allowedTags.push('img');                                                                                   // 173
    allowed.allowedAttributes.img = ['src'];                                                                           // 174
    allowed.allowedSchemes.push('data');                                                                               // 175
  }                                                                                                                    // 176
  return allowed;                                                                                                      // 177
}                                                                                                                      // 178
                                                                                                                       // 179
EditableText._transactionOptions = function (data) {                                                                   // 180
  return (tx.transactionStarted() && data.useExistingTransaction) ? {useExistingTransaction: true} : undefined;        // 181
}                                                                                                                      // 182
                                                                                                                       // 183
                                                                                                                       // 184
// *************                                                                                                       // 185
// UPDATE METHOD                                                                                                       // 186
// *************                                                                                                       // 187
                                                                                                                       // 188
Meteor.methods({                                                                                                       // 189
  _editableTextWrite : function (action, data, modifier, transaction) {                                                // 190
    check(action, String);                                                                                             // 191
    check(data, Object);                                                                                               // 192
    check(data.collection, String);                                                                                    // 193
    check(data.context, (typeof FS !== "undefined" && FS.File) ? Match.OneOf(Object, FS.File) : Object);               // 194
    check(modifier, (action === 'update') ? Object : null);                                                            // 195
    check(transaction, Boolean);                                                                                       // 196
    check(data.objectTypeText, Match.OneOf(String, undefined));                                                        // 197
    var hasPackageCollection2 = !!Package['aldeed:collection2'];                                                       // 198
    var hasPackageSimpleSchema = !!Package['aldeed:simple-schema'];                                                    // 199
    var Collection = Mongo.Collection.get(data.collection);                                                            // 200
    var c2optionsHashRequired = hasPackageCollection2 && hasPackageSimpleSchema && _.isFunction(Collection.simpleSchema) && Collection._c2;
    if (Collection && EditableText.userCanEdit.call(data, data.context, Collection)) {                                 // 202
      if (Meteor.isServer) {                                                                                           // 203
        if (_.isBoolean(EditableText.useTransactions) && !EditableText.clientControlsTransactions) {                   // 204
          transaction = EditableText.useTransactions;                                                                  // 205
        }                                                                                                              // 206
      }                                                                                                                // 207
      if (typeof tx === 'undefined') {                                                                                 // 208
        transaction = false;                                                                                           // 209
      }                                                                                                                // 210
      var setStatus = function (err, res) {                                                                            // 211
        data.status = {error: err, result: res};                                                                       // 212
      }                                                                                                                // 213
      var options = (transaction) ? {instant: true} : {};                                                              // 214
      if (c2optionsHashRequired) {                                                                                     // 215
        options = _.extend(options, EditableText.collection2options || {});                                            // 216
      }                                                                                                                // 217
      switch (action) {                                                                                                // 218
        case 'insert' :                                                                                                // 219
          if (Meteor.isServer) {                                                                                       // 220
            // run all string fields through sanitizeHtml                                                              // 221
            data.context = EditableText.sanitizeObject(data.context);                                                  // 222
          }                                                                                                            // 223
          if (transaction) {                                                                                           // 224
            if (data.objectTypeText || data.transactionInsertText) {                                                   // 225
              tx.start(data.transactionInsertText || 'add ' + data.objectTypeText, EditableText._transactionOptions(data));
            }                                                                                                          // 227
            data.context = EditableText._callback.call(data, 'beforeInsert', data.context) || data.context;            // 228
            var new_id = tx.insert(Collection, data.context, options, setStatus);                                      // 229
            EditableText._callback.call(data, 'afterInsert', Collection.findOne({_id: new_id}));                       // 230
            if (data.objectTypeText || data.transactionInsertText) {                                                   // 231
              tx.commit();                                                                                             // 232
            }                                                                                                          // 233
          }                                                                                                            // 234
          else {                                                                                                       // 235
            data.context = EditableText._callback.call(data,'beforeInsert',data.context) || data.context;              // 236
            var new_id = (c2optionsHashRequired) ? Collection.insert(data.context, options, setStatus) : Collection.insert(data.context, setStatus);
            EditableText._callback.call(data, 'afterInsert', Collection.findOne({_id: new_id}));                       // 238
          }                                                                                                            // 239
          return new_id;                                                                                               // 240
          break;                                                                                                       // 241
        case 'update' :                                                                                                // 242
          if (Meteor.isServer) {                                                                                       // 243
            var newValue, sanitized = false;                                                                           // 244
            if (modifier["$unset"]) {                                                                                  // 245
              sanitized = true;                                                                                        // 246
            }                                                                                                          // 247
            if (modifier["$set"] && _.isString(modifier["$set"][data.field])) {                                        // 248
            // run through sanitizeHtml                                                                                // 249
              newValue = modifier["$set"][data.field] = EditableText.sanitizeString(modifier["$set"][data.field], data.wysiwyg || !!data.editor);
              sanitized = true;                                                                                        // 251
            }                                                                                                          // 252
            if (modifier["$set"] && _.isArray(modifier["$set"][data.field])) {                                         // 253
              newValue = modifier["$set"][data.field] = _.map(modifier["$set"][data.field], function (str) { return EditableText.sanitizeString(str, data.wysiwyg || !!data.editor); });
              sanitized = true;                                                                                        // 255
            }                                                                                                          // 256
            if (modifier["$set"] && _.isNumber(modifier["$set"][data.field])) {                                        // 257
              newValue = modifier["$set"][data.field];                                                                 // 258
              sanitized = true;                                                                                        // 259
            }                                                                                                          // 260
            if (modifier["$addToSet"] && _.isString(modifier["$addToSet"][data.field])) {                              // 261
              newValue = modifier["$addToSet"][data.field] = EditableText.sanitizeString(modifier["$addToSet"][data.field], data.wysiwyg || !!data.editor);
              sanitized = true;                                                                                        // 263
            }                                                                                                          // 264
            if (modifier["$push"] && _.isString(modifier["$push"][data.field])) {                                      // 265
              newValue = modifier["$push"][data.field] = EditableText.sanitizeString(modifier["$push"][data.field], data.wysiwyg || !!data.editor);
              sanitized = true;                                                                                        // 267
            }                                                                                                          // 268
            if (!sanitized) {                                                                                          // 269
              throw new Meteor.Error('Wrong data type sent for update');                                               // 270
              return;                                                                                                  // 271
            }                                                                                                          // 272
          }                                                                                                            // 273
          else {                                                                                                       // 274
            var newValue;                                                                                              // 275
            if (modifier["$set"]) { // Do we need a special case for data.type === 'number' ?                          // 276
              newValue = modifier["$set"][data.field];                                                                 // 277
            }                                                                                                          // 278
            else if (modifier["$addToSet"]) {                                                                          // 279
              newValue = modifier["$addToSet"][data.field];                                                            // 280
            }                                                                                                          // 281
            else if (modifier["$push"]) {                                                                              // 282
              newValue = modifier["$push"][data.field];                                                                // 283
            }                                                                                                          // 284
            else if (modifier["$unset"]) {                                                                             // 285
              newValue = 1;                                                                                            // 286
            }                                                                                                          // 287
          }                                                                                                            // 288
          data.newValue = newValue;                                                                                    // 289
          data.oldValue = EditableText._drillDown(data.context, data.field);                                           // 290
          var callbackModifier = function (modifier, key, val) {                                                       // 291
            /*if (val === undefined) {                                                                                 // 292
              return modifier;                                                                                         // 293
            }*/                                                                                                        // 294
            var modifierTypes = ["$set", "$addToSet", "$push", "$unset"];                                              // 295
            var modType = _.find(modifierTypes, function (mt) {                                                        // 296
              return _.has(modifier, mt);                                                                              // 297
            });                                                                                                        // 298
            if (modType) {                                                                                             // 299
              modifier[modType][key] = val;                                                                            // 300
            }                                                                                                          // 301
            return modifier;                                                                                           // 302
          }                                                                                                            // 303
          if (transaction) {                                                                                           // 304
            if (data.transactionUpdateText || data.objectTypeText) {                                                   // 305
              tx.start(data.transactionUpdateText || 'update ' + data.objectTypeText, EditableText._transactionOptions(data));
            }                                                                                                          // 307
            var newVal = EditableText._callback.call(data, 'beforeUpdate', data.context, {value: data.newValue, modifier: modifier}); // By setting the fourth parameter, we are expecting a value, not the whole doc, to be returned from the callback
            modifier = callbackModifier(newVal.modifier || modifier, data.field, newVal.value);                        // 309
            tx.update(Collection,data.context._id, modifier, options, setStatus);                                      // 310
            EditableText._callback.call(data, 'afterUpdate', Collection.findOne({_id: data.context._id}));             // 311
            if (data.transactionUpdateText || data.objectTypeText) {                                                   // 312
              tx.commit();                                                                                             // 313
            }                                                                                                          // 314
          }                                                                                                            // 315
          else {                                                                                                       // 316
            var newVal = EditableText._callback.call(data, 'beforeUpdate', data.context, {value: data.newValue, modifier: modifier});
            modifier = callbackModifier(newVal.modifier || modifier, data.field, newVal.value);                        // 318
            if (c2optionsHashRequired) {                                                                               // 319
              Collection.update({_id: data.context._id}, modifier, options, setStatus);                                // 320
            }                                                                                                          // 321
            else {                                                                                                     // 322
              Collection.update({_id: data.context._id}, modifier, setStatus);                                         // 323
            }                                                                                                          // 324
            EditableText._callback.call(data, 'afterUpdate', Collection.findOne({_id: data.context._id}));             // 325
          }                                                                                                            // 326
          break;                                                                                                       // 327
        case 'remove' :                                                                                                // 328
          if (transaction) {                                                                                           // 329
            if (data.transactionRemoveText || data.objectTypeText) {                                                   // 330
              tx.start(data.transactionRemoveText || 'remove ' + data.objectTypeText, EditableText._transactionOptions(data));
            }                                                                                                          // 332
            data.context = EditableText._callback.call(data, 'beforeRemove', data.context) || data.context;            // 333
            tx.remove(Collection, data.context._id, {instant: true}, setStatus);                                       // 334
            EditableText._callback.call(data, 'afterRemove', data.context);                                            // 335
            if (data.transactionRemoveText || data.objectTypeText) {                                                   // 336
              tx.commit();                                                                                             // 337
            }                                                                                                          // 338
          }                                                                                                            // 339
          else {                                                                                                       // 340
            data.context = EditableText._callback.call(data, 'beforeRemove', data.context) || data.context;            // 341
            Collection.remove({_id: data.context._id}, setStatus);                                                     // 342
            EditableText._callback.call(data, 'afterRemove', data.context);                                            // 343
          }                                                                                                            // 344
          break;                                                                                                       // 345
      }                                                                                                                // 346
    }                                                                                                                  // 347
  }                                                                                                                    // 348
});                                                                                                                    // 349
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['babrahams:editable-text'] = {}, {
  EditableText: EditableText,
  sanitizeHtml: sanitizeHtml
});

})();
