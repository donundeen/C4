var require = meteorInstall({"template.C5.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// template.C5.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.body.addContent((function() {                                                                                 // 2
  var view = this;                                                                                                     // 3
  return [ HTML.DIV({                                                                                                  // 4
    class: "main container otherItem"                                                                                  // 5
  }, "\n    ", HTML.DIV({                                                                                              // 6
    class: "header container mainmenu"                                                                                 // 7
  }, "\n      ", HTML.Raw("<!-- logo link -->"), "\n      ", HTML.Raw('<div class="container-item titleBox">\n        <h1><a href="/">C5 (test v2)</a></h1>\n      </div>'), "\n\n      ", HTML.Raw("<!-- page identifier -->"), "\n      ", HTML.DIV({
    class: "container-item page_id_div",                                                                               // 9
    align: "center"                                                                                                    // 10
  }, "\n        ", HTML.H2(Blaze.If(function() {                                                                       // 11
    return Spacebars.call(view.lookup("pageurl"));                                                                     // 12
  }, function() {                                                                                                      // 13
    return [ HTML.SPAN({                                                                                               // 14
      "data-tooltip-direction": "s",                                                                                   // 15
      "data-tooltip": function() {                                                                                     // 16
        return [ "this is the <b>Page Type</b>: <i>", Spacebars.mustache(view.lookup("pagetype")), "</i>" ];           // 17
      }                                                                                                                // 18
    }, Blaze.View("lookup:pagetype", function() {                                                                      // 19
      return Spacebars.mustache(view.lookup("pagetype"));                                                              // 20
    })), "/", HTML.SPAN({                                                                                              // 21
      "data-tooltip-direction": "s",                                                                                   // 22
      "data-tooltip": function() {                                                                                     // 23
        return [ "this is the <b>Page ID</b>: <i>", Spacebars.mustache(view.lookup("pageid")), "</i>" ];               // 24
      }                                                                                                                // 25
    }, Blaze.View("lookup:pageid", function() {                                                                        // 26
      return Spacebars.mustache(view.lookup("pageid"));                                                                // 27
    })) ];                                                                                                             // 28
  }, function() {                                                                                                      // 29
    return "Home";                                                                                                     // 30
  })), "\n      "), "       \n\n\n    ", HTML.Raw("<!-- logged-in user options -->"), "\n    ", Blaze.If(function() {  // 31
    return Spacebars.call(view.lookup("currentUser"));                                                                 // 32
  }, function() {                                                                                                      // 33
    return [ "\n      ", HTML.DIV({                                                                                    // 34
      class: "container-item tooltip-right widgetlibrary",                                                             // 35
      align: "center",                                                                                                 // 36
      valign: "center",                                                                                                // 37
      "data-tooltip": "Add Widgets from Your Library",                                                                 // 38
      "data-tooltip-direction": "s"                                                                                    // 39
    }, "\n          ", HTML.BUTTON({                                                                                   // 40
      class: "clickable btn btn-default dropdown-toggle addFromWidgetLibrary",                                         // 41
      type: "button",                                                                                                  // 42
      id: "dropdownMenu1",                                                                                             // 43
      "data-toggle": "dropdown",                                                                                       // 44
      "aria-haspopup": "true",                                                                                         // 45
      "aria-expanded": "true",                                                                                         // 46
      style: "vertical-align: middle;"                                                                                 // 47
    }, "\n                    ", HTML.LI({                                                                             // 48
      class: "zmdi zmdi-collection-text zmdi-hc-3x"                                                                    // 49
    }), HTML.BR(), HTML.LI({                                                                                           // 50
      class: "zmdi zmdi-caret-down zmdi-hc-3x"                                                                         // 51
    }), "\n          "), "\n          ", HTML.UL({                                                                     // 52
      class: "dropdown-menu addFromWidgetLibraryUL",                                                                   // 53
      "aria-labelledby": "dropdownMenu1"                                                                               // 54
    }, "\n            ", Blaze.Each(function() {                                                                       // 55
      return Spacebars.call(view.lookup("widgetTemplates"));                                                           // 56
    }, function() {                                                                                                    // 57
      return [ "\n              ", HTML.LI(HTML.A({                                                                    // 58
        href: "#",                                                                                                     // 59
        class: function() {                                                                                            // 60
          return [ "copy_from_template ", Spacebars.mustache(view.lookup("url")) ];                                    // 61
        },                                                                                                             // 62
        target: function() {                                                                                           // 63
          return Spacebars.mustache(view.lookup("url"));                                                               // 64
        },                                                                                                             // 65
        type: "data",                                                                                                  // 66
        onclick: "return false;"                                                                                       // 67
      }, HTML.I({                                                                                                      // 68
        class: "widgetIdText"                                                                                          // 69
      }, Blaze.View("lookup:url", function() {                                                                         // 70
        return Spacebars.mustache(view.lookup("url"));                                                                 // 71
      }), ":"), " ", Blaze.View("lookup:name", function() {                                                            // 72
        return Spacebars.mustache(view.lookup("name"));                                                                // 73
      }))), "\n            " ];                                                                                        // 74
    }), "\n            ", HTML.LI("---Your Library---"), "\n            ", Blaze.Each(function() {                     // 75
      return Spacebars.call(view.lookup("libraryWidgets"));                                                            // 76
    }, function() {                                                                                                    // 77
      return [ "\n              ", HTML.LI(HTML.A({                                                                    // 78
        href: "#",                                                                                                     // 79
        class: function() {                                                                                            // 80
          return [ "copy_from_template ", Spacebars.mustache(view.lookup("url")) ];                                    // 81
        },                                                                                                             // 82
        target: function() {                                                                                           // 83
          return Spacebars.mustache(view.lookup("url"));                                                               // 84
        },                                                                                                             // 85
        type: "data",                                                                                                  // 86
        onclick: "return false;"                                                                                       // 87
      }, HTML.I({                                                                                                      // 88
        class: "widgetIdText"                                                                                          // 89
      }, Blaze.View("lookup:url", function() {                                                                         // 90
        return Spacebars.mustache(view.lookup("url"));                                                                 // 91
      }), ":"), " ", Blaze.View("lookup:name", function() {                                                            // 92
        return Spacebars.mustache(view.lookup("name"));                                                                // 93
      }))), "\n            " ];                                                                                        // 94
    }), "\n\n          "), "\n      "), "\n      ", HTML.DIV({                                                         // 95
      class: "container-item widgetmenu unlockall",                                                                    // 96
      "data-tooltip": "lock all widgets",                                                                              // 97
      "data-tooltip-direction": "s",                                                                                   // 98
      title: "click to lock all widgets",                                                                              // 99
      style: "display:none"                                                                                            // 100
    }, "\n        ", HTML.LI({                                                                                         // 101
      class: " clickable headericon zmdi zmdi-lock-open zmdi-hc-3x edit",                                              // 102
      id: function() {                                                                                                 // 103
        return [ "unlock_", Spacebars.mustache(view.lookup("url")) ];                                                  // 104
      },                                                                                                               // 105
      "data-pack": "default",                                                                                          // 106
      "data-tags": "",                                                                                                 // 107
      style: "display: inline-block;"                                                                                  // 108
    }), "\n      "), "\n      ", HTML.DIV({                                                                            // 109
      class: "container-item widgetmenu lockall",                                                                      // 110
      "data-tooltip": "unlock all widgets",                                                                            // 111
      "data-tooltip-direction": "s",                                                                                   // 112
      title: "click to unlock all widgets"                                                                             // 113
    }, "\n        ", HTML.LI({                                                                                         // 114
      class: " clickable headericon zmdi zmdi-lock zmdi-hc-3x display",                                                // 115
      id: function() {                                                                                                 // 116
        return [ "lock_", Spacebars.mustache(view.lookup("url")) ];                                                    // 117
      },                                                                                                               // 118
      "data-pack": "default",                                                                                          // 119
      "data-tags": "",                                                                                                 // 120
      style: "display: inline-block;"                                                                                  // 121
    }), "\n      "), "\n    " ];                                                                                       // 122
  }), "\n    ", HTML.Raw("<!-- end logged-in user options -->"), "\n\n    ", HTML.Raw("<!-- login features -->"), "\n      ", HTML.DIV({
    class: "container-item widgetmenu login",                                                                          // 124
    "data-tooltip": "Login for user things",                                                                           // 125
    "data-tooltip-direction": "s",                                                                                     // 126
    title: "Login for User Things.."                                                                                   // 127
  }, "\n        ", HTML.H4(Spacebars.include(view.lookupTemplate("loginButtons"))), "\n        ", HTML.SPAN({          // 128
    class: "link_to_library"                                                                                           // 129
  }, " ", HTML.A({                                                                                                     // 130
    href: function() {                                                                                                 // 131
      return [ "/user_libs/", Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "username")) ];             // 132
    }                                                                                                                  // 133
  }, HTML.Raw('<i class="zmdi zmdi-collection-text"> Your Library</i>'))), HTML.Raw("<br>"), "\n          ", Spacebars.With(function() {
    return Spacebars.call(view.lookup("userXtras"));                                                                   // 135
  }, function() {                                                                                                      // 136
    return [ "\n            ", Blaze.If(function() {                                                                   // 137
      return Spacebars.call(view.lookup("admin"));                                                                     // 138
    }, function() {                                                                                                    // 139
      return [ "\n              ", Blaze.If(function() {                                                               // 140
        return Spacebars.call(view.lookup("godmode"));                                                                 // 141
      }, function() {                                                                                                  // 142
        return [ "\n                ", HTML.INPUT({                                                                    // 143
          class: "godmode_check",                                                                                      // 144
          type: "checkbox",                                                                                            // 145
          checked: "true"                                                                                              // 146
        }), " god mode\n              " ];                                                                             // 147
      }, function() {                                                                                                  // 148
        return [ "\n              ", HTML.INPUT({                                                                      // 149
          class: "godmode_check",                                                                                      // 150
          type: "checkbox"                                                                                             // 151
        }), " god mode\n              " ];                                                                             // 152
      }), "\n            " ];                                                                                          // 153
    }), "\n          " ];                                                                                              // 154
  }), "\n      "), "\n      ", HTML.Raw("<!-- end login features -->"), "\n\n      ", HTML.DIV({                       // 155
    class: "container-item widgetmenu comments pagecomments",                                                          // 156
    "data-tooltip": "comments",                                                                                        // 157
    "data-tooltip-direction": "s"                                                                                      // 158
  }, "\n       ", HTML.Raw('<i data-toggle="modal" data-target="#comment_modal" class="zmdi zmdi-comment zmdi-hc-3x opencomments"></i>'), HTML.Raw("<br>"), HTML.SPAN({
    class: "numComments"                                                                                               // 160
  }, Blaze.View("lookup:numComments", function() {                                                                     // 161
    return Spacebars.mustache(view.lookup("numComments"), view.lookup("pagetype_neverblank"));                         // 162
  }), "/", Blaze.View("lookup:numComments", function() {                                                               // 163
    return Spacebars.mustache(view.lookup("numComments"), view.lookup("pageurl_neverblank"));                          // 164
  })), "\n      "), "\n\n      ", HTML.Raw('<div class="container-item widgetmenu help" data-tooltip="help" data-tooltip-direction="s">\n        <li class=" clickable headericon zmdi zmdi-help zmdi-hc-3x  display" id="help" data-pack="default" data-tags="" style="display: inline-block;" data-toggle="modal" data-target="#help_modal"></li>\n      </div>'), "\n\n\n    "), "\n    ", HTML.Raw("<br>"), "\n    ", Spacebars.include(view.lookupTemplate("help")), "\n    ", Spacebars.include(view.lookupTemplate("giphy_modal")), "\n    ", Spacebars.include(view.lookupTemplate("webservice_insert_modal")), "\n\n    ", HTML.DIV({
    class: "modal fade",                                                                                               // 166
    id: "comment_modal"                                                                                                // 167
  }, "\n        ", HTML.DIV({                                                                                          // 168
    class: "modal-dialog"                                                                                              // 169
  }, "\n            ", HTML.DIV({                                                                                      // 170
    class: "modal-content"                                                                                             // 171
  }, "\n                ", HTML.Raw('<div class="modal-header" style="text-align: center">Discuss!</div>'), "\n                ", HTML.DIV({
    class: "modal-body",                                                                                               // 173
    style: ""                                                                                                          // 174
  }, "\n                  ", HTML.DIV({                                                                                // 175
    class: "panel-group",                                                                                              // 176
    id: "accordion"                                                                                                    // 177
  }, "\n                    ", HTML.DIV({                                                                              // 178
    class: "panel panel-default"                                                                                       // 179
  }, "\n                      ", HTML.DIV({                                                                            // 180
    class: "panel-heading"                                                                                             // 181
  }, "\n                        ", HTML.H4({                                                                           // 182
    class: "panel-title"                                                                                               // 183
  }, "\n                          ", HTML.A({                                                                          // 184
    "data-toggle": "collapse",                                                                                         // 185
    "data-parent": "#accordion",                                                                                       // 186
    href: "#collapse1"                                                                                                 // 187
  }, "\n                          Comments for ", HTML.Raw("<b>All</b>"), " pages of type: ", Blaze.View("lookup:pagetype", function() {
    return Spacebars.mustache(view.lookup("pagetype"));                                                                // 189
  })), " ", Blaze.View("lookup:numComments", function() {                                                              // 190
    return Spacebars.mustache(view.lookup("numComments"), view.lookup("pagetype_neverblank"));                         // 191
  }), "\n                        "), "\n                      "), "\n                      ", HTML.DIV({               // 192
    id: "collapse1",                                                                                                   // 193
    class: "panel-collapse collapse in"                                                                                // 194
  }, "\n                        ", HTML.DIV({                                                                          // 195
    class: "panel-body"                                                                                                // 196
  }, "                 \n                          ", HTML.DIV({                                                       // 197
    class: "comment-section"                                                                                           // 198
  }, "\n                            ", Blaze._TemplateWith(function() {                                                // 199
    return {                                                                                                           // 200
      id: Spacebars.call(view.lookup("pagetype_neverblank"))                                                           // 201
    };                                                                                                                 // 202
  }, function() {                                                                                                      // 203
    return Spacebars.include(view.lookupTemplate("commentsBox"));                                                      // 204
  }), "\n                          "), "\n                        "), "\n                      "), "\n                    "), "\n                    ", HTML.DIV({
    class: "panel panel-default"                                                                                       // 206
  }, "\n                      ", HTML.DIV({                                                                            // 207
    class: "panel-heading"                                                                                             // 208
  }, "\n                        ", HTML.H4({                                                                           // 209
    class: "panel-title"                                                                                               // 210
  }, "\n                          ", HTML.A({                                                                          // 211
    "data-toggle": "collapse",                                                                                         // 212
    "data-parent": "#accordion",                                                                                       // 213
    href: "#collapse2"                                                                                                 // 214
  }, "\n                          Comments for this ", HTML.Raw("<b>SPECIFIC</b>"), " page: ", Blaze.View("lookup:pageurl", function() {
    return Spacebars.mustache(view.lookup("pageurl"));                                                                 // 216
  }), " ", Blaze.View("lookup:numComments", function() {                                                               // 217
    return Spacebars.mustache(view.lookup("numComments"), view.lookup("pageurl_neverblank"));                          // 218
  })), "\n                        "), "\n                      "), "\n                      ", HTML.DIV({              // 219
    id: "collapse2",                                                                                                   // 220
    class: "panel-collapse collapse"                                                                                   // 221
  }, "\n                        ", HTML.DIV({                                                                          // 222
    class: "panel-body"                                                                                                // 223
  }, "\n                          ", HTML.DIV({                                                                        // 224
    class: "comment-section"                                                                                           // 225
  }, "\n                            ", Blaze._TemplateWith(function() {                                                // 226
    return {                                                                                                           // 227
      id: Spacebars.call(view.lookup("pageurl_neverblank"))                                                            // 228
    };                                                                                                                 // 229
  }, function() {                                                                                                      // 230
    return Spacebars.include(view.lookupTemplate("commentsBox"));                                                      // 231
  }), "\n                          "), "\n                        "), "\n                      "), "\n                    "), "\n                  "), "\n                "), "\n                ", HTML.Raw('<div class="modal-footer">\n                  <center>\n                    <img src="giphy_proxy/discussion">\n                  </center>\n                </div>'), "                \n            "), "\n\n        "), "\n    "), "     \n\n      ", Spacebars.include(view.lookupTemplate("gridwidgets")), "\n\n\n\n      ", Spacebars.include(view.lookupTemplate("allWidgetsLoaded")), "\n\n\n\n\n  "), "\n    ", Spacebars.include(view.lookupTemplate("tooltips")) ];
}));                                                                                                                   // 233
Meteor.startup(Template.body.renderToDocument);                                                                        // 234
                                                                                                                       // 235
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"template.allWidgetsLoaded.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// template.allWidgetsLoaded.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("allWidgetsLoaded");                                                                              // 2
Template["allWidgetsLoaded"] = new Template("Template.allWidgetsLoaded", (function() {                                 // 3
  var view = this;                                                                                                     // 4
  return "";                                                                                                           // 5
}));                                                                                                                   // 6
                                                                                                                       // 7
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"template.functions.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// template.functions.js                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("functions");                                                                                     // 2
Template["functions"] = new Template("Template.functions", (function() {                                               // 3
  var view = this;                                                                                                     // 4
  return [ HTML.Raw('<p class="functionsIntro">In your jsbin edit window, in the upper left, is a button that says "Add Library"<br>\n    This provides access to a LOT of javascript libraries you can ue in your widget. <br>\n    Selecting one adds it to your html &lt;head&gt; tag. <br>\n    Most of these libraries are popular third-party packages, standard with JSBin. Explore them at your leisure.<br><br>\nSome of them have been created or added by the C5 team, to make your C5 coding experience more awesome. <br>\nThe useful functions from those libraries are described here.<br>\n<br>\n    <b>Note: when you add libraries, make sure that jQuery comes BEFORE the other libraries, as some Libraries require jQuery and don\'t work if they don\'t see it. You might have to move the code around after it\'s been imported.</b>\n</p>\n\n\n\n<p class="functionDef">\n<span class="functionname">requireWidgetData({requiresList}, callback)</span>\n<br>\n<span class="functionargs"><b>Parameters:</b>\n    <span class="functionarg">requiresList : [\n    Array of request objects (a few different types):\n    widget data request:\n    {\n        from : String: 3-letter unique widgetId\n        type : \'data\' or \'html\' returns JSON or HTML respectively\n    }\n    webservice data request:\n    {\n        id : String: unique id \n            (you make it up, needs to be unique to this call to requireWidgetData), \n            used to index the returned data \n            into the \'data\' array in the callback\n        type : "webservice",\n        authentication_token : String: apikey, if you need it,\n            we\'ll try to sort out the authentication protocols\n        url : url for the webservice call. \n    }\n]</span> \n\n   <span class="functionarg">callback :  function(data){\n    data includes all the results from the calls listed in requiresList, indexed by name.\n}</span> \n</span>\n<span class="functionreturns"><b>Returns:</b> null, use callback</span>\n<br>\n<span class="functioninlibrary"><b>In Library:</b> /c5libs/locallib.js</span><br>\n<span class="functionDescription">This function is the magic sauce of C5. It\'s how you call widget data from one widget to another. It\'s also how you call webservice data from any API. <br>\n    A good way to start playing with it is to look at the search examples, and the widgets on individual art object pages. \n    <br>You can also use the "Get Data" menu item to automagically add the code snippets to your javascript.\n    <br><b>Note:</b> Currently we only support GET requests. \n</span>\n</p>\n\n\n\n\n'), HTML.P({
    class: "functionDef"                                                                                               // 6
  }, "\n", HTML.Raw('<span class="functionname">pageType()</span>'), "\n", HTML.Raw("<br>"), "\n", HTML.Raw('<span class="functionreturns"><b>Returns:</b> String</span>'), "\n", HTML.Raw("<br>"), "\n", HTML.Raw('<span class="functioninlibrary"><b>In Library:</b>  /c5libs/locallib.js</span>'), HTML.Raw("<br>"), "\n", HTML.SPAN({
    class: "functionDescription"                                                                                       // 8
  }, "Returns the ", HTML.Raw("<b>Page Type</b>"), " for this page.", HTML.Raw("<br>"), '\nReturns empty string if this page has no type (like the home page for example)\nOn this page, the page type is "', Blaze.View("lookup:pagetype", function() {
    return Spacebars.mustache(view.lookup("pagetype"));                                                                // 10
  }), '"\n'), "\n"), "\n\n", HTML.P({                                                                                  // 11
    class: "functionDef"                                                                                               // 12
  }, "\n", HTML.Raw('<span class="functionname">pageId()</span>'), "\n", HTML.Raw("<br>"), "\n", HTML.Raw('<span class="functionreturns"><b>Returns:</b> String</span>'), "\n", HTML.Raw("<br>"), "\n", HTML.Raw('<span class="functioninlibrary"><b>In Library:</b>  /c5libs/locallib.js</span>'), HTML.Raw("<br>"), "\n", HTML.SPAN({
    class: "functionDescription"                                                                                       // 14
  }, "Returns the ", HTML.Raw("<b>Page ID</b>"), " for this page.", HTML.Raw("<br>"), '\nReturns empty string if this page has no ID (like the home page for example)\nOn this page, the page type is "', Blaze.View("lookup:pageid", function() {
    return Spacebars.mustache(view.lookup("pageid"));                                                                  // 16
  }), '"\n'), "\n"), "\n\n", HTML.P({                                                                                  // 17
    class: "functionDef"                                                                                               // 18
  }, "\n", HTML.Raw('<span class="functionname">userName()</span>'), "\n", HTML.Raw("<br>"), "\n", HTML.Raw('<span class="functionreturns"><b>Returns:</b> String</span>'), HTML.Raw("<br>"), "\n", HTML.Raw('<span class="functioninlibrary"><b>In Library:</b>  /c5libs/locallib.js</span>'), HTML.Raw("<br>"), "\n", HTML.SPAN({
    class: "functionDescription"                                                                                       // 20
  }, "Returns the ", HTML.Raw("<b>User Name</b>"), " of the logged-in user.", HTML.Raw("<br>"), "\nReturns empty string if there is no logged in user\nFor example, right now the userId is ", Blaze.View("lookup:currentUser.username", function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "username"));                                  // 22
  }), "\n"), "\n"), HTML.Raw('\n\n<p class="functionDef">\n<span class="functionname">userId()</span>\n<br>\n<span class="functionreturns"><b>Returns:</b> String</span><br>\n<span class="functioninlibrary"><b>In Library:</b>  /c5libs/locallib.js</span><br>\n\n<span class="functionDescription">Returns the <b>User Id</b> of the logged-in user.<br>\nReturns empty string if there is no logged in user\n</span>\n</p>\n\n<p class="functionDef">\n<span class="functionname">widgetId()</span>\n<br>\n<span class="functionreturns"><b>Returns:</b> String</span>\n<br>\n<span class="functioninlibrary"><b>In Library:</b> /c5libs/locallib.js</span><br>\n<span class="functionDescription">Returns the <b>3-Letter Unique ID</b> of the widget.\n</span>\n</p>\n\n<p class="functionDef">\n<span class="functionname">c5_done()</span>\n<br>\n<span class="functionreturns"><b>Returns:</b> Null</span>\n<br>\n<span class="functioninlibrary"><b>In Library:</b> /c5libs/locallib.js</span><br>\n<span class="functionDescription">Calling this function announces to the system that your code is \'done\'<br>\n    This is necessary for your widget output to be included in other widgets, used as an API, etc.<br>\n    Sometimes this can go at the bottom of your javascript code, but often it needs to go inside a callback.\n</span>\n</p>\n\n<p class="functionDef">\n<span class="functionname">saveC5data({options}, data, callback)</span>\n<br>\n<span class="functionargs"><b>Parameters:</b>\n    <span class="functionarg">options : {\n    thisUserOnly : true/false (default false) \n                    save data specifically for this logged-in user\n    thisPageIdOnly : true/false (default true) \n                    save data specifically for this widget on this page. \n                    Set to false to save data \n                    for this widget on all pages \n                    of the same type\n}</span> \n    <span class="functionarg">data : {\n    the data to save, in JSON format\n}</span> \n   <span class="functionarg">callback : function(result){\n    result is the result from MongoDB call, or an error message if it couldn\'t reach Mongo.\n}</span> \n\n</span>\n<span class="functionreturns"><b>Returns:</b> Null (use callback instead)</span>\n<br>\n<span class="functioninlibrary"><b>In Library:</b> /c5libs/locallib.js</span><br>\n<span class="functionDescription">\n    If your widget needs some data persistence (say you are saving comments, annotations, or other user entry stuff), then this function (along with getC5Data() ) is your jam.\n</span>\n</p>\n\n<p class="functionDef">\n<span class="functionname">getC5data({options}, callback)</span>\n<br>\n<span class="functionargs"><b>Parameters:</b>\n    <span class="functionarg">options : {\n    thisUserOnly : true/false (default false)\n                    get data specifically for this logged-in user\n    thisPageIdOnly : true/false (default true)\n                    get data specifically for this widget on this page. \n                    Set to false to get data \n                    for this widget on all pages \n                    of the same type\n}</span> \n\n   <span class="functionarg">callback: function(result)\n{\n    result is the result from MongoDB call, which includes the data.\n}</span> \n</span>\n<span class="functionreturns"><b>Returns:</b> Null (use callback instead)</span>\n<br>\n<span class="functioninlibrary"><b>In Library:</b> /c5libs/locallib.js</span><br>\n<span class="functionDescription">\n    If your widget needs some data persistence (say you are saving comments, annotations, or other user entry stuff), then this function (along with saveC5Data() ) is your jam.\n</span>\n</p>\n\n\n<p class="functionDef">\n<span class="functionname">elasticsearchInsert({data}, callback)</span>\n<br>\n<span class="functionargs"><b>Parameters:</b>\n    <span class="functionarg">data : {\n    Data to insert, in JSON format.\n    Will have pageid, pagetype, pageurl, widgetid properties automatically added.\n}</span> \n\n   <span class="functionarg">callback : function(results, error, status){\n    results: result from insert to elasticsearch:\n    error: true if there was an error\n    status: status message\n}</span> \n</span>\n<span class="functionreturns"><b>Returns:</b> null (use callback)</span>\n<br>\n<span class="functioninlibrary"><b>In Library:</b> /c5libs/locallib.js</span><br>\n<span class="functionDescription">C5 uses elasticSearch to empower robust search possibilities. Use this function to add any data to the elasticSearch index. With elasticSearchRequest() you have the ability to query this data any way you want.\n</span>\n</p>\n\n<p class="functionDef">\n<span class="functionname">elasticSearchRequest({query}, callback)</span>\n<br>\n<span class="functionargs"><b>Parameters:</b>\n    <span class="functionarg">query : {\n        any valid elasticSearch query.\n}</span> \n\n   <span class="functionarg">callback : function(results, error, status){\n    results: result from insert to elasticsearch:\n    error: true if there was an error\n    status: status message\n}</span> \n</span>\n<span class="functionreturns"><b>Returns: null (use callback)</b></span>\n<br>\n<span class="functioninlibrary"><b>In Library:</b> /c5libs/locallib.js</span><br>\n<span class="functionDescription">This function lets you send any valid query request to elasticSearch, and pass the results directly from Elastic back to the callback function.<br>\n    OK, elasticSearch can do a LOT, and it\'s therefore a bit complicated. Check out <a href="https://www.elastic.co/guide/en/elasticsearch/reference/current/search.html">This Documentation</a> to learn more. Also check out the ElasticSearch example widgets in the library.\n</span>\n</p>\n\n\n\n<p class="functionDef">\n<span class="functionname">$(jQuerySelector).JSONView(data, {options})</span>\n<br>\n<span class="functionargs"><b>Parameters:</b>\n    <span class="functionarg">jQuerySelector: a jQuery Selector for an element in your html panel</span> \n\n   <span class="functionarg">data : {\n    JSON data\n}</span> \n   <span class="functionarg">options : {\n    collapsed : true/false : Collapse all nodes when rendering first time, default is false.\n    nl2br : true/false : Convert new line to &lt;br&gt; in String, default is false.\n    recursive_collapser  : true/false : Collapse nodes recursively, default is false.\n    escape : true/false : Escape HTML in key, default is true.\n    strict : true/false : In strict mode, invalid JSON value type will throw a error, default is false.    \n}</span> \n</span>\n<span class="functionreturns"><b>Returns: null</b></span>\n<br>\n<span class="functioninlibrary"><b>In Library:</b> /c5libs/jquery.jsonview.min.js</span><br>\n<span class="functionDescription">This is a super handy function from JSONView. It creates a nice collapsable interactive view of the JSON data you pass to it. Comes in very handy as you\'re developing and debugging a widget that accesses other widgets, or webservices.<br>\n    Code by Wei Zhu, on GitHub here: <a href="https://github.com/yesmeck/jquery-jsonview">https://github.com/yesmeck/jquery-jsonview</a>\n</span>\n</p>') ];
}));                                                                                                                   // 24
                                                                                                                       // 25
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"template.help.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// template.help.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("help");                                                                                          // 2
Template["help"] = new Template("Template.help", (function() {                                                         // 3
  var view = this;                                                                                                     // 4
  return HTML.DIV({                                                                                                    // 5
    class: "modal fade",                                                                                               // 6
    id: "help_modal"                                                                                                   // 7
  }, "\n  ", HTML.DIV({                                                                                                // 8
    class: "modal-dialog"                                                                                              // 9
  }, "\n    ", HTML.DIV({                                                                                              // 10
    class: "modal-content"                                                                                             // 11
  }, "\n      ", HTML.Raw('<div class="modal-header">\n        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>\n        <h4 class="modal-title">Help</h4>\n      </div>'), "\n      ", HTML.DIV({
    class: "modal-body"                                                                                                // 13
  }, "\n        ", HTML.DIV({                                                                                          // 14
    class: "panel-group",                                                                                              // 15
    id: "accordion",                                                                                                   // 16
    role: "tablist",                                                                                                   // 17
    "aria-multiselectable": "true"                                                                                     // 18
  }, "\n          ", HTML.Raw('<div class="panel panel-default">\n            <div class="panel-heading" role="tab" id="headingOne">\n              <h4 class="panel-title">\n                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">\n        Welcome!        </a>\n              </h4>\n            </div>\n            <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">\n              <div class="panel-body">\n                Welcome to C5, the Collaborative Creative Commons Cultural Coding Clubhouse!\n              </div>\n            </div>\n          </div>'), "\n          ", HTML.DIV({
    class: "panel panel-default"                                                                                       // 20
  }, "\n            ", HTML.Raw('<div class="panel-heading" role="tab" id="headingTour">\n              <h4 class="panel-title">\n                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTour" aria-expanded="false" aria-controls="collapseTour">\n                  Try Some Tours of C5\'s Features\n                </a>\n              </h4>\n            </div>'), "\n            ", HTML.DIV({
    id: "collapseTour",                                                                                                // 22
    class: "panel-collapse collapse",                                                                                  // 23
    role: "tabpanel",                                                                                                  // 24
    "aria-labelledby": "headingTour"                                                                                   // 25
  }, "\n              ", HTML.DIV({                                                                                    // 26
    class: "panel-body",                                                                                               // 27
    "data-dismiss": "modal"                                                                                            // 28
  }, "\n                ", HTML.UL("\n                  ", HTML.Raw('<li class="clickForIntroTour clickable">Take an Introductory Tour of C5</li>'), "\n                  \n                  ", HTML.LI({
    class: "clickForUserFeaturesTour clickable",                                                                       // 30
    style: function() {                                                                                                // 31
      return Blaze.If(function() {                                                                                     // 32
        return Spacebars.call(view.lookup("currentUser"));                                                             // 33
      }, function() {                                                                                                  // 34
        return null;                                                                                                   // 35
      }, function() {                                                                                                  // 36
        return "display: none;";                                                                                       // 37
      });                                                                                                              // 38
    }                                                                                                                  // 39
  }, "I've logged in, show me what I can do."), "\n                  ", HTML.LI({                                      // 40
    class: "clickForWidgetEditingTour clickable",                                                                      // 41
    style: function() {                                                                                                // 42
      return Blaze.If(function() {                                                                                     // 43
        return Spacebars.call(view.lookup("currentUser"));                                                             // 44
      }, function() {                                                                                                  // 45
        return null;                                                                                                   // 46
      }, function() {                                                                                                  // 47
        return "display: none;";                                                                                       // 48
      });                                                                                                              // 49
    }                                                                                                                  // 50
  }, "Create your first widget!"), "\n                  ", Blaze.If(function() {                                       // 51
    return Spacebars.call(view.lookup("currentUser"));                                                                 // 52
  }, function() {                                                                                                      // 53
    return "\n                  ";                                                                                     // 54
  }, function() {                                                                                                      // 55
    return [ "\n                  ", HTML.LI(HTML.I("Log in to access more in-depth tutorials")), "\n                  " ];
  }), "\n                "), "\n              "), "\n            "), "\n          "), "\n\n          ", HTML.DIV({     // 57
    class: "panel panel-default"                                                                                       // 58
  }, "\n            ", HTML.Raw('<div class="panel-heading" role="tab" id="headingTwo">\n              <h4 class="panel-title">\n                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">\n                  Glossary\n                </a>\n              </h4>\n            </div>'), "\n            ", HTML.DIV({
    id: "collapseTwo",                                                                                                 // 60
    class: "panel-collapse collapse",                                                                                  // 61
    role: "tabpanel",                                                                                                  // 62
    "aria-labelledby": "headingTwo"                                                                                    // 63
  }, "\n              ", HTML.DIV({                                                                                    // 64
    class: "panel-body"                                                                                                // 65
  }, "\n                ", HTML.Raw("<b>Page ID:</b>"), " the id of the page (in this case, ", HTML.B(Blaze.View("lookup:pageid", function() {
    return Spacebars.mustache(view.lookup("pageid"));                                                                  // 67
  })), ")", HTML.Raw("<br>"), "\n                ", HTML.Raw("<b>Page Type:</b>"), " the type of the page (in this case, ", HTML.B(Blaze.View("lookup:pagetype", function() {
    return Spacebars.mustache(view.lookup("pagetype"));                                                                // 69
  })), ")", HTML.Raw("<br>"), "\n                ", HTML.Raw("<b>Page URL:</b>"), " the full path of the page (in this case, ", HTML.B(Blaze.View("lookup:pageurl", function() {
    return Spacebars.mustache(view.lookup("pageurl"));                                                                 // 71
  })), ")", HTML.Raw("<br>"), "\n                ", HTML.Raw("<b>Widget Url:</b>"), " An auto-generated three-letter abbrevation for the widget. Used in your javascript to reference other widgets.", HTML.Raw("<br>"), "\n              "), "\n            "), "\n          "), "\n          ", HTML.Raw('<div class="panel panel-default">\n            <div class="panel-heading" role="tab" id="headingThree">\n              <h4 class="panel-title">\n                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">\n                  Things you can do\n                </a>\n              </h4>\n            </div>\n            <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">\n              <div class="panel-body">\n                <ul>\n                    <li>Make Widgets!</li>\n                    <li>Copy them!</li>\n                    <li>More Things!</li>\n                </ul>\n              </div>\n            </div>\n          </div>'), "\n          ", HTML.DIV({
    class: "panel panel-default"                                                                                       // 73
  }, "\n            ", HTML.Raw('<div class="panel-heading" role="tab" id="headingThree">\n              <h4 class="panel-title">\n                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFunctions" aria-expanded="false" aria-controls="collapseFunctions">\nSpecial C5 Functions\n                </a>\n              </h4>\n            </div>'), "\n            ", HTML.DIV({
    id: "collapseFunctions",                                                                                           // 75
    class: "panel-collapse collapse",                                                                                  // 76
    role: "tabpanel",                                                                                                  // 77
    "aria-labelledby": "headingThree"                                                                                  // 78
  }, "\n              ", HTML.DIV({                                                                                    // 79
    class: "panel-body"                                                                                                // 80
  }, "\n", Spacebars.include(view.lookupTemplate("functions")), "\n              "), "\n            "), "\n          "), "\n\n          ", HTML.Raw('<div class="panel panel-default">\n            <div class="panel-heading" role="tab" id="headingFour">\n              <h4 class="panel-title">\n                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">\nBugs? Feature Requests?                </a>\n              </h4>\n            </div>\n            <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">\n              <div class="panel-body">\nPlease post them to our <a href="http://github.com/donundeen/C5">GitHub Page</a>\n              </div>\n            </div>\n          </div>'), "          \n\n          ", HTML.Raw('<div class="panel panel-default">\n            <div class="panel-heading" role="tab" id="headingFour">\n              <h4 class="panel-title">\n                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">\n                  About Us\n                </a>\n              </h4>\n            </div>\n            <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">\n              <div class="panel-body">\n                Who we are.\n              </div>\n            </div>\n          </div>'), "\n          ", HTML.Raw('<div class="panel panel-default">\n            <div class="panel-heading" role="tab" id="headingFive">\n              <h4 class="panel-title">\n                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">\n                    What\'s with all the GIFs?\n                </a>\n              </h4>\n            </div>\n            <div id="collapseFive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFive">\n              <div class="panel-body">\n                I thought it would be cute to include random animated GIFs (Pronounced "JIFTz") all over the place. Basically it\'s a gif pulled from Giphy\'s "Random GIF" search feature, using a term somewhat related to whatever\'s going on. So, if sometimes they seem a bit "inappropriate," please blame the internet, not me.\n                <br>\n                <br>\n                Click on the image and it will go away.\n              </div>\n            </div>\n          </div>'), "\n\n          ", HTML.Raw('<div class="help_gif_div" style="text-align: center">\n            <br>\n            <img class="help_gif giphy" src="/giphy_proxy/help" width="200">\n          </div>'), "  \n\n        "), "\n\n\n      "), "\n      ", HTML.Raw('<div class="modal-footer">\n        <a href="#" data-dismiss="modal" class="btn">Close</a>\n      </div>'), "\n    "), "\n  "), "\n");
}));                                                                                                                   // 82
                                                                                                                       // 83
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"template.modals.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// template.modals.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("giphy_modal");                                                                                   // 2
Template["giphy_modal"] = new Template("Template.giphy_modal", (function() {                                           // 3
  var view = this;                                                                                                     // 4
  return HTML.Raw('<div class="modal fade" id="giphy_modal">\n        <div class="modal-dialog modal-sm">\n            <div class="modal-content">\n                <div class="modal-header giphy_modal_header" style="text-align: center">\n                </div>\n                <div class="modal-body giphy_modal_image_div" style="text-align: center;">\n                </div>\n            </div>\n            <!--\n            <div class="modal-footer">\n                <a href="#" data-dismiss="modal" class="btn">Close</a>\n            </div>\n        -->\n        </div>\n    </div>');
}));                                                                                                                   // 6
                                                                                                                       // 7
Template.__checkName("webservice_insert_modal");                                                                       // 8
Template["webservice_insert_modal"] = new Template("Template.webservice_insert_modal", (function() {                   // 9
  var view = this;                                                                                                     // 10
  return HTML.DIV({                                                                                                    // 11
    class: "modal fade",                                                                                               // 12
    id: "webservice_insert_modal"                                                                                      // 13
  }, "\n        ", HTML.DIV({                                                                                          // 14
    class: "modal-dialog modal-sm"                                                                                     // 15
  }, "\n            ", HTML.DIV({                                                                                      // 16
    class: "modal-content"                                                                                             // 17
  }, "\n                ", HTML.Raw('<div class="modal-header webservice_insert_modal_header" style="text-align: center">\n                    Insert Webservice Call\n                </div>'), "\n                ", HTML.DIV({
    class: "modal-body form-group",                                                                                    // 19
    style: ""                                                                                                          // 20
  }, "\n                    ", HTML.Raw("<!-- text input field here -->"), "\n                    ", HTML.Raw('<label for="webservice_insert_name">Script Name (something short)</label>'), "\n                    ", HTML.Raw('<input type="text" id="webservice_insert_name">'), "\n                    ", HTML.Raw("<br>"), "\n                    ", HTML.Raw('<label for="webservice_insert_return_type">Return Type</label>'), "\n                    ", HTML.Raw('<input type="radio" name="webservice_insert_return_type" value="json">'), "JSON\n                    ", HTML.Raw('<input type="radio" name="webservice_insert_return_type" value="html">'), "HTML\n                    ", HTML.Raw("<br>"), "\n                    ", HTML.Raw('<label for="webservice_insert_auth_token">Authentication Token</label>'), "\n                    ", HTML.Raw('<input type="text" id="webservice_insert_auth_token">'), "\n                    ", HTML.Raw("<br>"), "\n                    ", HTML.Raw('<label for="webservice_insert_url">Webservice URL:</label>'), "\n                    ", HTML.TEXTAREA({
    class: "form-control",                                                                                             // 22
    rows: "4",                                                                                                         // 23
    id: "webservice_insert_url"                                                                                        // 24
  }), HTML.Raw("<br>"), "\n                    ", HTML.I("use ||PAGETYPE|| and ||PAGEID|| template vars in the URL. In this case, ||PAGETYPE|| value is '", Blaze.View("lookup:pagetype", function() {
    return Spacebars.mustache(view.lookup("pagetype"));                                                                // 26
  }), "'' and ||PAGEID|| value is '", Blaze.View("lookup:pageid", function() {                                         // 27
    return Spacebars.mustache(view.lookup("pageid"));                                                                  // 28
  }), "', but this will change when the template is used on other pages."), "\n                "), "\n            \n                ", HTML.Raw('<div class="modal-footer">\n                    <a href="#" data-dismiss="modal" id="webservice_insert_modal_submit" class="btn">Insert</a>\n                </div>'), "\n            "), "\n        "), "\n    ");
}));                                                                                                                   // 30
                                                                                                                       // 31
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"template.widget.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// template.widget.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("widget");                                                                                        // 2
Template["widget"] = new Template("Template.widget", (function() {                                                     // 3
  var view = this;                                                                                                     // 4
  return HTML.DIV({                                                                                                    // 5
    class: "grid-stack-item",                                                                                          // 6
    "data-widget-id": function() {                                                                                     // 7
      return Spacebars.mustache(view.lookup("url"));                                                                   // 8
    },                                                                                                                 // 9
    "data-panel-id": function() {                                                                                      // 10
      return Spacebars.mustache(view.lookup("url"));                                                                   // 11
    },                                                                                                                 // 12
    "data-gs-auto-position": "true",                                                                                   // 13
    "data-gs-width": function() {                                                                                      // 14
      return Spacebars.mustache(view.lookup("width_in_cells"));                                                        // 15
    },                                                                                                                 // 16
    "data-gs-height": function() {                                                                                     // 17
      return Spacebars.mustache(view.lookup("height_in_cells"));                                                       // 18
    },                                                                                                                 // 19
    "data-gs-min-width": function() {                                                                                  // 20
      return Spacebars.mustache(view.lookup("width_in_cells"));                                                        // 21
    },                                                                                                                 // 22
    "data-gs-min-height": function() {                                                                                 // 23
      return Spacebars.mustache(view.lookup("height_in_cells"));                                                       // 24
    }                                                                                                                  // 25
  }, "\n  ", HTML.DIV({                                                                                                // 26
    class: "grid-stack-item-content"                                                                                   // 27
  }, "\n\n", HTML.DIV({                                                                                                // 28
    class: function() {                                                                                                // 29
      return [ "widgetContainer container-item visibility_", Spacebars.mustache(view.lookup("visibility")) ];          // 30
    },                                                                                                                 // 31
    style: function() {                                                                                                // 32
      return Spacebars.mustache(view.lookup("usableWidgetStyle"));                                                     // 33
    },                                                                                                                 // 34
    id: function() {                                                                                                   // 35
      return [ "widgetContainer_", Spacebars.mustache(view.lookup("url")) ];                                           // 36
    },                                                                                                                 // 37
    "data-userid": function() {                                                                                        // 38
      return [ "user_", Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "_id")) ];                        // 39
    },                                                                                                                 // 40
    "data-username": function() {                                                                                      // 41
      return [ "user_", Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "username")) ];                   // 42
    },                                                                                                                 // 43
    "data-url": function() {                                                                                           // 44
      return Spacebars.mustache(view.lookup("url"));                                                                   // 45
    }                                                                                                                  // 46
  }, "\n\n    ", HTML.Raw("<!-- widget header, the menu -->"), "\n    ", HTML.Raw("<!-- display-mode header -->"), "\n    ", HTML.DIV({
    class: "widgetMouseOverTarget displaymodeonly"                                                                     // 48
  }, "\n      ", HTML.Raw("&nbsp;"), HTML.Raw("&nbsp;"), " ", HTML.SPAN({                                              // 49
    class: "displayModeHeader widgetname-display-mode"                                                                 // 50
  }, HTML.B(Blaze.View("lookup:name", function() {                                                                     // 51
    return Spacebars.mustache(view.lookup("name"));                                                                    // 52
  })), "  (", Blaze.View("lookup:url", function() {                                                                    // 53
    return Spacebars.mustache(view.lookup("url"));                                                                     // 54
  }), ") [", Blaze.View("lookup:sort_order", function() {                                                              // 55
    return Spacebars.mustache(view.lookup("sort_order"));                                                              // 56
  }), "] "), "\n        ", HTML.Raw("&nbsp;"), HTML.I({                                                                // 57
    "data-toggle": "modal",                                                                                            // 58
    "data-target": function() {                                                                                        // 59
      return [ "#comment_modal_", Spacebars.mustache(view.lookup("url")) ];                                            // 60
    },                                                                                                                 // 61
    "data-tooltip": "Comment on this widget",                                                                          // 62
    class: "zmdi zmdi-comment opencomments widgetcomments"                                                             // 63
  }, Blaze.View("lookup:numComments", function() {                                                                     // 64
    return Spacebars.mustache(view.lookup("numComments"), view.lookup("pageTypeAndUrl"));                              // 65
  }), "/", Blaze.View("lookup:numComments", function() {                                                               // 66
    return Spacebars.mustache(view.lookup("numComments"), view.lookup("pageUrlAndUrl"));                               // 67
  })), "\n        ", HTML.Raw("&nbsp;"), HTML.Raw('<i data-tooltip="view widget info" class="zmdi zmdi-info openinfo widgetinfo"></i>'), "\n        ", Blaze.If(function() {
    return Spacebars.call(view.lookup("currentUser"));                                                                 // 69
  }, function() {                                                                                                      // 70
    return [ "\n        ", HTML.CharRef({                                                                              // 71
      html: "&nbsp;",                                                                                                  // 72
      str: " "                                                                                                         // 73
    }), HTML.I({                                                                                                       // 74
      "data-tooltip": "copy widget on this page",                                                                      // 75
      class: "zmdi zmdi-copy copy"                                                                                     // 76
    }), "\n        ", HTML.CharRef({                                                                                   // 77
      html: "&nbsp;",                                                                                                  // 78
      str: " "                                                                                                         // 79
    }), HTML.I({                                                                                                       // 80
      "data-tooltip": "copy widget to your library",                                                                   // 81
      class: "zmdi zmdi-collection-plus save_to_library"                                                               // 82
    }), "\n        " ];                                                                                                // 83
  }), "\n      ", Blaze.If(function() {                                                                                // 84
    return Spacebars.call(view.lookup("isMyWidget"));                                                                  // 85
  }, function() {                                                                                                      // 86
    return [ "\n        ", HTML.CharRef({                                                                              // 87
      html: "&nbsp;",                                                                                                  // 88
      str: " "                                                                                                         // 89
    }), HTML.I({                                                                                                       // 90
      "data-tooltip": "unlock for editing",                                                                            // 91
      class: "zmdi zmdi-lock lock widgetUnlock"                                                                        // 92
    }), "\n      " ];                                                                                                  // 93
  }), "\n    "), "\n    \n    ", HTML.DIV({                                                                            // 94
    class: "widgetDisplayHeader container-item displaymodeonly"                                                        // 95
  }, "\n      ", HTML.DIV({                                                                                            // 96
    class: "widgetName"                                                                                                // 97
  }, "\n        ", HTML.H3(Blaze.View("lookup:name", function() {                                                      // 98
    return Spacebars.mustache(view.lookup("name"));                                                                    // 99
  }), " (", Blaze.View("lookup:url", function() {                                                                      // 100
    return Spacebars.mustache(view.lookup("url"));                                                                     // 101
  }), ")"), "\n      "), "\n      ", HTML.DIV({                                                                        // 102
    class: "widgetCreator"                                                                                             // 103
  }, "\n          ", HTML.Raw("<b>Created By:</b>"), " ", Blaze.View("lookup:createdBy.username", function() {         // 104
    return Spacebars.mustache(Spacebars.dot(view.lookup("createdBy"), "username"));                                    // 105
  }), " (", Blaze.View("lookup:visibility", function() {                                                               // 106
    return Spacebars.mustache(view.lookup("visibility"));                                                              // 107
  }), ")\n      "), "\n      ", HTML.DIV({                                                                             // 108
    class: "widgetDescription"                                                                                         // 109
  }, "\n      ", HTML.I(Blaze.View("lookup:description", function() {                                                  // 110
    return Spacebars.mustache(view.lookup("description"));                                                             // 111
  })), "\n      "), "\n      ", Blaze.If(function() {                                                                  // 112
    return Spacebars.call(view.lookup("isMyWidget"));                                                                  // 113
  }, function() {                                                                                                      // 114
    return [ "\n      ", HTML.DIV({                                                                                    // 115
      class: "widgetmenu lock clickable",                                                                              // 116
      "data-tooltip": "click to unlock widget",                                                                        // 117
      title: "click to unlock widget"                                                                                  // 118
    }, "\n        ", HTML.I({                                                                                          // 119
      class: "zmdi zmdi-lock zmdi-hc-lg"                                                                               // 120
    }, "Unlock for Editing"), "\n      "), "\n      " ];                                                               // 121
  }), "  \n      ", Blaze.If(function() {                                                                              // 122
    return Spacebars.call(view.lookup("currentUser"));                                                                 // 123
  }, function() {                                                                                                      // 124
    return [ "\n      ", HTML.DIV({                                                                                    // 125
      class: "widgetmenu copy clickable",                                                                              // 126
      "data-tooltip": "Copy widget onto this page",                                                                    // 127
      title: "click to copy widget"                                                                                    // 128
    }, "\n        ", HTML.I({                                                                                          // 129
      class: "zmdi zmdi-copy zmdi-hc-lg"                                                                               // 130
    }, " Copy Widget On This Page"), "\n      "), "      \n      ", HTML.DIV({                                         // 131
      class: "widgetmenu save_to_library clickable",                                                                   // 132
      "data-tooltip": "Copy to My (your) Library",                                                                     // 133
      title: "Add to My Library"                                                                                       // 134
    }, "\n        ", HTML.I({                                                                                          // 135
      class: "zmdi zmdi-collection-plus zmdi-hc-lg"                                                                    // 136
    }, " Add to My Library"), "\n      "), " \n      " ];                                                              // 137
  }), "\n      ", HTML.DIV("\n          ", HTML.Raw("<b>JSON Output:</b>"), HTML.A({                                   // 138
    href: function() {                                                                                                 // 139
      return [ "/headless/", Spacebars.mustache(view.lookup("url")), "/", Spacebars.mustache(view.lookup("pagetype")), "/", Spacebars.mustache(view.lookup("pageid")), ".json" ];
    },                                                                                                                 // 141
    target: "_blank"                                                                                                   // 142
  }, "/headless/", Blaze.View("lookup:url", function() {                                                               // 143
    return Spacebars.mustache(view.lookup("url"));                                                                     // 144
  }), "/", Blaze.View("lookup:pagetype", function() {                                                                  // 145
    return Spacebars.mustache(view.lookup("pagetype"));                                                                // 146
  }), "/", Blaze.View("lookup:pageid", function() {                                                                    // 147
    return Spacebars.mustache(view.lookup("pageid"));                                                                  // 148
  }), ".json"), "\n          ", HTML.Raw("<br>"), "\n          ", HTML.Raw("<b>HTML Output:</b>"), HTML.A({            // 149
    href: function() {                                                                                                 // 150
      return [ "/headless/", Spacebars.mustache(view.lookup("url")), "/", Spacebars.mustache(view.lookup("pagetype")), "/", Spacebars.mustache(view.lookup("pageid")), ".html" ];
    },                                                                                                                 // 152
    target: "_blank"                                                                                                   // 153
  }, "/headless/", Blaze.View("lookup:url", function() {                                                               // 154
    return Spacebars.mustache(view.lookup("url"));                                                                     // 155
  }), "/", Blaze.View("lookup:pagetype", function() {                                                                  // 156
    return Spacebars.mustache(view.lookup("pagetype"));                                                                // 157
  }), "/", Blaze.View("lookup:pageid", function() {                                                                    // 158
    return Spacebars.mustache(view.lookup("pageid"));                                                                  // 159
  }), ".html"), "\n          ", HTML.Raw("<br>"), "\n\n      "), "\n    "), "\n\n\n\n    ", HTML.DIV({                 // 160
    class: "modal fade",                                                                                               // 161
    id: function() {                                                                                                   // 162
      return [ "comment_modal_", Spacebars.mustache(view.lookup("url")) ];                                             // 163
    }                                                                                                                  // 164
  }, "\n      ", HTML.DIV({                                                                                            // 165
    class: "modal-dialog"                                                                                              // 166
  }, "\n        ", HTML.DIV({                                                                                          // 167
    class: "modal-content"                                                                                             // 168
  }, "\n          ", HTML.Raw('<div class="modal-header" style="text-align: center">Discuss!</div>'), "\n          ", HTML.DIV({
    class: "modal-body",                                                                                               // 170
    style: ""                                                                                                          // 171
  }, "\n            ", HTML.DIV({                                                                                      // 172
    class: "panel-group",                                                                                              // 173
    id: function() {                                                                                                   // 174
      return [ "accordion_", Spacebars.mustache(view.lookup("url")) ];                                                 // 175
    }                                                                                                                  // 176
  }, "\n              ", HTML.DIV({                                                                                    // 177
    class: "panel panel-default"                                                                                       // 178
  }, "\n                ", HTML.DIV({                                                                                  // 179
    class: "panel-heading"                                                                                             // 180
  }, "\n                  ", HTML.H4({                                                                                 // 181
    class: "panel-title"                                                                                               // 182
  }, "\n                    ", HTML.A({                                                                                // 183
    "data-toggle": "collapse",                                                                                         // 184
    "data-parent": function() {                                                                                        // 185
      return [ "#accordion_", Spacebars.mustache(view.lookup("url")) ];                                                // 186
    },                                                                                                                 // 187
    href: function() {                                                                                                 // 188
      return [ "#collapse1_", Spacebars.mustache(view.lookup("url")) ];                                                // 189
    }                                                                                                                  // 190
  }, '\n                    Comments for this widget: "', Blaze.View("lookup:name", function() {                       // 191
    return Spacebars.mustache(view.lookup("name"));                                                                    // 192
  }), " (", Blaze.View("lookup:url", function() {                                                                      // 193
    return Spacebars.mustache(view.lookup("url"));                                                                     // 194
  }), ')" on ', HTML.Raw("<b>All</b>"), " pages of type: ", Blaze.View("lookup:pagetype", function() {                 // 195
    return Spacebars.mustache(view.lookup("pagetype"));                                                                // 196
  }), " : ", Blaze.View("lookup:pageTypeAndUrl", function() {                                                          // 197
    return Spacebars.mustache(view.lookup("pageTypeAndUrl"));                                                          // 198
  }), " (", Blaze.View("lookup:numComments", function() {                                                              // 199
    return Spacebars.mustache(view.lookup("numComments"), view.lookup("pageTypeAndUrl"));                              // 200
  }), ")"), "\n                  "), "\n                "), "\n                ", HTML.DIV({                           // 201
    id: function() {                                                                                                   // 202
      return [ "collapse1_", Spacebars.mustache(view.lookup("url")) ];                                                 // 203
    },                                                                                                                 // 204
    class: "panel-collapse collapse in"                                                                                // 205
  }, "\n                  ", HTML.DIV({                                                                                // 206
    class: "panel-body"                                                                                                // 207
  }, "                 \n                    ", HTML.DIV({                                                             // 208
    class: "comment-section"                                                                                           // 209
  }, "\n                      ", Blaze._TemplateWith(function() {                                                      // 210
    return {                                                                                                           // 211
      id: Spacebars.call(view.lookup("pageTypeAndUrl"))                                                                // 212
    };                                                                                                                 // 213
  }, function() {                                                                                                      // 214
    return Spacebars.include(view.lookupTemplate("commentsBox"));                                                      // 215
  }), "\n                    "), "\n                  "), "\n                "), "\n              "), "\n              ", HTML.DIV({
    class: "panel panel-default"                                                                                       // 217
  }, "\n                ", HTML.DIV({                                                                                  // 218
    class: "panel-heading"                                                                                             // 219
  }, "\n                  ", HTML.H4({                                                                                 // 220
    class: "panel-title"                                                                                               // 221
  }, "\n                    ", HTML.A({                                                                                // 222
    "data-toggle": "collapse",                                                                                         // 223
    "data-parent": function() {                                                                                        // 224
      return [ "#accordion_", Spacebars.mustache(view.lookup("url")) ];                                                // 225
    },                                                                                                                 // 226
    href: function() {                                                                                                 // 227
      return [ "#collapse2_", Spacebars.mustache(view.lookup("url")) ];                                                // 228
    }                                                                                                                  // 229
  }, '\n                    Comments for this widget: "', Blaze.View("lookup:name", function() {                       // 230
    return Spacebars.mustache(view.lookup("name"));                                                                    // 231
  }), " (", Blaze.View("lookup:url", function() {                                                                      // 232
    return Spacebars.mustache(view.lookup("url"));                                                                     // 233
  }), ')" on this ', HTML.Raw("<b>SPECIFIC</b>"), " page: ", Blaze.View("lookup:pageurl", function() {                 // 234
    return Spacebars.mustache(view.lookup("pageurl"));                                                                 // 235
  }), " : ", Blaze.View("lookup:pageUrlAndUrl", function() {                                                           // 236
    return Spacebars.mustache(view.lookup("pageUrlAndUrl"));                                                           // 237
  }), "  (", Blaze.View("lookup:numComments", function() {                                                             // 238
    return Spacebars.mustache(view.lookup("numComments"), view.lookup("pageUrlAndUrl"));                               // 239
  }), ")"), "\n                  "), "\n                "), "\n                ", HTML.DIV({                           // 240
    id: function() {                                                                                                   // 241
      return [ "collapse2_", Spacebars.mustache(view.lookup("url")) ];                                                 // 242
    },                                                                                                                 // 243
    class: "panel-collapse collapse"                                                                                   // 244
  }, "\n                  ", HTML.DIV({                                                                                // 245
    class: "panel-body"                                                                                                // 246
  }, "\n                    ", HTML.DIV({                                                                              // 247
    class: "comment-section"                                                                                           // 248
  }, "\n                      ", Blaze._TemplateWith(function() {                                                      // 249
    return {                                                                                                           // 250
      id: Spacebars.call(view.lookup("pageUrlAndUrl"))                                                                 // 251
    };                                                                                                                 // 252
  }, function() {                                                                                                      // 253
    return Spacebars.include(view.lookupTemplate("commentsBox"));                                                      // 254
  }), "\n                    "), "\n                  "), "\n                "), "\n              "), "\n            "), "\n          "), "\n          ", HTML.Raw('<div class="modal-footer">\n            <center>\n              <img src="giphy_proxy/discussion">\n            </center>\n          </div>'), "\n        "), "\n        \n      "), "\n    "), "      \n\n\n    ", HTML.Raw("<!-- end display-mode header -->"), "\n\n    ", HTML.Raw("<!-- edit-mode header-->"), "\n    ", HTML.DIV({
    class: "widgetEditHeader editmodeonly",                                                                            // 256
    style: "display: none;"                                                                                            // 257
  }, "\n", HTML.NAV({                                                                                                  // 258
    class: "navbar navbar-default"                                                                                     // 259
  }, "\n  ", HTML.DIV({                                                                                                // 260
    class: "container-fluid"                                                                                           // 261
  }, "\n    ", HTML.DIV({                                                                                              // 262
    class: "navbar-header widget-name-editmode"                                                                        // 263
  }, HTML.A({                                                                                                          // 264
    class: "navbar-brand",                                                                                             // 265
    href: "#"                                                                                                          // 266
  }, Blaze.View("lookup:name", function() {                                                                            // 267
    return Spacebars.mustache(view.lookup("name"));                                                                    // 268
  }), " (", Blaze.View("lookup:url", function() {                                                                      // 269
    return Spacebars.mustache(view.lookup("url"));                                                                     // 270
  }), ")")), "\n    ", HTML.DIV({                                                                                      // 271
    class: "collapse navbar-collapse",                                                                                 // 272
    id: function() {                                                                                                   // 273
      return [ "bs-example-navbar-collapse-", Spacebars.mustache(view.lookup("_id")) ];                                // 274
    }                                                                                                                  // 275
  }, "    \n      ", HTML.UL({                                                                                         // 276
    class: "nav navbar-nav"                                                                                            // 277
  }, "\n        ", HTML.LI({                                                                                           // 278
    class: "widgetinfo-editmode"                                                                                       // 279
  }, HTML.A({                                                                                                          // 280
    href: "#myModal",                                                                                                  // 281
    "data-toggle": "modal",                                                                                            // 282
    "data-target": function() {                                                                                        // 283
      return [ "#info_modal_", Spacebars.mustache(view.lookup("_id")) ];                                               // 284
    }                                                                                                                  // 285
  }, "Info")), "\n        ", HTML.LI({                                                                                 // 286
    class: "dropdown widgetactions"                                                                                    // 287
  }, "\n          ", HTML.Raw('<a href="#" data-toggle="dropdown" class="dropdown-toggle">Actions <b class="caret"></b></a>'), "\n          ", HTML.UL({
    class: "dropdown-menu"                                                                                             // 289
  }, "\n            ", HTML.Raw('<li class="dropdown_widgeticon save ion-ios-upload clickable " data-pack="default" data-tags="" alt="save widget" style="display: inline-block;"> Save</li>'), "\n            ", HTML.Raw('<li class="divider"></li>'), "\n\n            ", HTML.LI({
    class: function() {                                                                                                // 291
      return [ "clickable dropdown_widgeticon save_to_library ", Blaze.If(function() {                                 // 292
        return Spacebars.call(view.lookup("isTemplate"));                                                              // 293
      }, function() {                                                                                                  // 294
        return "\nisWidget";                                                                                           // 295
      }) ];                                                                                                            // 296
    },                                                                                                                 // 297
    "data-pack": "default",                                                                                            // 298
    "data-tags": "",                                                                                                   // 299
    alt: "save as a reusable template in your library",                                                                // 300
    style: "display: inline-block;",                                                                                   // 301
    title: "save this widget as a reusable template in your library.",                                                 // 302
    "data-tooltip": "save this widget as a reusable template in your library."                                         // 303
  }, HTML.Raw('<i class="zmdi zmdi-collection-plus"> Add to My Library</i>')), "\n            ", HTML.Raw('<li class="divider"></li>'), "\n            ", HTML.LI({
    class: "clickable dropdown_widgeticon ion-ios-trash-outline delete",                                               // 305
    id: function() {                                                                                                   // 306
      return [ "delete_", Spacebars.mustache(view.lookup("url")) ];                                                    // 307
    },                                                                                                                 // 308
    "data-pack": "ios",                                                                                                // 309
    "data-tags": "delete, remove, dispose, waste, basket, dump, kill",                                                 // 310
    style: "display: inline-block;"                                                                                    // 311
  }, " Delete Widget"), "\n          "), "\n        "), "\n\n        ", HTML.LI({                                      // 312
    class: "dropdown widgetpulldata"                                                                                   // 313
  }, "\n          ", HTML.Raw('<a href="#" data-toggle="dropdown" class="dropdown-toggle">Get Data<b class="caret"></b></a>'), "\n          ", HTML.UL({
    class: "dropdown-menu",                                                                                            // 315
    "aria-labelledby": function() {                                                                                    // 316
      return [ "dropdownMenu1_", Spacebars.mustache(view.lookup("url")) ];                                             // 317
    }                                                                                                                  // 318
  }, "\n            ", HTML.Raw("<li>Pull Data from Widget:</li>"), "\n            ", Blaze.Each(function() {          // 319
    return Spacebars.call(view.lookup("otherwidgets"));                                                                // 320
  }, function() {                                                                                                      // 321
    return [ "\n              ", HTML.LI(HTML.A({                                                                      // 322
      href: "#",                                                                                                       // 323
      class: function() {                                                                                              // 324
        return [ "add_code ", Spacebars.mustache(view.lookup("url")), " clickable" ];                                  // 325
      },                                                                                                               // 326
      "data-pullfrom": function() {                                                                                    // 327
        return Spacebars.mustache(view.lookup("url"));                                                                 // 328
      },                                                                                                               // 329
      "data-pulltype": "data"                                                                                          // 330
    }, HTML.I({                                                                                                        // 331
      class: "widgetIDText",                                                                                           // 332
      "data-pullfrom": function() {                                                                                    // 333
        return Spacebars.mustache(view.lookup("url"));                                                                 // 334
      },                                                                                                               // 335
      "data-pulltype": "data"                                                                                          // 336
    }, Blaze.View("lookup:url", function() {                                                                           // 337
      return Spacebars.mustache(view.lookup("url"));                                                                   // 338
    })), ": ", Blaze.View("lookup:name", function() {                                                                  // 339
      return Spacebars.mustache(view.lookup("name"));                                                                  // 340
    }), " (data)")), "\n              ", HTML.LI(HTML.A({                                                              // 341
      href: "#",                                                                                                       // 342
      class: function() {                                                                                              // 343
        return [ "add_code ", Spacebars.mustache(view.lookup("url")), " clickable" ];                                  // 344
      },                                                                                                               // 345
      "data-pullfrom": function() {                                                                                    // 346
        return Spacebars.mustache(view.lookup("url"));                                                                 // 347
      },                                                                                                               // 348
      "data-pulltype": "html"                                                                                          // 349
    }, HTML.I({                                                                                                        // 350
      class: "widgetIDText",                                                                                           // 351
      "data-pullfrom": function() {                                                                                    // 352
        return Spacebars.mustache(view.lookup("url"));                                                                 // 353
      },                                                                                                               // 354
      "data-pulltype": "html"                                                                                          // 355
    }, Blaze.View("lookup:url", function() {                                                                           // 356
      return Spacebars.mustache(view.lookup("url"));                                                                   // 357
    })), ": ", Blaze.View("lookup:name", function() {                                                                  // 358
      return Spacebars.mustache(view.lookup("name"));                                                                  // 359
    }), " (html)")), "\n", HTML.LI({                                                                                   // 360
      role: "separator",                                                                                               // 361
      class: "divider"                                                                                                 // 362
    }), "              \n            " ];                                                                              // 363
  }), "\n            ", HTML.Raw('<li><a href="#" class="call_webservice_url clickable">Call Webservice Url...</a></li>'), "\n          "), "\n        "), "\n        ", HTML.LI({
    class: "widgetstylesettings"                                                                                       // 365
  }, HTML.A({                                                                                                          // 366
    href: "#myConfigModal",                                                                                            // 367
    "data-toggle": "modal",                                                                                            // 368
    "data-target": function() {                                                                                        // 369
      return [ "#config_modal_", Spacebars.mustache(view.lookup("_id")) ];                                             // 370
    }                                                                                                                  // 371
  }, "Style Settings")), "\n        ", HTML.LI({                                                                       // 372
    class: "widgetcachesettings"                                                                                       // 373
  }, HTML.A({                                                                                                          // 374
    href: "#myCacheModal",                                                                                             // 375
    "data-toggle": "modal",                                                                                            // 376
    "data-target": function() {                                                                                        // 377
      return [ "#cache_modal_", Spacebars.mustache(view.lookup("_id")) ];                                              // 378
    }                                                                                                                  // 379
  }, "Caching")), "\n      "), " \n\n      ", HTML.UL({                                                                // 380
    class: "nav navbar-nav navbar-right"                                                                               // 381
  }, "\n        ", HTML.LI(HTML.A({                                                                                    // 382
    href: "#"                                                                                                          // 383
  }, "\n          ", Blaze.If(function() {                                                                             // 384
    return Spacebars.call(view.lookup("isPublic"));                                                                    // 385
  }, function() {                                                                                                      // 386
    return [ "\n          ", HTML.DIV({                                                                                // 387
      class: "widgetmenu setprivate editmodeonly",                                                                     // 388
      title: "click to make widget private",                                                                           // 389
      "data-tooltip": "click to make widget private"                                                                   // 390
    }, "\n            ", Blaze.View("lookup:visibility", function() {                                                  // 391
      return Spacebars.mustache(view.lookup("visibility"));                                                            // 392
    }), " ", HTML.I({                                                                                                  // 393
      class: "zmdi zmdi-globe-lock"                                                                                    // 394
    }), "\n          "), "\n          " ];                                                                             // 395
  }, function() {                                                                                                      // 396
    return [ "\n          ", HTML.DIV({                                                                                // 397
      class: "widgetmenu setpublic editmodeonly",                                                                      // 398
      title: "click to make widget public",                                                                            // 399
      "data-tooltip": "click to make widget public"                                                                    // 400
    }, "\n            ", Blaze.View("lookup:visibility", function() {                                                  // 401
      return Spacebars.mustache(view.lookup("visibility"));                                                            // 402
    }), " ", HTML.I({                                                                                                  // 403
      class: "zmdi zmdi-globe"                                                                                         // 404
    }), "\n          "), "\n          " ];                                                                             // 405
  }), "\n        ")), "\n        ", HTML.LI(HTML.A({                                                                   // 406
    href: "#"                                                                                                          // 407
  }, "\n          ", HTML.DIV({                                                                                        // 408
    class: "widgetmenu unlock widgetLock editmodeonly",                                                                // 409
    title: "click to lock widget",                                                                                     // 410
    "data-tooltip": "click to lock widget"                                                                             // 411
  }, "\n            ", HTML.LI({                                                                                       // 412
    class: "widgeticon zmdi zmdi-lock edit",                                                                           // 413
    id: function() {                                                                                                   // 414
      return [ "unlock_", Spacebars.mustache(view.lookup("url")) ];                                                    // 415
    },                                                                                                                 // 416
    "data-pack": "default",                                                                                            // 417
    "data-tags": "",                                                                                                   // 418
    style: "display: inline-block;"                                                                                    // 419
  }), "\n          "), "\n        ")), "\n      "), "\n\n    "), "\n  "), "\n"), "\n\n", HTML.DIV({                    // 420
    class: "modal fade",                                                                                               // 421
    id: function() {                                                                                                   // 422
      return [ "info_modal_", Spacebars.mustache(view.lookup("_id")) ];                                                // 423
    }                                                                                                                  // 424
  }, "\n  ", HTML.DIV({                                                                                                // 425
    class: "modal-dialog"                                                                                              // 426
  }, "\n      ", HTML.DIV({                                                                                            // 427
    class: "modal-content"                                                                                             // 428
  }, "\n        ", HTML.Raw('<div class="modal-header">\n          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>\n          <h4 class="modal-title">Widget Info</h4>\n        </div>'), "\n        ", HTML.DIV({
    class: "modal-body"                                                                                                // 430
  }, "\n          ", HTML.Raw("<b>Widget Name:</b>"), Blaze.If(function() {                                            // 431
    return Spacebars.call(view.lookup("isMyWidget"));                                                                  // 432
  }, function() {                                                                                                      // 433
    return Blaze._TemplateWith(function() {                                                                            // 434
      return {                                                                                                         // 435
        collection: Spacebars.call("widgets"),                                                                         // 436
        field: Spacebars.call("name")                                                                                  // 437
      };                                                                                                               // 438
    }, function() {                                                                                                    // 439
      return Spacebars.include(view.lookupTemplate("editableText"));                                                   // 440
    });                                                                                                                // 441
  }, function() {                                                                                                      // 442
    return Blaze.View("lookup:name", function() {                                                                      // 443
      return Spacebars.mustache(view.lookup("name"));                                                                  // 444
    });                                                                                                                // 445
  }), "\n          ", HTML.Raw("<br>"), "\n          ", HTML.Raw("<b>Short Script Name:</b>"), Blaze.View("lookup:url", function() {
    return Spacebars.mustache(view.lookup("url"));                                                                     // 447
  }), "\n          ", HTML.Raw("<br>"), "\n          ", HTML.Raw("<b>Description:</b>"), " ", Blaze.If(function() {    // 448
    return Spacebars.call(view.lookup("isMyWidget"));                                                                  // 449
  }, function() {                                                                                                      // 450
    return Blaze._TemplateWith(function() {                                                                            // 451
      return {                                                                                                         // 452
        collection: Spacebars.call("widgets"),                                                                         // 453
        textarea: Spacebars.call(true),                                                                                // 454
        acceptEmpty: Spacebars.call(true),                                                                             // 455
        field: Spacebars.call("description")                                                                           // 456
      };                                                                                                               // 457
    }, function() {                                                                                                    // 458
      return Spacebars.include(view.lookupTemplate("editableText"));                                                   // 459
    });                                                                                                                // 460
  }, function() {                                                                                                      // 461
    return Blaze.View("lookup:description", function() {                                                               // 462
      return Spacebars.mustache(view.lookup("description"));                                                           // 463
    });                                                                                                                // 464
  }), "\n          ", HTML.Raw("<br>"), "\n          ", HTML.Raw("<b>Created By:</b>"), " ", Blaze.View("lookup:createdBy.username", function() {
    return Spacebars.mustache(Spacebars.dot(view.lookup("createdBy"), "username"));                                    // 466
  }), "\n          ", HTML.Raw("<hr>"), "\n          ", HTML.Raw('<b style="font-size: 1.1em;">API Links:</b>'), "\n          ", HTML.Raw("<br>"), "\n          ", HTML.Raw("<b>Standalone:</b>"), HTML.A({
    href: function() {                                                                                                 // 468
      return [ "/headless/", Spacebars.mustache(view.lookup("url")), "/", Spacebars.mustache(view.lookup("pagetype")), "/", Spacebars.mustache(view.lookup("pageid")), ".page" ];
    },                                                                                                                 // 470
    target: "_blank"                                                                                                   // 471
  }, "/headless/", Blaze.View("lookup:url", function() {                                                               // 472
    return Spacebars.mustache(view.lookup("url"));                                                                     // 473
  }), "/", Blaze.View("lookup:pagetype", function() {                                                                  // 474
    return Spacebars.mustache(view.lookup("pagetype"));                                                                // 475
  }), "/", Blaze.View("lookup:pageid", function() {                                                                    // 476
    return Spacebars.mustache(view.lookup("pageid"));                                                                  // 477
  }), ".page"), "\n          ", HTML.Raw("<br>"), "\n          ", HTML.Raw("<b>JSON Output:</b>"), HTML.A({            // 478
    href: function() {                                                                                                 // 479
      return [ "/headless/", Spacebars.mustache(view.lookup("url")), "/", Spacebars.mustache(view.lookup("pagetype")), "/", Spacebars.mustache(view.lookup("pageid")), ".json" ];
    },                                                                                                                 // 481
    target: "_blank"                                                                                                   // 482
  }, "/headless/", Blaze.View("lookup:url", function() {                                                               // 483
    return Spacebars.mustache(view.lookup("url"));                                                                     // 484
  }), "/", Blaze.View("lookup:pagetype", function() {                                                                  // 485
    return Spacebars.mustache(view.lookup("pagetype"));                                                                // 486
  }), "/", Blaze.View("lookup:pageid", function() {                                                                    // 487
    return Spacebars.mustache(view.lookup("pageid"));                                                                  // 488
  }), ".json"), "\n          ", HTML.Raw("<br>"), "\n          ", HTML.Raw("<b>HTML Output:</b>"), HTML.A({            // 489
    href: function() {                                                                                                 // 490
      return [ "/headless/", Spacebars.mustache(view.lookup("url")), "/", Spacebars.mustache(view.lookup("pagetype")), "/", Spacebars.mustache(view.lookup("pageid")), ".html" ];
    },                                                                                                                 // 492
    target: "_blank"                                                                                                   // 493
  }, "/headless/", Blaze.View("lookup:url", function() {                                                               // 494
    return Spacebars.mustache(view.lookup("url"));                                                                     // 495
  }), "/", Blaze.View("lookup:pagetype", function() {                                                                  // 496
    return Spacebars.mustache(view.lookup("pagetype"));                                                                // 497
  }), "/", Blaze.View("lookup:pageid", function() {                                                                    // 498
    return Spacebars.mustache(view.lookup("pageid"));                                                                  // 499
  }), ".html"), "\n          ", HTML.Raw("<br>"), "\n          ", HTML.Raw("<b>JSBIN Embed URL:</b>"), " ", HTML.A({   // 500
    href: function() {                                                                                                 // 501
      return [ "/jsbin/", Spacebars.mustache(view.lookup("url")), "/latest/edit?output&height=", Spacebars.mustache(view.lookup("jsbinHeight")), "&pagetype=", Spacebars.mustache(view.lookup("pagetype")), "&pageid=", Spacebars.mustache(view.lookup("pageid")) ];
    }                                                                                                                  // 503
  }, "/jsbin/", Blaze.View("lookup:url", function() {                                                                  // 504
    return Spacebars.mustache(view.lookup("url"));                                                                     // 505
  }), HTML.Raw("/latest/edit?output&amp;height="), Blaze.View("lookup:jsbinHeight", function() {                       // 506
    return Spacebars.mustache(view.lookup("jsbinHeight"));                                                             // 507
  }), HTML.Raw("&amp;pagetype="), Blaze.View("lookup:pagetype", function() {                                           // 508
    return Spacebars.mustache(view.lookup("pagetype"));                                                                // 509
  }), HTML.Raw("&amp;pageid="), Blaze.View("lookup:pageid", function() {                                               // 510
    return Spacebars.mustache(view.lookup("pageid"));                                                                  // 511
  })), "\n        "), "\n        ", HTML.Raw('<div class="modal-footer">\n          <a href="#" data-dismiss="modal" class="btn">Close</a>\n        </div>'), "\n      "), "\n    "), "\n"), "\n\n\n", HTML.DIV({
    class: "modal fade",                                                                                               // 513
    id: function() {                                                                                                   // 514
      return [ "config_modal_", Spacebars.mustache(view.lookup("_id")) ];                                              // 515
    }                                                                                                                  // 516
  }, "\n  ", HTML.DIV({                                                                                                // 517
    class: "modal-dialog"                                                                                              // 518
  }, "\n      ", HTML.DIV({                                                                                            // 519
    class: "modal-content"                                                                                             // 520
  }, "\n        ", HTML.Raw('<div class="modal-header">\n          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>\n          <h4 class="modal-title">Widget Style Config</h4>\n        </div>'), "\n        ", HTML.DIV({
    class: "modal-body"                                                                                                // 522
  }, "\n          ", HTML.Raw("<b>Raw CSS (for stye attribute):</b>"), " ", Blaze._TemplateWith(function() {           // 523
    return {                                                                                                           // 524
      textarea: Spacebars.call(true),                                                                                  // 525
      acceptEmpty: Spacebars.call(true),                                                                               // 526
      collection: Spacebars.call("widgets"),                                                                           // 527
      field: Spacebars.call("widgetStyle"),                                                                            // 528
      placeholder: Spacebars.call("enter valid css for 'style' attribute")                                             // 529
    };                                                                                                                 // 530
  }, function() {                                                                                                      // 531
    return Spacebars.include(view.lookupTemplate("editableText"));                                                     // 532
  }), "\n        "), "\n        ", HTML.Raw('<div class="modal-footer">\n          <a href="#" data-dismiss="modal" class="btn">Close</a>\n        </div>'), "\n      "), "\n    "), "\n"), "\n\n", HTML.DIV({
    class: "modal fade",                                                                                               // 534
    id: function() {                                                                                                   // 535
      return [ "cache_modal_", Spacebars.mustache(view.lookup("_id")) ];                                               // 536
    }                                                                                                                  // 537
  }, "\n  ", HTML.DIV({                                                                                                // 538
    class: "modal-dialog"                                                                                              // 539
  }, "\n      ", HTML.DIV({                                                                                            // 540
    class: "modal-content"                                                                                             // 541
  }, "\n        ", HTML.Raw('<div class="modal-header">\n          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>\n          <h4 class="modal-title">Cache Settings</h4>\n        </div>'), "\n        ", HTML.DIV({
    class: "modal-body"                                                                                                // 543
  }, "\n          ", HTML.Raw("<b>Cache TTL (in seconds):</b>"), " ", Blaze._TemplateWith(function() {                 // 544
    return {                                                                                                           // 545
      textarea: Spacebars.call(true),                                                                                  // 546
      acceptEmpty: Spacebars.call(true),                                                                               // 547
      collection: Spacebars.call("widgets"),                                                                           // 548
      field: Spacebars.call("cacheConfig.ttl"),                                                                        // 549
      placeholder: Spacebars.call("Enter Cache Time in Seconds")                                                       // 550
    };                                                                                                                 // 551
  }, function() {                                                                                                      // 552
    return Spacebars.include(view.lookupTemplate("editableText"));                                                     // 553
  }), "\n        "), "\n        ", HTML.Raw('<div class="modal-footer">\n          <a href="#" data-dismiss="modal" class="btn">Close</a>\n        </div>'), "\n      "), "\n    "), "\n"), "\n\n\n\n\n    "), "\n    ", HTML.Raw("<!-- edit-mode header-->"), "\n\n\n    ", HTML.Raw("<!-- end of menu header -->"), "\n\n    ", HTML.DIV({
    class: "widgetBody"                                                                                                // 555
  }, "\n      ", HTML.A({                                                                                              // 556
    class: "jsbin jsbin-embed jsbin-embed-dyn",                                                                        // 557
    id: function() {                                                                                                   // 558
      return [ "jsbin_", Spacebars.mustache(view.lookup("url")) ];                                                     // 559
    },                                                                                                                 // 560
    href: function() {                                                                                                 // 561
      return [ "/jsbin/", Spacebars.mustache(view.lookup("url")), "/latest/edit?output&pagetype=", Spacebars.mustache(view.lookup("pagetype")), "&pageid=", Spacebars.mustache(view.lookup("pageid")) ];
    }                                                                                                                  // 563
  }, "JS Bin....", Blaze.View("lookup:url", function() {                                                               // 564
    return Spacebars.mustache(view.lookup("url"));                                                                     // 565
  }), ":"), "\n\n      ", HTML.SCRIPT({                                                                                // 566
    src: "/jsbin/js/embed.js"                                                                                          // 567
  }), "\n    "), "\n  "), "\n\n\n  "), "\n");                                                                          // 568
}));                                                                                                                   // 569
                                                                                                                       // 570
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"template.widget_oldmenu.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// template.widget_oldmenu.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("widget_oldmenu");                                                                                // 2
Template["widget_oldmenu"] = new Template("Template.widget_oldmenu", (function() {                                     // 3
  var view = this;                                                                                                     // 4
  return HTML.DIV({                                                                                                    // 5
    class: "widgetContainer container-item",                                                                           // 6
    id: function() {                                                                                                   // 7
      return [ "widgetContainer_", Spacebars.mustache(view.lookup("url")) ];                                           // 8
    },                                                                                                                 // 9
    style: function() {                                                                                                // 10
      return Spacebars.mustache(view.lookup("widgetStyle"));                                                           // 11
    }                                                                                                                  // 12
  }, "\n    ", HTML.DIV({                                                                                              // 13
    class: "widgetHeader"                                                                                              // 14
  }, "\n      ", HTML.DIV({                                                                                            // 15
    class: "container-item"                                                                                            // 16
  }, "\n      ", HTML.B({                                                                                              // 17
    class: "widgetName"                                                                                                // 18
  }, Blaze._TemplateWith(function() {                                                                                  // 19
    return {                                                                                                           // 20
      collection: Spacebars.call("widgets"),                                                                           // 21
      field: Spacebars.call("name")                                                                                    // 22
    };                                                                                                                 // 23
  }, function() {                                                                                                      // 24
    return Spacebars.include(view.lookupTemplate("editableText"));                                                     // 25
  })), HTML.SPAN({                                                                                                     // 26
    class: "editmodeonly widgetIdText"                                                                                 // 27
  }, " uid: ", Blaze.View("lookup:url", function() {                                                                   // 28
    return Spacebars.mustache(view.lookup("url"));                                                                     // 29
  }), "/", Blaze.View("lookup:pageurl", function() {                                                                   // 30
    return Spacebars.mustache(view.lookup("pageurl"));                                                                 // 31
  })), "\n      "), "\n      ", HTML.DIV({                                                                             // 32
    class: "container-item widgetmenu unlock",                                                                         // 33
    title: "click to lock widget",                                                                                     // 34
    style: "display:none"                                                                                              // 35
  }, "\n        ", HTML.LI({                                                                                           // 36
    class: "widgeticon ion-unlocked edit",                                                                             // 37
    id: function() {                                                                                                   // 38
      return [ "unlock_", Spacebars.mustache(view.lookup("url")) ];                                                    // 39
    },                                                                                                                 // 40
    "data-pack": "default",                                                                                            // 41
    "data-tags": "",                                                                                                   // 42
    style: "display: inline-block;"                                                                                    // 43
  }), "\n      "), "\n      ", HTML.DIV({                                                                              // 44
    class: "container-item widgetmenu lock",                                                                           // 45
    title: "click to unlock widget"                                                                                    // 46
  }, "\n        ", HTML.LI({                                                                                           // 47
    class: "widgeticon ion-locked display",                                                                            // 48
    id: function() {                                                                                                   // 49
      return [ "lock_", Spacebars.mustache(view.lookup("url")) ];                                                      // 50
    },                                                                                                                 // 51
    "data-pack": "default",                                                                                            // 52
    "data-tags": "",                                                                                                   // 53
    style: "display: inline-block;"                                                                                    // 54
  }), "\n      "), "\n      ", HTML.Raw('<div class="container-item widgetmenu test editmodeonly" align="center" title="random testing button. click with caution">       \n        <li class="widgeticon test ion-pizza" data-pack="default" data-tags="" alt="random testing button" style="display: inline-block;"></li>\n      </div>'), "\n      ", HTML.DIV({
    class: "container-item widgetmenu save_template editmodeonly",                                                     // 56
    align: "center",                                                                                                   // 57
    title: "save this widget as a reusable template (will show up in the header drop down with the same icon)."        // 58
  }, "       \n        ", HTML.LI({                                                                                    // 59
    class: function() {                                                                                                // 60
      return [ "widgeticon save_template ion-paper-airplane       ", Blaze.If(function() {                             // 61
        return Spacebars.call(view.lookup("isTemplate"));                                                              // 62
      }, function() {                                                                                                  // 63
        return "\nisWidget";                                                                                           // 64
      }) ];                                                                                                            // 65
    },                                                                                                                 // 66
    "data-pack": "default",                                                                                            // 67
    "data-tags": "",                                                                                                   // 68
    alt: "save as a reusable template",                                                                                // 69
    style: "display: inline-block;"                                                                                    // 70
  }), "\n      "), "\n      ", HTML.Raw('<div class="container-item widgetmenu save editmodeonly" align="center" title="save this widget">       \n        <li class="widgeticon save ion-ios-upload " data-pack="default" data-tags="" alt="save widget" style="display: inline-block;"></li>\n      </div>'), "\n      ", HTML.DIV({
    class: "container-item widgetmenu editmodeonly",                                                                   // 72
    align: "center",                                                                                                   // 73
    title: "pull data from another widget on this page (dropdown)."                                                    // 74
  }, "\n        ", HTML.DIV({                                                                                          // 75
    class: "dropdown"                                                                                                  // 76
  }, "\n          ", HTML.BUTTON({                                                                                     // 77
    class: "btn btn-default dropdown-toggle tooltipped",                                                               // 78
    alt: "alt tooltip",                                                                                                // 79
    type: "button",                                                                                                    // 80
    id: function() {                                                                                                   // 81
      return [ "dropdownMenu1_", Spacebars.mustache(view.lookup("url")) ];                                             // 82
    },                                                                                                                 // 83
    "data-toggle": "dropdown",                                                                                         // 84
    "aria-haspopup": "true",                                                                                           // 85
    "aria-expanded": "true",                                                                                           // 86
    "data-tooltip": "pull data from widget"                                                                            // 87
  }, "\n            Pull from\n            ", HTML.Raw('<span class="caret"></span>'), "\n          "), "\n          ", HTML.UL({
    class: "dropdown-menu",                                                                                            // 89
    "aria-labelledby": function() {                                                                                    // 90
      return [ "dropdownMenu1_", Spacebars.mustache(view.lookup("url")) ];                                             // 91
    }                                                                                                                  // 92
  }, "\n            ", Blaze.Each(function() {                                                                         // 93
    return Spacebars.call(view.lookup("otherwidgets"));                                                                // 94
  }, function() {                                                                                                      // 95
    return [ "\n              ", HTML.LI(HTML.A({                                                                      // 96
      href: "#",                                                                                                       // 97
      class: function() {                                                                                              // 98
        return [ "add_code ", Spacebars.mustache(view.lookup("url")) ];                                                // 99
      },                                                                                                               // 100
      "data-pullfrom": function() {                                                                                    // 101
        return Spacebars.mustache(view.lookup("url"));                                                                 // 102
      },                                                                                                               // 103
      "data-pulltype": "data"                                                                                          // 104
    }, HTML.I({                                                                                                        // 105
      class: "widgetIDText",                                                                                           // 106
      "data-pullfrom": function() {                                                                                    // 107
        return Spacebars.mustache(view.lookup("url"));                                                                 // 108
      },                                                                                                               // 109
      "data-pulltype": "data"                                                                                          // 110
    }, Blaze.View("lookup:url", function() {                                                                           // 111
      return Spacebars.mustache(view.lookup("url"));                                                                   // 112
    })), ": ", Blaze.View("lookup:name", function() {                                                                  // 113
      return Spacebars.mustache(view.lookup("name"));                                                                  // 114
    }), " (data)")), "\n              ", HTML.LI(HTML.A({                                                              // 115
      href: "#",                                                                                                       // 116
      class: function() {                                                                                              // 117
        return [ "add_code ", Spacebars.mustache(view.lookup("url")) ];                                                // 118
      },                                                                                                               // 119
      "data-pullfrom": function() {                                                                                    // 120
        return Spacebars.mustache(view.lookup("url"));                                                                 // 121
      },                                                                                                               // 122
      "data-pulltype": "html"                                                                                          // 123
    }, HTML.I({                                                                                                        // 124
      class: "widgetIDText",                                                                                           // 125
      "data-pullfrom": function() {                                                                                    // 126
        return Spacebars.mustache(view.lookup("url"));                                                                 // 127
      },                                                                                                               // 128
      "data-pulltype": "html"                                                                                          // 129
    }, Blaze.View("lookup:url", function() {                                                                           // 130
      return Spacebars.mustache(view.lookup("url"));                                                                   // 131
    })), ": ", Blaze.View("lookup:name", function() {                                                                  // 132
      return Spacebars.mustache(view.lookup("name"));                                                                  // 133
    }), " (html)")), "\n", HTML.LI({                                                                                   // 134
      role: "separator",                                                                                               // 135
      class: "divider"                                                                                                 // 136
    }), "              \n            " ];                                                                              // 137
  }), "\n          "), "\n        "), "\n      "), "\n\n      ", HTML.DIV({                                            // 138
    class: "container-item editmodeonly"                                                                               // 139
  }, "\n        ", HTML.DIV({                                                                                          // 140
    class: "widgetDescription"                                                                                         // 141
  }, "\n          ", HTML.BUTTON({                                                                                     // 142
    class: "btn btn-primary",                                                                                          // 143
    type: "button",                                                                                                    // 144
    "data-toggle": "collapse",                                                                                         // 145
    "data-target": function() {                                                                                        // 146
      return [ "#widgetDescEdit_", Spacebars.mustache(view.lookup("url")) ];                                           // 147
    },                                                                                                                 // 148
    "aria-expanded": "false",                                                                                          // 149
    "aria-controls": function() {                                                                                      // 150
      return [ "widgetDescEdit_", Spacebars.mustache(view.lookup("url")) ];                                            // 151
    },                                                                                                                 // 152
    title: "Click to see/edit full description"                                                                        // 153
  }, HTML.I(Blaze.View("lookup:shortIt", function() {                                                                  // 154
    return Spacebars.mustache(view.lookup("shortIt"), view.lookup("description"), 15);                                 // 155
  }))), "\n          ", HTML.DIV({                                                                                     // 156
    class: "collapse",                                                                                                 // 157
    id: function() {                                                                                                   // 158
      return [ "widgetDescEdit_", Spacebars.mustache(view.lookup("url")) ];                                            // 159
    }                                                                                                                  // 160
  }, "\n            ", HTML.DIV({                                                                                      // 161
    class: "well"                                                                                                      // 162
  }, "\n              ", HTML.I({                                                                                      // 163
    class: "widgetDescriptionEdit"                                                                                     // 164
  }, Blaze._TemplateWith(function() {                                                                                  // 165
    return {                                                                                                           // 166
      collection: Spacebars.call("widgets"),                                                                           // 167
      textarea: Spacebars.call(true),                                                                                  // 168
      acceptEmpty: Spacebars.call(true),                                                                               // 169
      field: Spacebars.call("description")                                                                             // 170
    };                                                                                                                 // 171
  }, function() {                                                                                                      // 172
    return Spacebars.include(view.lookupTemplate("editableText"));                                                     // 173
  })), "\n            "), "\n          "), "\n        "), "\n      "), "\n\n\n      ", HTML.DIV({                      // 174
    class: "container-item editmodeonly"                                                                               // 175
  }, "\n        ", HTML.BUTTON({                                                                                       // 176
    class: "btn btn-primary",                                                                                          // 177
    type: "button",                                                                                                    // 178
    "data-toggle": "collapse",                                                                                         // 179
    "data-target": function() {                                                                                        // 180
      return [ "#widgetStyleEdit_", Spacebars.mustache(view.lookup("url")) ];                                          // 181
    },                                                                                                                 // 182
    "aria-expanded": "false",                                                                                          // 183
    "aria-controls": function() {                                                                                      // 184
      return [ "widgetStyleEdit_", Spacebars.mustache(view.lookup("url")) ];                                           // 185
    },                                                                                                                 // 186
    title: "CSS Style for this Widget's Display Mode"                                                                  // 187
  }, "\n            ", HTML.Raw('<li class="widgeticon ion-social-css3" data-pack="ios" style="display: inline-block;"></li>'), "\n        "), "\n        ", HTML.DIV({
    class: "collapse",                                                                                                 // 189
    id: function() {                                                                                                   // 190
      return [ "widgetStyleEdit_", Spacebars.mustache(view.lookup("url")) ];                                           // 191
    }                                                                                                                  // 192
  }, "\n          ", HTML.DIV({                                                                                        // 193
    class: "well"                                                                                                      // 194
  }, "\n            ", Blaze._TemplateWith(function() {                                                                // 195
    return {                                                                                                           // 196
      title: Spacebars.call("."),                                                                                      // 197
      textarea: Spacebars.call(true),                                                                                  // 198
      acceptEmpty: Spacebars.call(true),                                                                               // 199
      collection: Spacebars.call("widgets"),                                                                           // 200
      field: Spacebars.call("widgetStyle"),                                                                            // 201
      placeholder: Spacebars.call("enter valid css for 'style' attribute")                                             // 202
    };                                                                                                                 // 203
  }, function() {                                                                                                      // 204
    return Spacebars.include(view.lookupTemplate("editableText"));                                                     // 205
  }), "\n          "), "\n        "), "\n      "), "\n      ", HTML.DIV({                                              // 206
    class: "container-item editmodeonly"                                                                               // 207
  }, HTML.A({                                                                                                          // 208
    href: function() {                                                                                                 // 209
      return [ "/headless/", Spacebars.mustache(view.lookup("url")), "/", Spacebars.mustache(view.lookup("pagetype")), "/", Spacebars.mustache(view.lookup("pageid")) ];
    },                                                                                                                 // 211
    target: "_blank"                                                                                                   // 212
  }, Blaze.View("lookup:url", function() {                                                                             // 213
    return Spacebars.mustache(view.lookup("url"));                                                                     // 214
  }), "/", Blaze.View("lookup:pagetype", function() {                                                                  // 215
    return Spacebars.mustache(view.lookup("pagetype"));                                                                // 216
  }), "/", Blaze.View("lookup:pageid", function() {                                                                    // 217
    return Spacebars.mustache(view.lookup("pageid"));                                                                  // 218
  }))), "\n\n      ", HTML.Raw('<div class="container-item widgetmenu editmodeonly menuspacer">&nbsp;</div>'), " \n\n\n      ", HTML.DIV({
    class: "container-item widgetmenu editmodeonly deletewidget",                                                      // 220
    title: "delete this widget"                                                                                        // 221
  }, "\n        ", HTML.LI({                                                                                           // 222
    class: "widgeticon ion-ios-trash-outline delete",                                                                  // 223
    id: function() {                                                                                                   // 224
      return [ "delete_", Spacebars.mustache(view.lookup("url")) ];                                                    // 225
    },                                                                                                                 // 226
    "data-pack": "ios",                                                                                                // 227
    "data-tags": "delete, remove, dispose, waste, basket, dump, kill",                                                 // 228
    style: "display: inline-block;"                                                                                    // 229
  }), "\n      "), "\n    "), HTML.Raw("\n<!-- end of menu header -->\n\n    "), HTML.DIV({                            // 230
    class: "widgetBody"                                                                                                // 231
  }, "\n      ", HTML.A({                                                                                              // 232
    class: "jsbin jsbin-embed jsbin-embed-dyn",                                                                        // 233
    id: function() {                                                                                                   // 234
      return [ "jsbin_", Spacebars.mustache(view.lookup("url")) ];                                                     // 235
    },                                                                                                                 // 236
    href: function() {                                                                                                 // 237
      return [ "http://localhost/jsbin/", Spacebars.mustache(view.lookup("url")), "/latest/edit?output&height=600px&pagetype=", Spacebars.mustache(view.lookup("pagetype")), "&pageid=", Spacebars.mustache(view.lookup("pageid")) ];
    }                                                                                                                  // 239
  }, "JS Bin....", Blaze.View("lookup:url", function() {                                                               // 240
    return Spacebars.mustache(view.lookup("url"));                                                                     // 241
  }), ": ", Blaze.View("lookup:widgetStyle", function() {                                                              // 242
    return Spacebars.mustache(view.lookup("widgetStyle"));                                                             // 243
  })), "\n      ", HTML.SCRIPT({                                                                                       // 244
    src: "http://localhost/jsbin/js/embed.js"                                                                          // 245
  }), "\n    "), "\n  ");                                                                                              // 246
}));                                                                                                                   // 247
                                                                                                                       // 248
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"template.widgets.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// template.widgets.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       // 1
Template.__checkName("gridwidgets");                                                                                   // 2
Template["gridwidgets"] = new Template("Template.gridwidgets", (function() {                                           // 3
  var view = this;                                                                                                     // 4
  return HTML.DIV({                                                                                                    // 5
    class: "grid-stack"                                                                                                // 6
  }, "\n      ", Blaze.Each(function() {                                                                               // 7
    return Spacebars.call(view.lookup("widgets"));                                                                     // 8
  }, function() {                                                                                                      // 9
    return [ "\n        ", Spacebars.include(view.lookupTemplate("widget")), "\n      " ];                             // 10
  }), "\n      ", Blaze.Each(function() {                                                                              // 11
    return Spacebars.call(view.lookup("thisPageWidgets"));                                                             // 12
  }, function() {                                                                                                      // 13
    return [ "\n        ", Spacebars.include(view.lookupTemplate("widget")), "\n      " ];                             // 14
  }), "\n    ");                                                                                                       // 15
}));                                                                                                                   // 16
                                                                                                                       // 17
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"client":{"lib":{"gridstack.js":["jquery","lodash",function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// client/lib/gridstack.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * gridstack.js 0.2.5                                                                                                  //
 * http://troolee.github.io/gridstack.js/                                                                              //
 * (c) 2014-2016 Pavel Reznikov                                                                                        //
 * gridstack.js may be freely distributed under the MIT license.                                                       //
 * @preserve                                                                                                           //
*/                                                                                                                     //
(function (factory) {                                                                                                  // 8
    if (typeof define === 'function' && define.amd) {                                                                  // 9
        define(['jquery', 'lodash', 'jquery-ui/core', 'jquery-ui/widget', 'jquery-ui/mouse', 'jquery-ui/draggable', 'jquery-ui/resizable'], factory);
    } else if (typeof exports !== 'undefined') {                                                                       // 12
        try {                                                                                                          // 13
            jQuery = require('jquery');                                                                                // 13
        } catch (e) {}                                                                                                 // 13
        try {                                                                                                          // 14
            _ = require('lodash');                                                                                     // 14
        } catch (e) {}                                                                                                 // 14
        factory(jQuery, _);                                                                                            // 15
    } else {                                                                                                           // 16
        factory(jQuery, _);                                                                                            // 17
    }                                                                                                                  // 18
})(function ($, _) {                                                                                                   // 19
                                                                                                                       //
    var scope = window;                                                                                                // 21
                                                                                                                       //
    var obsolete = function obsolete(f, oldName, newName) {                                                            // 23
        var wrapper = function wrapper() {                                                                             // 24
            console.warn('gridstack.js: Function `' + oldName + '` is deprecated as of v0.2.5 and has been replaced ' + 'with `' + newName + '`. It will be **completely** removed in v1.0.');
            return f.apply(this, arguments);                                                                           // 27
        };                                                                                                             // 28
        wrapper.prototype = f.prototype;                                                                               // 29
                                                                                                                       //
        return wrapper;                                                                                                // 31
    };                                                                                                                 // 32
                                                                                                                       //
    var obsoleteOpts = function obsoleteOpts(oldName, newName) {                                                       // 34
        console.warn('gridstack.js: Option `' + oldName + '` is deprecated as of v0.2.5 and has been replaced with `' + newName + '`. It will be **completely** removed in v1.0.');
    };                                                                                                                 // 37
                                                                                                                       //
    var Utils = {                                                                                                      // 39
        isIntercepted: function () {                                                                                   // 40
            function isIntercepted(a, b) {                                                                             // 40
                return !(a.x + a.width <= b.x || b.x + b.width <= a.x || a.y + a.height <= b.y || b.y + b.height <= a.y);
            }                                                                                                          // 42
                                                                                                                       //
            return isIntercepted;                                                                                      // 40
        }(),                                                                                                           // 40
                                                                                                                       //
        sort: function () {                                                                                            // 44
            function sort(nodes, dir, width) {                                                                         // 44
                width = width || _.chain(nodes).map(function (node) {                                                  // 45
                    return node.x + node.width;                                                                        // 45
                }).max().value();                                                                                      // 45
                dir = dir != -1 ? 1 : -1;                                                                              // 46
                return _.sortBy(nodes, function (n) {                                                                  // 47
                    return dir * (n.x + n.y * width);                                                                  // 47
                });                                                                                                    // 47
            }                                                                                                          // 48
                                                                                                                       //
            return sort;                                                                                               // 44
        }(),                                                                                                           // 44
                                                                                                                       //
        createStylesheet: function () {                                                                                // 50
            function createStylesheet(id) {                                                                            // 50
                var style = document.createElement('style');                                                           // 51
                style.setAttribute('type', 'text/css');                                                                // 52
                style.setAttribute('data-gs-style-id', id);                                                            // 53
                if (style.styleSheet) {                                                                                // 54
                    style.styleSheet.cssText = '';                                                                     // 55
                } else {                                                                                               // 56
                    style.appendChild(document.createTextNode(''));                                                    // 57
                }                                                                                                      // 58
                document.getElementsByTagName('head')[0].appendChild(style);                                           // 59
                return style.sheet;                                                                                    // 60
            }                                                                                                          // 61
                                                                                                                       //
            return createStylesheet;                                                                                   // 50
        }(),                                                                                                           // 50
                                                                                                                       //
        removeStylesheet: function () {                                                                                // 63
            function removeStylesheet(id) {                                                                            // 63
                $('STYLE[data-gs-style-id=' + id + ']').remove();                                                      // 64
            }                                                                                                          // 65
                                                                                                                       //
            return removeStylesheet;                                                                                   // 63
        }(),                                                                                                           // 63
                                                                                                                       //
        insertCSSRule: function () {                                                                                   // 67
            function insertCSSRule(sheet, selector, rules, index) {                                                    // 67
                if (typeof sheet.insertRule === 'function') {                                                          // 68
                    sheet.insertRule(selector + '{' + rules + '}', index);                                             // 69
                } else if (typeof sheet.addRule === 'function') {                                                      // 70
                    sheet.addRule(selector, rules, index);                                                             // 71
                }                                                                                                      // 72
            }                                                                                                          // 73
                                                                                                                       //
            return insertCSSRule;                                                                                      // 67
        }(),                                                                                                           // 67
                                                                                                                       //
        toBool: function () {                                                                                          // 75
            function toBool(v) {                                                                                       // 75
                if (typeof v == 'boolean') {                                                                           // 76
                    return v;                                                                                          // 77
                }                                                                                                      // 78
                if (typeof v == 'string') {                                                                            // 79
                    v = v.toLowerCase();                                                                               // 80
                    return !(v === '' || v == 'no' || v == 'false' || v == '0');                                       // 81
                }                                                                                                      // 82
                return Boolean(v);                                                                                     // 83
            }                                                                                                          // 84
                                                                                                                       //
            return toBool;                                                                                             // 75
        }(),                                                                                                           // 75
                                                                                                                       //
        _collisionNodeCheck: function () {                                                                             // 86
            function _collisionNodeCheck(n) {                                                                          // 86
                return n != this.node && Utils.isIntercepted(n, this.nn);                                              // 87
            }                                                                                                          // 88
                                                                                                                       //
            return _collisionNodeCheck;                                                                                // 86
        }(),                                                                                                           // 86
                                                                                                                       //
        _didCollide: function () {                                                                                     // 90
            function _didCollide(bn) {                                                                                 // 90
                return Utils.isIntercepted({ x: this.n.x, y: this.newY, width: this.n.width, height: this.n.height }, bn);
            }                                                                                                          // 92
                                                                                                                       //
            return _didCollide;                                                                                        // 90
        }(),                                                                                                           // 90
                                                                                                                       //
        _isAddNodeIntercepted: function () {                                                                           // 94
            function _isAddNodeIntercepted(n) {                                                                        // 94
                return Utils.isIntercepted({ x: this.x, y: this.y, width: this.node.width, height: this.node.height }, n);
            }                                                                                                          // 96
                                                                                                                       //
            return _isAddNodeIntercepted;                                                                              // 94
        }(),                                                                                                           // 94
                                                                                                                       //
        parseHeight: function () {                                                                                     // 98
            function parseHeight(val) {                                                                                // 98
                var height = val;                                                                                      // 99
                var heightUnit = 'px';                                                                                 // 100
                if (height && _.isString(height)) {                                                                    // 101
                    var match = height.match(/^(-[0-9]+\.[0-9]+|[0-9]*\.[0-9]+|-[0-9]+|[0-9]+)(px|em|rem|vh|vw)?$/);   // 102
                    if (!match) {                                                                                      // 103
                        throw new Error('Invalid height');                                                             // 104
                    }                                                                                                  // 105
                    heightUnit = match[2] || 'px';                                                                     // 106
                    height = parseFloat(match[1]);                                                                     // 107
                }                                                                                                      // 108
                return { height: height, unit: heightUnit };                                                           // 109
            }                                                                                                          // 110
                                                                                                                       //
            return parseHeight;                                                                                        // 98
        }()                                                                                                            // 98
    };                                                                                                                 // 39
                                                                                                                       //
    // jscs:disable requireCamelCaseOrUpperCaseIdentifiers                                                             // 113
    Utils.is_intercepted = obsolete(Utils.isIntercepted, 'is_intercepted', 'isIntercepted');                           // 114
                                                                                                                       //
    Utils.create_stylesheet = obsolete(Utils.createStylesheet, 'create_stylesheet', 'createStylesheet');               // 116
                                                                                                                       //
    Utils.remove_stylesheet = obsolete(Utils.removeStylesheet, 'remove_stylesheet', 'removeStylesheet');               // 118
                                                                                                                       //
    Utils.insert_css_rule = obsolete(Utils.insertCSSRule, 'insert_css_rule', 'insertCSSRule');                         // 120
    // jscs:enable requireCamelCaseOrUpperCaseIdentifiers                                                              // 121
                                                                                                                       //
    var idSeq = 0;                                                                                                     // 123
                                                                                                                       //
    var GridStackEngine = function GridStackEngine(width, onchange, floatMode, height, items) {                        // 125
        this.width = width;                                                                                            // 126
        this.float = floatMode || false;                                                                               // 127
        this.height = height || 0;                                                                                     // 128
                                                                                                                       //
        this.nodes = items || [];                                                                                      // 130
        this.onchange = onchange || function () {};                                                                    // 131
                                                                                                                       //
        this._updateCounter = 0;                                                                                       // 133
        this._float = this.float;                                                                                      // 134
                                                                                                                       //
        this._addedNodes = [];                                                                                         // 136
        this._removedNodes = [];                                                                                       // 137
    };                                                                                                                 // 138
                                                                                                                       //
    GridStackEngine.prototype.batchUpdate = function () {                                                              // 140
        this._updateCounter = 1;                                                                                       // 141
        this.float = true;                                                                                             // 142
    };                                                                                                                 // 143
                                                                                                                       //
    GridStackEngine.prototype.commit = function () {                                                                   // 145
        if (this._updateCounter !== 0) {                                                                               // 146
            this._updateCounter = 0;                                                                                   // 147
            this.float = this._float;                                                                                  // 148
            this._packNodes();                                                                                         // 149
            this._notify();                                                                                            // 150
        }                                                                                                              // 151
    };                                                                                                                 // 152
                                                                                                                       //
    // For Meteor support: https://github.com/troolee/gridstack.js/pull/272                                            // 154
    GridStackEngine.prototype.getNodeDataByDOMEl = function (el) {                                                     // 155
        return _.find(this.nodes, function (n) {                                                                       // 156
            return el.get(0) === n.el.get(0);                                                                          // 156
        });                                                                                                            // 156
    };                                                                                                                 // 157
                                                                                                                       //
    GridStackEngine.prototype._fixCollisions = function (node) {                                                       // 159
        var self = this;                                                                                               // 160
        this._sortNodes(-1);                                                                                           // 161
                                                                                                                       //
        var nn = node;                                                                                                 // 163
        var hasLocked = Boolean(_.find(this.nodes, function (n) {                                                      // 164
            return n.locked;                                                                                           // 164
        }));                                                                                                           // 164
        if (!this.float && !hasLocked) {                                                                               // 165
            nn = { x: 0, y: node.y, width: this.width, height: node.height };                                          // 166
        }                                                                                                              // 167
        while (true) {                                                                                                 // 168
            var collisionNode = _.find(this.nodes, _.bind(Utils._collisionNodeCheck, { node: node, nn: nn }));         // 169
            if (typeof collisionNode == 'undefined') {                                                                 // 170
                return;                                                                                                // 171
            }                                                                                                          // 172
            this.moveNode(collisionNode, collisionNode.x, node.y + node.height, collisionNode.width, collisionNode.height, true);
        }                                                                                                              // 175
    };                                                                                                                 // 176
                                                                                                                       //
    GridStackEngine.prototype.isAreaEmpty = function (x, y, width, height) {                                           // 178
        var nn = { x: x || 0, y: y || 0, width: width || 1, height: height || 1 };                                     // 179
        var collisionNode = _.find(this.nodes, _.bind(function (n) {                                                   // 180
            return Utils.isIntercepted(n, nn);                                                                         // 181
        }, this));                                                                                                     // 182
        return collisionNode === null || typeof collisionNode === 'undefined';                                         // 183
    };                                                                                                                 // 184
                                                                                                                       //
    GridStackEngine.prototype._sortNodes = function (dir) {                                                            // 186
        this.nodes = Utils.sort(this.nodes, dir, this.width);                                                          // 187
    };                                                                                                                 // 188
                                                                                                                       //
    GridStackEngine.prototype._packNodes = function () {                                                               // 190
        this._sortNodes();                                                                                             // 191
                                                                                                                       //
        if (this.float) {                                                                                              // 193
            _.each(this.nodes, _.bind(function (n, i) {                                                                // 194
                if (n._updating || typeof n._origY == 'undefined' || n.y == n._origY) {                                // 195
                    return;                                                                                            // 196
                }                                                                                                      // 197
                                                                                                                       //
                var newY = n.y;                                                                                        // 199
                while (newY >= n._origY) {                                                                             // 200
                    var collisionNode = _.chain(this.nodes).find(_.bind(Utils._didCollide, { n: n, newY: newY })).value();
                                                                                                                       //
                    if (!collisionNode) {                                                                              // 205
                        n._dirty = true;                                                                               // 206
                        n.y = newY;                                                                                    // 207
                    }                                                                                                  // 208
                    --newY;                                                                                            // 209
                }                                                                                                      // 210
            }, this));                                                                                                 // 211
        } else {                                                                                                       // 212
            _.each(this.nodes, _.bind(function (n, i) {                                                                // 213
                if (n.locked) {                                                                                        // 214
                    return;                                                                                            // 215
                }                                                                                                      // 216
                while (n.y > 0) {                                                                                      // 217
                    var newY = n.y - 1;                                                                                // 218
                    var canBeMoved = i === 0;                                                                          // 219
                                                                                                                       //
                    if (i > 0) {                                                                                       // 221
                        var collisionNode = _.chain(this.nodes).take(i).find(_.bind(Utils._didCollide, { n: n, newY: newY })).value();
                        canBeMoved = typeof collisionNode == 'undefined';                                              // 226
                    }                                                                                                  // 227
                                                                                                                       //
                    if (!canBeMoved) {                                                                                 // 229
                        break;                                                                                         // 230
                    }                                                                                                  // 231
                    n._dirty = n.y != newY;                                                                            // 232
                    n.y = newY;                                                                                        // 233
                }                                                                                                      // 234
            }, this));                                                                                                 // 235
        }                                                                                                              // 236
    };                                                                                                                 // 237
                                                                                                                       //
    GridStackEngine.prototype._prepareNode = function (node, resizing) {                                               // 239
        node = _.defaults(node || {}, { width: 1, height: 1, x: 0, y: 0 });                                            // 240
                                                                                                                       //
        node.x = parseInt('' + node.x);                                                                                // 242
        node.y = parseInt('' + node.y);                                                                                // 243
        node.width = parseInt('' + node.width);                                                                        // 244
        node.height = parseInt('' + node.height);                                                                      // 245
        node.autoPosition = node.autoPosition || false;                                                                // 246
        node.noResize = node.noResize || false;                                                                        // 247
        node.noMove = node.noMove || false;                                                                            // 248
                                                                                                                       //
        if (node.width > this.width) {                                                                                 // 250
            node.width = this.width;                                                                                   // 251
        } else if (node.width < 1) {                                                                                   // 252
            node.width = 1;                                                                                            // 253
        }                                                                                                              // 254
                                                                                                                       //
        if (node.height < 1) {                                                                                         // 256
            node.height = 1;                                                                                           // 257
        }                                                                                                              // 258
                                                                                                                       //
        if (node.x < 0) {                                                                                              // 260
            node.x = 0;                                                                                                // 261
        }                                                                                                              // 262
                                                                                                                       //
        if (node.x + node.width > this.width) {                                                                        // 264
            if (resizing) {                                                                                            // 265
                node.width = this.width - node.x;                                                                      // 266
            } else {                                                                                                   // 267
                node.x = this.width - node.width;                                                                      // 268
            }                                                                                                          // 269
        }                                                                                                              // 270
                                                                                                                       //
        if (node.y < 0) {                                                                                              // 272
            node.y = 0;                                                                                                // 273
        }                                                                                                              // 274
                                                                                                                       //
        return node;                                                                                                   // 276
    };                                                                                                                 // 277
                                                                                                                       //
    GridStackEngine.prototype._notify = function () {                                                                  // 279
        if (this._updateCounter) {                                                                                     // 280
            return;                                                                                                    // 281
        }                                                                                                              // 282
        var deletedNodes = Array.prototype.slice.call(arguments, 0);                                                   // 283
        deletedNodes = deletedNodes.concat(this.getDirtyNodes());                                                      // 284
        this.onchange(deletedNodes);                                                                                   // 285
    };                                                                                                                 // 286
                                                                                                                       //
    GridStackEngine.prototype.cleanNodes = function () {                                                               // 288
        if (this._updateCounter) {                                                                                     // 289
            return;                                                                                                    // 290
        }                                                                                                              // 291
        _.each(this.nodes, function (n) {                                                                              // 292
            n._dirty = false;                                                                                          // 292
        });                                                                                                            // 292
    };                                                                                                                 // 293
                                                                                                                       //
    GridStackEngine.prototype.getDirtyNodes = function () {                                                            // 295
        return _.filter(this.nodes, function (n) {                                                                     // 296
            return n._dirty;                                                                                           // 296
        });                                                                                                            // 296
    };                                                                                                                 // 297
                                                                                                                       //
    GridStackEngine.prototype.addNode = function (node, triggerAddEvent) {                                             // 299
        node = this._prepareNode(node);                                                                                // 300
                                                                                                                       //
        if (typeof node.maxWidth != 'undefined') {                                                                     // 302
            node.width = Math.min(node.width, node.maxWidth);                                                          // 302
        }                                                                                                              // 302
        if (typeof node.maxHeight != 'undefined') {                                                                    // 303
            node.height = Math.min(node.height, node.maxHeight);                                                       // 303
        }                                                                                                              // 303
        if (typeof node.minWidth != 'undefined') {                                                                     // 304
            node.width = Math.max(node.width, node.minWidth);                                                          // 304
        }                                                                                                              // 304
        if (typeof node.minHeight != 'undefined') {                                                                    // 305
            node.height = Math.max(node.height, node.minHeight);                                                       // 305
        }                                                                                                              // 305
                                                                                                                       //
        node._id = ++idSeq;                                                                                            // 307
        node._dirty = true;                                                                                            // 308
                                                                                                                       //
        if (node.autoPosition) {                                                                                       // 310
            this._sortNodes();                                                                                         // 311
                                                                                                                       //
            for (var i = 0;; ++i) {                                                                                    // 313
                var x = i % this.width;                                                                                // 314
                var y = Math.floor(i / this.width);                                                                    // 315
                if (x + node.width > this.width) {                                                                     // 316
                    continue;                                                                                          // 317
                }                                                                                                      // 318
                if (!_.find(this.nodes, _.bind(Utils._isAddNodeIntercepted, { x: x, y: y, node: node }))) {            // 319
                    node.x = x;                                                                                        // 320
                    node.y = y;                                                                                        // 321
                    break;                                                                                             // 322
                }                                                                                                      // 323
            }                                                                                                          // 324
        }                                                                                                              // 325
                                                                                                                       //
        this.nodes.push(node);                                                                                         // 327
        if (typeof triggerAddEvent != 'undefined' && triggerAddEvent) {                                                // 328
            this._addedNodes.push(_.clone(node));                                                                      // 329
        }                                                                                                              // 330
                                                                                                                       //
        this._fixCollisions(node);                                                                                     // 332
        this._packNodes();                                                                                             // 333
        this._notify();                                                                                                // 334
        return node;                                                                                                   // 335
    };                                                                                                                 // 336
                                                                                                                       //
    GridStackEngine.prototype.removeNode = function (node, detachNode) {                                               // 338
        detachNode = typeof detachNode === 'undefined' ? true : detachNode;                                            // 339
        this._removedNodes.push(_.clone(node));                                                                        // 340
        node._id = null;                                                                                               // 341
        this.nodes = _.without(this.nodes, node);                                                                      // 342
        this._packNodes();                                                                                             // 343
        if (detachNode) {                                                                                              // 344
            this._notify(node);                                                                                        // 345
        }                                                                                                              // 346
    };                                                                                                                 // 347
                                                                                                                       //
    GridStackEngine.prototype.canMoveNode = function (node, x, y, width, height) {                                     // 349
        var hasLocked = Boolean(_.find(this.nodes, function (n) {                                                      // 350
            return n.locked;                                                                                           // 350
        }));                                                                                                           // 350
                                                                                                                       //
        if (!this.height && !hasLocked) {                                                                              // 352
            return true;                                                                                               // 353
        }                                                                                                              // 354
                                                                                                                       //
        var clonedNode;                                                                                                // 356
        var clone = new GridStackEngine(this.width, null, this.float, 0, _.map(this.nodes, function (n) {              // 357
            if (n == node) {                                                                                           // 363
                clonedNode = $.extend({}, n);                                                                          // 364
                return clonedNode;                                                                                     // 365
            }                                                                                                          // 366
            return $.extend({}, n);                                                                                    // 367
        }));                                                                                                           // 368
                                                                                                                       //
        if (typeof clonedNode === 'undefined') {                                                                       // 370
            return true;                                                                                               // 371
        }                                                                                                              // 372
                                                                                                                       //
        clone.moveNode(clonedNode, x, y, width, height);                                                               // 374
                                                                                                                       //
        var res = true;                                                                                                // 376
                                                                                                                       //
        if (hasLocked) {                                                                                               // 378
            res &= !Boolean(_.find(clone.nodes, function (n) {                                                         // 379
                return n != clonedNode && Boolean(n.locked) && Boolean(n._dirty);                                      // 380
            }));                                                                                                       // 381
        }                                                                                                              // 382
        if (this.height) {                                                                                             // 383
            res &= clone.getGridHeight() <= this.height;                                                               // 384
        }                                                                                                              // 385
                                                                                                                       //
        return res;                                                                                                    // 387
    };                                                                                                                 // 388
                                                                                                                       //
    GridStackEngine.prototype.canBePlacedWithRespectToHeight = function (node) {                                       // 390
        if (!this.height) {                                                                                            // 391
            return true;                                                                                               // 392
        }                                                                                                              // 393
                                                                                                                       //
        var clone = new GridStackEngine(this.width, null, this.float, 0, _.map(this.nodes, function (n) {              // 395
            return $.extend({}, n);                                                                                    // 400
        }));                                                                                                           // 400
        clone.addNode(node);                                                                                           // 401
        return clone.getGridHeight() <= this.height;                                                                   // 402
    };                                                                                                                 // 403
                                                                                                                       //
    GridStackEngine.prototype.moveNode = function (node, x, y, width, height, noPack) {                                // 405
        if (typeof x != 'number') {                                                                                    // 406
            x = node.x;                                                                                                // 406
        }                                                                                                              // 406
        if (typeof y != 'number') {                                                                                    // 407
            y = node.y;                                                                                                // 407
        }                                                                                                              // 407
        if (typeof width != 'number') {                                                                                // 408
            width = node.width;                                                                                        // 408
        }                                                                                                              // 408
        if (typeof height != 'number') {                                                                               // 409
            height = node.height;                                                                                      // 409
        }                                                                                                              // 409
                                                                                                                       //
        if (typeof node.maxWidth != 'undefined') {                                                                     // 411
            width = Math.min(width, node.maxWidth);                                                                    // 411
        }                                                                                                              // 411
        if (typeof node.maxHeight != 'undefined') {                                                                    // 412
            height = Math.min(height, node.maxHeight);                                                                 // 412
        }                                                                                                              // 412
        if (typeof node.minWidth != 'undefined') {                                                                     // 413
            width = Math.max(width, node.minWidth);                                                                    // 413
        }                                                                                                              // 413
        if (typeof node.minHeight != 'undefined') {                                                                    // 414
            height = Math.max(height, node.minHeight);                                                                 // 414
        }                                                                                                              // 414
                                                                                                                       //
        if (node.x == x && node.y == y && node.width == width && node.height == height) {                              // 416
            return node;                                                                                               // 417
        }                                                                                                              // 418
                                                                                                                       //
        var resizing = node.width != width;                                                                            // 420
        node._dirty = true;                                                                                            // 421
                                                                                                                       //
        node.x = x;                                                                                                    // 423
        node.y = y;                                                                                                    // 424
        node.width = width;                                                                                            // 425
        node.height = height;                                                                                          // 426
                                                                                                                       //
        node = this._prepareNode(node, resizing);                                                                      // 428
                                                                                                                       //
        this._fixCollisions(node);                                                                                     // 430
        if (!noPack) {                                                                                                 // 431
            this._packNodes();                                                                                         // 432
            this._notify();                                                                                            // 433
        }                                                                                                              // 434
        return node;                                                                                                   // 435
    };                                                                                                                 // 436
                                                                                                                       //
    GridStackEngine.prototype.getGridHeight = function () {                                                            // 438
        return _.reduce(this.nodes, function (memo, n) {                                                               // 439
            return Math.max(memo, n.y + n.height);                                                                     // 439
        }, 0);                                                                                                         // 439
    };                                                                                                                 // 440
                                                                                                                       //
    GridStackEngine.prototype.beginUpdate = function (node) {                                                          // 442
        _.each(this.nodes, function (n) {                                                                              // 443
            n._origY = n.y;                                                                                            // 444
        });                                                                                                            // 445
        node._updating = true;                                                                                         // 446
    };                                                                                                                 // 447
                                                                                                                       //
    GridStackEngine.prototype.endUpdate = function () {                                                                // 449
        _.each(this.nodes, function (n) {                                                                              // 450
            n._origY = n.y;                                                                                            // 451
        });                                                                                                            // 452
        var n = _.find(this.nodes, function (n) {                                                                      // 453
            return n._updating;                                                                                        // 453
        });                                                                                                            // 453
        if (n) {                                                                                                       // 454
            n._updating = false;                                                                                       // 455
        }                                                                                                              // 456
    };                                                                                                                 // 457
                                                                                                                       //
    var GridStack = function GridStack(el, opts) {                                                                     // 459
        var self = this;                                                                                               // 460
        var oneColumnMode, isAutoCellHeight;                                                                           // 461
                                                                                                                       //
        opts = opts || {};                                                                                             // 463
                                                                                                                       //
        this.container = $(el);                                                                                        // 465
                                                                                                                       //
        // jscs:disable requireCamelCaseOrUpperCaseIdentifiers                                                         // 467
        if (typeof opts.handle_class !== 'undefined') {                                                                // 468
            opts.handleClass = opts.handle_class;                                                                      // 469
            obsoleteOpts('handle_class', 'handleClass');                                                               // 470
        }                                                                                                              // 471
        if (typeof opts.item_class !== 'undefined') {                                                                  // 472
            opts.itemClass = opts.item_class;                                                                          // 473
            obsoleteOpts('item_class', 'itemClass');                                                                   // 474
        }                                                                                                              // 475
        if (typeof opts.placeholder_class !== 'undefined') {                                                           // 476
            opts.placeholderClass = opts.placeholder_class;                                                            // 477
            obsoleteOpts('placeholder_class', 'placeholderClass');                                                     // 478
        }                                                                                                              // 479
        if (typeof opts.placeholder_text !== 'undefined') {                                                            // 480
            opts.placeholderText = opts.placeholder_text;                                                              // 481
            obsoleteOpts('placeholder_text', 'placeholderText');                                                       // 482
        }                                                                                                              // 483
        if (typeof opts.cell_height !== 'undefined') {                                                                 // 484
            opts.cellHeight = opts.cell_height;                                                                        // 485
            obsoleteOpts('cell_height', 'cellHeight');                                                                 // 486
        }                                                                                                              // 487
        if (typeof opts.vertical_margin !== 'undefined') {                                                             // 488
            opts.verticalMargin = opts.vertical_margin;                                                                // 489
            obsoleteOpts('vertical_margin', 'verticalMargin');                                                         // 490
        }                                                                                                              // 491
        if (typeof opts.min_width !== 'undefined') {                                                                   // 492
            opts.minWidth = opts.min_width;                                                                            // 493
            obsoleteOpts('min_width', 'minWidth');                                                                     // 494
        }                                                                                                              // 495
        if (typeof opts.static_grid !== 'undefined') {                                                                 // 496
            opts.staticGrid = opts.static_grid;                                                                        // 497
            obsoleteOpts('static_grid', 'staticGrid');                                                                 // 498
        }                                                                                                              // 499
        if (typeof opts.is_nested !== 'undefined') {                                                                   // 500
            opts.isNested = opts.is_nested;                                                                            // 501
            obsoleteOpts('is_nested', 'isNested');                                                                     // 502
        }                                                                                                              // 503
        if (typeof opts.always_show_resize_handle !== 'undefined') {                                                   // 504
            opts.alwaysShowResizeHandle = opts.always_show_resize_handle;                                              // 505
            obsoleteOpts('always_show_resize_handle', 'alwaysShowResizeHandle');                                       // 506
        }                                                                                                              // 507
        // jscs:enable requireCamelCaseOrUpperCaseIdentifiers                                                          // 508
                                                                                                                       //
        opts.itemClass = opts.itemClass || 'grid-stack-item';                                                          // 510
        var isNested = this.container.closest('.' + opts.itemClass).size() > 0;                                        // 511
                                                                                                                       //
        this.opts = _.defaults(opts || {}, {                                                                           // 513
            width: parseInt(this.container.attr('data-gs-width')) || 12,                                               // 514
            height: parseInt(this.container.attr('data-gs-height')) || 0,                                              // 515
            itemClass: 'grid-stack-item',                                                                              // 516
            placeholderClass: 'grid-stack-placeholder',                                                                // 517
            placeholderText: '',                                                                                       // 518
            handle: '.grid-stack-item-content',                                                                        // 519
            handleClass: null,                                                                                         // 520
            cellHeight: 60,                                                                                            // 521
            verticalMargin: 20,                                                                                        // 522
            auto: true,                                                                                                // 523
            minWidth: 768,                                                                                             // 524
            float: false,                                                                                              // 525
            staticGrid: false,                                                                                         // 526
            _class: 'grid-stack-instance-' + (Math.random() * 10000).toFixed(0),                                       // 527
            animate: Boolean(this.container.attr('data-gs-animate')) || false,                                         // 528
            alwaysShowResizeHandle: opts.alwaysShowResizeHandle || false,                                              // 529
            resizable: _.defaults(opts.resizable || {}, {                                                              // 530
                autoHide: !(opts.alwaysShowResizeHandle || false),                                                     // 531
                handles: 'se'                                                                                          // 532
            }),                                                                                                        // 530
            draggable: _.defaults(opts.draggable || {}, {                                                              // 534
                handle: (opts.handleClass ? '.' + opts.handleClass : opts.handle ? opts.handle : '') || '.grid-stack-item-content',
                scroll: false,                                                                                         // 537
                appendTo: 'body'                                                                                       // 538
            }),                                                                                                        // 534
            disableDrag: opts.disableDrag || false,                                                                    // 540
            disableResize: opts.disableResize || false,                                                                // 541
            rtl: 'auto',                                                                                               // 542
            removable: false,                                                                                          // 543
            removeTimeout: 2000,                                                                                       // 544
            verticalMarginUnit: 'px',                                                                                  // 545
            cellHeightUnit: 'px'                                                                                       // 546
        });                                                                                                            // 513
                                                                                                                       //
        if (this.opts.rtl === 'auto') {                                                                                // 549
            this.opts.rtl = this.container.css('direction') === 'rtl';                                                 // 550
        }                                                                                                              // 551
                                                                                                                       //
        if (this.opts.rtl) {                                                                                           // 553
            this.container.addClass('grid-stack-rtl');                                                                 // 554
        }                                                                                                              // 555
                                                                                                                       //
        this.opts.isNested = isNested;                                                                                 // 557
                                                                                                                       //
        isAutoCellHeight = this.opts.cellHeight === 'auto';                                                            // 559
        if (isAutoCellHeight) {                                                                                        // 560
            self.cellHeight(self.cellWidth(), true);                                                                   // 561
        } else {                                                                                                       // 562
            this.cellHeight(this.opts.cellHeight, true);                                                               // 563
        }                                                                                                              // 564
        this.verticalMargin(this.opts.verticalMargin, true);                                                           // 565
                                                                                                                       //
        this.container.addClass(this.opts._class);                                                                     // 567
                                                                                                                       //
        this._setStaticClass();                                                                                        // 569
                                                                                                                       //
        if (isNested) {                                                                                                // 571
            this.container.addClass('grid-stack-nested');                                                              // 572
        }                                                                                                              // 573
                                                                                                                       //
        this._initStyles();                                                                                            // 575
                                                                                                                       //
        this.grid = new GridStackEngine(this.opts.width, function (nodes) {                                            // 577
            var maxHeight = 0;                                                                                         // 578
            _.each(nodes, function (n) {                                                                               // 579
                if (n._id === null) {                                                                                  // 580
                    if (n.el) {                                                                                        // 581
                        n.el.remove();                                                                                 // 582
                    }                                                                                                  // 583
                } else {                                                                                               // 584
                    n.el.attr('data-gs-x', n.x).attr('data-gs-y', n.y).attr('data-gs-width', n.width).attr('data-gs-height', n.height);
                    maxHeight = Math.max(maxHeight, n.y + n.height);                                                   // 590
                }                                                                                                      // 591
            });                                                                                                        // 592
            self._updateStyles(maxHeight + 10);                                                                        // 593
        }, this.opts.float, this.opts.height);                                                                         // 594
                                                                                                                       //
        if (this.opts.auto) {                                                                                          // 596
            var elements = [];                                                                                         // 597
            var _this = this;                                                                                          // 598
            this.container.children('.' + this.opts.itemClass + ':not(.' + this.opts.placeholderClass + ')').each(function (index, el) {
                el = $(el);                                                                                            // 601
                elements.push({                                                                                        // 602
                    el: el,                                                                                            // 603
                    i: parseInt(el.attr('data-gs-x')) + parseInt(el.attr('data-gs-y')) * _this.opts.width              // 604
                });                                                                                                    // 602
            });                                                                                                        // 606
            _.chain(elements).sortBy(function (x) {                                                                    // 607
                return x.i;                                                                                            // 607
            }).each(function (i) {                                                                                     // 607
                self._prepareElement(i.el);                                                                            // 608
            }).value();                                                                                                // 609
        }                                                                                                              // 610
                                                                                                                       //
        this.setAnimation(this.opts.animate);                                                                          // 612
                                                                                                                       //
        this.placeholder = $('<div class="' + this.opts.placeholderClass + ' ' + this.opts.itemClass + '">' + '<div class="placeholder-content">' + this.opts.placeholderText + '</div></div>').hide();
                                                                                                                       //
        this._updateContainerHeight();                                                                                 // 618
                                                                                                                       //
        this._updateHeightsOnResize = _.throttle(function () {                                                         // 620
            self.cellHeight(self.cellWidth(), false);                                                                  // 621
        }, 100);                                                                                                       // 622
                                                                                                                       //
        this.onResizeHandler = function () {                                                                           // 624
            if (isAutoCellHeight) {                                                                                    // 625
                self._updateHeightsOnResize();                                                                         // 626
            }                                                                                                          // 627
                                                                                                                       //
            if (self._isOneColumnMode()) {                                                                             // 629
                if (oneColumnMode) {                                                                                   // 630
                    return;                                                                                            // 631
                }                                                                                                      // 632
                                                                                                                       //
                oneColumnMode = true;                                                                                  // 634
                                                                                                                       //
                self.grid._sortNodes();                                                                                // 636
                _.each(self.grid.nodes, function (node) {                                                              // 637
                    self.container.append(node.el);                                                                    // 638
                                                                                                                       //
                    if (self.opts.staticGrid) {                                                                        // 640
                        return;                                                                                        // 641
                    }                                                                                                  // 642
                    if (node.noMove || self.opts.disableDrag) {                                                        // 643
                        node.el.draggable('disable');                                                                  // 644
                    }                                                                                                  // 645
                    if (node.noResize || self.opts.disableResize) {                                                    // 646
                        node.el.resizable('disable');                                                                  // 647
                    }                                                                                                  // 648
                                                                                                                       //
                    node.el.trigger('resize');                                                                         // 650
                });                                                                                                    // 651
            } else {                                                                                                   // 652
                if (!oneColumnMode) {                                                                                  // 653
                    return;                                                                                            // 654
                }                                                                                                      // 655
                                                                                                                       //
                oneColumnMode = false;                                                                                 // 657
                                                                                                                       //
                if (self.opts.staticGrid) {                                                                            // 659
                    return;                                                                                            // 660
                }                                                                                                      // 661
                                                                                                                       //
                _.each(self.grid.nodes, function (node) {                                                              // 663
                    if (!node.noMove && !self.opts.disableDrag) {                                                      // 664
                        node.el.draggable('enable');                                                                   // 665
                    }                                                                                                  // 666
                    if (!node.noResize && !self.opts.disableResize) {                                                  // 667
                        node.el.resizable('enable');                                                                   // 668
                    }                                                                                                  // 669
                                                                                                                       //
                    node.el.trigger('resize');                                                                         // 671
                });                                                                                                    // 672
            }                                                                                                          // 673
        };                                                                                                             // 674
                                                                                                                       //
        $(window).resize(this.onResizeHandler);                                                                        // 676
        this.onResizeHandler();                                                                                        // 677
                                                                                                                       //
        if (!self.opts.staticGrid && typeof self.opts.removable === 'string') {                                        // 679
            var trashZone = $(self.opts.removable);                                                                    // 680
            if (!trashZone.data('droppable')) {                                                                        // 681
                trashZone.droppable({                                                                                  // 682
                    accept: '.' + self.opts.itemClass                                                                  // 683
                });                                                                                                    // 682
            }                                                                                                          // 685
            trashZone.on('dropover', function (event, ui) {                                                            // 686
                var el = $(ui.draggable);                                                                              // 688
                var node = el.data('_gridstack_node');                                                                 // 689
                if (node._grid !== self) {                                                                             // 690
                    return;                                                                                            // 691
                }                                                                                                      // 692
                self._setupRemovingTimeout(el);                                                                        // 693
            }).on('dropout', function (event, ui) {                                                                    // 694
                var el = $(ui.draggable);                                                                              // 696
                var node = el.data('_gridstack_node');                                                                 // 697
                if (node._grid !== self) {                                                                             // 698
                    return;                                                                                            // 699
                }                                                                                                      // 700
                self._clearRemovingTimeout(el);                                                                        // 701
            });                                                                                                        // 702
        }                                                                                                              // 703
                                                                                                                       //
        if (!self.opts.staticGrid && self.opts.acceptWidgets) {                                                        // 705
            var draggingElement = null;                                                                                // 706
                                                                                                                       //
            var onDrag = function onDrag(event, ui) {                                                                  // 708
                var el = draggingElement;                                                                              // 709
                var node = el.data('_gridstack_node');                                                                 // 710
                var pos = self.getCellFromPixel(ui.offset, true);                                                      // 711
                var x = Math.max(0, pos.x);                                                                            // 712
                var y = Math.max(0, pos.y);                                                                            // 713
                if (!node._added) {                                                                                    // 714
                    node._added = true;                                                                                // 715
                                                                                                                       //
                    node.el = el;                                                                                      // 717
                    node.x = x;                                                                                        // 718
                    node.y = y;                                                                                        // 719
                    self.grid.cleanNodes();                                                                            // 720
                    self.grid.beginUpdate(node);                                                                       // 721
                    self.grid.addNode(node);                                                                           // 722
                                                                                                                       //
                    self.container.append(self.placeholder);                                                           // 724
                    self.placeholder.attr('data-gs-x', node.x).attr('data-gs-y', node.y).attr('data-gs-width', node.width).attr('data-gs-height', node.height).show();
                    node.el = self.placeholder;                                                                        // 731
                    node._beforeDragX = node.x;                                                                        // 732
                    node._beforeDragY = node.y;                                                                        // 733
                                                                                                                       //
                    self._updateContainerHeight();                                                                     // 735
                } else {                                                                                               // 736
                    if (!self.grid.canMoveNode(node, x, y)) {                                                          // 737
                        return;                                                                                        // 738
                    }                                                                                                  // 739
                    self.grid.moveNode(node, x, y);                                                                    // 740
                    self._updateContainerHeight();                                                                     // 741
                }                                                                                                      // 742
            };                                                                                                         // 743
                                                                                                                       //
            $(self.container).droppable({                                                                              // 745
                accept: function () {                                                                                  // 746
                    function accept(el) {                                                                              // 746
                        el = $(el);                                                                                    // 747
                        var node = el.data('_gridstack_node');                                                         // 748
                        if (node && node._grid === self) {                                                             // 749
                            return false;                                                                              // 750
                        }                                                                                              // 751
                        return el.is(self.opts.acceptWidgets === true ? '.grid-stack-item' : self.opts.acceptWidgets);
                    }                                                                                                  // 753
                                                                                                                       //
                    return accept;                                                                                     // 746
                }(),                                                                                                   // 746
                over: function () {                                                                                    // 754
                    function over(event, ui) {                                                                         // 754
                        var offset = self.container.offset();                                                          // 755
                        var el = $(ui.draggable);                                                                      // 756
                        var cellWidth = self.cellWidth();                                                              // 757
                        var cellHeight = self.cellHeight();                                                            // 758
                        var origNode = el.data('_gridstack_node');                                                     // 759
                                                                                                                       //
                        var width = origNode ? origNode.width : Math.ceil(el.outerWidth() / cellWidth);                // 761
                        var height = origNode ? origNode.height : Math.ceil(el.outerHeight() / cellHeight);            // 762
                                                                                                                       //
                        draggingElement = el;                                                                          // 764
                                                                                                                       //
                        var node = self.grid._prepareNode({ width: width, height: height, _added: false, _temporary: true });
                        el.data('_gridstack_node', node);                                                              // 767
                        el.data('_gridstack_node_orig', origNode);                                                     // 768
                                                                                                                       //
                        el.on('drag', onDrag);                                                                         // 770
                    }                                                                                                  // 771
                                                                                                                       //
                    return over;                                                                                       // 754
                }(),                                                                                                   // 754
                out: function () {                                                                                     // 772
                    function out(event, ui) {                                                                          // 772
                        var el = $(ui.draggable);                                                                      // 773
                        el.unbind('drag', onDrag);                                                                     // 774
                        var node = el.data('_gridstack_node');                                                         // 775
                        node.el = null;                                                                                // 776
                        self.grid.removeNode(node);                                                                    // 777
                        self.placeholder.detach();                                                                     // 778
                        self._updateContainerHeight();                                                                 // 779
                        el.data('_gridstack_node', el.data('_gridstack_node_orig'));                                   // 780
                    }                                                                                                  // 781
                                                                                                                       //
                    return out;                                                                                        // 772
                }(),                                                                                                   // 772
                drop: function () {                                                                                    // 782
                    function drop(event, ui) {                                                                         // 782
                        self.placeholder.detach();                                                                     // 783
                                                                                                                       //
                        var node = $(ui.draggable).data('_gridstack_node');                                            // 785
                        node._grid = self;                                                                             // 786
                        var el = $(ui.draggable).clone(false);                                                         // 787
                        el.data('_gridstack_node', node);                                                              // 788
                        $(ui.draggable).remove();                                                                      // 789
                        node.el = el;                                                                                  // 790
                        self.placeholder.hide();                                                                       // 791
                        el.attr('data-gs-x', node.x).attr('data-gs-y', node.y).attr('data-gs-width', node.width).attr('data-gs-height', node.height).addClass(self.opts.itemClass).removeAttr('style').enableSelection().removeData('draggable').removeClass('ui-draggable ui-draggable-dragging ui-draggable-disabled').unbind('drag', onDrag);
                        self.container.append(el);                                                                     // 803
                        self._prepareElementsByNode(el, node);                                                         // 804
                        self._updateContainerHeight();                                                                 // 805
                        self._triggerChangeEvent();                                                                    // 806
                                                                                                                       //
                        self.grid.endUpdate();                                                                         // 808
                    }                                                                                                  // 809
                                                                                                                       //
                    return drop;                                                                                       // 782
                }()                                                                                                    // 782
            });                                                                                                        // 745
        }                                                                                                              // 811
    };                                                                                                                 // 812
                                                                                                                       //
    GridStack.prototype._triggerChangeEvent = function (forceTrigger) {                                                // 814
        var elements = this.grid.getDirtyNodes();                                                                      // 815
        var hasChanges = false;                                                                                        // 816
                                                                                                                       //
        var eventParams = [];                                                                                          // 818
        if (elements && elements.length) {                                                                             // 819
            eventParams.push(elements);                                                                                // 820
            hasChanges = true;                                                                                         // 821
        }                                                                                                              // 822
                                                                                                                       //
        if (hasChanges || forceTrigger === true) {                                                                     // 824
            this.container.trigger('change', eventParams);                                                             // 825
        }                                                                                                              // 826
    };                                                                                                                 // 827
                                                                                                                       //
    GridStack.prototype._triggerAddEvent = function () {                                                               // 829
        if (this.grid._addedNodes && this.grid._addedNodes.length > 0) {                                               // 830
            this.container.trigger('added', [_.map(this.grid._addedNodes, _.clone)]);                                  // 831
            this.grid._addedNodes = [];                                                                                // 832
        }                                                                                                              // 833
    };                                                                                                                 // 834
                                                                                                                       //
    GridStack.prototype._triggerRemoveEvent = function () {                                                            // 836
        if (this.grid._removedNodes && this.grid._removedNodes.length > 0) {                                           // 837
            this.container.trigger('removed', [_.map(this.grid._removedNodes, _.clone)]);                              // 838
            this.grid._removedNodes = [];                                                                              // 839
        }                                                                                                              // 840
    };                                                                                                                 // 841
                                                                                                                       //
    GridStack.prototype._initStyles = function () {                                                                    // 843
        if (this._stylesId) {                                                                                          // 844
            Utils.removeStylesheet(this._stylesId);                                                                    // 845
        }                                                                                                              // 846
        this._stylesId = 'gridstack-style-' + (Math.random() * 100000).toFixed();                                      // 847
        this._styles = Utils.createStylesheet(this._stylesId);                                                         // 848
        if (this._styles !== null) {                                                                                   // 849
            this._styles._max = 0;                                                                                     // 850
        }                                                                                                              // 851
    };                                                                                                                 // 852
                                                                                                                       //
    GridStack.prototype._updateStyles = function (maxHeight) {                                                         // 854
        if (this._styles === null || typeof this._styles === 'undefined') {                                            // 855
            return;                                                                                                    // 856
        }                                                                                                              // 857
                                                                                                                       //
        var prefix = '.' + this.opts._class + ' .' + this.opts.itemClass;                                              // 859
        var self = this;                                                                                               // 860
        var getHeight;                                                                                                 // 861
                                                                                                                       //
        if (typeof maxHeight == 'undefined') {                                                                         // 863
            maxHeight = this._styles._max;                                                                             // 864
            this._initStyles();                                                                                        // 865
            this._updateContainerHeight();                                                                             // 866
        }                                                                                                              // 867
        if (!this.opts.cellHeight) {                                                                                   // 868
            // The rest will be handled by CSS                                                                         // 868
            return;                                                                                                    // 869
        }                                                                                                              // 870
        if (this._styles._max !== 0 && maxHeight <= this._styles._max) {                                               // 871
            return;                                                                                                    // 872
        }                                                                                                              // 873
                                                                                                                       //
        if (!this.opts.verticalMargin || this.opts.cellHeightUnit === this.opts.verticalMarginUnit) {                  // 875
            getHeight = function getHeight(nbRows, nbMargins) {                                                        // 876
                return self.opts.cellHeight * nbRows + self.opts.verticalMargin * nbMargins + self.opts.cellHeightUnit;
            };                                                                                                         // 879
        } else {                                                                                                       // 880
            getHeight = function getHeight(nbRows, nbMargins) {                                                        // 881
                if (!nbRows || !nbMargins) {                                                                           // 882
                    return self.opts.cellHeight * nbRows + self.opts.verticalMargin * nbMargins + self.opts.cellHeightUnit;
                }                                                                                                      // 885
                return 'calc(' + (self.opts.cellHeight * nbRows + self.opts.cellHeightUnit) + ' + ' + (self.opts.verticalMargin * nbMargins + self.opts.verticalMarginUnit) + ')';
            };                                                                                                         // 888
        }                                                                                                              // 889
                                                                                                                       //
        if (this._styles._max === 0) {                                                                                 // 891
            Utils.insertCSSRule(this._styles, prefix, 'min-height: ' + getHeight(1, 0) + ';', 0);                      // 892
        }                                                                                                              // 893
                                                                                                                       //
        if (maxHeight > this._styles._max) {                                                                           // 895
            for (var i = this._styles._max; i < maxHeight; ++i) {                                                      // 896
                Utils.insertCSSRule(this._styles, prefix + '[data-gs-height="' + (i + 1) + '"]', 'height: ' + getHeight(i + 1, i) + ';', i);
                Utils.insertCSSRule(this._styles, prefix + '[data-gs-min-height="' + (i + 1) + '"]', 'min-height: ' + getHeight(i + 1, i) + ';', i);
                Utils.insertCSSRule(this._styles, prefix + '[data-gs-max-height="' + (i + 1) + '"]', 'max-height: ' + getHeight(i + 1, i) + ';', i);
                Utils.insertCSSRule(this._styles, prefix + '[data-gs-y="' + i + '"]', 'top: ' + getHeight(i, i) + ';', i);
            }                                                                                                          // 917
            this._styles._max = maxHeight;                                                                             // 918
        }                                                                                                              // 919
    };                                                                                                                 // 920
                                                                                                                       //
    GridStack.prototype._updateContainerHeight = function () {                                                         // 922
        if (this.grid._updateCounter) {                                                                                // 923
            return;                                                                                                    // 924
        }                                                                                                              // 925
        var height = this.grid.getGridHeight();                                                                        // 926
        this.container.attr('data-gs-current-height', height);                                                         // 927
        if (!this.opts.cellHeight) {                                                                                   // 928
            return;                                                                                                    // 929
        }                                                                                                              // 930
        if (!this.opts.verticalMargin) {                                                                               // 931
            this.container.css('height', height * this.opts.cellHeight + this.opts.cellHeightUnit);                    // 932
        } else if (this.opts.cellHeightUnit === this.opts.verticalMarginUnit) {                                        // 933
            this.container.css('height', height * (this.opts.cellHeight + this.opts.verticalMargin) - this.opts.verticalMargin + this.opts.cellHeightUnit);
        } else {                                                                                                       // 936
            this.container.css('height', 'calc(' + (height * this.opts.cellHeight + this.opts.cellHeightUnit) + ' + ' + (height * (this.opts.verticalMargin - 1) + this.opts.verticalMarginUnit) + ')');
        }                                                                                                              // 939
    };                                                                                                                 // 940
                                                                                                                       //
    GridStack.prototype._isOneColumnMode = function () {                                                               // 942
        return (window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth) <= this.opts.minWidth;
    };                                                                                                                 // 945
                                                                                                                       //
    GridStack.prototype._setupRemovingTimeout = function (el) {                                                        // 947
        var self = this;                                                                                               // 948
        var node = $(el).data('_gridstack_node');                                                                      // 949
                                                                                                                       //
        if (node._removeTimeout || !self.opts.removable) {                                                             // 951
            return;                                                                                                    // 952
        }                                                                                                              // 953
        node._removeTimeout = setTimeout(function () {                                                                 // 954
            el.addClass('grid-stack-item-removing');                                                                   // 955
            node._isAboutToRemove = true;                                                                              // 956
        }, self.opts.removeTimeout);                                                                                   // 957
    };                                                                                                                 // 958
                                                                                                                       //
    GridStack.prototype._clearRemovingTimeout = function (el) {                                                        // 960
        var node = $(el).data('_gridstack_node');                                                                      // 961
                                                                                                                       //
        if (!node._removeTimeout) {                                                                                    // 963
            return;                                                                                                    // 964
        }                                                                                                              // 965
        clearTimeout(node._removeTimeout);                                                                             // 966
        node._removeTimeout = null;                                                                                    // 967
        el.removeClass('grid-stack-item-removing');                                                                    // 968
        node._isAboutToRemove = false;                                                                                 // 969
    };                                                                                                                 // 970
                                                                                                                       //
    GridStack.prototype._prepareElementsByNode = function (el, node) {                                                 // 972
        var self = this;                                                                                               // 973
                                                                                                                       //
        var cellWidth;                                                                                                 // 975
        var cellHeight;                                                                                                // 976
                                                                                                                       //
        var dragOrResize = function dragOrResize(event, ui) {                                                          // 978
            var x = Math.round(ui.position.left / cellWidth);                                                          // 979
            var y = Math.floor((ui.position.top + cellHeight / 2) / cellHeight);                                       // 980
            var width;                                                                                                 // 981
            var height;                                                                                                // 982
                                                                                                                       //
            if (event.type != 'drag') {                                                                                // 984
                width = Math.round(ui.size.width / cellWidth);                                                         // 985
                height = Math.round(ui.size.height / cellHeight);                                                      // 986
            }                                                                                                          // 987
                                                                                                                       //
            if (event.type == 'drag') {                                                                                // 989
                if (x < 0 || x >= self.grid.width || y < 0) {                                                          // 990
                    if (self.opts.removable === true) {                                                                // 991
                        self._setupRemovingTimeout(el);                                                                // 992
                    }                                                                                                  // 993
                                                                                                                       //
                    x = node._beforeDragX;                                                                             // 995
                    y = node._beforeDragY;                                                                             // 996
                                                                                                                       //
                    self.placeholder.detach();                                                                         // 998
                    self.placeholder.hide();                                                                           // 999
                    self.grid.removeNode(node);                                                                        // 1000
                    self._updateContainerHeight();                                                                     // 1001
                                                                                                                       //
                    node._temporaryRemoved = true;                                                                     // 1003
                } else {                                                                                               // 1004
                    self._clearRemovingTimeout(el);                                                                    // 1005
                                                                                                                       //
                    if (node._temporaryRemoved) {                                                                      // 1007
                        self.grid.addNode(node);                                                                       // 1008
                        self.placeholder.attr('data-gs-x', x).attr('data-gs-y', y).attr('data-gs-width', width).attr('data-gs-height', height).show();
                        self.container.append(self.placeholder);                                                       // 1015
                        node.el = self.placeholder;                                                                    // 1016
                        node._temporaryRemoved = false;                                                                // 1017
                    }                                                                                                  // 1018
                }                                                                                                      // 1019
            } else if (event.type == 'resize') {                                                                       // 1020
                if (x < 0) {                                                                                           // 1021
                    return;                                                                                            // 1022
                }                                                                                                      // 1023
            }                                                                                                          // 1024
                                                                                                                       //
            if (!self.grid.canMoveNode(node, x, y, width, height)) {                                                   // 1026
                return;                                                                                                // 1027
            }                                                                                                          // 1028
            self.grid.moveNode(node, x, y, width, height);                                                             // 1029
            self._updateContainerHeight();                                                                             // 1030
        };                                                                                                             // 1031
                                                                                                                       //
        var onStartMoving = function onStartMoving(event, ui) {                                                        // 1033
            self.container.append(self.placeholder);                                                                   // 1034
            var o = $(this);                                                                                           // 1035
            self.grid.cleanNodes();                                                                                    // 1036
            self.grid.beginUpdate(node);                                                                               // 1037
            cellWidth = Math.ceil(o.outerWidth() / o.attr('data-gs-width'));                                           // 1038
            var strictCellHeight = Math.ceil(o.outerHeight() / o.attr('data-gs-height'));                              // 1039
            cellHeight = self.container.height() / parseInt(self.container.attr('data-gs-current-height'));            // 1040
            self.placeholder.attr('data-gs-x', o.attr('data-gs-x')).attr('data-gs-y', o.attr('data-gs-y')).attr('data-gs-width', o.attr('data-gs-width')).attr('data-gs-height', o.attr('data-gs-height')).show();
            node.el = self.placeholder;                                                                                // 1047
            node._beforeDragX = node.x;                                                                                // 1048
            node._beforeDragY = node.y;                                                                                // 1049
                                                                                                                       //
            el.resizable('option', 'minWidth', cellWidth * (node.minWidth || 1));                                      // 1051
            el.resizable('option', 'minHeight', strictCellHeight * (node.minHeight || 1));                             // 1052
                                                                                                                       //
            if (event.type == 'resizestart') {                                                                         // 1054
                o.find('.grid-stack-item').trigger('resizestart');                                                     // 1055
            }                                                                                                          // 1056
        };                                                                                                             // 1057
                                                                                                                       //
        var onEndMoving = function onEndMoving(event, ui) {                                                            // 1059
            var o = $(this);                                                                                           // 1060
            if (!o.data('_gridstack_node')) {                                                                          // 1061
                return;                                                                                                // 1062
            }                                                                                                          // 1063
                                                                                                                       //
            var forceNotify = false;                                                                                   // 1065
            self.placeholder.detach();                                                                                 // 1066
            node.el = o;                                                                                               // 1067
            self.placeholder.hide();                                                                                   // 1068
                                                                                                                       //
            if (node._isAboutToRemove) {                                                                               // 1070
                forceNotify = true;                                                                                    // 1071
                el.removeData('_gridstack_node');                                                                      // 1072
                el.remove();                                                                                           // 1073
            } else {                                                                                                   // 1074
                self._clearRemovingTimeout(el);                                                                        // 1075
                if (!node._temporaryRemoved) {                                                                         // 1076
                    o.attr('data-gs-x', node.x).attr('data-gs-y', node.y).attr('data-gs-width', node.width).attr('data-gs-height', node.height).removeAttr('style');
                } else {                                                                                               // 1083
                    o.attr('data-gs-x', node._beforeDragX).attr('data-gs-y', node._beforeDragY).attr('data-gs-width', node.width).attr('data-gs-height', node.height).removeAttr('style');
                    node.x = node._beforeDragX;                                                                        // 1090
                    node.y = node._beforeDragY;                                                                        // 1091
                    self.grid.addNode(node);                                                                           // 1092
                }                                                                                                      // 1093
            }                                                                                                          // 1094
            self._updateContainerHeight();                                                                             // 1095
            self._triggerChangeEvent(forceNotify);                                                                     // 1096
                                                                                                                       //
            self.grid.endUpdate();                                                                                     // 1098
                                                                                                                       //
            var nestedGrids = o.find('.grid-stack');                                                                   // 1100
            if (nestedGrids.length && event.type == 'resizestop') {                                                    // 1101
                nestedGrids.each(function (index, el) {                                                                // 1102
                    $(el).data('gridstack').onResizeHandler();                                                         // 1103
                });                                                                                                    // 1104
                o.find('.grid-stack-item').trigger('resizestop');                                                      // 1105
            }                                                                                                          // 1106
        };                                                                                                             // 1107
                                                                                                                       //
        el.draggable(_.extend(this.opts.draggable, {                                                                   // 1109
            containment: this.opts.isNested ? this.container.parent() : null,                                          // 1111
            start: onStartMoving,                                                                                      // 1112
            stop: onEndMoving,                                                                                         // 1113
            drag: dragOrResize                                                                                         // 1114
        })).resizable(_.extend(this.opts.resizable, {                                                                  // 1110
            start: onStartMoving,                                                                                      // 1117
            stop: onEndMoving,                                                                                         // 1118
            resize: dragOrResize                                                                                       // 1119
        }));                                                                                                           // 1116
                                                                                                                       //
        if (node.noMove || this._isOneColumnMode() || this.opts.disableDrag) {                                         // 1122
            el.draggable('disable');                                                                                   // 1123
        }                                                                                                              // 1124
                                                                                                                       //
        if (node.noResize || this._isOneColumnMode() || this.opts.disableResize) {                                     // 1126
            el.resizable('disable');                                                                                   // 1127
        }                                                                                                              // 1128
                                                                                                                       //
        el.attr('data-gs-locked', node.locked ? 'yes' : null);                                                         // 1130
    };                                                                                                                 // 1131
                                                                                                                       //
    GridStack.prototype._prepareElement = function (el, triggerAddEvent) {                                             // 1133
        triggerAddEvent = typeof triggerAddEvent != 'undefined' ? triggerAddEvent : false;                             // 1134
        var self = this;                                                                                               // 1135
        el = $(el);                                                                                                    // 1136
                                                                                                                       //
        el.addClass(this.opts.itemClass);                                                                              // 1138
        var node = self.grid.addNode({                                                                                 // 1139
            x: el.attr('data-gs-x'),                                                                                   // 1140
            y: el.attr('data-gs-y'),                                                                                   // 1141
            width: el.attr('data-gs-width'),                                                                           // 1142
            height: el.attr('data-gs-height'),                                                                         // 1143
            maxWidth: el.attr('data-gs-max-width'),                                                                    // 1144
            minWidth: el.attr('data-gs-min-width'),                                                                    // 1145
            maxHeight: el.attr('data-gs-max-height'),                                                                  // 1146
            minHeight: el.attr('data-gs-min-height'),                                                                  // 1147
            autoPosition: Utils.toBool(el.attr('data-gs-auto-position')),                                              // 1148
            noResize: Utils.toBool(el.attr('data-gs-no-resize')),                                                      // 1149
            noMove: Utils.toBool(el.attr('data-gs-no-move')),                                                          // 1150
            locked: Utils.toBool(el.attr('data-gs-locked')),                                                           // 1151
            el: el,                                                                                                    // 1152
            id: el.attr('data-gs-id'),                                                                                 // 1153
            _grid: self                                                                                                // 1154
        }, triggerAddEvent);                                                                                           // 1139
        el.data('_gridstack_node', node);                                                                              // 1156
                                                                                                                       //
        if (!this.opts.staticGrid) {                                                                                   // 1158
            this._prepareElementsByNode(el, node);                                                                     // 1159
        }                                                                                                              // 1160
    };                                                                                                                 // 1161
                                                                                                                       //
    GridStack.prototype.setAnimation = function (enable) {                                                             // 1163
        if (enable) {                                                                                                  // 1164
            this.container.addClass('grid-stack-animate');                                                             // 1165
        } else {                                                                                                       // 1166
            this.container.removeClass('grid-stack-animate');                                                          // 1167
        }                                                                                                              // 1168
    };                                                                                                                 // 1169
                                                                                                                       //
    GridStack.prototype.addWidget = function (el, x, y, width, height, autoPosition, minWidth, maxWidth, minHeight, maxHeight, id) {
        el = $(el);                                                                                                    // 1173
        if (typeof x != 'undefined') {                                                                                 // 1174
            el.attr('data-gs-x', x);                                                                                   // 1174
        }                                                                                                              // 1174
        if (typeof y != 'undefined') {                                                                                 // 1175
            el.attr('data-gs-y', y);                                                                                   // 1175
        }                                                                                                              // 1175
        if (typeof width != 'undefined') {                                                                             // 1176
            el.attr('data-gs-width', width);                                                                           // 1176
        }                                                                                                              // 1176
        if (typeof height != 'undefined') {                                                                            // 1177
            el.attr('data-gs-height', height);                                                                         // 1177
        }                                                                                                              // 1177
        if (typeof autoPosition != 'undefined') {                                                                      // 1178
            el.attr('data-gs-auto-position', autoPosition ? 'yes' : null);                                             // 1178
        }                                                                                                              // 1178
        if (typeof minWidth != 'undefined') {                                                                          // 1179
            el.attr('data-gs-min-width', minWidth);                                                                    // 1179
        }                                                                                                              // 1179
        if (typeof maxWidth != 'undefined') {                                                                          // 1180
            el.attr('data-gs-max-width', maxWidth);                                                                    // 1180
        }                                                                                                              // 1180
        if (typeof minHeight != 'undefined') {                                                                         // 1181
            el.attr('data-gs-min-height', minHeight);                                                                  // 1181
        }                                                                                                              // 1181
        if (typeof maxHeight != 'undefined') {                                                                         // 1182
            el.attr('data-gs-max-height', maxHeight);                                                                  // 1182
        }                                                                                                              // 1182
        if (typeof id != 'undefined') {                                                                                // 1183
            el.attr('data-gs-id', id);                                                                                 // 1183
        }                                                                                                              // 1183
        this.container.append(el);                                                                                     // 1184
        this._prepareElement(el, true);                                                                                // 1185
        this._triggerAddEvent();                                                                                       // 1186
        this._updateContainerHeight();                                                                                 // 1187
        this._triggerChangeEvent(true);                                                                                // 1188
                                                                                                                       //
        return el;                                                                                                     // 1190
    };                                                                                                                 // 1191
                                                                                                                       //
    GridStack.prototype.makeWidget = function (el) {                                                                   // 1193
        el = $(el);                                                                                                    // 1194
        this._prepareElement(el, true);                                                                                // 1195
        this._triggerAddEvent();                                                                                       // 1196
        this._updateContainerHeight();                                                                                 // 1197
        this._triggerChangeEvent(true);                                                                                // 1198
                                                                                                                       //
        return el;                                                                                                     // 1200
    };                                                                                                                 // 1201
                                                                                                                       //
    GridStack.prototype.willItFit = function (x, y, width, height, autoPosition) {                                     // 1203
        var node = { x: x, y: y, width: width, height: height, autoPosition: autoPosition };                           // 1204
        return this.grid.canBePlacedWithRespectToHeight(node);                                                         // 1205
    };                                                                                                                 // 1206
                                                                                                                       //
    GridStack.prototype.removeWidget = function (el, detachNode) {                                                     // 1208
        detachNode = typeof detachNode === 'undefined' ? true : detachNode;                                            // 1209
        el = $(el);                                                                                                    // 1210
        var node = el.data('_gridstack_node');                                                                         // 1211
                                                                                                                       //
        // For Meteor support: https://github.com/troolee/gridstack.js/pull/272                                        // 1213
        if (!node) {                                                                                                   // 1214
            node = this.grid.getNodeDataByDOMEl(el);                                                                   // 1215
        }                                                                                                              // 1216
                                                                                                                       //
        this.grid.removeNode(node, detachNode);                                                                        // 1218
        el.removeData('_gridstack_node');                                                                              // 1219
        this._updateContainerHeight();                                                                                 // 1220
        if (detachNode) {                                                                                              // 1221
            el.remove();                                                                                               // 1222
        }                                                                                                              // 1223
        this._triggerChangeEvent(true);                                                                                // 1224
        this._triggerRemoveEvent();                                                                                    // 1225
    };                                                                                                                 // 1226
                                                                                                                       //
    GridStack.prototype.removeAll = function (detachNode) {                                                            // 1228
        _.each(this.grid.nodes, _.bind(function (node) {                                                               // 1229
            this.removeWidget(node.el, detachNode);                                                                    // 1230
        }, this));                                                                                                     // 1231
        this.grid.nodes = [];                                                                                          // 1232
        this._updateContainerHeight();                                                                                 // 1233
    };                                                                                                                 // 1234
                                                                                                                       //
    GridStack.prototype.destroy = function (detachGrid) {                                                              // 1236
        $(window).off('resize', this.onResizeHandler);                                                                 // 1237
        this.disable();                                                                                                // 1238
        if (typeof detachGrid != 'undefined' && !detachGrid) {                                                         // 1239
            this.removeAll(false);                                                                                     // 1240
        } else {                                                                                                       // 1241
            this.container.remove();                                                                                   // 1242
        }                                                                                                              // 1243
        Utils.removeStylesheet(this._stylesId);                                                                        // 1244
        if (this.grid) {                                                                                               // 1245
            this.grid = null;                                                                                          // 1246
        }                                                                                                              // 1247
    };                                                                                                                 // 1248
                                                                                                                       //
    GridStack.prototype.resizable = function (el, val) {                                                               // 1250
        var self = this;                                                                                               // 1251
        el = $(el);                                                                                                    // 1252
        el.each(function (index, el) {                                                                                 // 1253
            el = $(el);                                                                                                // 1254
            var node = el.data('_gridstack_node');                                                                     // 1255
            if (self.opts.staticGrid || typeof node == 'undefined' || node === null) {                                 // 1256
                return;                                                                                                // 1257
            }                                                                                                          // 1258
                                                                                                                       //
            node.noResize = !(val || false);                                                                           // 1260
            if (node.noResize || self._isOneColumnMode()) {                                                            // 1261
                el.resizable('disable');                                                                               // 1262
            } else {                                                                                                   // 1263
                el.resizable('enable');                                                                                // 1264
            }                                                                                                          // 1265
        });                                                                                                            // 1266
        return this;                                                                                                   // 1267
    };                                                                                                                 // 1268
                                                                                                                       //
    GridStack.prototype.movable = function (el, val) {                                                                 // 1270
        var self = this;                                                                                               // 1271
        el = $(el);                                                                                                    // 1272
        el.each(function (index, el) {                                                                                 // 1273
            el = $(el);                                                                                                // 1274
            var node = el.data('_gridstack_node');                                                                     // 1275
            if (self.opts.staticGrid || typeof node == 'undefined' || node === null) {                                 // 1276
                return;                                                                                                // 1277
            }                                                                                                          // 1278
                                                                                                                       //
            node.noMove = !(val || false);                                                                             // 1280
            if (node.noMove || self._isOneColumnMode()) {                                                              // 1281
                el.draggable('disable');                                                                               // 1282
                el.removeClass('ui-draggable-handle');                                                                 // 1283
            } else {                                                                                                   // 1284
                el.draggable('enable');                                                                                // 1285
                el.addClass('ui-draggable-handle');                                                                    // 1286
            }                                                                                                          // 1287
        });                                                                                                            // 1288
        return this;                                                                                                   // 1289
    };                                                                                                                 // 1290
                                                                                                                       //
    GridStack.prototype.enableMove = function (doEnable, includeNewWidgets) {                                          // 1292
        this.movable(this.container.children('.' + this.opts.itemClass), doEnable);                                    // 1293
        if (includeNewWidgets) {                                                                                       // 1294
            this.opts.disableDrag = !doEnable;                                                                         // 1295
        }                                                                                                              // 1296
    };                                                                                                                 // 1297
                                                                                                                       //
    GridStack.prototype.enableResize = function (doEnable, includeNewWidgets) {                                        // 1299
        this.resizable(this.container.children('.' + this.opts.itemClass), doEnable);                                  // 1300
        if (includeNewWidgets) {                                                                                       // 1301
            this.opts.disableResize = !doEnable;                                                                       // 1302
        }                                                                                                              // 1303
    };                                                                                                                 // 1304
                                                                                                                       //
    GridStack.prototype.disable = function () {                                                                        // 1306
        this.movable(this.container.children('.' + this.opts.itemClass), false);                                       // 1307
        this.resizable(this.container.children('.' + this.opts.itemClass), false);                                     // 1308
        this.container.trigger('disable');                                                                             // 1309
    };                                                                                                                 // 1310
                                                                                                                       //
    GridStack.prototype.enable = function () {                                                                         // 1312
        this.movable(this.container.children('.' + this.opts.itemClass), true);                                        // 1313
        this.resizable(this.container.children('.' + this.opts.itemClass), true);                                      // 1314
        this.container.trigger('enable');                                                                              // 1315
    };                                                                                                                 // 1316
                                                                                                                       //
    GridStack.prototype.locked = function (el, val) {                                                                  // 1318
        el = $(el);                                                                                                    // 1319
        el.each(function (index, el) {                                                                                 // 1320
            el = $(el);                                                                                                // 1321
            var node = el.data('_gridstack_node');                                                                     // 1322
            if (typeof node == 'undefined' || node === null) {                                                         // 1323
                return;                                                                                                // 1324
            }                                                                                                          // 1325
                                                                                                                       //
            node.locked = val || false;                                                                                // 1327
            el.attr('data-gs-locked', node.locked ? 'yes' : null);                                                     // 1328
        });                                                                                                            // 1329
        return this;                                                                                                   // 1330
    };                                                                                                                 // 1331
                                                                                                                       //
    GridStack.prototype.maxHeight = function (el, val) {                                                               // 1333
        el = $(el);                                                                                                    // 1334
        el.each(function (index, el) {                                                                                 // 1335
            el = $(el);                                                                                                // 1336
            var node = el.data('_gridstack_node');                                                                     // 1337
            if (typeof node === 'undefined' || node === null) {                                                        // 1338
                return;                                                                                                // 1339
            }                                                                                                          // 1340
                                                                                                                       //
            if (!isNaN(val)) {                                                                                         // 1342
                node.maxHeight = val || false;                                                                         // 1343
                el.attr('data-gs-max-height', val);                                                                    // 1344
            }                                                                                                          // 1345
        });                                                                                                            // 1346
        return this;                                                                                                   // 1347
    };                                                                                                                 // 1348
                                                                                                                       //
    GridStack.prototype.minHeight = function (el, val) {                                                               // 1350
        el = $(el);                                                                                                    // 1351
        el.each(function (index, el) {                                                                                 // 1352
            el = $(el);                                                                                                // 1353
            var node = el.data('_gridstack_node');                                                                     // 1354
            if (typeof node === 'undefined' || node === null) {                                                        // 1355
                return;                                                                                                // 1356
            }                                                                                                          // 1357
                                                                                                                       //
            if (!isNaN(val)) {                                                                                         // 1359
                node.minHeight = val || false;                                                                         // 1360
                el.attr('data-gs-min-height', val);                                                                    // 1361
            }                                                                                                          // 1362
        });                                                                                                            // 1363
        return this;                                                                                                   // 1364
    };                                                                                                                 // 1365
                                                                                                                       //
    GridStack.prototype.maxWidth = function (el, val) {                                                                // 1367
        el = $(el);                                                                                                    // 1368
        el.each(function (index, el) {                                                                                 // 1369
            el = $(el);                                                                                                // 1370
            var node = el.data('_gridstack_node');                                                                     // 1371
            if (typeof node === 'undefined' || node === null) {                                                        // 1372
                return;                                                                                                // 1373
            }                                                                                                          // 1374
                                                                                                                       //
            if (!isNaN(val)) {                                                                                         // 1376
                node.maxWidth = val || false;                                                                          // 1377
                el.attr('data-gs-max-width', val);                                                                     // 1378
            }                                                                                                          // 1379
        });                                                                                                            // 1380
        return this;                                                                                                   // 1381
    };                                                                                                                 // 1382
                                                                                                                       //
    GridStack.prototype.minWidth = function (el, val) {                                                                // 1384
        el = $(el);                                                                                                    // 1385
        el.each(function (index, el) {                                                                                 // 1386
            el = $(el);                                                                                                // 1387
            var node = el.data('_gridstack_node');                                                                     // 1388
            if (typeof node === 'undefined' || node === null) {                                                        // 1389
                return;                                                                                                // 1390
            }                                                                                                          // 1391
                                                                                                                       //
            if (!isNaN(val)) {                                                                                         // 1393
                node.minWidth = val || false;                                                                          // 1394
                el.attr('data-gs-min-width', val);                                                                     // 1395
            }                                                                                                          // 1396
        });                                                                                                            // 1397
        return this;                                                                                                   // 1398
    };                                                                                                                 // 1399
                                                                                                                       //
    GridStack.prototype._updateElement = function (el, callback) {                                                     // 1401
        el = $(el).first();                                                                                            // 1402
        var node = el.data('_gridstack_node');                                                                         // 1403
        if (typeof node == 'undefined' || node === null) {                                                             // 1404
            return;                                                                                                    // 1405
        }                                                                                                              // 1406
                                                                                                                       //
        var self = this;                                                                                               // 1408
                                                                                                                       //
        self.grid.cleanNodes();                                                                                        // 1410
        self.grid.beginUpdate(node);                                                                                   // 1411
                                                                                                                       //
        callback.call(this, el, node);                                                                                 // 1413
                                                                                                                       //
        self._updateContainerHeight();                                                                                 // 1415
        self._triggerChangeEvent();                                                                                    // 1416
                                                                                                                       //
        self.grid.endUpdate();                                                                                         // 1418
    };                                                                                                                 // 1419
                                                                                                                       //
    GridStack.prototype.resize = function (el, width, height) {                                                        // 1421
        this._updateElement(el, function (el, node) {                                                                  // 1422
            width = width !== null && typeof width != 'undefined' ? width : node.width;                                // 1423
            height = height !== null && typeof height != 'undefined' ? height : node.height;                           // 1424
            this.grid.moveNode(node, node.x, node.y, width, height);                                                   // 1425
        });                                                                                                            // 1426
    };                                                                                                                 // 1427
                                                                                                                       //
    GridStack.prototype.move = function (el, x, y) {                                                                   // 1429
        this._updateElement(el, function (el, node) {                                                                  // 1430
            x = x !== null && typeof x != 'undefined' ? x : node.x;                                                    // 1431
            y = y !== null && typeof y != 'undefined' ? y : node.y;                                                    // 1432
                                                                                                                       //
            this.grid.moveNode(node, x, y, node.width, node.height);                                                   // 1434
        });                                                                                                            // 1435
    };                                                                                                                 // 1436
                                                                                                                       //
    GridStack.prototype.update = function (el, x, y, width, height) {                                                  // 1438
        this._updateElement(el, function (el, node) {                                                                  // 1439
            x = x !== null && typeof x != 'undefined' ? x : node.x;                                                    // 1440
            y = y !== null && typeof y != 'undefined' ? y : node.y;                                                    // 1441
            width = width !== null && typeof width != 'undefined' ? width : node.width;                                // 1442
            height = height !== null && typeof height != 'undefined' ? height : node.height;                           // 1443
                                                                                                                       //
            this.grid.moveNode(node, x, y, width, height);                                                             // 1445
        });                                                                                                            // 1446
    };                                                                                                                 // 1447
                                                                                                                       //
    GridStack.prototype.verticalMargin = function (val, noUpdate) {                                                    // 1449
        if (typeof val == 'undefined') {                                                                               // 1450
            return this.opts.verticalMargin;                                                                           // 1451
        }                                                                                                              // 1452
                                                                                                                       //
        var heightData = Utils.parseHeight(val);                                                                       // 1454
                                                                                                                       //
        if (this.opts.verticalMarginUnit === heightData.unit && this.opts.height === heightData.height) {              // 1456
            return;                                                                                                    // 1457
        }                                                                                                              // 1458
        this.opts.verticalMarginUnit = heightData.unit;                                                                // 1459
        this.opts.verticalMargin = heightData.height;                                                                  // 1460
                                                                                                                       //
        if (!noUpdate) {                                                                                               // 1462
            this._updateStyles();                                                                                      // 1463
        }                                                                                                              // 1464
    };                                                                                                                 // 1465
                                                                                                                       //
    GridStack.prototype.cellHeight = function (val, noUpdate) {                                                        // 1467
        if (typeof val == 'undefined') {                                                                               // 1468
            if (this.opts.cellHeight) {                                                                                // 1469
                return this.opts.cellHeight;                                                                           // 1470
            }                                                                                                          // 1471
            var o = this.container.children('.' + this.opts.itemClass).first();                                        // 1472
            return Math.ceil(o.outerHeight() / o.attr('data-gs-height'));                                              // 1473
        }                                                                                                              // 1474
        var heightData = Utils.parseHeight(val);                                                                       // 1475
                                                                                                                       //
        if (this.opts.cellHeightUnit === heightData.heightUnit && this.opts.height === heightData.height) {            // 1477
            return;                                                                                                    // 1478
        }                                                                                                              // 1479
        this.opts.cellHeightUnit = heightData.unit;                                                                    // 1480
        this.opts.cellHeight = heightData.height;                                                                      // 1481
                                                                                                                       //
        if (!noUpdate) {                                                                                               // 1483
            this._updateStyles();                                                                                      // 1484
        }                                                                                                              // 1485
    };                                                                                                                 // 1487
                                                                                                                       //
    GridStack.prototype.cellWidth = function () {                                                                      // 1489
        var o = this.container.children('.' + this.opts.itemClass).first();                                            // 1490
        return Math.ceil(o.outerWidth() / parseInt(o.attr('data-gs-width'), 10));                                      // 1491
    };                                                                                                                 // 1492
                                                                                                                       //
    GridStack.prototype.getCellFromPixel = function (position, useOffset) {                                            // 1494
        var containerPos = typeof useOffset != 'undefined' && useOffset ? this.container.offset() : this.container.position();
        var relativeLeft = position.left - containerPos.left;                                                          // 1497
        var relativeTop = position.top - containerPos.top;                                                             // 1498
                                                                                                                       //
        var columnWidth = Math.floor(this.container.width() / this.opts.width);                                        // 1500
        var rowHeight = Math.floor(this.container.height() / parseInt(this.container.attr('data-gs-current-height')));
                                                                                                                       //
        return { x: Math.floor(relativeLeft / columnWidth), y: Math.floor(relativeTop / rowHeight) };                  // 1503
    };                                                                                                                 // 1504
                                                                                                                       //
    GridStack.prototype.batchUpdate = function () {                                                                    // 1506
        this.grid.batchUpdate();                                                                                       // 1507
    };                                                                                                                 // 1508
                                                                                                                       //
    GridStack.prototype.commit = function () {                                                                         // 1510
        this.grid.commit();                                                                                            // 1511
        this._updateContainerHeight();                                                                                 // 1512
    };                                                                                                                 // 1513
                                                                                                                       //
    GridStack.prototype.isAreaEmpty = function (x, y, width, height) {                                                 // 1515
        return this.grid.isAreaEmpty(x, y, width, height);                                                             // 1516
    };                                                                                                                 // 1517
                                                                                                                       //
    GridStack.prototype.setStatic = function (staticValue) {                                                           // 1519
        this.opts.staticGrid = staticValue === true;                                                                   // 1520
        this.enableMove(!staticValue);                                                                                 // 1521
        this.enableResize(!staticValue);                                                                               // 1522
        this._setStaticClass();                                                                                        // 1523
    };                                                                                                                 // 1524
                                                                                                                       //
    GridStack.prototype._setStaticClass = function () {                                                                // 1526
        var staticClassName = 'grid-stack-static';                                                                     // 1527
                                                                                                                       //
        if (this.opts.staticGrid === true) {                                                                           // 1529
            this.container.addClass(staticClassName);                                                                  // 1530
        } else {                                                                                                       // 1531
            this.container.removeClass(staticClassName);                                                               // 1532
        }                                                                                                              // 1533
    };                                                                                                                 // 1534
                                                                                                                       //
    GridStack.prototype._updateNodeWidths = function (oldWidth, newWidth) {                                            // 1536
        this.grid._sortNodes();                                                                                        // 1537
        this.grid.batchUpdate();                                                                                       // 1538
        var node = {};                                                                                                 // 1539
        for (var i = 0; i < this.grid.nodes.length; i++) {                                                             // 1540
            node = this.grid.nodes[i];                                                                                 // 1541
            this.update(node.el, Math.round(node.x * newWidth / oldWidth), undefined, Math.round(node.width * newWidth / oldWidth), undefined);
        }                                                                                                              // 1544
        this.grid.commit();                                                                                            // 1545
    };                                                                                                                 // 1546
                                                                                                                       //
    GridStack.prototype.setGridWidth = function (gridWidth, doNotPropagate) {                                          // 1548
        this.container.removeClass('grid-stack-' + this.opts.width);                                                   // 1549
        if (doNotPropagate !== true) {                                                                                 // 1550
            this._updateNodeWidths(this.opts.width, gridWidth);                                                        // 1551
        }                                                                                                              // 1552
        this.opts.width = gridWidth;                                                                                   // 1553
        this.grid.width = gridWidth;                                                                                   // 1554
        this.container.addClass('grid-stack-' + gridWidth);                                                            // 1555
    };                                                                                                                 // 1556
                                                                                                                       //
    // jscs:disable requireCamelCaseOrUpperCaseIdentifiers                                                             // 1558
    GridStackEngine.prototype.batch_update = obsolete(GridStackEngine.prototype.batchUpdate);                          // 1559
    GridStackEngine.prototype._fix_collisions = obsolete(GridStackEngine.prototype._fixCollisions, '_fix_collisions', '_fixCollisions');
    GridStackEngine.prototype.is_area_empty = obsolete(GridStackEngine.prototype.isAreaEmpty, 'is_area_empty', 'isAreaEmpty');
    GridStackEngine.prototype._sort_nodes = obsolete(GridStackEngine.prototype._sortNodes, '_sort_nodes', '_sortNodes');
    GridStackEngine.prototype._pack_nodes = obsolete(GridStackEngine.prototype._packNodes, '_pack_nodes', '_packNodes');
    GridStackEngine.prototype._prepare_node = obsolete(GridStackEngine.prototype._prepareNode, '_prepare_node', '_prepareNode');
    GridStackEngine.prototype.clean_nodes = obsolete(GridStackEngine.prototype.cleanNodes, 'clean_nodes', 'cleanNodes');
    GridStackEngine.prototype.get_dirty_nodes = obsolete(GridStackEngine.prototype.getDirtyNodes, 'get_dirty_nodes', 'getDirtyNodes');
    GridStackEngine.prototype.add_node = obsolete(GridStackEngine.prototype.addNode, 'add_node', 'addNode, ');         // 1574
    GridStackEngine.prototype.remove_node = obsolete(GridStackEngine.prototype.removeNode, 'remove_node', 'removeNode');
    GridStackEngine.prototype.can_move_node = obsolete(GridStackEngine.prototype.canMoveNode, 'can_move_node', 'canMoveNode');
    GridStackEngine.prototype.move_node = obsolete(GridStackEngine.prototype.moveNode, 'move_node', 'moveNode');       // 1580
    GridStackEngine.prototype.get_grid_height = obsolete(GridStackEngine.prototype.getGridHeight, 'get_grid_height', 'getGridHeight');
    GridStackEngine.prototype.begin_update = obsolete(GridStackEngine.prototype.beginUpdate, 'begin_update', 'beginUpdate');
    GridStackEngine.prototype.end_update = obsolete(GridStackEngine.prototype.endUpdate, 'end_update', 'endUpdate');   // 1586
    GridStackEngine.prototype.can_be_placed_with_respect_to_height = obsolete(GridStackEngine.prototype.canBePlacedWithRespectToHeight, 'can_be_placed_with_respect_to_height', 'canBePlacedWithRespectToHeight');
    GridStack.prototype._trigger_change_event = obsolete(GridStack.prototype._triggerChangeEvent, '_trigger_change_event', '_triggerChangeEvent');
    GridStack.prototype._init_styles = obsolete(GridStack.prototype._initStyles, '_init_styles', '_initStyles');       // 1593
    GridStack.prototype._update_styles = obsolete(GridStack.prototype._updateStyles, '_update_styles', '_updateStyles');
    GridStack.prototype._update_container_height = obsolete(GridStack.prototype._updateContainerHeight, '_update_container_height', '_updateContainerHeight');
    GridStack.prototype._is_one_column_mode = obsolete(GridStack.prototype._isOneColumnMode, '_is_one_column_mode', '_isOneColumnMode');
    GridStack.prototype._prepare_element = obsolete(GridStack.prototype._prepareElement, '_prepare_element', '_prepareElement');
    GridStack.prototype.set_animation = obsolete(GridStack.prototype.setAnimation, 'set_animation', 'setAnimation');   // 1603
    GridStack.prototype.add_widget = obsolete(GridStack.prototype.addWidget, 'add_widget', 'addWidget');               // 1605
    GridStack.prototype.make_widget = obsolete(GridStack.prototype.makeWidget, 'make_widget', 'makeWidget');           // 1607
    GridStack.prototype.will_it_fit = obsolete(GridStack.prototype.willItFit, 'will_it_fit', 'willItFit');             // 1609
    GridStack.prototype.remove_widget = obsolete(GridStack.prototype.removeWidget, 'remove_widget', 'removeWidget');   // 1611
    GridStack.prototype.remove_all = obsolete(GridStack.prototype.removeAll, 'remove_all', 'removeAll');               // 1613
    GridStack.prototype.min_height = obsolete(GridStack.prototype.minHeight, 'min_height', 'minHeight');               // 1615
    GridStack.prototype.min_width = obsolete(GridStack.prototype.minWidth, 'min_width', 'minWidth');                   // 1617
    GridStack.prototype._update_element = obsolete(GridStack.prototype._updateElement, '_update_element', '_updateElement');
    GridStack.prototype.cell_height = obsolete(GridStack.prototype.cellHeight, 'cell_height', 'cellHeight');           // 1621
    GridStack.prototype.cell_width = obsolete(GridStack.prototype.cellWidth, 'cell_width', 'cellWidth');               // 1623
    GridStack.prototype.get_cell_from_pixel = obsolete(GridStack.prototype.getCellFromPixel, 'get_cell_from_pixel', 'getCellFromPixel');
    GridStack.prototype.batch_update = obsolete(GridStack.prototype.batchUpdate, 'batch_update', 'batchUpdate');       // 1627
    GridStack.prototype.is_area_empty = obsolete(GridStack.prototype.isAreaEmpty, 'is_area_empty', 'isAreaEmpty');     // 1629
    GridStack.prototype.set_static = obsolete(GridStack.prototype.setStatic, 'set_static', 'setStatic');               // 1631
    GridStack.prototype._set_static_class = obsolete(GridStack.prototype._setStaticClass, '_set_static_class', '_setStaticClass');
    // jscs:enable requireCamelCaseOrUpperCaseIdentifiers                                                              // 1635
                                                                                                                       //
    scope.GridStackUI = GridStack;                                                                                     // 1637
                                                                                                                       //
    scope.GridStackUI.Utils = Utils;                                                                                   // 1639
    scope.GridStackUI.Engine = GridStackEngine;                                                                        // 1640
                                                                                                                       //
    $.fn.gridstack = function (opts) {                                                                                 // 1642
        return this.each(function () {                                                                                 // 1643
            var o = $(this);                                                                                           // 1644
            if (!o.data('gridstack')) {                                                                                // 1645
                o.data('gridstack', new GridStack(this, opts));                                                        // 1646
            }                                                                                                          // 1648
        });                                                                                                            // 1649
    };                                                                                                                 // 1650
                                                                                                                       //
    return scope.GridStackUI;                                                                                          // 1652
});                                                                                                                    // 1653
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"lodash.js":["babel-runtime/helpers/typeof",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// client/lib/lodash.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof;module.import("babel-runtime/helpers/typeof",{"default":function(v){_typeof=v}});                          //
/**                                                                                                                    // 1
 * @license                                                                                                            //
 * lodash lodash.com/license | Underscore.js 1.8.3 underscorejs.org/LICENSE                                            //
 */                                                                                                                    //
;(function () {                                                                                                        // 5
  function t(t, n) {                                                                                                   // 5
    return t.set(n[0], n[1]), t;                                                                                       // 5
  }function n(t, n) {                                                                                                  // 5
    return t.add(n), t;                                                                                                // 5
  }function r(t, n, r) {                                                                                               // 5
    switch (r.length) {case 0:                                                                                         // 5
        return t.call(n);case 1:                                                                                       // 5
        return t.call(n, r[0]);case 2:                                                                                 // 5
        return t.call(n, r[0], r[1]);case 3:                                                                           // 5
        return t.call(n, r[0], r[1], r[2]);}return t.apply(n, r);                                                      // 5
  }function e(t, n, r, e) {                                                                                            // 5
    for (var u = -1, o = t ? t.length : 0; ++u < o;) {                                                                 // 5
      var i = t[u];n(e, i, r(i), t);                                                                                   // 5
    }return e;                                                                                                         // 5
  }function u(t, n) {                                                                                                  // 5
    for (var r = -1, e = t ? t.length : 0; ++r < e && false !== n(t[r], r, t);) {}return t;                            // 5
  }function o(t, n) {                                                                                                  // 5
    for (var r = t ? t.length : 0; r-- && false !== n(t[r], r, t);) {}                                                 // 5
    return t;                                                                                                          // 6
  }function i(t, n) {                                                                                                  // 6
    for (var r = -1, e = t ? t.length : 0; ++r < e;) {                                                                 // 6
      if (!n(t[r], r, t)) return false;                                                                                // 6
    }return true;                                                                                                      // 6
  }function f(t, n) {                                                                                                  // 6
    for (var r = -1, e = t ? t.length : 0, u = 0, o = []; ++r < e;) {                                                  // 6
      var i = t[r];n(i, r, t) && (o[u++] = i);                                                                         // 6
    }return o;                                                                                                         // 6
  }function c(t, n) {                                                                                                  // 6
    return !(!t || !t.length) && -1 < d(t, n, 0);                                                                      // 6
  }function a(t, n, r) {                                                                                               // 6
    for (var e = -1, u = t ? t.length : 0; ++e < u;) {                                                                 // 6
      if (r(n, t[e])) return true;                                                                                     // 6
    }return false;                                                                                                     // 6
  }function l(t, n) {                                                                                                  // 6
    for (var r = -1, e = t ? t.length : 0, u = Array(e); ++r < e;) {                                                   // 6
      u[r] = n(t[r], r, t);                                                                                            // 6
    }return u;                                                                                                         // 6
  }function s(t, n) {                                                                                                  // 6
    for (var r = -1, e = n.length, u = t.length; ++r < e;) {                                                           // 6
      t[u + r] = n[r];                                                                                                 // 6
    }return t;                                                                                                         // 6
  }function h(t, n, r, e) {                                                                                            // 6
    var u = -1,                                                                                                        // 7
        o = t ? t.length : 0;for (e && o && (r = t[++u]); ++u < o;) {                                                  // 7
      r = n(r, t[u], u, t);                                                                                            // 7
    }return r;                                                                                                         // 7
  }function p(t, n, r, e) {                                                                                            // 7
    var u = t ? t.length : 0;for (e && u && (r = t[--u]); u--;) {                                                      // 7
      r = n(r, t[u], u, t);                                                                                            // 7
    }return r;                                                                                                         // 7
  }function _(t, n) {                                                                                                  // 7
    for (var r = -1, e = t ? t.length : 0; ++r < e;) {                                                                 // 7
      if (n(t[r], r, t)) return true;                                                                                  // 7
    }return false;                                                                                                     // 7
  }function v(t, n, r) {                                                                                               // 7
    var e;return r(t, function (t, r, u) {                                                                             // 7
      if (n(t, r, u)) return e = r, false;                                                                             // 7
    }), e;                                                                                                             // 7
  }function g(t, n, r, e) {                                                                                            // 7
    var u = t.length;for (r += e ? 1 : -1; e ? r-- : ++r < u;) {                                                       // 7
      if (n(t[r], r, t)) return r;                                                                                     // 7
    }return -1;                                                                                                        // 7
  }function d(t, n, r) {                                                                                               // 7
    if (n !== n) return g(t, b, r);--r;for (var e = t.length; ++r < e;) {                                              // 7
      if (t[r] === n) return r;                                                                                        // 7
    }return -1;                                                                                                        // 7
  }function y(t, n, r, e) {                                                                                            // 8
    --r;for (var u = t.length; ++r < u;) {                                                                             // 8
      if (e(t[r], n)) return r;                                                                                        // 8
    }return -1;                                                                                                        // 8
  }function b(t) {                                                                                                     // 8
    return t !== t;                                                                                                    // 8
  }function x(t, n) {                                                                                                  // 8
    var r = t ? t.length : 0;return r ? O(t, n) / r : q;                                                               // 8
  }function j(t) {                                                                                                     // 8
    return function (n) {                                                                                              // 8
      return null == n ? P : n[t];                                                                                     // 8
    };                                                                                                                 // 8
  }function w(t) {                                                                                                     // 8
    return function (n) {                                                                                              // 8
      return null == t ? P : t[n];                                                                                     // 8
    };                                                                                                                 // 8
  }function m(t, n, r, e, u) {                                                                                         // 8
    return u(t, function (t, u, o) {                                                                                   // 8
      r = e ? (e = false, t) : n(r, t, u, o);                                                                          // 8
    }), r;                                                                                                             // 8
  }function A(t, n) {                                                                                                  // 8
    var r = t.length;for (t.sort(n); r--;) {                                                                           // 8
      t[r] = t[r].c;                                                                                                   // 8
    }return t;                                                                                                         // 8
  }function O(t, n) {                                                                                                  // 8
    for (var r, e = -1, u = t.length; ++e < u;) {                                                                      // 8
      var o = n(t[e]);o !== P && (r = r === P ? o : r + o);                                                            // 8
    }return r;                                                                                                         // 9
  }function k(t, n) {                                                                                                  // 9
    for (var r = -1, e = Array(t); ++r < t;) {                                                                         // 9
      e[r] = n(r);                                                                                                     // 9
    }return e;                                                                                                         // 9
  }function E(t, n) {                                                                                                  // 9
    return l(n, function (n) {                                                                                         // 9
      return [n, t[n]];                                                                                                // 9
    });                                                                                                                // 9
  }function S(t) {                                                                                                     // 9
    return function (n) {                                                                                              // 9
      return t(n);                                                                                                     // 9
    };                                                                                                                 // 9
  }function R(t, n) {                                                                                                  // 9
    return l(n, function (n) {                                                                                         // 9
      return t[n];                                                                                                     // 9
    });                                                                                                                // 9
  }function I(t, n) {                                                                                                  // 9
    return t.has(n);                                                                                                   // 9
  }function W(t, n) {                                                                                                  // 9
    for (var r = -1, e = t.length; ++r < e && -1 < d(n, t[r], 0);) {}return r;                                         // 9
  }function B(t, n) {                                                                                                  // 9
    for (var r = t.length; r-- && -1 < d(n, t[r], 0);) {}return r;                                                     // 9
  }function M(t) {                                                                                                     // 9
    return "\\" + Tt[t];                                                                                               // 9
  }function C(t) {                                                                                                     // 9
    var n = false;if (null != t && typeof t.toString != "function") try {                                              // 9
      n = !!(t + "");                                                                                                  // 10
    } catch (t) {}return n;                                                                                            // 10
  }function L(t) {                                                                                                     // 10
    for (var n, r = []; !(n = t.next()).done;) {                                                                       // 10
      r.push(n.value);                                                                                                 // 10
    }return r;                                                                                                         // 10
  }function z(t) {                                                                                                     // 10
    var n = -1,                                                                                                        // 10
        r = Array(t.size);return t.forEach(function (t, e) {                                                           // 10
      r[++n] = [e, t];                                                                                                 // 10
    }), r;                                                                                                             // 10
  }function U(t) {                                                                                                     // 10
    var n = Object;return function (r) {                                                                               // 10
      return t(n(r));                                                                                                  // 10
    };                                                                                                                 // 10
  }function D(t, n) {                                                                                                  // 10
    for (var r = -1, e = t.length, u = 0, o = []; ++r < e;) {                                                          // 10
      var i = t[r];i !== n && "__lodash_placeholder__" !== i || (t[r] = "__lodash_placeholder__", o[u++] = r);         // 10
    }return o;                                                                                                         // 10
  }function $(t) {                                                                                                     // 10
    var n = -1,                                                                                                        // 10
        r = Array(t.size);return t.forEach(function (t) {                                                              // 10
      r[++n] = t;                                                                                                      // 10
    }), r;                                                                                                             // 10
  }function F(t) {                                                                                                     // 10
    var n = -1,                                                                                                        // 11
        r = Array(t.size);return t.forEach(function (t) {                                                              // 11
      r[++n] = [t, t];                                                                                                 // 11
    }), r;                                                                                                             // 11
  }function T(t) {                                                                                                     // 11
    if (!t || !Lt.test(t)) return t.length;for (var n = Mt.lastIndex = 0; Mt.test(t);) {                               // 11
      n++;                                                                                                             // 11
    }return n;                                                                                                         // 11
  }function N(w) {                                                                                                     // 11
    function St(t) {                                                                                                   // 11
      return Xu.call(t);                                                                                               // 11
    }function Rt(t, n) {                                                                                               // 11
      return w.setTimeout.call(Vt, t, n);                                                                              // 11
    }function It(t) {                                                                                                  // 11
      if (au(t) && !Zi(t) && !(t instanceof Zt)) {                                                                     // 11
        if (t instanceof Tt) return t;if (Yu.call(t, "__wrapped__")) return Se(t);                                     // 11
      }return new Tt(t);                                                                                               // 11
    }function Ft() {}function Tt(t, n) {                                                                               // 11
      this.__wrapped__ = t, this.__actions__ = [], this.__chain__ = !!n, this.__index__ = 0, this.__values__ = P;      // 11
    }function Zt(t) {                                                                                                  // 12
      this.__wrapped__ = t, this.__actions__ = [], this.__dir__ = 1, this.__filtered__ = false, this.__iteratees__ = [], this.__takeCount__ = 4294967295, this.__views__ = [];
    }function qt(t) {                                                                                                  // 12
      var n = -1,                                                                                                      // 12
          r = t ? t.length : 0;for (this.clear(); ++n < r;) {                                                          // 12
        var e = t[n];this.set(e[0], e[1]);                                                                             // 12
      }                                                                                                                // 12
    }function Kt(t) {                                                                                                  // 12
      var n = -1,                                                                                                      // 12
          r = t ? t.length : 0;for (this.clear(); ++n < r;) {                                                          // 12
        var e = t[n];this.set(e[0], e[1]);                                                                             // 12
      }                                                                                                                // 12
    }function Gt(t) {                                                                                                  // 12
      var n = -1,                                                                                                      // 12
          r = t ? t.length : 0;for (this.clear(); ++n < r;) {                                                          // 12
        var e = t[n];this.set(e[0], e[1]);                                                                             // 12
      }                                                                                                                // 12
    }function Yt(t) {                                                                                                  // 12
      var n = -1,                                                                                                      // 12
          r = t ? t.length : 0;                                                                                        // 12
      for (this.__data__ = new Gt(); ++n < r;) {                                                                       // 13
        this.add(t[n]);                                                                                                // 13
      }                                                                                                                // 13
    }function cn(t) {                                                                                                  // 13
      this.__data__ = new Kt(t);                                                                                       // 13
    }function an(t, n, r, e) {                                                                                         // 13
      return t === P || tu(t, qu[r]) && !Yu.call(e, r) ? n : t;                                                        // 13
    }function ln(t, n, r) {                                                                                            // 13
      (r === P || tu(t[n], r)) && (typeof n != "number" || r !== P || n in t) || (t[n] = r);                           // 13
    }function sn(t, n, r) {                                                                                            // 13
      var e = t[n];Yu.call(t, n) && tu(e, r) && (r !== P || n in t) || (t[n] = r);                                     // 13
    }function hn(t, n) {                                                                                               // 13
      for (var r = t.length; r--;) {                                                                                   // 13
        if (tu(t[r][0], n)) return r;                                                                                  // 13
      }return -1;                                                                                                      // 13
    }function pn(t, n, r, e) {                                                                                         // 13
      return Vo(t, function (t, u, o) {                                                                                // 13
        n(e, t, r(t), o);                                                                                              // 13
      }), e;                                                                                                           // 13
    }function _n(t, n) {                                                                                               // 13
      return t && Br(n, mu(n), t);                                                                                     // 13
    }                                                                                                                  // 13
    function vn(t, n) {                                                                                                // 14
      for (var r = -1, e = null == t, u = n.length, o = Du(u); ++r < u;) {                                             // 14
        o[r] = e ? P : ju(t, n[r]);                                                                                    // 14
      }return o;                                                                                                       // 14
    }function gn(t, n, r) {                                                                                            // 14
      return t === t && (r !== P && (t = t <= r ? t : r), n !== P && (t = t >= n ? t : n)), t;                         // 14
    }function dn(t, n, r, e, o, i, f) {                                                                                // 14
      var c;if (e && (c = i ? e(t, o, i, f) : e(t)), c !== P) return c;if (!cu(t)) return t;if (o = Zi(t)) {           // 14
        if (c = he(t), !n) return Wr(t, c);                                                                            // 14
      } else {                                                                                                         // 14
        var a = St(t),                                                                                                 // 14
            l = "[object Function]" == a || "[object GeneratorFunction]" == a;if (Vi(t)) return kr(t, n);if ("[object Object]" == a || "[object Arguments]" == a || l && !i) {
          if (C(t)) return i ? t : {};if (c = pe(l ? {} : t), !n) return Mr(t, _n(c, t));                              // 14
        } else {                                                                                                       // 15
          if (!$t[a]) return i ? t : {};c = _e(t, a, dn, n);                                                           // 15
        }                                                                                                              // 15
      }if (f || (f = new cn()), i = f.get(t)) return i;if (f.set(t, c), !o) var s = r ? Wn(t, mu, ri) : mu(t);return u(s || t, function (u, o) {
        s && (o = u, u = t[o]), sn(c, o, dn(u, n, r, e, o, t, f));                                                     // 15
      }), c;                                                                                                           // 15
    }function yn(t) {                                                                                                  // 15
      var n = mu(t);return function (r) {                                                                              // 15
        return bn(r, t, n);                                                                                            // 15
      };                                                                                                               // 15
    }function bn(t, n, r) {                                                                                            // 15
      var e = r.length;if (null == t) return !e;for (; e--;) {                                                         // 15
        var u = r[e],                                                                                                  // 15
            o = n[u],                                                                                                  // 15
            i = t[u];if (i === P && !(u in Object(t)) || !o(i)) return false;                                          // 15
      }return true;                                                                                                    // 15
    }function xn(t) {                                                                                                  // 15
      return cu(t) ? co(t) : {};                                                                                       // 15
    }function jn(t, n, r) {                                                                                            // 15
      if (typeof t != "function") throw new Pu("Expected a function");                                                 // 15
      return Rt(function () {                                                                                          // 16
        t.apply(P, r);                                                                                                 // 16
      }, n);                                                                                                           // 16
    }function wn(t, n, r, e) {                                                                                         // 16
      var u = -1,                                                                                                      // 16
          o = c,                                                                                                       // 16
          i = true,                                                                                                    // 16
          f = t.length,                                                                                                // 16
          s = [],                                                                                                      // 16
          h = n.length;if (!f) return s;r && (n = l(n, S(r))), e ? (o = a, i = false) : 200 <= n.length && (o = I, i = false, n = new Yt(n));t: for (; ++u < f;) {
        var p = t[u],                                                                                                  // 16
            _ = r ? r(p) : p,                                                                                          // 16
            p = e || 0 !== p ? p : 0;if (i && _ === _) {                                                               // 16
          for (var v = h; v--;) {                                                                                      // 16
            if (n[v] === _) continue t;                                                                                // 16
          }s.push(p);                                                                                                  // 16
        } else o(n, _, e) || s.push(p);                                                                                // 16
      }return s;                                                                                                       // 16
    }function mn(t, n) {                                                                                               // 16
      var r = true;return Vo(t, function (t, e, u) {                                                                   // 16
        return r = !!n(t, e, u);                                                                                       // 16
      }), r;                                                                                                           // 16
    }function An(t, n, r) {                                                                                            // 16
      for (var e = -1, u = t.length; ++e < u;) {                                                                       // 16
        var o = t[e],                                                                                                  // 16
            i = n(o);if (null != i && (f === P ? i === i && !pu(i) : r(i, f))) var f = i,                              // 16
            c = o;                                                                                                     // 16
      }return c;                                                                                                       // 17
    }function On(t, n) {                                                                                               // 17
      var r = [];return Vo(t, function (t, e, u) {                                                                     // 17
        n(t, e, u) && r.push(t);                                                                                       // 17
      }), r;                                                                                                           // 17
    }function kn(t, n, r, e, u) {                                                                                      // 17
      var o = -1,                                                                                                      // 17
          i = t.length;for (r || (r = ge), u || (u = []); ++o < i;) {                                                  // 17
        var f = t[o];0 < n && r(f) ? 1 < n ? kn(f, n - 1, r, e, u) : s(u, f) : e || (u[u.length] = f);                 // 17
      }return u;                                                                                                       // 17
    }function En(t, n) {                                                                                               // 17
      return t && Go(t, n, mu);                                                                                        // 17
    }function Sn(t, n) {                                                                                               // 17
      return t && Jo(t, n, mu);                                                                                        // 17
    }function Rn(t, n) {                                                                                               // 17
      return f(n, function (n) {                                                                                       // 17
        return ou(t[n]);                                                                                               // 17
      });                                                                                                              // 17
    }function In(t, n) {                                                                                               // 17
      n = be(n, t) ? [n] : Ar(n);for (var r = 0, e = n.length; null != t && r < e;) {                                  // 17
        t = t[Oe(n[r++])];                                                                                             // 17
      }return r && r == e ? t : P;                                                                                     // 17
    }function Wn(t, n, r) {                                                                                            // 17
      return n = n(t), Zi(t) ? n : s(n, r(t));                                                                         // 18
    }function Bn(t, n) {                                                                                               // 18
      return t > n;                                                                                                    // 18
    }function Mn(t, n) {                                                                                               // 18
      return null != t && (Yu.call(t, n) || (typeof t === "undefined" ? "undefined" : _typeof(t)) == "object" && n in t && null === ni(t));
    }function Cn(t, n) {                                                                                               // 18
      return null != t && n in Object(t);                                                                              // 18
    }function Ln(t, n, r) {                                                                                            // 18
      for (var e = r ? a : c, u = t[0].length, o = t.length, i = o, f = Du(o), s = 1 / 0, h = []; i--;) {              // 18
        var p = t[i];i && n && (p = l(p, S(n))), s = wo(p.length, s), f[i] = !r && (n || 120 <= u && 120 <= p.length) ? new Yt(i && p) : P;
      }var p = t[0],                                                                                                   // 18
          _ = -1,                                                                                                      // 18
          v = f[0];t: for (; ++_ < u && h.length < s;) {                                                               // 18
        var g = p[_],                                                                                                  // 18
            d = n ? n(g) : g,                                                                                          // 18
            g = r || 0 !== g ? g : 0;if (v ? !I(v, d) : !e(h, d, r)) {                                                 // 18
          for (i = o; --i;) {                                                                                          // 18
            var y = f[i];if (y ? !I(y, d) : !e(t[i], d, r)) continue t;                                                // 19
          }v && v.push(d), h.push(g);                                                                                  // 19
        }                                                                                                              // 19
      }return h;                                                                                                       // 19
    }function zn(t, n, r) {                                                                                            // 19
      var e = {};return En(t, function (t, u, o) {                                                                     // 19
        n(e, r(t), u, o);                                                                                              // 19
      }), e;                                                                                                           // 19
    }function Un(t, n, e) {                                                                                            // 19
      return be(n, t) || (n = Ar(n), t = Ae(t, n), n = Ce(n)), n = null == t ? t : t[Oe(n)], null == n ? P : r(n, t, e);
    }function Dn(t) {                                                                                                  // 19
      return au(t) && "[object ArrayBuffer]" == Xu.call(t);                                                            // 19
    }function $n(t) {                                                                                                  // 19
      return au(t) && "[object Date]" == Xu.call(t);                                                                   // 19
    }function Fn(t, n, r, e, u) {                                                                                      // 19
      if (t === n) n = true;else if (null == t || null == n || !cu(t) && !au(n)) n = t !== t && n !== n;else t: {      // 19
        var o = Zi(t),                                                                                                 // 19
            i = Zi(n),                                                                                                 // 19
            f = "[object Array]",                                                                                      // 19
            c = "[object Array]";                                                                                      // 19
        o || (f = St(t), f = "[object Arguments]" == f ? "[object Object]" : f), i || (c = St(n), c = "[object Arguments]" == c ? "[object Object]" : c);var a = "[object Object]" == f && !C(t),
            i = "[object Object]" == c && !C(n);if ((c = f == c) && !a) u || (u = new cn()), n = o || Hi(t) ? ee(t, n, Fn, r, e, u) : ue(t, n, f, Fn, r, e, u);else {
          if (!(2 & e) && (o = a && Yu.call(t, "__wrapped__"), f = i && Yu.call(n, "__wrapped__"), o || f)) {          // 20
            t = o ? t.value() : t, n = f ? n.value() : n, u || (u = new cn()), n = Fn(t, n, r, e, u);break t;          // 20
          }if (c) {                                                                                                    // 20
            n: if (u || (u = new cn()), o = 2 & e, f = mu(t), i = f.length, c = mu(n).length, i == c || o) {           // 20
              for (a = i; a--;) {                                                                                      // 20
                var l = f[a];                                                                                          // 20
                if (!(o ? l in n : Mn(n, l))) {                                                                        // 21
                  n = false;break n;                                                                                   // 21
                }                                                                                                      // 21
              }if ((c = u.get(t)) && u.get(n)) n = c == n;else {                                                       // 21
                c = true, u.set(t, n), u.set(n, t);for (var s = o; ++a < i;) {                                         // 21
                  var l = f[a],                                                                                        // 21
                      h = t[l],                                                                                        // 21
                      p = n[l];if (r) var _ = o ? r(p, h, l, n, t, u) : r(h, p, l, t, n, u);if (_ === P ? h !== p && !Fn(h, p, r, e, u) : !_) {
                    c = false;break;                                                                                   // 21
                  }s || (s = "constructor" == l);                                                                      // 21
                }c && !s && (r = t.constructor, e = n.constructor, r != e && "constructor" in t && "constructor" in n && !(typeof r == "function" && r instanceof r && typeof e == "function" && e instanceof e) && (c = false)), u["delete"](t), u["delete"](n), n = c;
              }                                                                                                        // 21
            } else n = false;                                                                                          // 21
          } else n = false;                                                                                            // 20
        }                                                                                                              // 21
      }return n;                                                                                                       // 21
    }function Tn(t) {                                                                                                  // 21
      return au(t) && "[object Map]" == St(t);                                                                         // 22
    }function Nn(t, n, r, e) {                                                                                         // 22
      var u = r.length,                                                                                                // 22
          o = u,                                                                                                       // 22
          i = !e;if (null == t) return !o;for (t = Object(t); u--;) {                                                  // 22
        var f = r[u];if (i && f[2] ? f[1] !== t[f[0]] : !(f[0] in t)) return false;                                    // 22
      }for (; ++u < o;) {                                                                                              // 22
        var f = r[u],                                                                                                  // 22
            c = f[0],                                                                                                  // 22
            a = t[c],                                                                                                  // 22
            l = f[1];if (i && f[2]) {                                                                                  // 22
          if (a === P && !(c in t)) return false;                                                                      // 22
        } else {                                                                                                       // 22
          if (f = new cn(), e) var s = e(a, l, c, t, n, f);if (s === P ? !Fn(l, a, e, 3, f) : !s) return false;        // 22
        }                                                                                                              // 22
      }return true;                                                                                                    // 22
    }function Pn(t) {                                                                                                  // 22
      return !(!cu(t) || Gu && Gu in t) && (ou(t) || C(t) ? no : wt).test(ke(t));                                      // 22
    }function Zn(t) {                                                                                                  // 22
      return cu(t) && "[object RegExp]" == Xu.call(t);                                                                 // 22
    }function qn(t) {                                                                                                  // 22
      return au(t) && "[object Set]" == St(t);                                                                         // 23
    }function Vn(t) {                                                                                                  // 23
      return au(t) && fu(t.length) && !!Dt[Xu.call(t)];                                                                // 23
    }function Kn(t) {                                                                                                  // 23
      return typeof t == "function" ? t : null == t ? Wu : (typeof t === "undefined" ? "undefined" : _typeof(t)) == "object" ? Zi(t) ? Qn(t[0], t[1]) : Hn(t) : Lu(t);
    }function Gn(t) {                                                                                                  // 23
      t = null == t ? t : Object(t);var n,                                                                             // 23
          r = [];for (n in meteorBabelHelpers.sanitizeForInObject(t)) {                                                // 23
        r.push(n);                                                                                                     // 23
      }return r;                                                                                                       // 23
    }function Jn(t, n) {                                                                                               // 23
      return t < n;                                                                                                    // 23
    }function Yn(t, n) {                                                                                               // 23
      var r = -1,                                                                                                      // 23
          e = ru(t) ? Du(t.length) : [];return Vo(t, function (t, u, o) {                                              // 23
        e[++r] = n(t, u, o);                                                                                           // 23
      }), e;                                                                                                           // 23
    }function Hn(t) {                                                                                                  // 23
      var n = ae(t);return 1 == n.length && n[0][2] ? we(n[0][0], n[0][1]) : function (r) {                            // 23
        return r === t || Nn(r, t, n);                                                                                 // 23
      };                                                                                                               // 24
    }function Qn(t, n) {                                                                                               // 24
      return be(t) && n === n && !cu(n) ? we(Oe(t), n) : function (r) {                                                // 24
        var e = ju(r, t);return e === P && e === n ? wu(r, t) : Fn(n, e, P, 3);                                        // 24
      };                                                                                                               // 24
    }function Xn(t, n, r, e, o) {                                                                                      // 24
      if (t !== n) {                                                                                                   // 24
        if (!Zi(n) && !Hi(n)) var i = Au(n);u(i || n, function (u, f) {                                                // 24
          if (i && (f = u, u = n[f]), cu(u)) {                                                                         // 24
            o || (o = new cn());var c = f,                                                                             // 24
                a = o,                                                                                                 // 24
                l = t[c],                                                                                              // 24
                s = n[c],                                                                                              // 24
                h = a.get(s);if (h) ln(t, c, h);else {                                                                 // 24
              var h = e ? e(l, s, c + "", t, n, a) : P,                                                                // 24
                  p = h === P;p && (h = s, Zi(s) || Hi(s) ? Zi(l) ? h = l : eu(l) ? h = Wr(l) : (p = false, h = dn(s, true)) : su(s) || nu(s) ? nu(l) ? h = bu(l) : !cu(l) || r && ou(l) ? (p = false, h = dn(s, true)) : h = l : p = false), p && (a.set(s, h), Xn(h, s, r, e, a), a["delete"](s)), ln(t, c, h);
            }                                                                                                          // 25
          } else c = e ? e(t[f], u, f + "", t, n, o) : P, c === P && (c = u), ln(t, f, c);                             // 25
        });                                                                                                            // 25
      }                                                                                                                // 25
    }function tr(t, n) {                                                                                               // 25
      var r = t.length;if (r) return n += 0 > n ? r : 0, de(n, r) ? t[n] : P;                                          // 25
    }function nr(t, n, r) {                                                                                            // 25
      var e = -1;return n = l(n.length ? n : [Wu], S(fe())), t = Yn(t, function (t) {                                  // 25
        return { a: l(n, function (n) {                                                                                // 25
            return n(t);                                                                                               // 25
          }), b: ++e, c: t };                                                                                          // 25
      }), A(t, function (t, n) {                                                                                       // 25
        var e;t: {                                                                                                     // 25
          e = -1;for (var u = t.a, o = n.a, i = u.length, f = r.length; ++e < i;) {                                    // 25
            var c = Sr(u[e], o[e]);if (c) {                                                                            // 25
              e = e >= f ? c : c * ("desc" == r[e] ? -1 : 1);break t;                                                  // 25
            }                                                                                                          // 25
          }e = t.b - n.b;                                                                                              // 25
        }return e;                                                                                                     // 25
      });                                                                                                              // 25
    }function rr(t, n) {                                                                                               // 25
      return t = Object(t), er(t, n, function (n, r) {                                                                 // 25
        return r in t;                                                                                                 // 26
      });                                                                                                              // 26
    }function er(t, n, r) {                                                                                            // 26
      for (var e = -1, u = n.length, o = {}; ++e < u;) {                                                               // 26
        var i = n[e],                                                                                                  // 26
            f = t[i];r(f, i) && (o[i] = f);                                                                            // 26
      }return o;                                                                                                       // 26
    }function ur(t) {                                                                                                  // 26
      return function (n) {                                                                                            // 26
        return In(n, t);                                                                                               // 26
      };                                                                                                               // 26
    }function or(t, n, r, e) {                                                                                         // 26
      var u = e ? y : d,                                                                                               // 26
          o = -1,                                                                                                      // 26
          i = n.length,                                                                                                // 26
          f = t;for (t === n && (n = Wr(n)), r && (f = l(t, S(r))); ++o < i;) {                                        // 26
        for (var c = 0, a = n[o], a = r ? r(a) : a; -1 < (c = u(f, a, c, e));) {                                       // 26
          f !== t && lo.call(f, c, 1), lo.call(t, c, 1);                                                               // 26
        }                                                                                                              // 26
      }return t;                                                                                                       // 26
    }function ir(t, n) {                                                                                               // 26
      for (var r = t ? n.length : 0, e = r - 1; r--;) {                                                                // 26
        var u = n[r];if (r == e || u !== o) {                                                                          // 26
          var o = u;if (de(u)) lo.call(t, u, 1);else if (be(u, t)) delete t[Oe(u)];else {                              // 26
            var u = Ar(u),                                                                                             // 27
                i = Ae(t, u);null != i && delete i[Oe(Ce(u))];                                                         // 27
          }                                                                                                            // 27
        }                                                                                                              // 27
      }                                                                                                                // 27
    }function fr(t, n) {                                                                                               // 27
      return t + po(Ao() * (n - t + 1));                                                                               // 27
    }function cr(t, n) {                                                                                               // 27
      var r = "";if (!t || 1 > n || 9007199254740991 < n) return r;do {                                                // 27
        n % 2 && (r += t), (n = po(n / 2)) && (t += t);                                                                // 27
      } while (n);return r;                                                                                            // 27
    }function ar(t, n) {                                                                                               // 27
      return n = jo(n === P ? t.length - 1 : n, 0), function () {                                                      // 27
        for (var e = arguments, u = -1, o = jo(e.length - n, 0), i = Du(o); ++u < o;) {                                // 27
          i[u] = e[n + u];                                                                                             // 27
        }for (u = -1, o = Du(n + 1); ++u < n;) {                                                                       // 27
          o[u] = e[u];                                                                                                 // 27
        }return o[n] = i, r(t, this, o);                                                                               // 27
      };                                                                                                               // 27
    }function lr(t, n, r, e) {                                                                                         // 27
      n = be(n, t) ? [n] : Ar(n);for (var u = -1, o = n.length, i = o - 1, f = t; null != f && ++u < o;) {             // 27
        var c = Oe(n[u]);if (cu(f)) {                                                                                  // 28
          var a = r;if (u != i) {                                                                                      // 28
            var l = f[c],                                                                                              // 28
                a = e ? e(l, c, f) : P;a === P && (a = null == l ? de(n[u + 1]) ? [] : {} : l);                        // 28
          }sn(f, c, a);                                                                                                // 28
        }f = f[c];                                                                                                     // 28
      }return t;                                                                                                       // 28
    }function sr(t, n, r) {                                                                                            // 28
      var e = -1,                                                                                                      // 28
          u = t.length;for (0 > n && (n = -n > u ? 0 : u + n), r = r > u ? u : r, 0 > r && (r += u), u = n > r ? 0 : r - n >>> 0, n >>>= 0, r = Du(u); ++e < u;) {
        r[e] = t[e + n];                                                                                               // 28
      }return r;                                                                                                       // 28
    }function hr(t, n) {                                                                                               // 28
      var r;return Vo(t, function (t, e, u) {                                                                          // 28
        return r = n(t, e, u), !r;                                                                                     // 28
      }), !!r;                                                                                                         // 28
    }function pr(t, n, r) {                                                                                            // 28
      var e = 0,                                                                                                       // 28
          u = t ? t.length : e;if (typeof n == "number" && n === n && 2147483647 >= u) {                               // 28
        for (; e < u;) {                                                                                               // 28
          var o = e + u >>> 1,                                                                                         // 28
              i = t[o];null !== i && !pu(i) && (r ? i <= n : i < n) ? e = o + 1 : u = o;                               // 28
        }return u;                                                                                                     // 29
      }return _r(t, n, Wu, r);                                                                                         // 29
    }function _r(t, n, r, e) {                                                                                         // 29
      n = r(n);for (var u = 0, o = t ? t.length : 0, i = n !== n, f = null === n, c = pu(n), a = n === P; u < o;) {    // 29
        var l = po((u + o) / 2),                                                                                       // 29
            s = r(t[l]),                                                                                               // 29
            h = s !== P,                                                                                               // 29
            p = null === s,                                                                                            // 29
            _ = s === s,                                                                                               // 29
            v = pu(s);(i ? e || _ : a ? _ && (e || h) : f ? _ && h && (e || !p) : c ? _ && h && !p && (e || !v) : p || v ? 0 : e ? s <= n : s < n) ? u = l + 1 : o = l;
      }return wo(o, 4294967294);                                                                                       // 29
    }function vr(t, n) {                                                                                               // 29
      for (var r = -1, e = t.length, u = 0, o = []; ++r < e;) {                                                        // 29
        var i = t[r],                                                                                                  // 29
            f = n ? n(i) : i;if (!r || !tu(f, c)) {                                                                    // 29
          var c = f;o[u++] = 0 === i ? 0 : i;                                                                          // 29
        }                                                                                                              // 29
      }return o;                                                                                                       // 29
    }function gr(t) {                                                                                                  // 29
      return typeof t == "number" ? t : pu(t) ? q : +t;                                                                // 29
    }function dr(t) {                                                                                                  // 29
      if (typeof t == "string") return t;                                                                              // 29
      if (pu(t)) return qo ? qo.call(t) : "";var n = t + "";return "0" == n && 1 / t == -Z ? "-0" : n;                 // 30
    }function yr(t, n, r) {                                                                                            // 30
      var e = -1,                                                                                                      // 30
          u = c,                                                                                                       // 30
          o = t.length,                                                                                                // 30
          i = true,                                                                                                    // 30
          f = [],                                                                                                      // 30
          l = f;if (r) i = false, u = a;else if (200 <= o) {                                                           // 30
        if (u = n ? null : Qo(t)) return $(u);i = false, u = I, l = new Yt();                                          // 30
      } else l = n ? [] : f;t: for (; ++e < o;) {                                                                      // 30
        var s = t[e],                                                                                                  // 30
            h = n ? n(s) : s,                                                                                          // 30
            s = r || 0 !== s ? s : 0;if (i && h === h) {                                                               // 30
          for (var p = l.length; p--;) {                                                                               // 30
            if (l[p] === h) continue t;                                                                                // 30
          }n && l.push(h), f.push(s);                                                                                  // 30
        } else u(l, h, r) || (l !== f && l.push(h), f.push(s));                                                        // 30
      }return f;                                                                                                       // 30
    }function br(t, n, r, e) {                                                                                         // 30
      for (var u = t.length, o = e ? u : -1; (e ? o-- : ++o < u) && n(t[o], o, t);) {}return r ? sr(t, e ? 0 : o, e ? o + 1 : u) : sr(t, e ? o + 1 : 0, e ? u : o);
    }function xr(t, n) {                                                                                               // 31
      var r = t;return r instanceof Zt && (r = r.value()), h(n, function (t, n) {                                      // 31
        return n.func.apply(n.thisArg, s([t], n.args));                                                                // 31
      }, r);                                                                                                           // 31
    }function jr(t, n, r) {                                                                                            // 31
      for (var e = -1, u = t.length; ++e < u;) {                                                                       // 31
        var o = o ? s(wn(o, t[e], n, r), wn(t[e], o, n, r)) : t[e];                                                    // 31
      }return o && o.length ? yr(o, n, r) : [];                                                                        // 31
    }function wr(t, n, r) {                                                                                            // 31
      for (var e = -1, u = t.length, o = n.length, i = {}; ++e < u;) {                                                 // 31
        r(i, t[e], e < o ? n[e] : P);                                                                                  // 31
      }return i;                                                                                                       // 31
    }function mr(t) {                                                                                                  // 31
      return eu(t) ? t : [];                                                                                           // 31
    }function Ar(t) {                                                                                                  // 31
      return Zi(t) ? t : fi(t);                                                                                        // 31
    }function Or(t, n, r) {                                                                                            // 31
      var e = t.length;return r = r === P ? e : r, !n && r >= e ? t : sr(t, n, r);                                     // 31
    }function kr(t, n) {                                                                                               // 31
      if (n) return t.slice();var r = new t.constructor(t.length);return t.copy(r), r;                                 // 32
    }function Er(t) {                                                                                                  // 32
      var n = new t.constructor(t.byteLength);return new oo(n).set(new oo(t)), n;                                      // 32
    }function Sr(t, n) {                                                                                               // 32
      if (t !== n) {                                                                                                   // 32
        var r = t !== P,                                                                                               // 32
            e = null === t,                                                                                            // 32
            u = t === t,                                                                                               // 32
            o = pu(t),                                                                                                 // 32
            i = n !== P,                                                                                               // 32
            f = null === n,                                                                                            // 32
            c = n === n,                                                                                               // 32
            a = pu(n);if (!f && !a && !o && t > n || o && i && c && !f && !a || e && i && c || !r && c || !u) return 1;if (!e && !o && !a && t < n || a && r && u && !e && !o || f && r && u || !i && u || !c) return -1;
      }return 0;                                                                                                       // 32
    }function Rr(t, n, r, e) {                                                                                         // 32
      var u = -1,                                                                                                      // 32
          o = t.length,                                                                                                // 32
          i = r.length,                                                                                                // 32
          f = -1,                                                                                                      // 32
          c = n.length,                                                                                                // 32
          a = jo(o - i, 0),                                                                                            // 32
          l = Du(c + a);for (e = !e; ++f < c;) {                                                                       // 32
        l[f] = n[f];                                                                                                   // 32
      }for (; ++u < i;) {                                                                                              // 32
        (e || u < o) && (l[r[u]] = t[u]);                                                                              // 33
      }for (; a--;) {                                                                                                  // 33
        l[f++] = t[u++];                                                                                               // 33
      }return l;                                                                                                       // 33
    }function Ir(t, n, r, e) {                                                                                         // 33
      var u = -1,                                                                                                      // 33
          o = t.length,                                                                                                // 33
          i = -1,                                                                                                      // 33
          f = r.length,                                                                                                // 33
          c = -1,                                                                                                      // 33
          a = n.length,                                                                                                // 33
          l = jo(o - f, 0),                                                                                            // 33
          s = Du(l + a);for (e = !e; ++u < l;) {                                                                       // 33
        s[u] = t[u];                                                                                                   // 33
      }for (l = u; ++c < a;) {                                                                                         // 33
        s[l + c] = n[c];                                                                                               // 33
      }for (; ++i < f;) {                                                                                              // 33
        (e || u < o) && (s[l + r[i]] = t[u++]);                                                                        // 33
      }return s;                                                                                                       // 33
    }function Wr(t, n) {                                                                                               // 33
      var r = -1,                                                                                                      // 33
          e = t.length;for (n || (n = Du(e)); ++r < e;) {                                                              // 33
        n[r] = t[r];                                                                                                   // 33
      }return n;                                                                                                       // 33
    }function Br(t, n, r, e) {                                                                                         // 33
      r || (r = {});for (var u = -1, o = n.length; ++u < o;) {                                                         // 33
        var i = n[u],                                                                                                  // 33
            f = e ? e(r[i], t[i], i, r, t) : P;sn(r, i, f === P ? t[i] : f);                                           // 33
      }return r;                                                                                                       // 33
    }function Mr(t, n) {                                                                                               // 33
      return Br(t, ri(t), n);                                                                                          // 33
    }function Cr(t, n) {                                                                                               // 34
      return function (r, u) {                                                                                         // 34
        var o = Zi(r) ? e : pn,                                                                                        // 34
            i = n ? n() : {};return o(r, t, fe(u, 2), i);                                                              // 34
      };                                                                                                               // 34
    }function Lr(t) {                                                                                                  // 34
      return ar(function (n, r) {                                                                                      // 34
        var e = -1,                                                                                                    // 34
            u = r.length,                                                                                              // 34
            o = 1 < u ? r[u - 1] : P,                                                                                  // 34
            i = 2 < u ? r[2] : P,                                                                                      // 34
            o = 3 < t.length && typeof o == "function" ? (u--, o) : P;for (i && ye(r[0], r[1], i) && (o = 3 > u ? P : o, u = 1), n = Object(n); ++e < u;) {
          (i = r[e]) && t(n, i, e, o);                                                                                 // 34
        }return n;                                                                                                     // 34
      });                                                                                                              // 34
    }function zr(t, n) {                                                                                               // 34
      return function (r, e) {                                                                                         // 34
        if (null == r) return r;if (!ru(r)) return t(r, e);for (var u = r.length, o = n ? u : -1, i = Object(r); (n ? o-- : ++o < u) && false !== e(i[o], o, i);) {}return r;
      };                                                                                                               // 34
    }function Ur(t) {                                                                                                  // 34
      return function (n, r, e) {                                                                                      // 34
        var u = -1,                                                                                                    // 35
            o = Object(n);e = e(n);for (var i = e.length; i--;) {                                                      // 35
          var f = e[t ? i : ++u];if (false === r(o[f], f, o)) break;                                                   // 35
        }return n;                                                                                                     // 35
      };                                                                                                               // 35
    }function Dr(t, n, r) {                                                                                            // 35
      function e() {                                                                                                   // 35
        return (this && this !== Vt && this instanceof e ? o : t).apply(u ? r : this, arguments);                      // 35
      }var u = 1 & n,                                                                                                  // 35
          o = Tr(t);return e;                                                                                          // 35
    }function $r(t) {                                                                                                  // 35
      return function (n) {                                                                                            // 35
        n = xu(n);var r = Lt.test(n) ? n.match(Mt) : P,                                                                // 35
            e = r ? r[0] : n.charAt(0);return n = r ? Or(r, 1).join("") : n.slice(1), e[t]() + n;                      // 35
      };                                                                                                               // 35
    }function Fr(t) {                                                                                                  // 35
      return function (n) {                                                                                            // 35
        return h(Ru(Su(n).replace(Wt, "")), t, "");                                                                    // 35
      };                                                                                                               // 35
    }function Tr(t) {                                                                                                  // 35
      return function () {                                                                                             // 35
        var n = arguments;                                                                                             // 35
        switch (n.length) {case 0:                                                                                     // 36
            return new t();case 1:                                                                                     // 36
            return new t(n[0]);case 2:                                                                                 // 36
            return new t(n[0], n[1]);case 3:                                                                           // 36
            return new t(n[0], n[1], n[2]);case 4:                                                                     // 36
            return new t(n[0], n[1], n[2], n[3]);case 5:                                                               // 36
            return new t(n[0], n[1], n[2], n[3], n[4]);case 6:                                                         // 36
            return new t(n[0], n[1], n[2], n[3], n[4], n[5]);case 7:                                                   // 36
            return new t(n[0], n[1], n[2], n[3], n[4], n[5], n[6]);}var r = xn(t.prototype),                           // 36
            n = t.apply(r, n);return cu(n) ? n : r;                                                                    // 36
      };                                                                                                               // 36
    }function Nr(t, n, e) {                                                                                            // 36
      function u() {                                                                                                   // 36
        for (var i = arguments.length, f = Du(i), c = i, a = ie(u); c--;) {                                            // 36
          f[c] = arguments[c];                                                                                         // 36
        }return c = 3 > i && f[0] !== a && f[i - 1] !== a ? [] : D(f, a), i -= c.length, i < e ? Xr(t, n, qr, u.placeholder, P, f, c, P, P, e - i) : r(this && this !== Vt && this instanceof u ? o : t, this, f);
      }var o = Tr(t);return u;                                                                                         // 37
    }function Pr(t) {                                                                                                  // 37
      return function (n, r, e) {                                                                                      // 37
        var u = Object(n);if (!ru(n)) {                                                                                // 37
          var o = fe(r, 3);n = mu(n), r = function r(t) {                                                              // 37
            return o(u[t], t, u);                                                                                      // 37
          };                                                                                                           // 37
        }return r = t(n, r, e), -1 < r ? u[o ? n[r] : r] : P;                                                          // 37
      };                                                                                                               // 37
    }function Zr(t) {                                                                                                  // 37
      return ar(function (n) {                                                                                         // 37
        n = kn(n, 1);var r = n.length,                                                                                 // 37
            e = r,                                                                                                     // 37
            u = Tt.prototype.thru;for (t && n.reverse(); e--;) {                                                       // 37
          var o = n[e];if (typeof o != "function") throw new Pu("Expected a function");if (u && !i && "wrapper" == oe(o)) var i = new Tt([], true);
        }for (e = i ? e : r; ++e < r;) {                                                                               // 38
          var o = n[e],                                                                                                // 38
              u = oe(o),                                                                                               // 38
              f = "wrapper" == u ? Xo(o) : P,                                                                          // 38
              i = f && xe(f[0]) && 424 == f[1] && !f[4].length && 1 == f[9] ? i[oe(f[0])].apply(i, f[3]) : 1 == o.length && xe(o) ? i[u]() : i.thru(o);
        }return function () {                                                                                          // 38
          var t = arguments,                                                                                           // 38
              e = t[0];if (i && 1 == t.length && Zi(e) && 200 <= e.length) return i.plant(e).value();for (var u = 0, t = r ? n[u].apply(this, t) : e; ++u < r;) {
            t = n[u].call(this, t);                                                                                    // 38
          }return t;                                                                                                   // 38
        };                                                                                                             // 38
      });                                                                                                              // 38
    }function qr(t, n, r, e, u, o, i, f, c, a) {                                                                       // 38
      function l() {                                                                                                   // 38
        for (var d = arguments.length, y = Du(d), b = d; b--;) {                                                       // 38
          y[b] = arguments[b];                                                                                         // 38
        }if (_) {                                                                                                      // 38
          var x,                                                                                                       // 38
              j = ie(l),                                                                                               // 38
              b = y.length;for (x = 0; b--;) {                                                                         // 38
            y[b] === j && x++;                                                                                         // 38
          }                                                                                                            // 38
        }if (e && (y = Rr(y, e, u, _)), o && (y = Ir(y, o, i, _)), d -= x, _ && d < a) return j = D(y, j), Xr(t, n, qr, l.placeholder, r, y, j, f, c, a - d);if (j = h ? r : this, b = p ? j[t] : t, d = y.length, f) {
          x = y.length;for (var w = wo(f.length, x), m = Wr(y); w--;) {                                                // 39
            var A = f[w];y[w] = de(A, x) ? m[A] : P;                                                                   // 39
          }                                                                                                            // 39
        } else v && 1 < d && y.reverse();return s && c < d && (y.length = c), this && this !== Vt && this instanceof l && (b = g || Tr(b)), b.apply(j, y);
      }var s = 128 & n,                                                                                                // 39
          h = 1 & n,                                                                                                   // 39
          p = 2 & n,                                                                                                   // 39
          _ = 24 & n,                                                                                                  // 39
          v = 512 & n,                                                                                                 // 39
          g = p ? P : Tr(t);return l;                                                                                  // 39
    }function Vr(t, n) {                                                                                               // 39
      return function (r, e) {                                                                                         // 39
        return zn(r, t, n(e));                                                                                         // 39
      };                                                                                                               // 39
    }function Kr(t, n) {                                                                                               // 39
      return function (r, e) {                                                                                         // 39
        var u;if (r === P && e === P) return n;if (r !== P && (u = r), e !== P) {                                      // 40
          if (u === P) return e;typeof r == "string" || typeof e == "string" ? (r = dr(r), e = dr(e)) : (r = gr(r), e = gr(e)), u = t(r, e);
        }return u;                                                                                                     // 40
      };                                                                                                               // 40
    }function Gr(t) {                                                                                                  // 40
      return ar(function (n) {                                                                                         // 40
        return n = 1 == n.length && Zi(n[0]) ? l(n[0], S(fe())) : l(kn(n, 1), S(fe())), ar(function (e) {              // 40
          var u = this;return t(n, function (t) {                                                                      // 40
            return r(t, u, e);                                                                                         // 40
          });                                                                                                          // 40
        });                                                                                                            // 40
      });                                                                                                              // 40
    }function Jr(t, n) {                                                                                               // 40
      n = n === P ? " " : dr(n);var r = n.length;return 2 > r ? r ? cr(n, t) : n : (r = cr(n, ho(t / T(n))), Lt.test(n) ? Or(r.match(Mt), 0, t).join("") : r.slice(0, t));
    }function Yr(t, n, e, u) {                                                                                         // 40
      function o() {                                                                                                   // 41
        for (var n = -1, c = arguments.length, a = -1, l = u.length, s = Du(l + c), h = this && this !== Vt && this instanceof o ? f : t; ++a < l;) {
          s[a] = u[a];                                                                                                 // 41
        }for (; c--;) {                                                                                                // 41
          s[a++] = arguments[++n];                                                                                     // 41
        }return r(h, i ? e : this, s);                                                                                 // 41
      }var i = 1 & n,                                                                                                  // 41
          f = Tr(t);return o;                                                                                          // 41
    }function Hr(t) {                                                                                                  // 41
      return function (n, r, e) {                                                                                      // 41
        e && typeof e != "number" && ye(n, r, e) && (r = e = P), n = vu(n), r === P ? (r = n, n = 0) : r = vu(r), e = e === P ? n < r ? 1 : -1 : vu(e);var u = -1;r = jo(ho((r - n) / (e || 1)), 0);for (var o = Du(r); r--;) {
          o[t ? r : ++u] = n, n += e;                                                                                  // 41
        }return o;                                                                                                     // 41
      };                                                                                                               // 41
    }function Qr(t) {                                                                                                  // 41
      return function (n, r) {                                                                                         // 41
        return typeof n == "string" && typeof r == "string" || (n = yu(n), r = yu(r)), t(n, r);                        // 41
      };                                                                                                               // 42
    }function Xr(t, n, r, e, u, o, i, f, c, a) {                                                                       // 42
      var l = 8 & n,                                                                                                   // 42
          s = l ? i : P;i = l ? P : i;var h = l ? o : P;return o = l ? P : o, n = (n | (l ? 32 : 64)) & ~(l ? 64 : 32), 4 & n || (n &= -4), u = [t, n, u, h, s, o, i, f, c, a], r = r.apply(P, u), xe(t) && oi(r, u), r.placeholder = e, ii(r, t, n);
    }function te(t) {                                                                                                  // 42
      var n = Tu[t];return function (t, r) {                                                                           // 42
        if (t = yu(t), r = wo(gu(r), 292)) {                                                                           // 42
          var e = (xu(t) + "e").split("e"),                                                                            // 42
              e = n(e[0] + "e" + (+e[1] + r)),                                                                         // 42
              e = (xu(e) + "e").split("e");return +(e[0] + "e" + (+e[1] - r));                                         // 42
        }return n(t);                                                                                                  // 42
      };                                                                                                               // 42
    }function ne(t) {                                                                                                  // 42
      return function (n) {                                                                                            // 42
        var r = St(n);return "[object Map]" == r ? z(n) : "[object Set]" == r ? F(n) : E(n, t(n));                     // 42
      };                                                                                                               // 43
    }function re(t, n, r, e, u, o, i, f) {                                                                             // 43
      var c = 2 & n;if (!c && typeof t != "function") throw new Pu("Expected a function");var a = e ? e.length : 0;if (a || (n &= -97, e = u = P), i = i === P ? i : jo(gu(i), 0), f = f === P ? f : gu(f), a -= u ? u.length : 0, 64 & n) {
        var l = e,                                                                                                     // 43
            s = u;e = u = P;                                                                                           // 43
      }var h = c ? P : Xo(t);return o = [t, n, r, e, u, l, s, o, i, f], h && (r = o[1], t = h[1], n = r | t, e = 128 == t && 8 == r || 128 == t && 256 == r && o[7].length <= h[8] || 384 == t && h[7].length <= h[8] && 8 == r, 131 > n || e) && (1 & t && (o[2] = h[2], n |= 1 & r ? 0 : 4), (r = h[3]) && (e = o[3], o[3] = e ? Rr(e, r, h[4]) : r, o[4] = e ? D(o[3], "__lodash_placeholder__") : h[4]), (r = h[5]) && (e = o[5], o[5] = e ? Ir(e, r, h[6]) : r, o[6] = e ? D(o[5], "__lodash_placeholder__") : h[6]), (r = h[7]) && (o[7] = r), 128 & t && (o[8] = null == o[8] ? h[8] : wo(o[8], h[8])), null == o[9] && (o[9] = h[9]), o[0] = h[0], o[1] = n), t = o[0], n = o[1], r = o[2], e = o[3], u = o[4], f = o[9] = null == o[9] ? c ? 0 : t.length : jo(o[9] - a, 0), !f && 24 & n && (n &= -25), ii((h ? Ho : oi)(n && 1 != n ? 8 == n || 16 == n ? Nr(t, n, f) : 32 != n && 33 != n || u.length ? qr.apply(P, o) : Yr(t, n, r, e) : Dr(t, n, r), o), t, n);
    }function ee(t, n, r, e, u, o) {                                                                                   // 44
      var i = 2 & u,                                                                                                   // 44
          f = t.length,                                                                                                // 44
          c = n.length;if (f != c && !(i && c > f)) return false;if ((c = o.get(t)) && o.get(n)) return c == n;        // 44
      var c = -1,                                                                                                      // 45
          a = true,                                                                                                    // 45
          l = 1 & u ? new Yt() : P;for (o.set(t, n), o.set(n, t); ++c < f;) {                                          // 45
        var s = t[c],                                                                                                  // 45
            h = n[c];if (e) var p = i ? e(h, s, c, n, t, o) : e(s, h, c, t, n, o);if (p !== P) {                       // 45
          if (p) continue;a = false;break;                                                                             // 45
        }if (l) {                                                                                                      // 45
          if (!_(n, function (t, n) {                                                                                  // 45
            if (!l.has(n) && (s === t || r(s, t, e, u, o))) return l.add(n);                                           // 45
          })) {                                                                                                        // 45
            a = false;break;                                                                                           // 45
          }                                                                                                            // 45
        } else if (s !== h && !r(s, h, e, u, o)) {                                                                     // 45
          a = false;break;                                                                                             // 45
        }                                                                                                              // 45
      }return o["delete"](t), o["delete"](n), a;                                                                       // 45
    }function ue(t, n, r, e, u, o, i) {                                                                                // 45
      switch (r) {case "[object DataView]":                                                                            // 45
          if (t.byteLength != n.byteLength || t.byteOffset != n.byteOffset) break;t = t.buffer, n = n.buffer;case "[object ArrayBuffer]":
          if (t.byteLength != n.byteLength || !e(new oo(t), new oo(n))) break;return true;case "[object Boolean]":case "[object Date]":case "[object Number]":
          return tu(+t, +n);case "[object Error]":                                                                     // 46
          return t.name == n.name && t.message == n.message;case "[object RegExp]":case "[object String]":             // 46
          return t == n + "";case "[object Map]":                                                                      // 46
          var f = z;case "[object Set]":                                                                               // 46
          if (f || (f = $), t.size != n.size && !(2 & o)) break;return (r = i.get(t)) ? r == n : (o |= 1, i.set(t, n), n = ee(f(t), f(n), e, u, o, i), i["delete"](t), n);case "[object Symbol]":
          if (Zo) return Zo.call(t) == Zo.call(n);}                                                                    // 46
      return false;                                                                                                    // 47
    }function oe(t) {                                                                                                  // 47
      for (var n = t.name + "", r = Uo[n], e = Yu.call(Uo, n) ? r.length : 0; e--;) {                                  // 47
        var u = r[e],                                                                                                  // 47
            o = u.func;if (null == o || o == t) return u.name;                                                         // 47
      }return n;                                                                                                       // 47
    }function ie(t) {                                                                                                  // 47
      return (Yu.call(It, "placeholder") ? It : t).placeholder;                                                        // 47
    }function fe() {                                                                                                   // 47
      var t = It.iteratee || Bu,                                                                                       // 47
          t = t === Bu ? Kn : t;return arguments.length ? t(arguments[0], arguments[1]) : t;                           // 47
    }function ce(t, n) {                                                                                               // 47
      var r = t.__data__,                                                                                              // 47
          e = typeof n === "undefined" ? "undefined" : _typeof(n);return ("string" == e || "number" == e || "symbol" == e || "boolean" == e ? "__proto__" !== n : null === n) ? r[typeof n == "string" ? "string" : "hash"] : r.map;
    }function ae(t) {                                                                                                  // 47
      for (var n = mu(t), r = n.length; r--;) {                                                                        // 48
        var e = n[r],                                                                                                  // 48
            u = t[e];n[r] = [e, u, u === u && !cu(u)];                                                                 // 48
      }return n;                                                                                                       // 48
    }function le(t, n) {                                                                                               // 48
      var r = null == t ? P : t[n];return Pn(r) ? r : P;                                                               // 48
    }function se(t, n, r) {                                                                                            // 48
      n = be(n, t) ? [n] : Ar(n);for (var e, u = -1, o = n.length; ++u < o;) {                                         // 48
        var i = Oe(n[u]);if (!(e = null != t && r(t, i))) break;t = t[i];                                              // 48
      }return e ? e : (o = t ? t.length : 0, !!o && fu(o) && de(i, o) && (Zi(t) || hu(t) || nu(t)));                   // 48
    }function he(t) {                                                                                                  // 48
      var n = t.length,                                                                                                // 48
          r = t.constructor(n);return n && "string" == typeof t[0] && Yu.call(t, "index") && (r.index = t.index, r.input = t.input), r;
    }function pe(t) {                                                                                                  // 48
      return typeof t.constructor != "function" || je(t) ? {} : xn(ni(t));                                             // 48
    }function _e(r, e, u, o) {                                                                                         // 49
      var i = r.constructor;switch (e) {case "[object ArrayBuffer]":                                                   // 49
          return Er(r);case "[object Boolean]":case "[object Date]":                                                   // 49
          return new i(+r);case "[object DataView]":                                                                   // 49
          return e = o ? Er(r.buffer) : r.buffer, new r.constructor(e, r.byteOffset, r.byteLength);case "[object Float32Array]":case "[object Float64Array]":case "[object Int8Array]":case "[object Int16Array]":case "[object Int32Array]":case "[object Uint8Array]":case "[object Uint8ClampedArray]":case "[object Uint16Array]":case "[object Uint32Array]":
          return e = o ? Er(r.buffer) : r.buffer, new r.constructor(e, r.byteOffset, r.length);case "[object Map]":    // 50
          return e = o ? u(z(r), true) : z(r), h(e, t, new r.constructor());case "[object Number]":case "[object String]":
          return new i(r);case "[object RegExp]":                                                                      // 50
          return e = new r.constructor(r.source, yt.exec(r)), e.lastIndex = r.lastIndex, e;case "[object Set]":        // 50
          return e = o ? u($(r), true) : $(r), h(e, n, new r.constructor());case "[object Symbol]":                    // 50
          return Zo ? Object(Zo.call(r)) : {};}                                                                        // 50
    }function ve(t) {                                                                                                  // 50
      var n = t ? t.length : P;return fu(n) && (Zi(t) || hu(t) || nu(t)) ? k(n, String) : null;                        // 50
    }function ge(t) {                                                                                                  // 51
      return Zi(t) || nu(t) || !!(so && t && t[so]);                                                                   // 51
    }function de(t, n) {                                                                                               // 51
      return n = null == n ? 9007199254740991 : n, !!n && (typeof t == "number" || At.test(t)) && -1 < t && 0 == t % 1 && t < n;
    }function ye(t, n, r) {                                                                                            // 51
      if (!cu(r)) return false;var e = typeof n === "undefined" ? "undefined" : _typeof(n);return !!("number" == e ? ru(r) && de(n, r.length) : "string" == e && n in r) && tu(r[n], t);
    }function be(t, n) {                                                                                               // 51
      if (Zi(t)) return false;var r = typeof t === "undefined" ? "undefined" : _typeof(t);return !("number" != r && "symbol" != r && "boolean" != r && null != t && !pu(t)) || ut.test(t) || !et.test(t) || null != n && t in Object(n);
    }function xe(t) {                                                                                                  // 51
      var n = oe(t),                                                                                                   // 51
          r = It[n];return typeof r == "function" && n in Zt.prototype && (t === r || (n = Xo(r), !!n && t === n[0]));
    }function je(t) {                                                                                                  // 52
      var n = t && t.constructor;return t === (typeof n == "function" && n.prototype || qu);                           // 52
    }function we(t, n) {                                                                                               // 52
      return function (r) {                                                                                            // 52
        return null != r && r[t] === n && (n !== P || t in Object(r));                                                 // 52
      };                                                                                                               // 52
    }function me(t, n, r, e, u, o) {                                                                                   // 52
      return cu(t) && cu(n) && (o.set(n, t), Xn(t, n, P, me, o), o["delete"](n)), t;                                   // 52
    }function Ae(t, n) {                                                                                               // 52
      return 1 == n.length ? t : In(t, sr(n, 0, -1));                                                                  // 52
    }function Oe(t) {                                                                                                  // 52
      if (typeof t == "string" || pu(t)) return t;var n = t + "";return "0" == n && 1 / t == -Z ? "-0" : n;            // 52
    }function ke(t) {                                                                                                  // 52
      if (null != t) {                                                                                                 // 52
        try {                                                                                                          // 52
          return Ju.call(t);                                                                                           // 52
        } catch (t) {}return t + "";                                                                                   // 52
      }                                                                                                                // 52
      return "";                                                                                                       // 53
    }function Ee(t, n) {                                                                                               // 53
      return u(V, function (r) {                                                                                       // 53
        var e = "_." + r[0];n & r[1] && !c(t, e) && t.push(e);                                                         // 53
      }), t.sort();                                                                                                    // 53
    }function Se(t) {                                                                                                  // 53
      if (t instanceof Zt) return t.clone();var n = new Tt(t.__wrapped__, t.__chain__);return n.__actions__ = Wr(t.__actions__), n.__index__ = t.__index__, n.__values__ = t.__values__, n;
    }function Re(t, n, r) {                                                                                            // 53
      var e = t ? t.length : 0;return e ? (n = r || n === P ? 1 : gu(n), sr(t, 0 > n ? 0 : n, e)) : [];                // 53
    }function Ie(t, n, r) {                                                                                            // 53
      var e = t ? t.length : 0;return e ? (n = r || n === P ? 1 : gu(n), n = e - n, sr(t, 0, 0 > n ? 0 : n)) : [];     // 53
    }function We(t, n, r) {                                                                                            // 53
      var e = t ? t.length : 0;                                                                                        // 53
      return e ? (r = null == r ? 0 : gu(r), 0 > r && (r = jo(e + r, 0)), g(t, fe(n, 3), r)) : -1;                     // 54
    }function Be(t, n, r) {                                                                                            // 54
      var e = t ? t.length : 0;if (!e) return -1;var u = e - 1;return r !== P && (u = gu(r), u = 0 > r ? jo(e + u, 0) : wo(u, e - 1)), g(t, fe(n, 3), u, true);
    }function Me(t) {                                                                                                  // 54
      return t && t.length ? t[0] : P;                                                                                 // 54
    }function Ce(t) {                                                                                                  // 54
      var n = t ? t.length : 0;return n ? t[n - 1] : P;                                                                // 54
    }function Le(t, n) {                                                                                               // 54
      return t && t.length && n && n.length ? or(t, n) : t;                                                            // 54
    }function ze(t) {                                                                                                  // 54
      return t ? ko.call(t) : t;                                                                                       // 54
    }function Ue(t) {                                                                                                  // 54
      if (!t || !t.length) return [];var n = 0;return t = f(t, function (t) {                                          // 54
        if (eu(t)) return n = jo(t.length, n), true;                                                                   // 54
      }), k(n, function (n) {                                                                                          // 54
        return l(t, j(n));                                                                                             // 55
      });                                                                                                              // 55
    }function De(t, n) {                                                                                               // 55
      if (!t || !t.length) return [];var e = Ue(t);return null == n ? e : l(e, function (t) {                          // 55
        return r(n, P, t);                                                                                             // 55
      });                                                                                                              // 55
    }function $e(t) {                                                                                                  // 55
      return t = It(t), t.__chain__ = true, t;                                                                         // 55
    }function Fe(t, n) {                                                                                               // 55
      return n(t);                                                                                                     // 55
    }function Te() {                                                                                                   // 55
      return this;                                                                                                     // 55
    }function Ne(t, n) {                                                                                               // 55
      return (Zi(t) ? u : Vo)(t, fe(n, 3));                                                                            // 55
    }function Pe(t, n) {                                                                                               // 55
      return (Zi(t) ? o : Ko)(t, fe(n, 3));                                                                            // 55
    }function Ze(t, n) {                                                                                               // 55
      return (Zi(t) ? l : Yn)(t, fe(n, 3));                                                                            // 55
    }function qe(t, n, r) {                                                                                            // 55
      var e = -1,                                                                                                      // 55
          u = _u(t),                                                                                                   // 55
          o = u.length,                                                                                                // 55
          i = o - 1;for (n = (r ? ye(t, n, r) : n === P) ? 1 : gn(gu(n), 0, o); ++e < n;) {                            // 55
        t = fr(e, i), r = u[t], u[t] = u[e], u[e] = r;                                                                 // 55
      }return u.length = n, u;                                                                                         // 55
    }function Ve() {                                                                                                   // 56
      return $u.now();                                                                                                 // 56
    }function Ke(t, n, r) {                                                                                            // 56
      return n = r ? P : n, n = t && null == n ? t.length : n, re(t, 128, P, P, P, P, n);                              // 56
    }function Ge(t, n) {                                                                                               // 56
      var r;if (typeof n != "function") throw new Pu("Expected a function");return t = gu(t), function () {            // 56
        return 0 < --t && (r = n.apply(this, arguments)), 1 >= t && (n = P), r;                                        // 56
      };                                                                                                               // 56
    }function Je(t, n, r) {                                                                                            // 56
      return n = r ? P : n, t = re(t, 8, P, P, P, P, P, n), t.placeholder = Je.placeholder, t;                         // 56
    }function Ye(t, n, r) {                                                                                            // 56
      return n = r ? P : n, t = re(t, 16, P, P, P, P, P, n), t.placeholder = Ye.placeholder, t;                        // 56
    }function He(t, n, r) {                                                                                            // 56
      function e(n) {                                                                                                  // 56
        var r = c,                                                                                                     // 57
            e = a;return c = a = P, _ = n, s = t.apply(e, r);                                                          // 57
      }function u(t) {                                                                                                 // 57
        var r = t - p;return t -= _, p === P || r >= n || 0 > r || g && t >= l;                                        // 57
      }function o() {                                                                                                  // 57
        var t = Ve();if (u(t)) return i(t);var r;r = t - _, t = n - (t - p), r = g ? wo(t, l - r) : t, h = Rt(o, r);   // 57
      }function i(t) {                                                                                                 // 57
        return h = P, d && c ? e(t) : (c = a = P, s);                                                                  // 57
      }function f() {                                                                                                  // 57
        var t = Ve(),                                                                                                  // 57
            r = u(t);if (c = arguments, a = this, p = t, r) {                                                          // 57
          if (h === P) return _ = t = p, h = Rt(o, n), v ? e(t) : s;if (g) return h = Rt(o, n), e(p);                  // 57
        }return h === P && (h = Rt(o, n)), s;                                                                          // 57
      }var c,                                                                                                          // 57
          a,                                                                                                           // 57
          l,                                                                                                           // 57
          s,                                                                                                           // 57
          h,                                                                                                           // 57
          p,                                                                                                           // 57
          _ = 0,                                                                                                       // 57
          v = false,                                                                                                   // 57
          g = false,                                                                                                   // 57
          d = true;if (typeof t != "function") throw new Pu("Expected a function");return n = yu(n) || 0, cu(r) && (v = !!r.leading, l = (g = "maxWait" in r) ? jo(yu(r.maxWait) || 0, n) : l, d = "trailing" in r ? !!r.trailing : d), f.cancel = function () {
        h !== P && w.clearTimeout.call(Vt, h), _ = 0, c = p = a = h = P;                                               // 58
      }, f.flush = function () {                                                                                       // 58
        return h === P ? s : i(Ve());                                                                                  // 58
      }, f;                                                                                                            // 58
    }function Qe(t, n) {                                                                                               // 58
      function r() {                                                                                                   // 58
        var e = arguments,                                                                                             // 58
            u = n ? n.apply(this, e) : e[0],                                                                           // 58
            o = r.cache;return o.has(u) ? o.get(u) : (e = t.apply(this, e), r.cache = o.set(u, e), e);                 // 58
      }if (typeof t != "function" || n && typeof n != "function") throw new Pu("Expected a function");return r.cache = new (Qe.Cache || Gt)(), r;
    }function Xe(t) {                                                                                                  // 58
      if (typeof t != "function") throw new Pu("Expected a function");                                                 // 58
      return function () {                                                                                             // 59
        var n = arguments;switch (n.length) {case 0:                                                                   // 59
            return !t.call(this);case 1:                                                                               // 59
            return !t.call(this, n[0]);case 2:                                                                         // 59
            return !t.call(this, n[0], n[1]);case 3:                                                                   // 59
            return !t.call(this, n[0], n[1], n[2]);}return !t.apply(this, n);                                          // 59
      };                                                                                                               // 59
    }function tu(t, n) {                                                                                               // 59
      return t === n || t !== t && n !== n;                                                                            // 59
    }function nu(t) {                                                                                                  // 59
      return eu(t) && Yu.call(t, "callee") && (!ao.call(t, "callee") || "[object Arguments]" == Xu.call(t));           // 59
    }function ru(t) {                                                                                                  // 59
      return null != t && fu(ti(t)) && !ou(t);                                                                         // 59
    }function eu(t) {                                                                                                  // 59
      return au(t) && ru(t);                                                                                           // 59
    }function uu(t) {                                                                                                  // 59
      return !!au(t) && ("[object Error]" == Xu.call(t) || typeof t.message == "string" && typeof t.name == "string");
    }function ou(t) {                                                                                                  // 60
      return t = cu(t) ? Xu.call(t) : "", "[object Function]" == t || "[object GeneratorFunction]" == t;               // 60
    }function iu(t) {                                                                                                  // 60
      return typeof t == "number" && t == gu(t);                                                                       // 60
    }function fu(t) {                                                                                                  // 60
      return typeof t == "number" && -1 < t && 0 == t % 1 && 9007199254740991 >= t;                                    // 60
    }function cu(t) {                                                                                                  // 60
      var n = typeof t === "undefined" ? "undefined" : _typeof(t);return !!t && ("object" == n || "function" == n);    // 60
    }function au(t) {                                                                                                  // 60
      return !!t && (typeof t === "undefined" ? "undefined" : _typeof(t)) == "object";                                 // 60
    }function lu(t) {                                                                                                  // 60
      return typeof t == "number" || au(t) && "[object Number]" == Xu.call(t);                                         // 60
    }function su(t) {                                                                                                  // 60
      return !(!au(t) || "[object Object]" != Xu.call(t) || C(t)) && (t = ni(t), null === t || (t = Yu.call(t, "constructor") && t.constructor, typeof t == "function" && t instanceof t && Ju.call(t) == Qu));
    }function hu(t) {                                                                                                  // 61
      return typeof t == "string" || !Zi(t) && au(t) && "[object String]" == Xu.call(t);                               // 61
    }function pu(t) {                                                                                                  // 61
      return (typeof t === "undefined" ? "undefined" : _typeof(t)) == "symbol" || au(t) && "[object Symbol]" == Xu.call(t);
    }function _u(t) {                                                                                                  // 61
      if (!t) return [];if (ru(t)) return hu(t) ? t.match(Mt) : Wr(t);if (fo && t[fo]) return L(t[fo]());var n = St(t);return ("[object Map]" == n ? z : "[object Set]" == n ? $ : ku)(t);
    }function vu(t) {                                                                                                  // 61
      return t ? (t = yu(t), t === Z || t === -Z ? 1.7976931348623157e308 * (0 > t ? -1 : 1) : t === t ? t : 0) : 0 === t ? t : 0;
    }function gu(t) {                                                                                                  // 61
      t = vu(t);var n = t % 1;return t === t ? n ? t - n : t : 0;                                                      // 62
    }function du(t) {                                                                                                  // 62
      return t ? gn(gu(t), 0, 4294967295) : 0;                                                                         // 62
    }function yu(t) {                                                                                                  // 62
      if (typeof t == "number") return t;if (pu(t)) return q;if (cu(t) && (t = ou(t.valueOf) ? t.valueOf() : t, t = cu(t) ? t + "" : t), typeof t != "string") return 0 === t ? t : +t;t = t.replace(at, "");var n = jt.test(t);return n || mt.test(t) ? Pt(t.slice(2), n ? 2 : 8) : xt.test(t) ? q : +t;
    }function bu(t) {                                                                                                  // 62
      return Br(t, Au(t));                                                                                             // 62
    }function xu(t) {                                                                                                  // 62
      return null == t ? "" : dr(t);                                                                                   // 62
    }function ju(t, n, r) {                                                                                            // 62
      return t = null == t ? P : In(t, n), t === P ? r : t;                                                            // 62
    }function wu(t, n) {                                                                                               // 62
      return null != t && se(t, n, Cn);                                                                                // 62
    }function mu(t) {                                                                                                  // 63
      var n = je(t);if (!n && !ru(t)) return Yo(t);var r,                                                              // 63
          e = ve(t),                                                                                                   // 63
          u = !!e,                                                                                                     // 63
          e = e || [],                                                                                                 // 63
          o = e.length;for (r in meteorBabelHelpers.sanitizeForInObject(t)) {                                          // 63
        !Mn(t, r) || u && ("length" == r || de(r, o)) || n && "constructor" == r || e.push(r);                         // 63
      }return e;                                                                                                       // 63
    }function Au(t) {                                                                                                  // 63
      for (var n = -1, r = je(t), e = Gn(t), u = e.length, o = ve(t), i = !!o, o = o || [], f = o.length; ++n < u;) {  // 63
        var c = e[n];i && ("length" == c || de(c, f)) || "constructor" == c && (r || !Yu.call(t, c)) || o.push(c);     // 63
      }return o;                                                                                                       // 63
    }function Ou(t, n) {                                                                                               // 63
      return null == t ? {} : er(t, Wn(t, Au, ei), fe(n));                                                             // 63
    }function ku(t) {                                                                                                  // 63
      return t ? R(t, mu(t)) : [];                                                                                     // 63
    }function Eu(t) {                                                                                                  // 63
      return Af(xu(t).toLowerCase());                                                                                  // 63
    }function Su(t) {                                                                                                  // 64
      return (t = xu(t)) && t.replace(Ot, en).replace(Bt, "");                                                         // 64
    }function Ru(t, n, r) {                                                                                            // 64
      return t = xu(t), n = r ? P : n, n === P && (n = zt.test(t) ? Ct : vt), t.match(n) || [];                        // 64
    }function Iu(t) {                                                                                                  // 64
      return function () {                                                                                             // 64
        return t;                                                                                                      // 64
      };                                                                                                               // 64
    }function Wu(t) {                                                                                                  // 64
      return t;                                                                                                        // 64
    }function Bu(t) {                                                                                                  // 64
      return Kn(typeof t == "function" ? t : dn(t, true));                                                             // 64
    }function Mu(t, n, r) {                                                                                            // 64
      var e = mu(n),                                                                                                   // 64
          o = Rn(n, e);null != r || cu(n) && (o.length || !e.length) || (r = n, n = t, t = this, o = Rn(n, mu(n)));var i = !(cu(r) && "chain" in r && !r.chain),
          f = ou(t);return u(o, function (r) {                                                                         // 64
        var e = n[r];t[r] = e, f && (t.prototype[r] = function () {                                                    // 64
          var n = this.__chain__;if (i || n) {                                                                         // 65
            var r = t(this.__wrapped__);return (r.__actions__ = Wr(this.__actions__)).push({ func: e, args: arguments, thisArg: t }), r.__chain__ = n, r;
          }return e.apply(t, s([this.value()], arguments));                                                            // 65
        });                                                                                                            // 65
      }), t;                                                                                                           // 65
    }function Cu() {}function Lu(t) {                                                                                  // 65
      return be(t) ? j(Oe(t)) : ur(t);                                                                                 // 65
    }function zu() {                                                                                                   // 65
      return [];                                                                                                       // 65
    }function Uu() {                                                                                                   // 65
      return false;                                                                                                    // 65
    }w = w ? fn.defaults({}, w, fn.pick(Vt, Ut)) : Vt;var Du = w.Array,                                                // 65
        $u = w.Date,                                                                                                   // 65
        Fu = w.Error,                                                                                                  // 65
        Tu = w.Math,                                                                                                   // 65
        Nu = w.RegExp,                                                                                                 // 65
        Pu = w.TypeError,                                                                                              // 65
        Zu = w.Array.prototype,                                                                                        // 65
        qu = w.Object.prototype,                                                                                       // 65
        Vu = w.String.prototype,                                                                                       // 65
        Ku = w["__core-js_shared__"],                                                                                  // 65
        Gu = function () {                                                                                             // 65
      var t = /[^.]+$/.exec(Ku && Ku.keys && Ku.keys.IE_PROTO || "");return t ? "Symbol(src)_1." + t : "";             // 66
    }(),                                                                                                               // 66
        Ju = w.Function.prototype.toString,                                                                            // 65
        Yu = qu.hasOwnProperty,                                                                                        // 65
        Hu = 0,                                                                                                        // 65
        Qu = Ju.call(Object),                                                                                          // 65
        Xu = qu.toString,                                                                                              // 65
        to = Vt._,                                                                                                     // 65
        no = Nu("^" + Ju.call(Yu).replace(ft, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
        ro = Jt ? w.Buffer : P,                                                                                        // 65
        eo = w.Reflect,                                                                                                // 65
        uo = w.Symbol,                                                                                                 // 65
        oo = w.Uint8Array,                                                                                             // 65
        io = eo ? eo.g : P,                                                                                            // 65
        fo = uo ? uo.iterator : P,                                                                                     // 65
        co = w.Object.create,                                                                                          // 65
        ao = qu.propertyIsEnumerable,                                                                                  // 65
        lo = Zu.splice,                                                                                                // 65
        so = uo ? uo.isConcatSpreadable : P,                                                                           // 65
        ho = Tu.ceil,                                                                                                  // 65
        po = Tu.floor,                                                                                                 // 65
        _o = Object.getPrototypeOf,                                                                                    // 65
        vo = Object.getOwnPropertySymbols,                                                                             // 65
        go = ro ? ro.isBuffer : P,                                                                                     // 65
        yo = w.isFinite,                                                                                               // 65
        bo = Zu.join,                                                                                                  // 65
        xo = Object.keys,                                                                                              // 65
        jo = Tu.max,                                                                                                   // 65
        wo = Tu.min,                                                                                                   // 65
        mo = w.parseInt,                                                                                               // 65
        Ao = Tu.random,                                                                                                // 65
        Oo = Vu.replace,                                                                                               // 65
        ko = Zu.reverse,                                                                                               // 65
        Eo = Vu.split,                                                                                                 // 65
        So = le(w, "DataView"),                                                                                        // 65
        Ro = le(w, "Map"),                                                                                             // 65
        Io = le(w, "Promise"),                                                                                         // 65
        Wo = le(w, "Set"),                                                                                             // 65
        Bo = le(w, "WeakMap"),                                                                                         // 65
        Mo = le(w.Object, "create"),                                                                                   // 65
        Co = function () {                                                                                             // 65
      var t = le(w.Object, "defineProperty"),                                                                          // 67
          n = le.name;return n && 2 < n.length ? t : P;                                                                // 67
    }(),                                                                                                               // 67
        Lo = Bo && new Bo(),                                                                                           // 65
        zo = !ao.call({ valueOf: 1 }, "valueOf"),                                                                      // 65
        Uo = {},                                                                                                       // 65
        Do = ke(So),                                                                                                   // 65
        $o = ke(Ro),                                                                                                   // 65
        Fo = ke(Io),                                                                                                   // 65
        To = ke(Wo),                                                                                                   // 65
        No = ke(Bo),                                                                                                   // 65
        Po = uo ? uo.prototype : P,                                                                                    // 65
        Zo = Po ? Po.valueOf : P,                                                                                      // 65
        qo = Po ? Po.toString : P;It.templateSettings = { escape: tt, evaluate: nt, interpolate: rt, variable: "", imports: { _: It } }, It.prototype = Ft.prototype, It.prototype.constructor = It, Tt.prototype = xn(Ft.prototype), Tt.prototype.constructor = Tt, Zt.prototype = xn(Ft.prototype), Zt.prototype.constructor = Zt, qt.prototype.clear = function () {
      this.__data__ = Mo ? Mo(null) : {};                                                                              // 68
    }, qt.prototype["delete"] = function (t) {                                                                         // 68
      return this.has(t) && delete this.__data__[t];                                                                   // 68
    }, qt.prototype.get = function (t) {                                                                               // 68
      var n = this.__data__;return Mo ? (t = n[t], "__lodash_hash_undefined__" === t ? P : t) : Yu.call(n, t) ? n[t] : P;
    }, qt.prototype.has = function (t) {                                                                               // 68
      var n = this.__data__;return Mo ? n[t] !== P : Yu.call(n, t);                                                    // 68
    }, qt.prototype.set = function (t, n) {                                                                            // 68
      return this.__data__[t] = Mo && n === P ? "__lodash_hash_undefined__" : n, this;                                 // 68
    }, Kt.prototype.clear = function () {                                                                              // 68
      this.__data__ = [];                                                                                              // 68
    }, Kt.prototype["delete"] = function (t) {                                                                         // 68
      var n = this.__data__;                                                                                           // 68
      return t = hn(n, t), !(0 > t) && (t == n.length - 1 ? n.pop() : lo.call(n, t, 1), true);                         // 69
    }, Kt.prototype.get = function (t) {                                                                               // 69
      var n = this.__data__;return t = hn(n, t), 0 > t ? P : n[t][1];                                                  // 69
    }, Kt.prototype.has = function (t) {                                                                               // 69
      return -1 < hn(this.__data__, t);                                                                                // 69
    }, Kt.prototype.set = function (t, n) {                                                                            // 69
      var r = this.__data__,                                                                                           // 69
          e = hn(r, t);return 0 > e ? r.push([t, n]) : r[e][1] = n, this;                                              // 69
    }, Gt.prototype.clear = function () {                                                                              // 69
      this.__data__ = { hash: new qt(), map: new (Ro || Kt)(), string: new qt() };                                     // 69
    }, Gt.prototype["delete"] = function (t) {                                                                         // 69
      return ce(this, t)["delete"](t);                                                                                 // 69
    }, Gt.prototype.get = function (t) {                                                                               // 69
      return ce(this, t).get(t);                                                                                       // 69
    }, Gt.prototype.has = function (t) {                                                                               // 70
      return ce(this, t).has(t);                                                                                       // 70
    }, Gt.prototype.set = function (t, n) {                                                                            // 70
      return ce(this, t).set(t, n), this;                                                                              // 70
    }, Yt.prototype.add = Yt.prototype.push = function (t) {                                                           // 70
      return this.__data__.set(t, "__lodash_hash_undefined__"), this;                                                  // 70
    }, Yt.prototype.has = function (t) {                                                                               // 70
      return this.__data__.has(t);                                                                                     // 70
    }, cn.prototype.clear = function () {                                                                              // 70
      this.__data__ = new Kt();                                                                                        // 70
    }, cn.prototype["delete"] = function (t) {                                                                         // 70
      return this.__data__["delete"](t);                                                                               // 70
    }, cn.prototype.get = function (t) {                                                                               // 70
      return this.__data__.get(t);                                                                                     // 70
    }, cn.prototype.has = function (t) {                                                                               // 70
      return this.__data__.has(t);                                                                                     // 70
    }, cn.prototype.set = function (t, n) {                                                                            // 71
      var r = this.__data__;if (r instanceof Kt) {                                                                     // 71
        if (r = r.__data__, !Ro || 199 > r.length) return r.push([t, n]), this;r = this.__data__ = new Gt(r);          // 71
      }return r.set(t, n), this;                                                                                       // 71
    };var Vo = zr(En),                                                                                                 // 71
        Ko = zr(Sn, true),                                                                                             // 71
        Go = Ur(),                                                                                                     // 71
        Jo = Ur(true),                                                                                                 // 71
        Yo = U(xo);io && !ao.call({ valueOf: 1 }, "valueOf") && (Gn = function Gn(t) {                                 // 71
      return L(io(t));                                                                                                 // 71
    });var Ho = Lo ? function (t, n) {                                                                                 // 71
      return Lo.set(t, n), t;                                                                                          // 71
    } : Wu,                                                                                                            // 71
        Qo = Wo && 1 / $(new Wo([, -0]))[1] == Z ? function (t) {                                                      // 71
      return new Wo(t);                                                                                                // 71
    } : Cu,                                                                                                            // 71
        Xo = Lo ? function (t) {                                                                                       // 71
      return Lo.get(t);                                                                                                // 71
    } : Cu,                                                                                                            // 71
        ti = j("length"),                                                                                              // 71
        ni = U(_o),                                                                                                    // 71
        ri = vo ? U(vo) : zu,                                                                                          // 71
        ei = vo ? function (t) {                                                                                       // 71
      for (var n = []; t;) {                                                                                           // 72
        s(n, ri(t)), t = ni(t);                                                                                        // 72
      }return n;                                                                                                       // 72
    } : zu;(So && "[object DataView]" != St(new So(new ArrayBuffer(1))) || Ro && "[object Map]" != St(new Ro()) || Io && "[object Promise]" != St(Io.resolve()) || Wo && "[object Set]" != St(new Wo()) || Bo && "[object WeakMap]" != St(new Bo())) && (St = function St(t) {
      var n = Xu.call(t);if (t = (t = "[object Object]" == n ? t.constructor : P) ? ke(t) : P) switch (t) {case Do:    // 72
          return "[object DataView]";case $o:                                                                          // 72
          return "[object Map]";case Fo:                                                                               // 72
          return "[object Promise]";case To:                                                                           // 72
          return "[object Set]";case No:                                                                               // 72
          return "[object WeakMap]";                                                                                   // 72
      }return n;                                                                                                       // 72
    });var ui = Ku ? ou : Uu,                                                                                          // 73
        oi = function () {                                                                                             // 73
      var t = 0,                                                                                                       // 73
          n = 0;return function (r, e) {                                                                               // 73
        var u = Ve(),                                                                                                  // 73
            o = 16 - (u - n);if (n = u, 0 < o) {                                                                       // 73
          if (150 <= ++t) return r;                                                                                    // 73
        } else t = 0;return Ho(r, e);                                                                                  // 73
      };                                                                                                               // 73
    }(),                                                                                                               // 73
        ii = Co ? function (t, n, r) {                                                                                 // 73
      n += "";var e;e = (e = n.match(pt)) ? e[1].split(_t) : [], r = Ee(e, r), e = r.length;var u = e - 1;return r[u] = (1 < e ? "& " : "") + r[u], r = r.join(2 < e ? ", " : " "), n = n.replace(ht, "{\n/* [wrapped with " + r + "] */\n"), Co(t, "toString", { configurable: true, enumerable: false, value: Iu(n) });
    } : Wu,                                                                                                            // 73
        fi = Qe(function (t) {                                                                                         // 73
      t = xu(t);var n = [];return ot.test(t) && n.push(""), t.replace(it, function (t, r, e, u) {                      // 73
        n.push(e ? u.replace(gt, "$1") : r || t);                                                                      // 74
      }), n;                                                                                                           // 74
    }),                                                                                                                // 74
        ci = ar(function (t, n) {                                                                                      // 73
      return eu(t) ? wn(t, kn(n, 1, eu, true)) : [];                                                                   // 74
    }),                                                                                                                // 74
        ai = ar(function (t, n) {                                                                                      // 73
      var r = Ce(n);return eu(r) && (r = P), eu(t) ? wn(t, kn(n, 1, eu, true), fe(r, 2)) : [];                         // 74
    }),                                                                                                                // 74
        li = ar(function (t, n) {                                                                                      // 73
      var r = Ce(n);return eu(r) && (r = P), eu(t) ? wn(t, kn(n, 1, eu, true), P, r) : [];                             // 74
    }),                                                                                                                // 74
        si = ar(function (t) {                                                                                         // 73
      var n = l(t, mr);return n.length && n[0] === t[0] ? Ln(n) : [];                                                  // 74
    }),                                                                                                                // 74
        hi = ar(function (t) {                                                                                         // 73
      var n = Ce(t),                                                                                                   // 74
          r = l(t, mr);return n === Ce(r) ? n = P : r.pop(), r.length && r[0] === t[0] ? Ln(r, fe(n, 2)) : [];         // 74
    }),                                                                                                                // 74
        pi = ar(function (t) {                                                                                         // 73
      var n = Ce(t),                                                                                                   // 74
          r = l(t, mr);return n === Ce(r) ? n = P : r.pop(), r.length && r[0] === t[0] ? Ln(r, P, n) : [];             // 74
    }),                                                                                                                // 75
        _i = ar(Le),                                                                                                   // 73
        vi = ar(function (t, n) {                                                                                      // 73
      n = kn(n, 1);var r = t ? t.length : 0,                                                                           // 75
          e = vn(t, n);return ir(t, l(n, function (t) {                                                                // 75
        return de(t, r) ? +t : t;                                                                                      // 75
      }).sort(Sr)), e;                                                                                                 // 75
    }),                                                                                                                // 75
        gi = ar(function (t) {                                                                                         // 73
      return yr(kn(t, 1, eu, true));                                                                                   // 75
    }),                                                                                                                // 75
        di = ar(function (t) {                                                                                         // 73
      var n = Ce(t);return eu(n) && (n = P), yr(kn(t, 1, eu, true), fe(n, 2));                                         // 75
    }),                                                                                                                // 75
        yi = ar(function (t) {                                                                                         // 73
      var n = Ce(t);return eu(n) && (n = P), yr(kn(t, 1, eu, true), P, n);                                             // 75
    }),                                                                                                                // 75
        bi = ar(function (t, n) {                                                                                      // 73
      return eu(t) ? wn(t, n) : [];                                                                                    // 75
    }),                                                                                                                // 75
        xi = ar(function (t) {                                                                                         // 73
      return jr(f(t, eu));                                                                                             // 75
    }),                                                                                                                // 75
        ji = ar(function (t) {                                                                                         // 73
      var n = Ce(t);return eu(n) && (n = P), jr(f(t, eu), fe(n, 2));                                                   // 75
    }),                                                                                                                // 76
        wi = ar(function (t) {                                                                                         // 73
      var n = Ce(t);return eu(n) && (n = P), jr(f(t, eu), P, n);                                                       // 76
    }),                                                                                                                // 76
        mi = ar(Ue),                                                                                                   // 73
        Ai = ar(function (t) {                                                                                         // 73
      var n = t.length,                                                                                                // 76
          n = 1 < n ? t[n - 1] : P,                                                                                    // 76
          n = typeof n == "function" ? (t.pop(), n) : P;return De(t, n);                                               // 76
    }),                                                                                                                // 76
        Oi = ar(function (t) {                                                                                         // 73
      function n(n) {                                                                                                  // 76
        return vn(n, t);                                                                                               // 76
      }t = kn(t, 1);var r = t.length,                                                                                  // 76
          e = r ? t[0] : 0,                                                                                            // 76
          u = this.__wrapped__;return !(1 < r || this.__actions__.length) && u instanceof Zt && de(e) ? (u = u.slice(e, +e + (r ? 1 : 0)), u.__actions__.push({ func: Fe, args: [n], thisArg: P }), new Tt(u, this.__chain__).thru(function (t) {
        return r && !t.length && t.push(P), t;                                                                         // 76
      })) : this.thru(n);                                                                                              // 77
    }),                                                                                                                // 77
        ki = Cr(function (t, n, r) {                                                                                   // 73
      Yu.call(t, r) ? ++t[r] : t[r] = 1;                                                                               // 77
    }),                                                                                                                // 77
        Ei = Pr(We),                                                                                                   // 73
        Si = Pr(Be),                                                                                                   // 73
        Ri = Cr(function (t, n, r) {                                                                                   // 73
      Yu.call(t, r) ? t[r].push(n) : t[r] = [n];                                                                       // 77
    }),                                                                                                                // 77
        Ii = ar(function (t, n, e) {                                                                                   // 73
      var u = -1,                                                                                                      // 77
          o = typeof n == "function",                                                                                  // 77
          i = be(n),                                                                                                   // 77
          f = ru(t) ? Du(t.length) : [];return Vo(t, function (t) {                                                    // 77
        var c = o ? n : i && null != t ? t[n] : P;f[++u] = c ? r(c, t, e) : Un(t, n, e);                               // 77
      }), f;                                                                                                           // 77
    }),                                                                                                                // 77
        Wi = Cr(function (t, n, r) {                                                                                   // 73
      t[r] = n;                                                                                                        // 77
    }),                                                                                                                // 77
        Bi = Cr(function (t, n, r) {                                                                                   // 73
      t[r ? 0 : 1].push(n);                                                                                            // 77
    }, function () {                                                                                                   // 77
      return [[], []];                                                                                                 // 77
    }),                                                                                                                // 77
        Mi = ar(function (t, n) {                                                                                      // 73
      if (null == t) return [];var r = n.length;return 1 < r && ye(t, n[0], n[1]) ? n = [] : 2 < r && ye(n[0], n[1], n[2]) && (n = [n[0]]), nr(t, kn(n, 1), []);
    }),                                                                                                                // 78
        Ci = ar(function (t, n, r) {                                                                                   // 73
      var e = 1;if (r.length) var u = D(r, ie(Ci)),                                                                    // 78
          e = 32 | e;return re(t, e, n, r, u);                                                                         // 78
    }),                                                                                                                // 78
        Li = ar(function (t, n, r) {                                                                                   // 73
      var e = 3;if (r.length) var u = D(r, ie(Li)),                                                                    // 78
          e = 32 | e;return re(n, e, t, r, u);                                                                         // 78
    }),                                                                                                                // 78
        zi = ar(function (t, n) {                                                                                      // 73
      return jn(t, 1, n);                                                                                              // 78
    }),                                                                                                                // 78
        Ui = ar(function (t, n, r) {                                                                                   // 73
      return jn(t, yu(n) || 0, r);                                                                                     // 78
    });Qe.Cache = Gt;var Di = ar(function (t, n) {                                                                     // 78
      n = 1 == n.length && Zi(n[0]) ? l(n[0], S(fe())) : l(kn(n, 1), S(fe()));var e = n.length;return ar(function (u) {
        for (var o = -1, i = wo(u.length, e); ++o < i;) {                                                              // 78
          u[o] = n[o].call(this, u[o]);                                                                                // 78
        }return r(t, this, u);                                                                                         // 78
      });                                                                                                              // 78
    }),                                                                                                                // 79
        $i = ar(function (t, n) {                                                                                      // 78
      var r = D(n, ie($i));return re(t, 32, P, n, r);                                                                  // 79
    }),                                                                                                                // 79
        Fi = ar(function (t, n) {                                                                                      // 78
      var r = D(n, ie(Fi));return re(t, 64, P, n, r);                                                                  // 79
    }),                                                                                                                // 79
        Ti = ar(function (t, n) {                                                                                      // 78
      return re(t, 256, P, P, P, kn(n, 1));                                                                            // 79
    }),                                                                                                                // 79
        Ni = Qr(Bn),                                                                                                   // 78
        Pi = Qr(function (t, n) {                                                                                      // 78
      return t >= n;                                                                                                   // 79
    }),                                                                                                                // 79
        Zi = Du.isArray,                                                                                               // 78
        qi = Ht ? S(Ht) : Dn,                                                                                          // 78
        Vi = go || Uu,                                                                                                 // 78
        Ki = Qt ? S(Qt) : $n,                                                                                          // 78
        Gi = Xt ? S(Xt) : Tn,                                                                                          // 78
        Ji = tn ? S(tn) : Zn,                                                                                          // 78
        Yi = nn ? S(nn) : qn,                                                                                          // 78
        Hi = rn ? S(rn) : Vn,                                                                                          // 78
        Qi = Qr(Jn),                                                                                                   // 78
        Xi = Qr(function (t, n) {                                                                                      // 78
      return t <= n;                                                                                                   // 79
    }),                                                                                                                // 79
        tf = Lr(function (t, n) {                                                                                      // 78
      if (zo || je(n) || ru(n)) Br(n, mu(n), t);else for (var r in meteorBabelHelpers.sanitizeForInObject(n)) {        // 79
        Yu.call(n, r) && sn(t, r, n[r]);                                                                               // 79
      }                                                                                                                // 79
    }),                                                                                                                // 79
        nf = Lr(function (t, n) {                                                                                      // 78
      if (zo || je(n) || ru(n)) Br(n, Au(n), t);else for (var r in meteorBabelHelpers.sanitizeForInObject(n)) {        // 80
        sn(t, r, n[r]);                                                                                                // 80
      }                                                                                                                // 80
    }),                                                                                                                // 80
        rf = Lr(function (t, n, r, e) {                                                                                // 78
      Br(n, Au(n), t, e);                                                                                              // 80
    }),                                                                                                                // 80
        ef = Lr(function (t, n, r, e) {                                                                                // 78
      Br(n, mu(n), t, e);                                                                                              // 80
    }),                                                                                                                // 80
        uf = ar(function (t, n) {                                                                                      // 78
      return vn(t, kn(n, 1));                                                                                          // 80
    }),                                                                                                                // 80
        of = ar(function (t) {                                                                                         // 78
      return t.push(P, an), r(rf, P, t);                                                                               // 80
    }),                                                                                                                // 80
        ff = ar(function (t) {                                                                                         // 78
      return t.push(P, me), r(hf, P, t);                                                                               // 80
    }),                                                                                                                // 80
        cf = Vr(function (t, n, r) {                                                                                   // 78
      t[n] = r;                                                                                                        // 80
    }, Iu(Wu)),                                                                                                        // 80
        af = Vr(function (t, n, r) {                                                                                   // 78
      Yu.call(t, n) ? t[n].push(r) : t[n] = [r];                                                                       // 80
    }, fe),                                                                                                            // 80
        lf = ar(Un),                                                                                                   // 78
        sf = Lr(function (t, n, r) {                                                                                   // 78
      Xn(t, n, r);                                                                                                     // 80
    }),                                                                                                                // 80
        hf = Lr(function (t, n, r, e) {                                                                                // 78
      Xn(t, n, r, e);                                                                                                  // 80
    }),                                                                                                                // 80
        pf = ar(function (t, n) {                                                                                      // 78
      return null == t ? {} : (n = l(kn(n, 1), Oe), rr(t, wn(Wn(t, Au, ei), n)));                                      // 80
    }),                                                                                                                // 81
        _f = ar(function (t, n) {                                                                                      // 78
      return null == t ? {} : rr(t, l(kn(n, 1), Oe));                                                                  // 81
    }),                                                                                                                // 81
        vf = ne(mu),                                                                                                   // 78
        gf = ne(Au),                                                                                                   // 78
        df = Fr(function (t, n, r) {                                                                                   // 78
      return n = n.toLowerCase(), t + (r ? Eu(n) : n);                                                                 // 81
    }),                                                                                                                // 81
        yf = Fr(function (t, n, r) {                                                                                   // 78
      return t + (r ? "-" : "") + n.toLowerCase();                                                                     // 81
    }),                                                                                                                // 81
        bf = Fr(function (t, n, r) {                                                                                   // 78
      return t + (r ? " " : "") + n.toLowerCase();                                                                     // 81
    }),                                                                                                                // 81
        xf = $r("toLowerCase"),                                                                                        // 78
        jf = Fr(function (t, n, r) {                                                                                   // 78
      return t + (r ? "_" : "") + n.toLowerCase();                                                                     // 81
    }),                                                                                                                // 81
        wf = Fr(function (t, n, r) {                                                                                   // 78
      return t + (r ? " " : "") + Af(n);                                                                               // 81
    }),                                                                                                                // 81
        mf = Fr(function (t, n, r) {                                                                                   // 78
      return t + (r ? " " : "") + n.toUpperCase();                                                                     // 81
    }),                                                                                                                // 81
        Af = $r("toUpperCase"),                                                                                        // 78
        Of = ar(function (t, n) {                                                                                      // 78
      try {                                                                                                            // 82
        return r(t, P, n);                                                                                             // 82
      } catch (t) {                                                                                                    // 82
        return uu(t) ? t : new Fu(t);                                                                                  // 82
      }                                                                                                                // 82
    }),                                                                                                                // 82
        kf = ar(function (t, n) {                                                                                      // 78
      return u(kn(n, 1), function (n) {                                                                                // 82
        n = Oe(n), t[n] = Ci(t[n], t);                                                                                 // 82
      }), t;                                                                                                           // 82
    }),                                                                                                                // 82
        Ef = Zr(),                                                                                                     // 78
        Sf = Zr(true),                                                                                                 // 78
        Rf = ar(function (t, n) {                                                                                      // 78
      return function (r) {                                                                                            // 82
        return Un(r, t, n);                                                                                            // 82
      };                                                                                                               // 82
    }),                                                                                                                // 82
        If = ar(function (t, n) {                                                                                      // 78
      return function (r) {                                                                                            // 82
        return Un(t, r, n);                                                                                            // 82
      };                                                                                                               // 82
    }),                                                                                                                // 82
        Wf = Gr(l),                                                                                                    // 78
        Bf = Gr(i),                                                                                                    // 78
        Mf = Gr(_),                                                                                                    // 78
        Cf = Hr(),                                                                                                     // 78
        Lf = Hr(true),                                                                                                 // 78
        zf = Kr(function (t, n) {                                                                                      // 78
      return t + n;                                                                                                    // 82
    }, 0),                                                                                                             // 82
        Uf = te("ceil"),                                                                                               // 78
        Df = Kr(function (t, n) {                                                                                      // 78
      return t / n;                                                                                                    // 82
    }, 1),                                                                                                             // 82
        $f = te("floor"),                                                                                              // 78
        Ff = Kr(function (t, n) {                                                                                      // 78
      return t * n;                                                                                                    // 82
    }, 1),                                                                                                             // 82
        Tf = te("round"),                                                                                              // 78
        Nf = Kr(function (t, n) {                                                                                      // 78
      return t - n;                                                                                                    // 82
    }, 0);return It.after = function (t, n) {                                                                          // 82
      if (typeof n != "function") throw new Pu("Expected a function");return t = gu(t), function () {                  // 83
        if (1 > --t) return n.apply(this, arguments);                                                                  // 83
      };                                                                                                               // 83
    }, It.ary = Ke, It.assign = tf, It.assignIn = nf, It.assignInWith = rf, It.assignWith = ef, It.at = uf, It.before = Ge, It.bind = Ci, It.bindAll = kf, It.bindKey = Li, It.castArray = function () {
      if (!arguments.length) return [];var t = arguments[0];return Zi(t) ? t : [t];                                    // 83
    }, It.chain = $e, It.chunk = function (t, n, r) {                                                                  // 83
      if (n = (r ? ye(t, n, r) : n === P) ? 1 : jo(gu(n), 0), r = t ? t.length : 0, !r || 1 > n) return [];for (var e = 0, u = 0, o = Du(ho(r / n)); e < r;) {
        o[u++] = sr(t, e, e += n);                                                                                     // 83
      }return o;                                                                                                       // 83
    }, It.compact = function (t) {                                                                                     // 84
      for (var n = -1, r = t ? t.length : 0, e = 0, u = []; ++n < r;) {                                                // 84
        var o = t[n];o && (u[e++] = o);                                                                                // 84
      }return u;                                                                                                       // 84
    }, It.concat = function () {                                                                                       // 84
      for (var t = arguments.length, n = Du(t ? t - 1 : 0), r = arguments[0], e = t; e--;) {                           // 84
        n[e - 1] = arguments[e];                                                                                       // 84
      }return t ? s(Zi(r) ? Wr(r) : [r], kn(n, 1)) : [];                                                               // 84
    }, It.cond = function (t) {                                                                                        // 84
      var n = t ? t.length : 0,                                                                                        // 84
          e = fe();return t = n ? l(t, function (t) {                                                                  // 84
        if ("function" != typeof t[1]) throw new Pu("Expected a function");return [e(t[0]), t[1]];                     // 84
      }) : [], ar(function (e) {                                                                                       // 84
        for (var u = -1; ++u < n;) {                                                                                   // 84
          var o = t[u];if (r(o[0], this, e)) return r(o[1], this, e);                                                  // 84
        }                                                                                                              // 85
      });                                                                                                              // 85
    }, It.conforms = function (t) {                                                                                    // 85
      return yn(dn(t, true));                                                                                          // 85
    }, It.constant = Iu, It.countBy = ki, It.create = function (t, n) {                                                // 85
      var r = xn(t);return n ? _n(r, n) : r;                                                                           // 85
    }, It.curry = Je, It.curryRight = Ye, It.debounce = He, It.defaults = of, It.defaultsDeep = ff, It.defer = zi, It.delay = Ui, It.difference = ci, It.differenceBy = ai, It.differenceWith = li, It.drop = Re, It.dropRight = Ie, It.dropRightWhile = function (t, n) {
      return t && t.length ? br(t, fe(n, 3), true, true) : [];                                                         // 85
    }, It.dropWhile = function (t, n) {                                                                                // 85
      return t && t.length ? br(t, fe(n, 3), true) : [];                                                               // 85
    }, It.fill = function (t, n, r, e) {                                                                               // 85
      var u = t ? t.length : 0;                                                                                        // 85
      if (!u) return [];for (r && typeof r != "number" && ye(t, n, r) && (r = 0, e = u), u = t.length, r = gu(r), 0 > r && (r = -r > u ? 0 : u + r), e = e === P || e > u ? u : gu(e), 0 > e && (e += u), e = r > e ? 0 : du(e); r < e;) {
        t[r++] = n;                                                                                                    // 86
      }return t;                                                                                                       // 86
    }, It.filter = function (t, n) {                                                                                   // 86
      return (Zi(t) ? f : On)(t, fe(n, 3));                                                                            // 86
    }, It.flatMap = function (t, n) {                                                                                  // 86
      return kn(Ze(t, n), 1);                                                                                          // 86
    }, It.flatMapDeep = function (t, n) {                                                                              // 86
      return kn(Ze(t, n), Z);                                                                                          // 86
    }, It.flatMapDepth = function (t, n, r) {                                                                          // 86
      return r = r === P ? 1 : gu(r), kn(Ze(t, n), r);                                                                 // 86
    }, It.flatten = function (t) {                                                                                     // 86
      return t && t.length ? kn(t, 1) : [];                                                                            // 86
    }, It.flattenDeep = function (t) {                                                                                 // 86
      return t && t.length ? kn(t, Z) : [];                                                                            // 86
    }, It.flattenDepth = function (t, n) {                                                                             // 87
      return t && t.length ? (n = n === P ? 1 : gu(n), kn(t, n)) : [];                                                 // 87
    }, It.flip = function (t) {                                                                                        // 87
      return re(t, 512);                                                                                               // 87
    }, It.flow = Ef, It.flowRight = Sf, It.fromPairs = function (t) {                                                  // 87
      for (var n = -1, r = t ? t.length : 0, e = {}; ++n < r;) {                                                       // 87
        var u = t[n];e[u[0]] = u[1];                                                                                   // 87
      }return e;                                                                                                       // 87
    }, It.functions = function (t) {                                                                                   // 87
      return null == t ? [] : Rn(t, mu(t));                                                                            // 87
    }, It.functionsIn = function (t) {                                                                                 // 87
      return null == t ? [] : Rn(t, Au(t));                                                                            // 87
    }, It.groupBy = Ri, It.initial = function (t) {                                                                    // 87
      return Ie(t, 1);                                                                                                 // 87
    }, It.intersection = si, It.intersectionBy = hi, It.intersectionWith = pi, It.invert = cf, It.invertBy = af, It.invokeMap = Ii, It.iteratee = Bu, It.keyBy = Wi, It.keys = mu, It.keysIn = Au, It.map = Ze, It.mapKeys = function (t, n) {
      var r = {};return n = fe(n, 3), En(t, function (t, e, u) {                                                       // 88
        r[n(t, e, u)] = t;                                                                                             // 88
      }), r;                                                                                                           // 88
    }, It.mapValues = function (t, n) {                                                                                // 88
      var r = {};return n = fe(n, 3), En(t, function (t, e, u) {                                                       // 88
        r[e] = n(t, e, u);                                                                                             // 88
      }), r;                                                                                                           // 88
    }, It.matches = function (t) {                                                                                     // 88
      return Hn(dn(t, true));                                                                                          // 88
    }, It.matchesProperty = function (t, n) {                                                                          // 88
      return Qn(t, dn(n, true));                                                                                       // 88
    }, It.memoize = Qe, It.merge = sf, It.mergeWith = hf, It.method = Rf, It.methodOf = If, It.mixin = Mu, It.negate = Xe, It.nthArg = function (t) {
      return t = gu(t), ar(function (n) {                                                                              // 88
        return tr(n, t);                                                                                               // 89
      });                                                                                                              // 89
    }, It.omit = pf, It.omitBy = function (t, n) {                                                                     // 89
      return Ou(t, Xe(fe(n)));                                                                                         // 89
    }, It.once = function (t) {                                                                                        // 89
      return Ge(2, t);                                                                                                 // 89
    }, It.orderBy = function (t, n, r, e) {                                                                            // 89
      return null == t ? [] : (Zi(n) || (n = null == n ? [] : [n]), r = e ? P : r, Zi(r) || (r = null == r ? [] : [r]), nr(t, n, r));
    }, It.over = Wf, It.overArgs = Di, It.overEvery = Bf, It.overSome = Mf, It.partial = $i, It.partialRight = Fi, It.partition = Bi, It.pick = _f, It.pickBy = Ou, It.property = Lu, It.propertyOf = function (t) {
      return function (n) {                                                                                            // 89
        return null == t ? P : In(t, n);                                                                               // 89
      };                                                                                                               // 89
    }, It.pull = _i, It.pullAll = Le, It.pullAllBy = function (t, n, r) {                                              // 89
      return t && t.length && n && n.length ? or(t, n, fe(r, 2)) : t;                                                  // 90
    }, It.pullAllWith = function (t, n, r) {                                                                           // 90
      return t && t.length && n && n.length ? or(t, n, P, r) : t;                                                      // 90
    }, It.pullAt = vi, It.range = Cf, It.rangeRight = Lf, It.rearg = Ti, It.reject = function (t, n) {                 // 90
      return (Zi(t) ? f : On)(t, Xe(fe(n, 3)));                                                                        // 90
    }, It.remove = function (t, n) {                                                                                   // 90
      var r = [];if (!t || !t.length) return r;var e = -1,                                                             // 90
          u = [],                                                                                                      // 90
          o = t.length;for (n = fe(n, 3); ++e < o;) {                                                                  // 90
        var i = t[e];n(i, e, t) && (r.push(i), u.push(e));                                                             // 90
      }return ir(t, u), r;                                                                                             // 90
    }, It.rest = function (t, n) {                                                                                     // 90
      if (typeof t != "function") throw new Pu("Expected a function");return n = n === P ? n : gu(n), ar(t, n);        // 90
    }, It.reverse = ze, It.sampleSize = qe, It.set = function (t, n, r) {                                              // 91
      return null == t ? t : lr(t, n, r);                                                                              // 91
    }, It.setWith = function (t, n, r, e) {                                                                            // 91
      return e = typeof e == "function" ? e : P, null == t ? t : lr(t, n, r, e);                                       // 91
    }, It.shuffle = function (t) {                                                                                     // 91
      return qe(t, 4294967295);                                                                                        // 91
    }, It.slice = function (t, n, r) {                                                                                 // 91
      var e = t ? t.length : 0;return e ? (r && typeof r != "number" && ye(t, n, r) ? (n = 0, r = e) : (n = null == n ? 0 : gu(n), r = r === P ? e : gu(r)), sr(t, n, r)) : [];
    }, It.sortBy = Mi, It.sortedUniq = function (t) {                                                                  // 91
      return t && t.length ? vr(t) : [];                                                                               // 91
    }, It.sortedUniqBy = function (t, n) {                                                                             // 91
      return t && t.length ? vr(t, fe(n, 2)) : [];                                                                     // 91
    }, It.split = function (t, n, r) {                                                                                 // 92
      return r && typeof r != "number" && ye(t, n, r) && (n = r = P), r = r === P ? 4294967295 : r >>> 0, r ? (t = xu(t)) && (typeof n == "string" || null != n && !Ji(n)) && (n = dr(n), "" == n && Lt.test(t)) ? Or(t.match(Mt), 0, r) : Eo.call(t, n, r) : [];
    }, It.spread = function (t, n) {                                                                                   // 92
      if (typeof t != "function") throw new Pu("Expected a function");return n = n === P ? 0 : jo(gu(n), 0), ar(function (e) {
        var u = e[n];return e = Or(e, 0, n), u && s(e, u), r(t, this, e);                                              // 92
      });                                                                                                              // 92
    }, It.tail = function (t) {                                                                                        // 92
      return Re(t, 1);                                                                                                 // 92
    }, It.take = function (t, n, r) {                                                                                  // 92
      return t && t.length ? (n = r || n === P ? 1 : gu(n), sr(t, 0, 0 > n ? 0 : n)) : [];                             // 92
    }, It.takeRight = function (t, n, r) {                                                                             // 93
      var e = t ? t.length : 0;return e ? (n = r || n === P ? 1 : gu(n), n = e - n, sr(t, 0 > n ? 0 : n, e)) : [];     // 93
    }, It.takeRightWhile = function (t, n) {                                                                           // 93
      return t && t.length ? br(t, fe(n, 3), false, true) : [];                                                        // 93
    }, It.takeWhile = function (t, n) {                                                                                // 93
      return t && t.length ? br(t, fe(n, 3)) : [];                                                                     // 93
    }, It.tap = function (t, n) {                                                                                      // 93
      return n(t), t;                                                                                                  // 93
    }, It.throttle = function (t, n, r) {                                                                              // 93
      var e = true,                                                                                                    // 93
          u = true;if (typeof t != "function") throw new Pu("Expected a function");return cu(r) && (e = "leading" in r ? !!r.leading : e, u = "trailing" in r ? !!r.trailing : u), He(t, n, { leading: e, maxWait: n,
        trailing: u });                                                                                                // 94
    }, It.thru = Fe, It.toArray = _u, It.toPairs = vf, It.toPairsIn = gf, It.toPath = function (t) {                   // 94
      return Zi(t) ? l(t, Oe) : pu(t) ? [t] : Wr(fi(t));                                                               // 94
    }, It.toPlainObject = bu, It.transform = function (t, n, r) {                                                      // 94
      var e = Zi(t) || Hi(t);if (n = fe(n, 4), null == r) if (e || cu(t)) {                                            // 94
        var o = t.constructor;r = e ? Zi(t) ? new o() : [] : ou(o) ? xn(ni(t)) : {};                                   // 94
      } else r = {};return (e ? u : En)(t, function (t, e, u) {                                                        // 94
        return n(r, t, e, u);                                                                                          // 94
      }), r;                                                                                                           // 94
    }, It.unary = function (t) {                                                                                       // 94
      return Ke(t, 1);                                                                                                 // 94
    }, It.union = gi, It.unionBy = di, It.unionWith = yi, It.uniq = function (t) {                                     // 94
      return t && t.length ? yr(t) : [];                                                                               // 94
    }, It.uniqBy = function (t, n) {                                                                                   // 94
      return t && t.length ? yr(t, fe(n, 2)) : [];                                                                     // 95
    }, It.uniqWith = function (t, n) {                                                                                 // 95
      return t && t.length ? yr(t, P, n) : [];                                                                         // 95
    }, It.unset = function (t, n) {                                                                                    // 95
      var r;if (null == t) r = true;else {                                                                             // 95
        r = t;var e = n,                                                                                               // 95
            e = be(e, r) ? [e] : Ar(e);r = Ae(r, e), e = Oe(Ce(e)), r = !(null != r && Mn(r, e)) || delete r[e];       // 95
      }return r;                                                                                                       // 95
    }, It.unzip = Ue, It.unzipWith = De, It.update = function (t, n, r) {                                              // 95
      return null == t ? t : lr(t, n, (typeof r == "function" ? r : Wu)(In(t, n)), void 0);                            // 95
    }, It.updateWith = function (t, n, r, e) {                                                                         // 95
      return e = typeof e == "function" ? e : P, null != t && (t = lr(t, n, (typeof r == "function" ? r : Wu)(In(t, n)), e)), t;
    }, It.values = ku, It.valuesIn = function (t) {                                                                    // 95
      return null == t ? [] : R(t, Au(t));                                                                             // 96
    }, It.without = bi, It.words = Ru, It.wrap = function (t, n) {                                                     // 96
      return n = null == n ? Wu : n, $i(n, t);                                                                         // 96
    }, It.xor = xi, It.xorBy = ji, It.xorWith = wi, It.zip = mi, It.zipObject = function (t, n) {                      // 96
      return wr(t || [], n || [], sn);                                                                                 // 96
    }, It.zipObjectDeep = function (t, n) {                                                                            // 96
      return wr(t || [], n || [], lr);                                                                                 // 96
    }, It.zipWith = Ai, It.entries = vf, It.entriesIn = gf, It.extend = nf, It.extendWith = rf, Mu(It, It), It.add = zf, It.attempt = Of, It.camelCase = df, It.capitalize = Eu, It.ceil = Uf, It.clamp = function (t, n, r) {
      return r === P && (r = n, n = P), r !== P && (r = yu(r), r = r === r ? r : 0), n !== P && (n = yu(n), n = n === n ? n : 0), gn(yu(t), n, r);
    }, It.clone = function (t) {                                                                                       // 97
      return dn(t, false, true);                                                                                       // 97
    }, It.cloneDeep = function (t) {                                                                                   // 97
      return dn(t, true, true);                                                                                        // 97
    }, It.cloneDeepWith = function (t, n) {                                                                            // 97
      return dn(t, true, true, n);                                                                                     // 97
    }, It.cloneWith = function (t, n) {                                                                                // 97
      return dn(t, false, true, n);                                                                                    // 97
    }, It.conformsTo = function (t, n) {                                                                               // 97
      return null == n || bn(t, n, mu(n));                                                                             // 97
    }, It.deburr = Su, It.defaultTo = function (t, n) {                                                                // 97
      return null == t || t !== t ? n : t;                                                                             // 97
    }, It.divide = Df, It.endsWith = function (t, n, r) {                                                              // 97
      t = xu(t), n = dr(n);var e = t.length,                                                                           // 97
          e = r = r === P ? e : gn(gu(r), 0, e);return r -= n.length, 0 <= r && t.slice(r, e) == n;                    // 97
    }, It.eq = tu, It.escape = function (t) {                                                                          // 98
      return (t = xu(t)) && X.test(t) ? t.replace(H, un) : t;                                                          // 98
    }, It.escapeRegExp = function (t) {                                                                                // 98
      return (t = xu(t)) && ct.test(t) ? t.replace(ft, "\\$&") : t;                                                    // 98
    }, It.every = function (t, n, r) {                                                                                 // 98
      var e = Zi(t) ? i : mn;return r && ye(t, n, r) && (n = P), e(t, fe(n, 3));                                       // 98
    }, It.find = Ei, It.findIndex = We, It.findKey = function (t, n) {                                                 // 98
      return v(t, fe(n, 3), En);                                                                                       // 98
    }, It.findLast = Si, It.findLastIndex = Be, It.findLastKey = function (t, n) {                                     // 98
      return v(t, fe(n, 3), Sn);                                                                                       // 98
    }, It.floor = $f, It.forEach = Ne, It.forEachRight = Pe, It.forIn = function (t, n) {                              // 98
      return null == t ? t : Go(t, fe(n, 3), Au);                                                                      // 98
    }, It.forInRight = function (t, n) {                                                                               // 99
      return null == t ? t : Jo(t, fe(n, 3), Au);                                                                      // 99
    }, It.forOwn = function (t, n) {                                                                                   // 99
      return t && En(t, fe(n, 3));                                                                                     // 99
    }, It.forOwnRight = function (t, n) {                                                                              // 99
      return t && Sn(t, fe(n, 3));                                                                                     // 99
    }, It.get = ju, It.gt = Ni, It.gte = Pi, It.has = function (t, n) {                                                // 99
      return null != t && se(t, n, Mn);                                                                                // 99
    }, It.hasIn = wu, It.head = Me, It.identity = Wu, It.includes = function (t, n, r, e) {                            // 99
      return t = ru(t) ? t : ku(t), r = r && !e ? gu(r) : 0, e = t.length, 0 > r && (r = jo(e + r, 0)), hu(t) ? r <= e && -1 < t.indexOf(n, r) : !!e && -1 < d(t, n, r);
    }, It.indexOf = function (t, n, r) {                                                                               // 99
      var e = t ? t.length : 0;return e ? (r = null == r ? 0 : gu(r), 0 > r && (r = jo(e + r, 0)), d(t, n, r)) : -1;   // 99
    }, It.inRange = function (t, n, r) {                                                                               // 100
      return n = vu(n), r === P ? (r = n, n = 0) : r = vu(r), t = yu(t), t >= wo(n, r) && t < jo(n, r);                // 100
    }, It.invoke = lf, It.isArguments = nu, It.isArray = Zi, It.isArrayBuffer = qi, It.isArrayLike = ru, It.isArrayLikeObject = eu, It.isBoolean = function (t) {
      return true === t || false === t || au(t) && "[object Boolean]" == Xu.call(t);                                   // 100
    }, It.isBuffer = Vi, It.isDate = Ki, It.isElement = function (t) {                                                 // 100
      return !!t && 1 === t.nodeType && au(t) && !su(t);                                                               // 100
    }, It.isEmpty = function (t) {                                                                                     // 100
      if (ru(t) && (Zi(t) || hu(t) || ou(t.splice) || nu(t) || Vi(t))) return !t.length;                               // 100
      if (au(t)) {                                                                                                     // 101
        var n = St(t);if ("[object Map]" == n || "[object Set]" == n) return !t.size;                                  // 101
      }for (var r in meteorBabelHelpers.sanitizeForInObject(t)) {                                                      // 101
        if (Yu.call(t, r)) return false;                                                                               // 101
      }return !(zo && mu(t).length);                                                                                   // 101
    }, It.isEqual = function (t, n) {                                                                                  // 101
      return Fn(t, n);                                                                                                 // 101
    }, It.isEqualWith = function (t, n, r) {                                                                           // 101
      var e = (r = typeof r == "function" ? r : P) ? r(t, n) : P;return e === P ? Fn(t, n, r) : !!e;                   // 101
    }, It.isError = uu, It.isFinite = function (t) {                                                                   // 101
      return typeof t == "number" && yo(t);                                                                            // 101
    }, It.isFunction = ou, It.isInteger = iu, It.isLength = fu, It.isMap = Gi, It.isMatch = function (t, n) {          // 101
      return t === n || Nn(t, n, ae(n));                                                                               // 101
    }, It.isMatchWith = function (t, n, r) {                                                                           // 101
      return r = typeof r == "function" ? r : P, Nn(t, n, ae(n), r);                                                   // 102
    }, It.isNaN = function (t) {                                                                                       // 102
      return lu(t) && t != +t;                                                                                         // 102
    }, It.isNative = function (t) {                                                                                    // 102
      if (ui(t)) throw new Fu("This method is not supported with core-js. Try https://github.com/es-shims.");return Pn(t);
    }, It.isNil = function (t) {                                                                                       // 102
      return null == t;                                                                                                // 102
    }, It.isNull = function (t) {                                                                                      // 102
      return null === t;                                                                                               // 102
    }, It.isNumber = lu, It.isObject = cu, It.isObjectLike = au, It.isPlainObject = su, It.isRegExp = Ji, It.isSafeInteger = function (t) {
      return iu(t) && -9007199254740991 <= t && 9007199254740991 >= t;                                                 // 102
    }, It.isSet = Yi, It.isString = hu, It.isSymbol = pu, It.isTypedArray = Hi, It.isUndefined = function (t) {        // 102
      return t === P;                                                                                                  // 103
    }, It.isWeakMap = function (t) {                                                                                   // 103
      return au(t) && "[object WeakMap]" == St(t);                                                                     // 103
    }, It.isWeakSet = function (t) {                                                                                   // 103
      return au(t) && "[object WeakSet]" == Xu.call(t);                                                                // 103
    }, It.join = function (t, n) {                                                                                     // 103
      return t ? bo.call(t, n) : "";                                                                                   // 103
    }, It.kebabCase = yf, It.last = Ce, It.lastIndexOf = function (t, n, r) {                                          // 103
      var e = t ? t.length : 0;if (!e) return -1;var u = e;if (r !== P && (u = gu(r), u = (0 > u ? jo(e + u, 0) : wo(u, e - 1)) + 1), n !== n) return g(t, b, u - 1, true);for (; u--;) {
        if (t[u] === n) return u;                                                                                      // 103
      }return -1;                                                                                                      // 103
    }, It.lowerCase = bf, It.lowerFirst = xf, It.lt = Qi, It.lte = Xi, It.max = function (t) {                         // 103
      return t && t.length ? An(t, Wu, Bn) : P;                                                                        // 104
    }, It.maxBy = function (t, n) {                                                                                    // 104
      return t && t.length ? An(t, fe(n, 2), Bn) : P;                                                                  // 104
    }, It.mean = function (t) {                                                                                        // 104
      return x(t, Wu);                                                                                                 // 104
    }, It.meanBy = function (t, n) {                                                                                   // 104
      return x(t, fe(n, 2));                                                                                           // 104
    }, It.min = function (t) {                                                                                         // 104
      return t && t.length ? An(t, Wu, Jn) : P;                                                                        // 104
    }, It.minBy = function (t, n) {                                                                                    // 104
      return t && t.length ? An(t, fe(n, 2), Jn) : P;                                                                  // 104
    }, It.stubArray = zu, It.stubFalse = Uu, It.stubObject = function () {                                             // 104
      return {};                                                                                                       // 104
    }, It.stubString = function () {                                                                                   // 104
      return "";                                                                                                       // 104
    }, It.stubTrue = function () {                                                                                     // 104
      return true;                                                                                                     // 104
    }, It.multiply = Ff, It.nth = function (t, n) {                                                                    // 104
      return t && t.length ? tr(t, gu(n)) : P;                                                                         // 105
    }, It.noConflict = function () {                                                                                   // 105
      return Vt._ === this && (Vt._ = to), this;                                                                       // 105
    }, It.noop = Cu, It.now = Ve, It.pad = function (t, n, r) {                                                        // 105
      t = xu(t);var e = (n = gu(n)) ? T(t) : 0;return !n || e >= n ? t : (n = (n - e) / 2, Jr(po(n), r) + t + Jr(ho(n), r));
    }, It.padEnd = function (t, n, r) {                                                                                // 105
      t = xu(t);var e = (n = gu(n)) ? T(t) : 0;return n && e < n ? t + Jr(n - e, r) : t;                               // 105
    }, It.padStart = function (t, n, r) {                                                                              // 105
      t = xu(t);var e = (n = gu(n)) ? T(t) : 0;return n && e < n ? Jr(n - e, r) + t : t;                               // 105
    }, It.parseInt = function (t, n, r) {                                                                              // 105
      return r || null == n ? n = 0 : n && (n = +n), t = xu(t).replace(at, ""), mo(t, n || (bt.test(t) ? 16 : 10));    // 105
    }, It.random = function (t, n, r) {                                                                                // 106
      if (r && typeof r != "boolean" && ye(t, n, r) && (n = r = P), r === P && (typeof n == "boolean" ? (r = n, n = P) : typeof t == "boolean" && (r = t, t = P)), t === P && n === P ? (t = 0, n = 1) : (t = vu(t), n === P ? (n = t, t = 0) : n = vu(n)), t > n) {
        var e = t;t = n, n = e;                                                                                        // 106
      }return r || t % 1 || n % 1 ? (r = Ao(), wo(t + r * (n - t + Nt("1e-" + ((r + "").length - 1))), n)) : fr(t, n);
    }, It.reduce = function (t, n, r) {                                                                                // 106
      var e = Zi(t) ? h : m,                                                                                           // 106
          u = 3 > arguments.length;return e(t, fe(n, 4), r, u, Vo);                                                    // 106
    }, It.reduceRight = function (t, n, r) {                                                                           // 106
      var e = Zi(t) ? p : m,                                                                                           // 106
          u = 3 > arguments.length;return e(t, fe(n, 4), r, u, Ko);                                                    // 106
    }, It.repeat = function (t, n, r) {                                                                                // 106
      return n = (r ? ye(t, n, r) : n === P) ? 1 : gu(n), cr(xu(t), n);                                                // 107
    }, It.replace = function () {                                                                                      // 107
      var t = arguments,                                                                                               // 107
          n = xu(t[0]);return 3 > t.length ? n : Oo.call(n, t[1], t[2]);                                               // 107
    }, It.result = function (t, n, r) {                                                                                // 107
      n = be(n, t) ? [n] : Ar(n);var e = -1,                                                                           // 107
          u = n.length;for (u || (t = P, u = 1); ++e < u;) {                                                           // 107
        var o = null == t ? P : t[Oe(n[e])];o === P && (e = u, o = r), t = ou(o) ? o.call(t) : o;                      // 107
      }return t;                                                                                                       // 107
    }, It.round = Tf, It.runInContext = N, It.sample = function (t) {                                                  // 107
      t = ru(t) ? t : ku(t);var n = t.length;return 0 < n ? t[fr(0, n - 1)] : P;                                       // 107
    }, It.size = function (t) {                                                                                        // 107
      if (null == t) return 0;if (ru(t)) {                                                                             // 107
        var n = t.length;return n && hu(t) ? T(t) : n;                                                                 // 107
      }return au(t) && (n = St(t), "[object Map]" == n || "[object Set]" == n) ? t.size : mu(t).length;                // 108
    }, It.snakeCase = jf, It.some = function (t, n, r) {                                                               // 108
      var e = Zi(t) ? _ : hr;return r && ye(t, n, r) && (n = P), e(t, fe(n, 3));                                       // 108
    }, It.sortedIndex = function (t, n) {                                                                              // 108
      return pr(t, n);                                                                                                 // 108
    }, It.sortedIndexBy = function (t, n, r) {                                                                         // 108
      return _r(t, n, fe(r, 2));                                                                                       // 108
    }, It.sortedIndexOf = function (t, n) {                                                                            // 108
      var r = t ? t.length : 0;if (r) {                                                                                // 108
        var e = pr(t, n);if (e < r && tu(t[e], n)) return e;                                                           // 108
      }return -1;                                                                                                      // 108
    }, It.sortedLastIndex = function (t, n) {                                                                          // 108
      return pr(t, n, true);                                                                                           // 108
    }, It.sortedLastIndexBy = function (t, n, r) {                                                                     // 108
      return _r(t, n, fe(r, 2), true);                                                                                 // 108
    }, It.sortedLastIndexOf = function (t, n) {                                                                        // 109
      if (t && t.length) {                                                                                             // 109
        var r = pr(t, n, true) - 1;if (tu(t[r], n)) return r;                                                          // 109
      }return -1;                                                                                                      // 109
    }, It.startCase = wf, It.startsWith = function (t, n, r) {                                                         // 109
      return t = xu(t), r = gn(gu(r), 0, t.length), n = dr(n), t.slice(r, r + n.length) == n;                          // 109
    }, It.subtract = Nf, It.sum = function (t) {                                                                       // 109
      return t && t.length ? O(t, Wu) : 0;                                                                             // 109
    }, It.sumBy = function (t, n) {                                                                                    // 109
      return t && t.length ? O(t, fe(n, 2)) : 0;                                                                       // 109
    }, It.template = function (t, n, r) {                                                                              // 109
      var e = It.templateSettings;r && ye(t, n, r) && (n = P), t = xu(t), n = rf({}, n, e, an), r = rf({}, n.imports, e.imports, an);var u,
          o,                                                                                                           // 109
          i = mu(r),                                                                                                   // 109
          f = R(r, i),                                                                                                 // 109
          c = 0;                                                                                                       // 109
      r = n.interpolate || kt;var a = "__p+='";r = Nu((n.escape || kt).source + "|" + r.source + "|" + (r === rt ? dt : kt).source + "|" + (n.evaluate || kt).source + "|$", "g");var l = "sourceURL" in n ? "//# sourceURL=" + n.sourceURL + "\n" : "";if (t.replace(r, function (n, r, e, i, f, l) {
        return e || (e = i), a += t.slice(c, l).replace(Et, M), r && (u = true, a += "'+__e(" + r + ")+'"), f && (o = true, a += "';" + f + ";\n__p+='"), e && (a += "'+((__t=(" + e + "))==null?'':__t)+'"), c = l + n.length, n;
      }), a += "';", (n = n.variable) || (a = "with(obj){" + a + "}"), a = (o ? a.replace(K, "") : a).replace(G, "$1").replace(J, "$1;"), a = "function(" + (n || "obj") + "){" + (n ? "" : "obj||(obj={});") + "var __t,__p=''" + (u ? ",__e=_.escape" : "") + (o ? ",__j=Array.prototype.join;function print(){__p+=__j.call(arguments,'')}" : ";") + a + "return __p}", n = Of(function () {
        return Function(i, l + "return " + a).apply(P, f);                                                             // 111
      }), n.source = a, uu(n)) throw n;return n;                                                                       // 111
    }, It.times = function (t, n) {                                                                                    // 111
      if (t = gu(t), 1 > t || 9007199254740991 < t) return [];var r = 4294967295,                                      // 111
          e = wo(t, 4294967295);for (n = fe(n), t -= 4294967295, e = k(e, n); ++r < t;) {                              // 111
        n(r);                                                                                                          // 111
      }return e;                                                                                                       // 111
    }, It.toFinite = vu, It.toInteger = gu, It.toLength = du, It.toLower = function (t) {                              // 111
      return xu(t).toLowerCase();                                                                                      // 112
    }, It.toNumber = yu, It.toSafeInteger = function (t) {                                                             // 112
      return gn(gu(t), -9007199254740991, 9007199254740991);                                                           // 112
    }, It.toString = xu, It.toUpper = function (t) {                                                                   // 112
      return xu(t).toUpperCase();                                                                                      // 112
    }, It.trim = function (t, n, r) {                                                                                  // 112
      return (t = xu(t)) && (r || n === P) ? t.replace(at, "") : t && (n = dr(n)) ? (t = t.match(Mt), r = n.match(Mt), n = W(t, r), r = B(t, r) + 1, Or(t, n, r).join("")) : t;
    }, It.trimEnd = function (t, n, r) {                                                                               // 112
      return (t = xu(t)) && (r || n === P) ? t.replace(st, "") : t && (n = dr(n)) ? (t = t.match(Mt), n = B(t, n.match(Mt)) + 1, Or(t, 0, n).join("")) : t;
    }, It.trimStart = function (t, n, r) {                                                                             // 112
      return (t = xu(t)) && (r || n === P) ? t.replace(lt, "") : t && (n = dr(n)) ? (t = t.match(Mt), n = W(t, n.match(Mt)), Or(t, n).join("")) : t;
    }, It.truncate = function (t, n) {                                                                                 // 113
      var r = 30,                                                                                                      // 113
          e = "...";if (cu(n)) var u = "separator" in n ? n.separator : u,                                             // 113
          r = "length" in n ? gu(n.length) : r,                                                                        // 113
          e = "omission" in n ? dr(n.omission) : e;t = xu(t);var o = t.length;if (Lt.test(t)) var i = t.match(Mt),     // 113
          o = i.length;if (r >= o) return t;if (o = r - T(e), 1 > o) return e;if (r = i ? Or(i, 0, o).join("") : t.slice(0, o), u === P) return r + e;if (i && (o += r.length - o), Ji(u)) {
        if (t.slice(o).search(u)) {                                                                                    // 113
          var f = r;for (u.global || (u = Nu(u.source, xu(yt.exec(u)) + "g")), u.lastIndex = 0; i = u.exec(f);) {      // 113
            var c = i.index;                                                                                           // 114
          }r = r.slice(0, c === P ? o : c);                                                                            // 113
        }                                                                                                              // 114
      } else t.indexOf(dr(u), o) != o && (u = r.lastIndexOf(u), -1 < u && (r = r.slice(0, u)));return r + e;           // 114
    }, It.unescape = function (t) {                                                                                    // 114
      return (t = xu(t)) && Q.test(t) ? t.replace(Y, on) : t;                                                          // 114
    }, It.uniqueId = function (t) {                                                                                    // 114
      var n = ++Hu;return xu(t) + n;                                                                                   // 114
    }, It.upperCase = mf, It.upperFirst = Af, It.each = Ne, It.eachRight = Pe, It.first = Me, Mu(It, function () {     // 114
      var t = {};return En(It, function (n, r) {                                                                       // 114
        Yu.call(It.prototype, r) || (t[r] = n);                                                                        // 114
      }), t;                                                                                                           // 114
    }(), { chain: false }), It.VERSION = "4.14.1", u("bind bindKey curry curryRight partial partialRight".split(" "), function (t) {
      It[t].placeholder = It;                                                                                          // 115
    }), u(["drop", "take"], function (t, n) {                                                                          // 115
      Zt.prototype[t] = function (r) {                                                                                 // 115
        var e = this.__filtered__;if (e && !n) return new Zt(this);r = r === P ? 1 : jo(gu(r), 0);var u = this.clone();return e ? u.__takeCount__ = wo(r, u.__takeCount__) : u.__views__.push({ size: wo(r, 4294967295), type: t + (0 > u.__dir__ ? "Right" : "") }), u;
      }, Zt.prototype[t + "Right"] = function (n) {                                                                    // 115
        return this.reverse()[t](n).reverse();                                                                         // 115
      };                                                                                                               // 115
    }), u(["filter", "map", "takeWhile"], function (t, n) {                                                            // 115
      var r = n + 1,                                                                                                   // 115
          e = 1 == r || 3 == r;Zt.prototype[t] = function (t) {                                                        // 115
        var n = this.clone();return n.__iteratees__.push({                                                             // 115
          iteratee: fe(t, 3), type: r }), n.__filtered__ = n.__filtered__ || e, n;                                     // 116
      };                                                                                                               // 116
    }), u(["head", "last"], function (t, n) {                                                                          // 116
      var r = "take" + (n ? "Right" : "");Zt.prototype[t] = function () {                                              // 116
        return this[r](1).value()[0];                                                                                  // 116
      };                                                                                                               // 116
    }), u(["initial", "tail"], function (t, n) {                                                                       // 116
      var r = "drop" + (n ? "" : "Right");Zt.prototype[t] = function () {                                              // 116
        return this.__filtered__ ? new Zt(this) : this[r](1);                                                          // 116
      };                                                                                                               // 116
    }), Zt.prototype.compact = function () {                                                                           // 116
      return this.filter(Wu);                                                                                          // 116
    }, Zt.prototype.find = function (t) {                                                                              // 116
      return this.filter(t).head();                                                                                    // 116
    }, Zt.prototype.findLast = function (t) {                                                                          // 116
      return this.reverse().find(t);                                                                                   // 116
    }, Zt.prototype.invokeMap = ar(function (t, n) {                                                                   // 117
      return typeof t == "function" ? new Zt(this) : this.map(function (r) {                                           // 117
        return Un(r, t, n);                                                                                            // 117
      });                                                                                                              // 117
    }), Zt.prototype.reject = function (t) {                                                                           // 117
      return this.filter(Xe(fe(t)));                                                                                   // 117
    }, Zt.prototype.slice = function (t, n) {                                                                          // 117
      t = gu(t);var r = this;return r.__filtered__ && (0 < t || 0 > n) ? new Zt(r) : (0 > t ? r = r.takeRight(-t) : t && (r = r.drop(t)), n !== P && (n = gu(n), r = 0 > n ? r.dropRight(-n) : r.take(n - t)), r);
    }, Zt.prototype.takeRightWhile = function (t) {                                                                    // 117
      return this.reverse().takeWhile(t).reverse();                                                                    // 117
    }, Zt.prototype.toArray = function () {                                                                            // 117
      return this.take(4294967295);                                                                                    // 117
    }, En(Zt.prototype, function (t, n) {                                                                              // 118
      var r = /^(?:filter|find|map|reject)|While$/.test(n),                                                            // 118
          e = /^(?:head|last)$/.test(n),                                                                               // 118
          u = It[e ? "take" + ("last" == n ? "Right" : "") : n],                                                       // 118
          o = e || /^find/.test(n);u && (It.prototype[n] = function () {                                               // 118
        function n(t) {                                                                                                // 118
          return t = u.apply(It, s([t], f)), e && h ? t[0] : t;                                                        // 118
        }var i = this.__wrapped__,                                                                                     // 118
            f = e ? [1] : arguments,                                                                                   // 118
            c = i instanceof Zt,                                                                                       // 118
            a = f[0],                                                                                                  // 118
            l = c || Zi(i);l && r && typeof a == "function" && 1 != a.length && (c = l = false);var h = this.__chain__,
            p = !!this.__actions__.length,                                                                             // 118
            a = o && !h,                                                                                               // 118
            c = c && !p;return !o && l ? (i = c ? i : new Zt(this), i = t.apply(i, f), i.__actions__.push({            // 118
          func: Fe, args: [n], thisArg: P }), new Tt(i, h)) : a && c ? t.apply(this, f) : (i = this.thru(n), a ? e ? i.value()[0] : i.value() : i);
      });                                                                                                              // 119
    }), u("pop push shift sort splice unshift".split(" "), function (t) {                                              // 119
      var n = Zu[t],                                                                                                   // 119
          r = /^(?:push|sort|unshift)$/.test(t) ? "tap" : "thru",                                                      // 119
          e = /^(?:pop|shift)$/.test(t);It.prototype[t] = function () {                                                // 119
        var t = arguments;if (e && !this.__chain__) {                                                                  // 119
          var u = this.value();return n.apply(Zi(u) ? u : [], t);                                                      // 119
        }return this[r](function (r) {                                                                                 // 119
          return n.apply(Zi(r) ? r : [], t);                                                                           // 119
        });                                                                                                            // 119
      };                                                                                                               // 119
    }), En(Zt.prototype, function (t, n) {                                                                             // 119
      var r = It[n];if (r) {                                                                                           // 119
        var e = r.name + "";                                                                                           // 119
        (Uo[e] || (Uo[e] = [])).push({ name: n, func: r });                                                            // 120
      }                                                                                                                // 120
    }), Uo[qr(P, 2).name] = [{ name: "wrapper", func: P }], Zt.prototype.clone = function () {                         // 120
      var t = new Zt(this.__wrapped__);return t.__actions__ = Wr(this.__actions__), t.__dir__ = this.__dir__, t.__filtered__ = this.__filtered__, t.__iteratees__ = Wr(this.__iteratees__), t.__takeCount__ = this.__takeCount__, t.__views__ = Wr(this.__views__), t;
    }, Zt.prototype.reverse = function () {                                                                            // 120
      if (this.__filtered__) {                                                                                         // 120
        var t = new Zt(this);t.__dir__ = -1, t.__filtered__ = true;                                                    // 120
      } else t = this.clone(), t.__dir__ *= -1;return t;                                                               // 120
    }, Zt.prototype.value = function () {                                                                              // 121
      var t,                                                                                                           // 121
          n = this.__wrapped__.value(),                                                                                // 121
          r = this.__dir__,                                                                                            // 121
          e = Zi(n),                                                                                                   // 121
          u = 0 > r,                                                                                                   // 121
          o = e ? n.length : 0;t = o;for (var i = this.__views__, f = 0, c = -1, a = i.length; ++c < a;) {             // 121
        var l = i[c],                                                                                                  // 121
            s = l.size;switch (l.type) {case "drop":                                                                   // 121
            f += s;break;case "dropRight":                                                                             // 121
            t -= s;break;case "take":                                                                                  // 121
            t = wo(t, f + s);break;case "takeRight":                                                                   // 121
            f = jo(f, t - s);}                                                                                         // 121
      }if (t = { start: f, end: t }, i = t.start, f = t.end, t = f - i, u = u ? f : i - 1, i = this.__iteratees__, f = i.length, c = 0, a = wo(t, this.__takeCount__), !e || 200 > o || o == t && a == t) return xr(n, this.__actions__);e = [];t: for (; t-- && c < a;) {
        for (u += r, o = -1, l = n[u]; ++o < f;) {                                                                     // 122
          var h = i[o],                                                                                                // 122
              s = h.type,                                                                                              // 122
              h = (0, h.iteratee)(l);if (2 == s) l = h;else if (!h) {                                                  // 122
            if (1 == s) continue t;break t;                                                                            // 122
          }                                                                                                            // 122
        }e[c++] = l;                                                                                                   // 122
      }return e;                                                                                                       // 122
    }, It.prototype.at = Oi, It.prototype.chain = function () {                                                        // 122
      return $e(this);                                                                                                 // 122
    }, It.prototype.commit = function () {                                                                             // 122
      return new Tt(this.value(), this.__chain__);                                                                     // 122
    }, It.prototype.next = function () {                                                                               // 122
      this.__values__ === P && (this.__values__ = _u(this.value()));var t = this.__index__ >= this.__values__.length,  // 122
          n = t ? P : this.__values__[this.__index__++];return { done: t, value: n };                                  // 122
    }, It.prototype.plant = function (t) {                                                                             // 122
      for (var n, r = this; r instanceof Ft;) {                                                                        // 123
        var e = Se(r);e.__index__ = 0, e.__values__ = P, n ? u.__wrapped__ = e : n = e;var u = e,                      // 123
            r = r.__wrapped__;                                                                                         // 123
      }return u.__wrapped__ = t, n;                                                                                    // 123
    }, It.prototype.reverse = function () {                                                                            // 123
      var t = this.__wrapped__;return t instanceof Zt ? (this.__actions__.length && (t = new Zt(this)), t = t.reverse(), t.__actions__.push({ func: Fe, args: [ze], thisArg: P }), new Tt(t, this.__chain__)) : this.thru(ze);
    }, It.prototype.toJSON = It.prototype.valueOf = It.prototype.value = function () {                                 // 123
      return xr(this.__wrapped__, this.__actions__);                                                                   // 123
    }, It.prototype.first = It.prototype.head, fo && (It.prototype[fo] = Te), It;                                      // 123
  }var P,                                                                                                              // 124
      Z = 1 / 0,                                                                                                       // 124
      q = NaN,                                                                                                         // 124
      V = [["ary", 128], ["bind", 1], ["bindKey", 2], ["curry", 8], ["curryRight", 16], ["flip", 512], ["partial", 32], ["partialRight", 64], ["rearg", 256]],
      K = /\b__p\+='';/g,                                                                                              // 124
      G = /\b(__p\+=)''\+/g,                                                                                           // 124
      J = /(__e\(.*?\)|\b__t\))\+'';/g,                                                                                // 124
      Y = /&(?:amp|lt|gt|quot|#39|#96);/g,                                                                             // 124
      H = /[&<>"'`]/g,                                                                                                 // 124
      Q = RegExp(Y.source),                                                                                            // 124
      X = RegExp(H.source),                                                                                            // 124
      tt = /<%-([\s\S]+?)%>/g,                                                                                         // 124
      nt = /<%([\s\S]+?)%>/g,                                                                                          // 124
      rt = /<%=([\s\S]+?)%>/g,                                                                                         // 124
      et = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,                                                         // 124
      ut = /^\w*$/,                                                                                                    // 124
      ot = /^\./,                                                                                                      // 124
      it = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,         // 124
      ft = /[\\^$.*+?()[\]{}|]/g,                                                                                      // 124
      ct = RegExp(ft.source),                                                                                          // 124
      at = /^\s+|\s+$/g,                                                                                               // 124
      lt = /^\s+/,                                                                                                     // 124
      st = /\s+$/,                                                                                                     // 124
      ht = /\{(?:\n\/\* \[wrapped with .+\] \*\/)?\n?/,                                                                // 124
      pt = /\{\n\/\* \[wrapped with (.+)\] \*/,                                                                        // 124
      _t = /,? & /,                                                                                                    // 124
      vt = /[a-zA-Z0-9]+/g,                                                                                            // 124
      gt = /\\(\\)?/g,                                                                                                 // 124
      dt = /\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g,                                                                          // 124
      yt = /\w*$/,                                                                                                     // 124
      bt = /^0x/i,                                                                                                     // 124
      xt = /^[-+]0x[0-9a-f]+$/i,                                                                                       // 124
      jt = /^0b[01]+$/i,                                                                                               // 124
      wt = /^\[object .+?Constructor\]$/,                                                                              // 124
      mt = /^0o[0-7]+$/i,                                                                                              // 124
      At = /^(?:0|[1-9]\d*)$/,                                                                                         // 124
      Ot = /[\xc0-\xd6\xd8-\xde\xdf-\xf6\xf8-\xff]/g,                                                                  // 124
      kt = /($^)/,                                                                                                     // 124
      Et = /['\n\r\u2028\u2029\\]/g,                                                                                   // 124
      St = "[\\ufe0e\\ufe0f]?(?:[\\u0300-\\u036f\\ufe20-\\ufe23\\u20d0-\\u20f0]|\\ud83c[\\udffb-\\udfff])?(?:\\u200d(?:[^\\ud800-\\udfff]|(?:\\ud83c[\\udde6-\\uddff]){2}|[\\ud800-\\udbff][\\udc00-\\udfff])[\\ufe0e\\ufe0f]?(?:[\\u0300-\\u036f\\ufe20-\\ufe23\\u20d0-\\u20f0]|\\ud83c[\\udffb-\\udfff])?)*",
      Rt = "(?:[\\u2700-\\u27bf]|(?:\\ud83c[\\udde6-\\uddff]){2}|[\\ud800-\\udbff][\\udc00-\\udfff])" + St,            // 124
      It = "(?:[^\\ud800-\\udfff][\\u0300-\\u036f\\ufe20-\\ufe23\\u20d0-\\u20f0]?|[\\u0300-\\u036f\\ufe20-\\ufe23\\u20d0-\\u20f0]|(?:\\ud83c[\\udde6-\\uddff]){2}|[\\ud800-\\udbff][\\udc00-\\udfff]|[\\ud800-\\udfff])",
      Wt = RegExp("['\u2019]", "g"),                                                                                   // 124
      Bt = RegExp("[\\u0300-\\u036f\\ufe20-\\ufe23\\u20d0-\\u20f0]", "g"),                                             // 124
      Mt = RegExp("\\ud83c[\\udffb-\\udfff](?=\\ud83c[\\udffb-\\udfff])|" + It + St, "g"),                             // 124
      Ct = RegExp(["[A-Z\\xc0-\\xd6\\xd8-\\xde]?[a-z\\xdf-\\xf6\\xf8-\\xff]+(?:['\u2019](?:d|ll|m|re|s|t|ve))?(?=[\\xac\\xb1\\xd7\\xf7\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf\\u2000-\\u206f \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000]|[A-Z\\xc0-\\xd6\\xd8-\\xde]|$)|(?:[A-Z\\xc0-\\xd6\\xd8-\\xde]|[^\\ud800-\\udfff\\xac\\xb1\\xd7\\xf7\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf\\u2000-\\u206f \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000\\d+\\u2700-\\u27bfa-z\\xdf-\\xf6\\xf8-\\xffA-Z\\xc0-\\xd6\\xd8-\\xde])+(?:['\u2019](?:D|LL|M|RE|S|T|VE))?(?=[\\xac\\xb1\\xd7\\xf7\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf\\u2000-\\u206f \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000]|[A-Z\\xc0-\\xd6\\xd8-\\xde](?:[a-z\\xdf-\\xf6\\xf8-\\xff]|[^\\ud800-\\udfff\\xac\\xb1\\xd7\\xf7\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf\\u2000-\\u206f \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000\\d+\\u2700-\\u27bfa-z\\xdf-\\xf6\\xf8-\\xffA-Z\\xc0-\\xd6\\xd8-\\xde])|$)|[A-Z\\xc0-\\xd6\\xd8-\\xde]?(?:[a-z\\xdf-\\xf6\\xf8-\\xff]|[^\\ud800-\\udfff\\xac\\xb1\\xd7\\xf7\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf\\u2000-\\u206f \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000\\d+\\u2700-\\u27bfa-z\\xdf-\\xf6\\xf8-\\xffA-Z\\xc0-\\xd6\\xd8-\\xde])+(?:['\u2019](?:d|ll|m|re|s|t|ve))?|[A-Z\\xc0-\\xd6\\xd8-\\xde]+(?:['\u2019](?:D|LL|M|RE|S|T|VE))?|\\d+", Rt].join("|"), "g"),
      Lt = RegExp("[\\u200d\\ud800-\\udfff\\u0300-\\u036f\\ufe20-\\ufe23\\u20d0-\\u20f0\\ufe0e\\ufe0f]"),              // 124
      zt = /[a-z][A-Z]|[A-Z]{2,}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/,                                      // 124
      Ut = "Array Buffer DataView Date Error Float32Array Float64Array Function Int8Array Int16Array Int32Array Map Math Object Promise Reflect RegExp Set String Symbol TypeError Uint8Array Uint8ClampedArray Uint16Array Uint32Array WeakMap _ clearTimeout isFinite parseInt setTimeout".split(" "),
      Dt = {};                                                                                                         // 124
  Dt["[object Float32Array]"] = Dt["[object Float64Array]"] = Dt["[object Int8Array]"] = Dt["[object Int16Array]"] = Dt["[object Int32Array]"] = Dt["[object Uint8Array]"] = Dt["[object Uint8ClampedArray]"] = Dt["[object Uint16Array]"] = Dt["[object Uint32Array]"] = true, Dt["[object Arguments]"] = Dt["[object Array]"] = Dt["[object ArrayBuffer]"] = Dt["[object Boolean]"] = Dt["[object DataView]"] = Dt["[object Date]"] = Dt["[object Error]"] = Dt["[object Function]"] = Dt["[object Map]"] = Dt["[object Number]"] = Dt["[object Object]"] = Dt["[object RegExp]"] = Dt["[object Set]"] = Dt["[object String]"] = Dt["[object WeakMap]"] = false;
  var $t = {};$t["[object Arguments]"] = $t["[object Array]"] = $t["[object ArrayBuffer]"] = $t["[object DataView]"] = $t["[object Boolean]"] = $t["[object Date]"] = $t["[object Float32Array]"] = $t["[object Float64Array]"] = $t["[object Int8Array]"] = $t["[object Int16Array]"] = $t["[object Int32Array]"] = $t["[object Map]"] = $t["[object Number]"] = $t["[object Object]"] = $t["[object RegExp]"] = $t["[object Set]"] = $t["[object String]"] = $t["[object Symbol]"] = $t["[object Uint8Array]"] = $t["[object Uint8ClampedArray]"] = $t["[object Uint16Array]"] = $t["[object Uint32Array]"] = true, $t["[object Error]"] = $t["[object Function]"] = $t["[object WeakMap]"] = false;var Ft,
      Tt = { "\\": "\\", "'": "'", "\n": "n", "\r": "r", "\u2028": "u2028", "\u2029": "u2029" },                       // 127
      Nt = parseFloat,                                                                                                 // 127
      Pt = parseInt,                                                                                                   // 127
      Zt = (typeof global === "undefined" ? "undefined" : _typeof(global)) == "object" && global && global.Object === Object && global,
      qt = (typeof self === "undefined" ? "undefined" : _typeof(self)) == "object" && self && self.Object === Object && self,
      Vt = Zt || qt || Function("return this")(),                                                                      // 127
      Kt = (typeof exports === "undefined" ? "undefined" : _typeof(exports)) == "object" && exports && !exports.nodeType && exports,
      Gt = Kt && (typeof module === "undefined" ? "undefined" : _typeof(module)) == "object" && module && !module.nodeType && module,
      Jt = Gt && Gt.exports === Kt,                                                                                    // 127
      Yt = Jt && Zt.h;                                                                                                 // 127
  t: {                                                                                                                 // 128
    try {                                                                                                              // 128
      Ft = Yt && Yt.f("util");break t;                                                                                 // 128
    } catch (t) {}Ft = void 0;                                                                                         // 128
  }var Ht = Ft && Ft.isArrayBuffer,                                                                                    // 128
      Qt = Ft && Ft.isDate,                                                                                            // 128
      Xt = Ft && Ft.isMap,                                                                                             // 128
      tn = Ft && Ft.isRegExp,                                                                                          // 128
      nn = Ft && Ft.isSet,                                                                                             // 128
      rn = Ft && Ft.isTypedArray,                                                                                      // 128
      en = w({ "\xc0": "A", "\xc1": "A", "\xc2": "A", "\xc3": "A", "\xc4": "A", "\xc5": "A", "\xe0": "a", "\xe1": "a", "\xe2": "a", "\xe3": "a", "\xe4": "a", "\xe5": "a", "\xc7": "C", "\xe7": "c", "\xd0": "D", "\xf0": "d", "\xc8": "E", "\xc9": "E", "\xca": "E", "\xcb": "E", "\xe8": "e", "\xe9": "e", "\xea": "e", "\xeb": "e", "\xcc": "I", "\xcd": "I", "\xce": "I", "\xcf": "I", "\xec": "i", "\xed": "i",
    "\xee": "i", "\xef": "i", "\xd1": "N", "\xf1": "n", "\xd2": "O", "\xd3": "O", "\xd4": "O", "\xd5": "O", "\xd6": "O", "\xd8": "O", "\xf2": "o", "\xf3": "o", "\xf4": "o", "\xf5": "o", "\xf6": "o", "\xf8": "o", "\xd9": "U", "\xda": "U", "\xdb": "U", "\xdc": "U", "\xf9": "u", "\xfa": "u", "\xfb": "u", "\xfc": "u", "\xdd": "Y", "\xfd": "y", "\xff": "y", "\xc6": "Ae", "\xe6": "ae", "\xde": "Th", "\xfe": "th", "\xdf": "ss" }),
      un = w({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;", "`": "&#96;" }),                   // 128
      on = w({ "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&#39;": "'",                                    // 128
    "&#96;": "`" }),                                                                                                   // 130
      fn = N();typeof define == "function" && _typeof(define.amd) == "object" && define.amd ? (Vt._ = fn, define(function () {
    return fn;                                                                                                         // 130
  })) : Gt ? ((Gt.exports = fn)._ = fn, Kt._ = fn) : Vt._ = fn;                                                        // 130
}).call(this);                                                                                                         // 130
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"tour.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// client/lib/tour.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// app tour                                                                                                            // 1
// see http://bootstraptour.com/api/                                                                                   // 2
                                                                                                                       //
// parseUri 1.2.2                                                                                                      // 4
// (c) Steven Levithan <stevenlevithan.com>                                                                            // 5
// MIT License                                                                                                         // 6
function parseUri(str) {                                                                                               // 7
    var o = parseUri.options,                                                                                          // 8
        m = o.parser[o.strictMode ? "strict" : "loose"].exec(str),                                                     // 8
        uri = {},                                                                                                      // 8
        i = 14;                                                                                                        // 8
                                                                                                                       //
    while (i--) {                                                                                                      // 13
        uri[o.key[i]] = m[i] || "";                                                                                    // 13
    }uri[o.q.name] = {};                                                                                               // 13
    uri[o.key[12]].replace(o.q.parser, function ($0, $1, $2) {                                                         // 16
        if ($1) uri[o.q.name][$1] = $2;                                                                                // 17
    });                                                                                                                // 18
                                                                                                                       //
    return uri;                                                                                                        // 20
};                                                                                                                     // 21
                                                                                                                       //
parseUri.options = {                                                                                                   // 23
    strictMode: false,                                                                                                 // 24
    key: ["source", "protocol", "authority", "userInfo", "user", "password", "host", "port", "relative", "path", "directory", "file", "query", "anchor"],
    q: {                                                                                                               // 26
        name: "queryKey",                                                                                              // 27
        parser: /(?:^|&)([^&=]*)=?([^&]*)/g                                                                            // 28
    },                                                                                                                 // 26
    parser: {                                                                                                          // 30
        strict: /^(?:([^:\/?#]+):)?(?:\/\/((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?))?((((?:[^?#\/]*\/)*)([^?#]*))(?:\?([^#]*))?(?:#(.*))?)/,
        loose: /^(?:(?![^:@]+:[^:@\/]*@)([^:\/?#.]+):)?(?:\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/
    }                                                                                                                  // 30
};                                                                                                                     // 23
                                                                                                                       //
var testPageType = "testvaobject";                                                                                     // 37
if (Meteor.userId()) {                                                                                                 // 38
    testPageType += "_" + Meteor.userId();                                                                             // 39
}                                                                                                                      // 40
var testPageId = "O89553";                                                                                             // 41
                                                                                                                       //
var tours = {                                                                                                          // 43
    "intro": {                                                                                                         // 44
        steps: [{                                                                                                      // 45
            path: "/?tour=intro&step=0",                                                                               // 47
            element: ".titleBox",                                                                                      // 48
            title: "This is C5",                                                                                       // 49
            content: "Welcome to the Tour of C5. <BR> <BR> " + "<B>C5</b> stands for <i>Collaborative Creative Coding with Cultural Commons.</i>  " + "It's designed to make it fun and easy to create, share, and re-use code that does interesting stuff with Open Data from Museums and other cultural institutions. " + "<BR><BR> " + "This is the home button. Click here to come back to the home page. ",
            onNext: function () {                                                                                      // 55
                function onNext(tour) {                                                                                // 55
                    console.log("next clicked");tour.goTo(1);                                                          // 55
                }                                                                                                      // 55
                                                                                                                       //
                return onNext;                                                                                         // 55
            }()                                                                                                        // 55
        }, {                                                                                                           // 46
            element: ".widgetContainer:first",                                                                         // 58
            title: "It's All Widgets!",                                                                                // 59
            content: "C5 Pages are made up of <B>Widgets</b>, which you can add to any page. <BR>A Widget is a unit of HTML/CSS/Javascript, which can be live-edited by whomever created it."
        }, {                                                                                                           // 57
            element: ".pagecomments",                                                                                  // 63
            title: "Comments",                                                                                         // 64
            content: "Something you like? Don't Like? Have an idea for a widget, and need some help? <BR><BR>" + "You can leave attach comments to:" + "<ul><li>A specific page,</li><li>All pages of the same <b>Page Type</b>,</li><li>Or to individual widgets</li></ul>" + "<BR><BR><i>'Page Type? What's that?' We'll get into that stuff in the next Tour!</i>"
        }, {                                                                                                           // 62
            element: ".widgetcomments:first",                                                                          // 71
            title: "Widget Comments",                                                                                  // 72
            content: "You can also leave comments on individual widgets, for" + "<ul><li>The specific instance of this widget on this page, or</li><li>This widget on all pages of the same type</li>"
        }, {                                                                                                           // 70
            element: ".widgetinfo:first",                                                                              // 77
            title: "Widget Info and URLs",                                                                             // 78
            content: "If you click on the info icon, you'll see that every widget has a JSON and HTML endpoint URL." + "This means you can access the output of ANY widget, as data or presentation, from ANYWHERE -- From other widgets, other pages, or even totally independant applications<BR>" + "<BR><b>This means you can prototype your own Apps right here in C5!</b>"
        }, {                                                                                                           // 76
            element: ".login:first",                                                                                   // 84
            title: "Join up!",                                                                                         // 85
            content: "Feel free to cruise the site without logging in. You can check out all the cool stuff other people have made, use the search feature, and play with widgets that have interactive bits.<BR><BR> " + "But once you create an account, you'll be able to add widgets, copy other people's widgets, contribute comments, create your own libraries of widgets, and in general do all the things.<BR><BR>" + "Log in now, and some new tours will be made available, so you can get started creating!"
        }]                                                                                                             // 83
    },                                                                                                                 // 44
                                                                                                                       //
    "userFeatures": {                                                                                                  // 93
        steps: [{                                                                                                      // 94
            path: "/?tour=userFeatures&step=0",                                                                        // 96
            element: ".widgetlibrary",                                                                                 // 97
            title: "The Widget Library",                                                                               // 98
            content: "Now that you've logged in, you'll notice there's some new features available." + "<BR><BR>This is the <b>Widget Library</b>" + "<BR>Select a widget from here, and it appears on the page, initially as a 'private widget' that only you can see." + "<BR><BR>We start you out with a few basics, but you can build up your own library by copying any other widget to it." + "<BR><br>Then you can add widgets from your library to any Page",
            onNext: function () {                                                                                      // 104
                function onNext(tour) {                                                                                // 104
                    console.log("next clicked");tour.goTo(1);                                                          // 104
                }                                                                                                      // 104
                                                                                                                       //
                return onNext;                                                                                         // 104
            }()                                                                                                        // 104
        }, {                                                                                                           // 95
            element: ".save_to_library:first",                                                                         // 107
            title: "Copy this Widget to Your Library",                                                                 // 108
            content: "Click this icon to add this widget to your library"                                              // 109
        }, {                                                                                                           // 106
            element: ".copy:first",                                                                                    // 112
            title: "Copy a widget to this page",                                                                       // 113
            content: "Click this icon to create a new version of this widget on the same page"                         // 114
        }, {                                                                                                           // 111
            element: ".link_to_library",                                                                               // 117
            title: "link to your library",                                                                             // 118
            content: "click here to go to a special page that holds all the widgets in your library."                  // 119
        }, {                                                                                                           // 116
            element: ".link_to_library",                                                                               // 122
            title: "Thanks!",                                                                                          // 123
            content: "Hope you like being a member of C5!" + "<BR><BR>Please send questions to donundeen@gmail.com," + "or post them a <a href='http://github.com/donundeen/C5'>On our github page</a>"
        }]                                                                                                             // 121
    },                                                                                                                 // 93
                                                                                                                       //
    "widgetEditing": {                                                                                                 // 132
        orphan: true,                                                                                                  // 133
        steps: [{                                                                                                      // 134
            element: ".help",                                                                                          // 136
            title: "Creating your first widget",                                                                       // 137
            content: "Now that you've learned a bit about what C5 can do, let's go create a new page and put some widgets on it." + "<Br><BR>We're going to go to a new page now, hold tight!"
        }, {                                                                                                           // 135
            path: "/" + testPageType + "/" + testPageId + "?tour=widgetEditing&step=1",                                // 142
            element: ".page_id_div",                                                                                   // 143
            title: "A New Page",                                                                                       // 144
            content: "Now we're on a New Page!" + "<BR><BR>This section holds the PAGE NAME, which is made of two parts:" + "<BR><BR>1. The <B>Page Type</b>, in this case '" + testPageType + "' All pages of the same type have the SAME WIDGETS. So if you add a widget here, it will appear on every page of the same type." + "<BR><BR>2. The <b>Page ID</b>, in this case '" + testPageId + "', which happens to the the unique identifier for an object from the Victoria &amp; Albert Museum." + "<BR><BR>Put another way, the Page Type is like the 'class' in Object-oriented programming. The PageType + PageID is like the 'instance' of that class." + "<BR><BR>Or putting it another way: you make a PageType for a set of objects that you get from the same API. Like V&amp;A API." + "<BR><BR>Note: We CREATED this page Type just by going to the URL '" + testPageType + "/something'. Just start adding widgets, and you're good to go!",
            onNext: function () {                                                                                      // 152
                function onNext(tour) {                                                                                // 152
                    console.log("next clicked");                                                                       // 153
                    tour.goTo(2);                                                                                      // 154
                }                                                                                                      // 155
                                                                                                                       //
                return onNext;                                                                                         // 152
            }()                                                                                                        // 152
                                                                                                                       //
        }, {                                                                                                           // 141
            element: ".widgetlibrary",                                                                                 // 159
            placement: "left",                                                                                         // 160
            title: "Add a Widget to this page",                                                                        // 161
            content: "The first thing we want to do is add a widget to this page, by copying a basic widget example from the Library." + "<BR><BR>Let's grab the 'Webservice Search Example.' That's a good starting point." + "<BR><BR><i>Just click 'next', and we'll select it for you<i>",
            onNext: function () {                                                                                      // 165
                function onNext(tour) {                                                                                // 165
                    tour.end();                                                                                        // 166
                    $(".addFromWidgetLibraryUL").toggle();                                                             // 167
                    setTimeout(function () {                                                                           // 168
                        $(".copy_from_template.ciy").mouseover();                                                      // 169
                        setTimeout(function () {                                                                       // 170
                            $(".copy_from_template.ciy").mouseout();                                                   // 171
                            copyWidgetToPage("ciy", pageinfo().pagetype, pageinfo().pageurl, pageinfo().pageid);       // 172
                            $(".addFromWidgetLibraryUL").toggle();                                                     // 173
                            setTimeout(function () {                                                                   // 174
                                tour.start(true);                                                                      // 175
                                tour.goTo(3);                                                                          // 176
                            }, 2000);                                                                                  // 177
                        }, 2000);                                                                                      // 178
                    }, 2000);                                                                                          // 179
                    //                    return (new jQuery.Deferred()).promise();                                    // 180
                }                                                                                                      // 181
                                                                                                                       //
                return onNext;                                                                                         // 165
            }()                                                                                                        // 165
        }, {                                                                                                           // 158
            //   path : "/testvaobject/O89553?tour=widgetEditing&step=3",                                              // 184
            element: ".widgetUnlock:first",                                                                            // 185
            title: "Your First Widget",                                                                                // 186
            content: "Congrats ! You've created a widget of your very own!" + "<Br><BR>You'll notice it's grey, which means it's private; only you can see it right now." + "<BR><BR>If you click on the little lock icon here, you'll open it for editing." + "<BR><BR>Now, <B>Click the Lock Icon to the Left</b>, THEN click 'Next' below."
        }, {                                                                                                           // 183
            element: ".widgetLock.editmodeonly:first",                                                                 // 205
            title: "Edit Mode",                                                                                        // 206
            placement: "left",                                                                                         // 207
            content: "<B>Welcome to Edit Mode</b>" + "<BR><BR>Now we're cooking" + "<BR><BR>If you've ever used <a href='http://jsbin.com'>JsBIN</a>, <a href='http://jsfiddle.net'>JsFiddle</a>, or <a href='http://codepen.io'>CodePen</a>, this should look familiar." + "<br>In fact, a widget is just an embedded JsBin, with some helpful glue to make the widgets talk to each other." + "<BR><BR>Try editing the html panel on the left, and you'll see the output code on the right update in real time."
        }, {                                                                                                           // 204
            element: ".setpublic:first",                                                                               // 216
            title: "Private Widget",                                                                                   // 217
            placement: "left",                                                                                         // 218
            content: "Right now this widget is PRIVATE, meaning only you can see it." + "<BR><BR>So feel free to muck about." + "<BR><BR>When you're ready to share it with the world, click the icon to make it public."
        }, {                                                                                                           // 215
            element: ".widgetinfo-editmode:first",                                                                     // 225
            title: "Widget Info",                                                                                      // 226
            content: "Click this to get info about the Widget, such as:" + "<BR>- Editable name and description" + "<BR>- Data and HTML Urls"
        }, {                                                                                                           // 224
            element: ".widgetactions:first",                                                                           // 233
            title: "Widget Actions",                                                                                   // 234
            content: "Click this to perform actions like Save, Delete, and Adding to your Library."                    // 235
                                                                                                                       //
        }, {                                                                                                           // 232
            element: ".widgetpulldata:first",                                                                          // 239
            title: "Pull Data",                                                                                        // 240
            content: "This section has super useful helper functions that help you access data from other widgets on this page" + "<BR><BR>More on this in a bit!"
        }, {                                                                                                           // 238
            element: ".widgetstylesettings:first",                                                                     // 246
            title: "Widget Style",                                                                                     // 247
            content: "Using this menu item, you can edit the style of the widget container, like the width and height of the widget, border color, etc"
        }, {                                                                                                           // 245
            element: ".widgetcachesettings:first",                                                                     // 252
            title: "Cache Settings",                                                                                   // 253
            content: "Here you can set how long you want to cache the output of this widget" + "<BR><BR>If your input doesn't change very often, it's good to set this pretty high," + "it will really help with performance."
        }, {                                                                                                           // 251
            element: ".widgetorder:first",                                                                             // 261
            title: "Widget Order",                                                                                     // 262
            content: "Edit this value to re-order your widget on the page."                                            // 263
        },                                                                                                             // 260
                                                                                                                       //
        /*                                                                                                             // 266
                                                                                                                       //
                                                                                                                       //
                    {                                                                                                  //
                        element : ".widgetorder:first",                                                                //
                        title : "Widget Order",                                                                        //
                        content : "Edit this value to re-order your widget on the page."                               //
                    },                                                                                                 //
                */                                                                                                     //
        {                                                                                                              // 275
            element: ".page_id_div",                                                                                   // 276
            title: "End of tour",                                                                                      // 277
            content: "Thanks for taking the tour." + "<BR><BR>Now clean up after yourself by deleting this widget  (Actions ->  Delete)." + "<BR><BR>Please send questions to donundeen@gmail.com," + "or post them a <a href='http://github.com/donundeen/C5'>On our github page</a>"
        }]                                                                                                             // 275
    }                                                                                                                  // 132
};                                                                                                                     // 43
                                                                                                                       //
/*                                                                                                                     // 291
Template.widget.onRendered(function(){                                                                                 //
                                                                                                                       //
    if(!this.rendered){                                                                                                //
        setupTour(".clickForIntroTour", tours["intro"]);                                                               //
        setupTour(".clickForUserFeaturesTour", tours["userFeatures"]);                                                 //
        setupTour(".clickForWidgetEditingTour", tours["widgetEditing"]);                                               //
    }else{                                                                                                             //
        console.log("not attaching");                                                                                  //
    }                                                                                                                  //
});                                                                                                                    //
*/                                                                                                                     //
                                                                                                                       //
Template.help.onRendered(function () {                                                                                 // 304
    if (!this.rendered) {                                                                                              // 305
        console.log("attaching for help");                                                                             // 306
                                                                                                                       //
        setupTour(".clickForUserFeaturesTour", tours["userFeatures"]);                                                 // 308
        this.rendered = true;                                                                                          // 309
    }                                                                                                                  // 310
});                                                                                                                    // 312
                                                                                                                       //
Template.body.onRendered(function () {                                                                                 // 314
                                                                                                                       //
    if (!this.rendered) {                                                                                              // 316
        console.log("attaching for body");                                                                             // 317
        setupTour(".clickForIntroTour", tours["intro"]);                                                               // 318
                                                                                                                       //
        setupTour(".clickForWidgetEditingTour", tours["widgetEditing"]);                                               // 320
        //        setupTour(".clickForUserFeaturesTour", tours["userFeatures"]);                                       // 321
                                                                                                                       //
        console.log("attaching");                                                                                      // 323
        var uri = parseUri(window.location.href);                                                                      // 324
        if (uri.queryKey && uri.queryKey.tour) {                                                                       // 325
            console.log("loading tour, gonna run " + uri.queryKey.tour);                                               // 326
            var tourname = uri.queryKey.tour;                                                                          // 327
            var step = uri.queryKey.step;                                                                              // 328
            runTour(tours[tourname], parseInt(step, 10));                                                              // 329
        }                                                                                                              // 330
        this.rendered = true;                                                                                          // 331
    } else {                                                                                                           // 332
        console.log("not attaching");                                                                                  // 333
    }                                                                                                                  // 334
});                                                                                                                    // 335
                                                                                                                       //
function runTour(tourdata, step) {                                                                                     // 342
    console.log("running tour ");                                                                                      // 343
    console.log(tourdata);                                                                                             // 344
    (function (_tourdata, _step, _jquery) {                                                                            // 345
        $(document).ready(function () {                                                                                // 346
            console.log("starting");                                                                                   // 347
            var tour = new Tour(_tourdata);                                                                            // 348
            tour.jquery = _jquery;                                                                                     // 349
            tour.init();                                                                                               // 350
            tour.start(true);                                                                                          // 351
            tour.goTo(step);                                                                                           // 352
        });                                                                                                            // 353
    })(tourdata, step, $);                                                                                             // 354
}                                                                                                                      // 355
                                                                                                                       //
function setupTour(element, tourdata) {                                                                                // 358
    console.log("seeting up tour " + element);                                                                         // 359
    console.log(tourdata);                                                                                             // 360
    console.log($(element));                                                                                           // 361
    (function (_tourdata, _element, _jquery) {                                                                         // 362
        $(_element).click(function () {                                                                                // 363
            console.log("running tour");                                                                               // 364
            var tour = new Tour(_tourdata);                                                                            // 365
            tour.jquery = _jquery;                                                                                     // 366
            tour.init();                                                                                               // 367
            tour.start(true);                                                                                          // 368
            tour.goTo(0);                                                                                              // 369
        });                                                                                                            // 370
    })(tourdata, element, $);                                                                                          // 371
}                                                                                                                      // 372
                                                                                                                       //
/*                                                                                                                     // 375
function setupTour(element, tourdata){                                                                                 //
    (function(_tourdata, _element, _jquery){                                                                           //
        $(document).ready(function(){                                                                                  //
            var tour = new Tour(_tourdata);                                                                            //
            tour.jquery = _jquery;                                                                                     //
            tour.init();                                                                                               //
            (function(_tour, __element){                                                                               //
                $(__element).click(function(){                                                                         //
                    _tour.start(true);                                                                                 //
                    _tour.goTo(0);                                                                                     //
                });                                                                                                    //
            })(tour, _element);                                                                                        //
        });                                                                                                            //
    })(tourdata, element, $);                                                                                          //
}                                                                                                                      //
*/                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"uiutils.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// client/lib/uiutils.js                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       //
                                                                                                                       //
addJsCodeAtTop = function addJsCodeAtTop(snippet, editors) {                                                           // 3
    var code = editors.javascript.getCode(),                                                                           // 4
        state = { line: editors.javascript.editor.currentLine(),                                                       // 4
        character: editors.javascript.editor.getCursor().ch,                                                           // 6
        add: 0                                                                                                         // 7
    };                                                                                                                 // 5
                                                                                                                       //
    code = snippet + '\n' + code;                                                                                      // 10
                                                                                                                       //
    editors.javascript.setCode(code);                                                                                  // 12
    editors.javascript.editor.setCursor({ line: state.line + state.add, ch: state.character });                        // 13
};                                                                                                                     // 14
addJsCodeAtBottom = function addJsCodeAtBottom(snippet, editors) {                                                     // 15
    var code = editors.javascript.getCode(),                                                                           // 16
        state = { line: editors.javascript.editor.currentLine(),                                                       // 16
        character: editors.javascript.editor.getCursor().ch,                                                           // 18
        add: 0                                                                                                         // 19
    };                                                                                                                 // 17
                                                                                                                       //
    code = code + '\n' + snippet;                                                                                      // 22
                                                                                                                       //
    editors.javascript.setCode(code);                                                                                  // 24
    editors.javascript.editor.setCursor({ line: state.line + state.add, ch: state.character });                        // 25
};                                                                                                                     // 26
                                                                                                                       //
addJsCodeAtCursor = function addJsCodeAtCursor(snippet, editors) {                                                     // 28
    var code = editors.javascript.getCode();                                                                           // 29
    var line = editors.javascript.editor.getCursor().line;                                                             // 30
    var charpos = editors.javascript.editor.getCursor().ch;                                                            // 31
    var codelines = code.split("\n");                                                                                  // 32
    var codeline = codelines[line];                                                                                    // 33
    var newline = codeline.substr(0, charpos) + snippet + codeline.substr(charpos);                                    // 34
                                                                                                                       //
    codelines[line] = newline;                                                                                         // 36
    code = codelines.join("\n");                                                                                       // 37
                                                                                                                       //
    var state = { line: editors.javascript.editor.currentLine(),                                                       // 39
        character: editors.javascript.editor.getCursor().ch,                                                           // 40
        add: 0                                                                                                         // 41
    };                                                                                                                 // 39
                                                                                                                       //
    editors.javascript.setCode(code);                                                                                  // 44
    editors.javascript.editor.setCursor({ line: state.line + state.add, ch: state.character });                        // 45
};                                                                                                                     // 46
                                                                                                                       //
addJsRequireCode = function addJsRequireCode(widgetName, type, editors) {                                              // 48
    var code = editors.javascript.getCode();                                                                           // 49
    var codeString = widgetName + " : '" + type + "'";                                                                 // 50
    var matches = /c[54]_requires[\s\S]*(\{[\s\S]+\})[\s\S]*end_c[54]_requires/.matches(code);                         // 51
    console.log(matches);                                                                                              // 52
};                                                                                                                     // 55
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"C5.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// C5.js                                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       //
Widgets = new Mongo.Collection("widgets");                                                                             // 2
UserXtras = new Mongo.Collection("userxtras");                                                                         // 3
                                                                                                                       //
// set GLOBAL VARS                                                                                                     // 5
//In the client side                                                                                                   // 6
SERVER_NAME = "localhost";                                                                                             // 7
SERVER_IP = "localhost";                                                                                               // 8
                                                                                                                       //
if (Meteor.isClient) {                                                                                                 // 10
  Meteor.call('getServerName', function (err, results) {                                                               // 11
    SERVER_NAME = results;                                                                                             // 12
  });                                                                                                                  // 13
  Meteor.call('getServerIP', function (err, results) {                                                                 // 14
    SERVER_IP = results;                                                                                               // 15
  });                                                                                                                  // 16
}                                                                                                                      // 17
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 20
                                                                                                                       //
  Meteor.startup(function () {                                                                                         // 22
    /*                                                                                                                 // 23
    var to ="donundeen@gmail.com";                                                                                     //
    var from = "c5@boomhifive.com";                                                                                    //
    var subject = "C5 started";                                                                                        //
    var text = "notifying you that C5 started";                                                                        //
    console.log("sending email");                                                                                      //
    Email.send({                                                                                                       //
      to: to,                                                                                                          //
      from: from,                                                                                                      //
      subject: subject,                                                                                                //
      text: text                                                                                                       //
    });                                                                                                                //
    */                                                                                                                 //
  });                                                                                                                  // 36
                                                                                                                       //
  Meteor.methods({                                                                                                     // 39
    getServerName: function () {                                                                                       // 40
      function getServerName() {                                                                                       // 40
        SERVER_NAME = process.env.SERVER_NAME;                                                                         // 41
        if (typeof SERVER_NAME === "undefined") {                                                                      // 42
          SERVER_NAME = "localhost";                                                                                   // 43
        }                                                                                                              // 44
        return SERVER_NAME;                                                                                            // 45
      }                                                                                                                // 46
                                                                                                                       //
      return getServerName;                                                                                            // 40
    }(),                                                                                                               // 40
    getServerIP: function () {                                                                                         // 47
      function getServerIP() {                                                                                         // 47
        SERVER_IP = process.env.SERVER_IP;                                                                             // 48
        if (typeof SERVER_IP === "undefined") {                                                                        // 49
          SERVER_IP = "localhost";                                                                                     // 50
        }                                                                                                              // 51
        return SERVER_IP;                                                                                              // 52
      }                                                                                                                // 53
                                                                                                                       //
      return getServerIP;                                                                                              // 47
    }()                                                                                                                // 47
  });                                                                                                                  // 39
}                                                                                                                      // 55
                                                                                                                       //
if (Meteor.isClient) {                                                                                                 // 57
                                                                                                                       //
  Meteor.startup(function () {                                                                                         // 60
    console.log("starting meteor");                                                                                    // 61
    $(window).bind('beforeunload', function () {                                                                       // 62
      $(".save").trigger("click");                                                                                     // 63
    });                                                                                                                // 64
  });                                                                                                                  // 66
                                                                                                                       //
  /// comments config                                                                                                  // 71
  // On the Client                                                                                                     // 72
  Comments.ui.config({                                                                                                 // 73
    template: 'bootstrap' // or ionic, semantic-ui                                                                     // 74
  });                                                                                                                  // 73
                                                                                                                       //
  ////// HELPERS                                                                                                       // 77
  UI.registerHelper('shortIt', function (stringToShorten, maxCharsAmount) {                                            // 78
    if (stringToShorten.length > maxCharsAmount) {                                                                     // 79
      return stringToShorten.substring(0, maxCharsAmount) + '...';                                                     // 80
    }                                                                                                                  // 81
    return stringToShorten;                                                                                            // 82
  });                                                                                                                  // 83
                                                                                                                       //
  UI.registerHelper('encodeURIComponent', function (string) {                                                          // 85
    return encodeURIComponent(string);                                                                                 // 86
  });                                                                                                                  // 87
                                                                                                                       //
  UI.registerHelper('absoluteUrl', function () {                                                                       // 89
    return Meteor.absoluteUrl();                                                                                       // 90
  });                                                                                                                  // 91
                                                                                                                       //
  Accounts.ui.config({                                                                                                 // 93
    passwordSignupFields: "USERNAME_AND_EMAIL"                                                                         // 94
  });                                                                                                                  // 93
                                                                                                                       //
  Template.registerHelper("pageid", function () {                                                                      // 97
    return pageinfo().pageid;                                                                                          // 98
  });                                                                                                                  // 99
                                                                                                                       //
  Template.registerHelper("pageurl", function () {                                                                     // 101
    return pageinfo().pageurl;                                                                                         // 102
  });                                                                                                                  // 103
                                                                                                                       //
  Template.registerHelper("pagetype", function () {                                                                    // 106
    return pageinfo().pagetype;                                                                                        // 107
  });                                                                                                                  // 108
                                                                                                                       //
  Template.registerHelper("pageid_neverblank", function () {                                                           // 110
    return "_pi_" + pageinfo().pageid;                                                                                 // 111
  });                                                                                                                  // 112
                                                                                                                       //
  Template.registerHelper("pageurl_neverblank", function () {                                                          // 114
    return "_pu_" + pageinfo().pageurl;                                                                                // 115
  });                                                                                                                  // 116
  Template.registerHelper("pagetype_neverblank", function () {                                                         // 117
    return "_pt_" + pageinfo().pagetype;                                                                               // 118
  });                                                                                                                  // 119
                                                                                                                       //
  Template.registerHelper("numComments", function (commentId) {                                                        // 121
                                                                                                                       //
    var instance = Template.instance;                                                                                  // 123
                                                                                                                       //
    if (!instance.commentCounters) {                                                                                   // 125
      instance.commentCounters = {};                                                                                   // 126
    }                                                                                                                  // 127
    if (!instance.commentCounters[commentId]) {                                                                        // 128
      instance.commentCounters[commentId] = new ReactiveVar();                                                         // 129
    }                                                                                                                  // 130
    Comments.getCount(commentId, function (error, count) {                                                             // 131
      instance.commentCounters[commentId].set(count);                                                                  // 132
    });                                                                                                                // 133
    return instance.commentCounters[commentId].get();                                                                  // 134
  });                                                                                                                  // 135
                                                                                                                       //
  Template.registerHelper("commentIcon", function (commentId) {                                                        // 137
                                                                                                                       //
    var instance = Template.instance;                                                                                  // 139
                                                                                                                       //
    var noComments = "zmdi-comment";                                                                                   // 141
    var hasComments = "zmdi-comment-alert";                                                                            // 142
                                                                                                                       //
    if (!instance.commentIcons) {                                                                                      // 144
      instance.commentIcons = {};                                                                                      // 145
    }                                                                                                                  // 146
    if (!instance.commentIcons[commentId]) {                                                                           // 147
      instance.commentIcons[commentId] = new ReactiveVar();                                                            // 148
    }                                                                                                                  // 149
    Comments.getCount(commentId, function (error, count) {                                                             // 150
      if (count > 0) {                                                                                                 // 151
        console.log(commentId + " has comments");                                                                      // 152
        instance.commentCounters[commentId].set("zmdi-comment-alert");                                                 // 153
      } else {                                                                                                         // 154
        console.log(commentId + " no comments");                                                                       // 155
        instance.commentIcons[commentId].set("zmdi-comment");                                                          // 156
      }                                                                                                                // 157
    });                                                                                                                // 158
    return instance.commentIcons[commentId].get();                                                                     // 159
  });                                                                                                                  // 160
                                                                                                                       //
  Template.registerHelper("SERVER_NAME", function () {                                                                 // 164
    return SERVER_NAME;                                                                                                // 165
  });                                                                                                                  // 166
  Template.registerHelper("SERVER_IP", function () {                                                                   // 167
    return SERVER_IP;                                                                                                  // 168
  });                                                                                                                  // 169
  Template.gridwidgets.helpers({                                                                                       // 170
    widgets: function () {                                                                                             // 171
      function widgets() {                                                                                             // 171
        // Otherwise, return all of the tasks                                                                          // 172
        var find = {                                                                                                   // 173
          this_page_only: { $in: [false, null] },                                                                      // 174
          pagetype: pageinfo().pagetype,                                                                               // 175
          $or: [{ visibility: "public" }, { $and: [{ visibility: "private" }, { "createdBy.userid": Meteor.userId() }] }, { visibility: null }]
        };                                                                                                             // 173
                                                                                                                       //
        //        var results = Widgets.find(find, {sort: {sort_order : -1, createdAt: -1}}).map(setWidgetDefaults);   // 186
        var results = Widgets.find(find, { sort: { sort_order: 1 } }).map(setWidgetDefaults);                          // 187
        console.log("got results");                                                                                    // 188
        console.log(results);                                                                                          // 189
                                                                                                                       //
        return results;                                                                                                // 191
      }                                                                                                                // 192
                                                                                                                       //
      return widgets;                                                                                                  // 171
    }(),                                                                                                               // 171
    thisPageWidgets: function () {                                                                                     // 193
      function thisPageWidgets() {                                                                                     // 193
        // Otherwise, return all of the tasks                                                                          // 194
        var find = { this_page_only: true,                                                                             // 195
          pagetype: pageinfo().pagetype,                                                                               // 196
          pageid: pageinfo().pageid };                                                                                 // 197
        var results = Widgets.find(find, { sort: { sort_order: 1, createdAt: -1 } }).map(setWidgetDefaults);           // 198
        return results;                                                                                                // 199
      }                                                                                                                // 200
                                                                                                                       //
      return thisPageWidgets;                                                                                          // 193
    }()                                                                                                                // 193
                                                                                                                       //
  });                                                                                                                  // 170
  Template.body.helpers({                                                                                              // 203
    widgets: function () {                                                                                             // 204
      function widgets() {                                                                                             // 204
        // Otherwise, return all of the tasks                                                                          // 205
        var find = {                                                                                                   // 206
          this_page_only: { $in: [false, null] },                                                                      // 207
          pagetype: pageinfo().pagetype,                                                                               // 208
          $or: [{ visibility: "public" }, { $and: [{ visibility: "private" }, { "createdBy.userid": Meteor.userId() }] }, { visibility: null }]
        };                                                                                                             // 206
                                                                                                                       //
        //        var results = Widgets.find(find, {sort: {sort_order : -1, createdAt: -1}}).map(setWidgetDefaults);   // 219
        var results = Widgets.find(find, { sort: { sort_order: 1 } }).map(setWidgetDefaults);                          // 220
                                                                                                                       //
        console.log(results);                                                                                          // 222
        return results;                                                                                                // 223
      }                                                                                                                // 224
                                                                                                                       //
      return widgets;                                                                                                  // 204
    }(),                                                                                                               // 204
    widgetTemplates: function () {                                                                                     // 225
      function widgetTemplates() {                                                                                     // 225
        // Otherwise, return all of the tasks                                                                          // 226
        var results = Widgets.find({ isTemplate: true }, { sort: { sort_order: -1, createdAt: -1 } }).map(setWidgetDefaults);
        return results;                                                                                                // 228
      }                                                                                                                // 229
                                                                                                                       //
      return widgetTemplates;                                                                                          // 225
    }(),                                                                                                               // 225
    libraryWidgets: function () {                                                                                      // 230
      function libraryWidgets() {                                                                                      // 230
        // Otherwise, return all of the tasks                                                                          // 231
        var find = { inLibrary: true };                                                                                // 232
        find["createdBy.userid"] = Meteor.userId();                                                                    // 233
        var results = Widgets.find(find, { sort: { sort_order: -1, createdAt: -1 } }).map(setWidgetDefaults);          // 234
        return results;                                                                                                // 235
      }                                                                                                                // 236
                                                                                                                       //
      return libraryWidgets;                                                                                           // 230
    }(),                                                                                                               // 230
    thisPageWidgets: function () {                                                                                     // 237
      function thisPageWidgets() {                                                                                     // 237
        // Otherwise, return all of the tasks                                                                          // 238
        var find = { this_page_only: true,                                                                             // 239
          pagetype: pageinfo().pagetype,                                                                               // 240
          pageid: pageinfo().pageid };                                                                                 // 241
        var results = Widgets.find(find, { sort: { sort_order: -1, createdAt: -1 } }).map(setWidgetDefaults);          // 242
        return results;                                                                                                // 243
      }                                                                                                                // 244
                                                                                                                       //
      return thisPageWidgets;                                                                                          // 237
    }(),                                                                                                               // 237
                                                                                                                       //
    userXtras: function () {                                                                                           // 246
      function userXtras() {                                                                                           // 246
        return getUserXtras();                                                                                         // 247
      }                                                                                                                // 248
                                                                                                                       //
      return userXtras;                                                                                                // 246
    }(),                                                                                                               // 246
                                                                                                                       //
    godmode: function () {                                                                                             // 250
      function godmode() {                                                                                             // 250
        return getUserXtras().godmode;                                                                                 // 251
      }                                                                                                                // 252
                                                                                                                       //
      return godmode;                                                                                                  // 250
    }()                                                                                                                // 250
                                                                                                                       //
  });                                                                                                                  // 203
  ////// END HELPERS                                                                                                   // 255
                                                                                                                       //
                                                                                                                       //
  ////// TEMPLATE ONRENDERED                                                                                           // 258
  Template.body.onRendered(function () {                                                                               // 259
    //$(".tooltip-right").tooltip({placement: "right"});                                                               // 260
    //  $("[title]").tooltip({placement: "auto"});                                                                     // 261
    console.log("555555555555C5 rendered");                                                                            // 262
  });                                                                                                                  // 263
  ////// END ONRENDERED                                                                                                // 264
                                                                                                                       //
                                                                                                                       //
  /////// EVENTS                                                                                                       // 268
  Template.body.events({                                                                                               // 269
                                                                                                                       //
    "click .lockall": function () {                                                                                    // 272
      function clickLockall() {                                                                                        // 272
        $(".lock").trigger("click");                                                                                   // 273
        $(".lockall").hide();                                                                                          // 274
        $(".unlockall").show();                                                                                        // 275
        giphy_modal("unlock", "Unlocking all widgets you have access to");                                             // 276
        return false;                                                                                                  // 277
      }                                                                                                                // 279
                                                                                                                       //
      return clickLockall;                                                                                             // 272
    }(),                                                                                                               // 272
    "click .unlockall": function () {                                                                                  // 280
      function clickUnlockall() {                                                                                      // 280
        $(".unlock").trigger("click");                                                                                 // 281
        $(".lockall").show();                                                                                          // 282
        $(".unlockall").hide();                                                                                        // 283
        giphy_modal("lock", "Locking all Widgets");                                                                    // 284
        return false;                                                                                                  // 285
      }                                                                                                                // 286
                                                                                                                       //
      return clickUnlockall;                                                                                           // 280
    }(),                                                                                                               // 280
                                                                                                                       //
    "click .giphy": function () {                                                                                      // 288
      function clickGiphy(e, t) {                                                                                      // 288
        $(e.target).hide();                                                                                            // 289
      }                                                                                                                // 290
                                                                                                                       //
      return clickGiphy;                                                                                               // 288
    }(),                                                                                                               // 288
                                                                                                                       //
    "click .godmode_check": function () {                                                                              // 292
      function clickGodmode_check(e, t) {                                                                              // 292
        //      console.log(t);                                                                                        // 293
        UserXtras.update({ _id: Meteor.userId() }, { $set: { godmode: e.target.checked } });                           // 294
      }                                                                                                                // 295
                                                                                                                       //
      return clickGodmode_check;                                                                                       // 292
    }(),                                                                                                               // 292
                                                                                                                       //
    'click .copy_from_template': function () {                                                                         // 297
      function clickCopy_from_template() {                                                                             // 297
        copyWidgetToPage($(this).attr("target"), pageinfo().pagetype, pageinfo().pageurl, pageinfo().pageid);          // 298
        giphy_modal("copy", "New Widget Copied From Template");                                                        // 299
        return false;                                                                                                  // 300
      }                                                                                                                // 301
                                                                                                                       //
      return clickCopy_from_template;                                                                                  // 297
    }(),                                                                                                               // 297
                                                                                                                       //
    'click .deletetemplate': function () {                                                                             // 303
      function clickDeletetemplate() {                                                                                 // 303
        var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                                  // 304
        template.isTemplate = false;                                                                                   // 305
        Widgets.update(template._id, template);                                                                        // 306
      }                                                                                                                // 307
                                                                                                                       //
      return clickDeletetemplate;                                                                                      // 303
    }(),                                                                                                               // 303
                                                                                                                       //
    'click .addwidget': function () {                                                                                  // 309
      function clickAddwidget() {                                                                                      // 309
        //add jsbin widget                                                                                             // 310
                                                                                                                       //
        var htmlstring = '<html>\n ' + '<head>\n ' + '<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>\n ' + '<script src="/c5libs/locallib.js"></script>\n ' + '   <script type="application/json" class="c5_data">{"data" : "data placed here gets passed along"}</script>\n ' + '</head>\n ' + '<body>\n ' + '  <div class="c5_html">\n ' + '  html placed here gets passed along\n ' + '  </div>\n ' + '</body>\n ' + '</html>\n';
        var csstring = "";                                                                                             // 324
        var jsstring = "function doTheThings(data){\n" + "// everything you want to do should happen inside this function\n " + "// the data var will be populated with whatever you've requested from other widgets\n" + "// and this function will be call when all those widgets have complete \n" + "   c5_done(); // this message is required at the end of all the processing, so the system knows this widget is done \n " + "} \n" + "requireWidgetData( \n" + "// all requests to other widgets go here (automatically if you use the 'pull from' interface): \n" + "// c5_requires \n" + "{} \n" + "// end_c5_requires \n" + "// end other widget requests \n" + ", doTheThings)";
        var dataobj = { html: htmlstring, css: csstring, javascript: jsstring };                                       // 338
        var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                                  // 339
        var options = { data: dataobj };                                                                               // 340
        HTTP.post(url, options, function (error, results) {                                                            // 341
          newWidget = { _id: results.data.url,                                                                         // 342
            createdBy: { username: Meteor.user().username,                                                             // 343
              userid: Meteor.userId() },                                                                               // 344
            isTemplate: false,                                                                                         // 345
            name: results.data.url,                                                                                    // 346
            description: "",                                                                                           // 347
            html: results.data.html,                                                                                   // 348
            javascript: results.data.javascript,                                                                       // 349
            css: results.data.css,                                                                                     // 350
            displayWidth: "",                                                                                          // 351
            displayHeight: "",                                                                                         // 352
            widgetStyle: "",                                                                                           // 353
            pagetype: pageinfo().pagetype,                                                                             // 354
            pageurl: pageinfo().pageurl,                                                                               // 355
            pageid: pageinfo().pageid,                                                                                 // 356
            url: results.data.url,                                                                                     // 357
            visibility: "private",                                                                                     // 358
            createdAt: new Date(),                                                                                     // 359
            rand: Math.random() };                                                                                     // 360
          Widgets.insert(newWidget);                                                                                   // 361
        });                                                                                                            // 362
        return false;                                                                                                  // 363
      }                                                                                                                // 364
                                                                                                                       //
      return clickAddwidget;                                                                                           // 309
    }(),                                                                                                               // 309
                                                                                                                       //
    'click .test': function () {                                                                                       // 366
      function clickTest() {                                                                                           // 366
        return false;                                                                                                  // 367
      }                                                                                                                // 368
                                                                                                                       //
      return clickTest;                                                                                                // 366
    }()                                                                                                                // 366
  });                                                                                                                  // 269
                                                                                                                       //
  ///// END EVENTS                                                                                                     // 372
                                                                                                                       //
}                                                                                                                      // 375
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 377
  Meteor.startup(function () {                                                                                         // 378
    // code to run on server at startup                                                                                // 379
  });                                                                                                                  // 380
}                                                                                                                      // 381
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"common_functions.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// common_functions.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
justaddedid = pageinfo = setWidgetDefaults = giphy_modal = getUserXtras = null;                                        // 1
                                                                                                                       //
if (Meteor.isClient) {                                                                                                 // 3
                                                                                                                       //
  getUserXtras = function getUserXtras() {                                                                             // 5
    var userxtras = false;                                                                                             // 6
    var user = Meteor.user();                                                                                          // 7
    if (user) {                                                                                                        // 8
      /*                                                                                                               // 9
      console.log(user.username);                                                                                      //
      console.log(user._id);                                                                                           //
      console.log("getting for " + user._id);                                                                          //
      */                                                                                                               //
      userxtras = UserXtras.findOne({ _id: user._id });                                                                // 14
      if (!userxtras || !userxtras.foo) {                                                                              // 15
        console.log("userxtras " + userxtras);                                                                         // 16
        userxtras = { _id: user._id, admin: false, godmode: false, foo: "var" };                                       // 17
        if (user.username == "donundeen") {                                                                            // 18
          userxtras.admin = true;                                                                                      // 19
        }                                                                                                              // 20
        console.log("saving for " + user._id);                                                                         // 21
        UserXtras.upsert({ _id: user._id }, userxtras);                                                                // 22
        var userxtras2 = UserXtras.findOne({ _id: user._id });                                                         // 23
      }                                                                                                                // 24
    }                                                                                                                  // 25
    return userxtras;                                                                                                  // 26
  };                                                                                                                   // 28
                                                                                                                       //
  giphy_modal = function giphy_modal(term, text) {                                                                     // 32
    $("#giphy_modal").modal('show');                                                                                   // 33
    $(".giphy_modal_header").text(text);                                                                               // 34
    var url = "/giphy_proxy/" + encodeURIComponent(term);                                                              // 35
    $(".giphy_modal_image_div").empty();                                                                               // 36
    var imgurl = url + "?" + new Date().getTime();                                                                     // 37
    $(".giphy_modal_image_div").html("<img src='" + imgurl + "' width='200' class='giphy_modal_image_img'/>");         // 38
                                                                                                                       //
    setTimeout(function () {                                                                                           // 40
      $("#giphy_modal").modal('hide');                                                                                 // 41
    }, 2000);                                                                                                          // 42
  };                                                                                                                   // 44
                                                                                                                       //
  pageinfo = function pageinfo() {                                                                                     // 46
    var pagetype = "";                                                                                                 // 47
    var pageid = "";                                                                                                   // 48
    var pathname = window.location.pathname;                                                                           // 49
    var split = pathname.split("/");                                                                                   // 50
    split.shift();                                                                                                     // 51
    var pageurl = split.join("/");                                                                                     // 52
                                                                                                                       //
    if (split.length > 0) {                                                                                            // 54
      pagetype = split.shift();                                                                                        // 55
    }                                                                                                                  // 56
    if (split.length > 0) {                                                                                            // 57
      pageid = split.shift();                                                                                          // 58
    }                                                                                                                  // 59
    pageid = pageid.replace(/:script/, "");                                                                            // 60
    return { pageurl: pageurl,                                                                                         // 61
      pagetype: pagetype,                                                                                              // 62
      pageid: pageid };                                                                                                // 63
  };                                                                                                                   // 65
                                                                                                                       //
  copyWidgetToPage = function copyWidgetToPage(origID, pagetype, pageid, pageurl) {                                    // 68
    console.log("calling CopyWidgetToPage for " + origID);                                                             // 69
    var template = Widgets.findOne({ url: origID }); //.map(setWidgetDefaults);                                        // 70
    var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                         // 71
    var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                                      // 72
    var options = { data: dataobj };                                                                                   // 73
                                                                                                                       //
    HTTP.post(url, options, function (error, results) {                                                                // 75
      newWidget = { _id: results.data.url,                                                                             // 76
        createdBy: { username: Meteor.user().username,                                                                 // 77
          userid: Meteor.userId() },                                                                                   // 78
        isTemplate: false,                                                                                             // 79
        html: results.data.html,                                                                                       // 80
        javascript: results.data.javascript,                                                                           // 81
        css: results.data.css,                                                                                         // 82
        displayWidth: results.data.displayWidth,                                                                       // 83
        displayHeight: results.data.displayHeight,                                                                     // 84
        description: "(copied from " + template.name + ") " + template.description,                                    // 85
        widgetStyle: results.data.widgetStyle,                                                                         // 86
        name: "copy of " + template.name,                                                                              // 87
        pagetype: pagetype,                                                                                            // 88
        pageurl: pageurl,                                                                                              // 89
        pageid: pageid,                                                                                                // 90
        url: results.data.url,                                                                                         // 91
        createdAt: new Date(),                                                                                         // 92
        visibility: "private",                                                                                         // 93
        rand: Math.random() };                                                                                         // 94
      justaddedid = Widgets.insert(newWidget);                                                                         // 95
      console.log("setting justaddedid " + justaddedid);                                                               // 96
                                                                                                                       //
      var grid = $(".grid-stack").data('gridstack');                                                                   // 98
      var widgetElement = $("#widgetContainer_" + results.data.url);                                                   // 99
                                                                                                                       //
      console.log("added ");                                                                                           // 101
      console.log(widgetElement);                                                                                      // 102
      /*                                                                                                               // 103
      var griditem = $(widgetElement).parent().parent();                                                               //
      $(griditem).data("gs-width", "12");                                                                              //
      $(griditem).data("gs-height", "5");                                                                              //
      $(griditem).data("gs-auto-position", "true");                                                                    //
      grid.makeWidget(griditem);                                                                                       //
      grid.resize(griditem, 12, 5);                                                                                    //
       var next = $(".grid-stack-item").get(0)  ;                                                                      //
      console.log("moving next" + $(next).data("widget-id"));                                                          //
      console.log(next);                                                                                               //
      grid.move(next, 0, 6);                                                                                           //
      */                                                                                                               //
    });                                                                                                                // 116
    giphy_modal("copy", "New Widget Copied From Template");                                                            // 117
  };                                                                                                                   // 119
                                                                                                                       //
  setWidgetDefaults = function setWidgetDefaults(doc) {                                                                // 122
    if (typeof doc.displayWidth === "undefined" || !doc.displayWidth || doc.displayWidth.trim() == "" || doc.displayWidth == "width" || doc.displayWidth == "default") {
      doc.displayWidth = "320px";                                                                                      // 124
      doc.displayUsableWidth = "320px";                                                                                // 125
    } else {                                                                                                           // 126
      doc.displayUsableWidth = doc.displayWidth;                                                                       // 127
    }                                                                                                                  // 128
    if (typeof doc.displayHeight === "undefined" || !doc.displayHeight || doc.displayHeight.trim() == "" || doc.displayHeight == "height" || doc.displayHeight == "default") {
      doc.displayHeight = "400px";                                                                                     // 130
      doc.displayUsableHeight = "400px";                                                                               // 131
    } else {                                                                                                           // 132
      doc.displayUsableHeight = doc.displayHeight;                                                                     // 133
    }                                                                                                                  // 134
    if (typeof doc.widgetStyle === "undefined" || !doc.widgetStyle || doc.widgetStyle.trim() == "" || doc.widgetStyle == "css" || doc.widgetStyle == "default") {
      doc.widgetStyle = "default";                                                                                     // 136
      doc.usableWidgetStyle = "";                                                                                      // 137
    } else {                                                                                                           // 138
      doc.usableWidgetStyle = doc.widgetStyle;                                                                         // 139
    }                                                                                                                  // 140
    if (!doc.createdBy) {                                                                                              // 141
      doc.createdBy = {};                                                                                              // 142
    }                                                                                                                  // 143
                                                                                                                       //
    if (doc.displayUsableHeight.match(/px/)) {                                                                         // 145
      var height = doc.displayUsableHeight.replace(/px/, "");                                                          // 146
      doc.jsbinHeight = height - 20;                                                                                   // 147
      doc.jsbinHeight += "px";                                                                                         // 148
    } else {                                                                                                           // 149
      doc.jsbinHeight = "";                                                                                            // 150
    }                                                                                                                  // 151
                                                                                                                       //
    if (!doc.this_page_only) {                                                                                         // 153
      doc.this_page_only = false;                                                                                      // 154
    }                                                                                                                  // 155
                                                                                                                       //
    if (!doc.sort_order) {                                                                                             // 157
      doc.sort_order = 0;                                                                                              // 158
    }                                                                                                                  // 159
                                                                                                                       //
    if (!doc.visibility) {                                                                                             // 161
      doc.visibility = "public";                                                                                       // 162
    }                                                                                                                  // 163
                                                                                                                       //
    if (!doc.cacheConfig) {                                                                                            // 165
      doc.cacheConfig = {};                                                                                            // 166
    }                                                                                                                  // 167
                                                                                                                       //
    if (!doc.cacheConfig.ttl) {                                                                                        // 169
      doc.cacheConfig.ttl = 60;                                                                                        // 170
    }                                                                                                                  // 171
                                                                                                                       //
    if (typeof doc.width_in_cells == "undefined") {                                                                    // 173
      doc.width_in_cells = 12;                                                                                         // 174
    }                                                                                                                  // 175
    if (typeof doc.height_in_cells == "undefined") {                                                                   // 176
      doc.height_in_cells = 5;                                                                                         // 177
    }                                                                                                                  // 178
    if (doc.width_in_cells == 0) {                                                                                     // 179
      doc.width_in_cells = 1;                                                                                          // 180
    }                                                                                                                  // 181
    if (doc.height_in_cells == 0) {                                                                                    // 182
      doc.height_in_cells = 1;                                                                                         // 183
    }                                                                                                                  // 184
    if (typeof doc.width_in_px == "undefined") {                                                                       // 185
      doc.width_in_px = 640;                                                                                           // 186
    }                                                                                                                  // 187
    if (typeof doc.height_in_px == "undefined") {                                                                      // 188
      doc.height_in_px = 320;                                                                                          // 189
    }                                                                                                                  // 190
    if (doc.width_in_px == 0) {                                                                                        // 191
      doc.width_in_px = 640;                                                                                           // 192
    }                                                                                                                  // 193
    if (doc.height_in_px == 0) {                                                                                       // 194
      doc.height_in_px = 320;                                                                                          // 195
    }                                                                                                                  // 196
                                                                                                                       //
    return doc;                                                                                                        // 199
  };                                                                                                                   // 200
}                                                                                                                      // 201
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"widget.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// widget.js                                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
                                                                                                                       //
if (Meteor.isClient) {                                                                                                 // 2
  var dix;                                                                                                             // 2
                                                                                                                       //
  (function () {                                                                                                       // 2
    var setDisplayModeOn = function setDisplayModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin, widgetid, isnew) {
      var grid = $(".grid-stack").data("gridstack");                                                                   // 8
      var griditem = $(widgetElement).parent().parent();                                                               // 9
      var result = grid.resize(griditem, widgetData.width_in_cells, widgetData.height_in_cells);                       // 10
                                                                                                                       //
      // get the size of the navbar, subtract from height of iframe                                                    // 12
                                                                                                                       //
      dix++;                                                                                                           // 14
      var di = dix;                                                                                                    // 15
      var newbintop = 0;                                                                                               // 16
      $(menu).hide();                                                                                                  // 17
                                                                                                                       //
      $(".editmodeonly", widgetElement).hide();                                                                        // 19
      $(".displaymodeonly", widgetElement).show();                                                                     // 20
      iframeElement.oldbintop = $(bin).css("top");                                                                     // 21
      $(bin).css("top", newbintop);                                                                                    // 22
      $(widgetElement).attr("style", widgetData.usableWidgetStyle);                                                    // 23
                                                                                                                       //
      $(widgetElement).css("border-radius", "10px");                                                                   // 25
      $(".widgetDisplayHeader", widgetElement).hide();                                                                 // 26
                                                                                                                       //
      if (jsbin && jsbin.panels) {                                                                                     // 28
        jsbin.panels.hide("html");                                                                                     // 29
        jsbin.panels.hide("javascript");                                                                               // 30
        jsbin.panels.hide("css");                                                                                      // 31
        jsbin.panels.hide("console");                                                                                  // 32
      }                                                                                                                // 33
      $(".lock", widgetElement).show();                                                                                // 34
      $(".unlock", widgetElement).hide();                                                                              // 35
      $(widgetElement).data("mode", "display");                                                                        // 36
      $(iframeElement).css("border-radius", "10px");                                                                   // 37
                                                                                                                       //
      var initialH = $(griditem).height();                                                                             // 39
      var finalh = initialH;                                                                                           // 40
      var initialW = $(griditem).width();                                                                              // 41
      var finalw = initialW;                                                                                           // 42
      $(widgetElement).width(finalw - 35);                                                                             // 43
      $(widgetElement).height(finalh - 15);                                                                            // 44
                                                                                                                       //
      $(iframeElement).css("max-height", "");                                                                          // 46
      $(iframeElement).css("max-width", "");                                                                           // 47
      $(iframeElement).css("min-height", "");                                                                          // 48
      $(iframeElement).css("min-width", "");                                                                           // 49
                                                                                                                       //
      $(iframeElement).width(finalw - 35);                                                                             // 51
      $(iframeElement).css("max-width", finalw - 35);                                                                  // 52
      $(iframeElement).height(finalh - 25);                                                                            // 53
      $(iframeElement).css("max-height", finalh - 25);                                                                 // 54
      $(iframeElement).css("min-height", finalh - 25);                                                                 // 55
    };                                                                                                                 // 57
                                                                                                                       //
    var setEditModeOn = function setEditModeOn(widgetData, iframeElement, widgetElement, menu, bin, jsbin) {           // 2
      var grid = $(".grid-stack").data("gridstack");                                                                   // 61
      var griditem = $(widgetElement).parent().parent();                                                               // 62
      if (jsbin) {                                                                                                     // 63
        jsbin.panels.show("html");                                                                                     // 64
        jsbin.panels.show("javascript");                                                                               // 65
      }                                                                                                                // 66
      $(".lock", widgetElement).hide();                                                                                // 67
      $(".unlock", widgetElement).show();                                                                              // 68
      //      editors.panels.show("css");                                                                              // 69
                                                                                                                       //
      var newbintop = 0;                                                                                               // 71
                                                                                                                       //
      grid.resize(griditem, 12, 6);                                                                                    // 73
                                                                                                                       //
      // put it in EDIT MODE                                                                                           // 75
      $(menu).show();                                                                                                  // 76
      $(".editmodeonly", widgetElement).show();                                                                        // 77
      $(".displaymodeonly", widgetElement).hide();                                                                     // 78
      $(bin).css("top", iframeElement.oldbintop);                                                                      // 79
      $(widgetElement).css("border-radius", "10px");                                                                   // 80
      $(iframeElement).css("border-radius", "10px");                                                                   // 81
                                                                                                                       //
      // ".navbar-collapse"                                                                                            // 83
      var height_adjust = $(".navbar-collapse", widgetElement).height() - 20;                                          // 84
      // adjust for height of menu                                                                                     // 85
                                                                                                                       //
                                                                                                                       //
      var initialH = $(griditem).height();                                                                             // 88
      var finalh = initialH;                                                                                           // 89
      var initialW = $(griditem).width();                                                                              // 90
      var finalw = initialW;                                                                                           // 91
      $(widgetElement).width(finalw - 25);                                                                             // 92
      $(widgetElement).height(finalh - 15);                                                                            // 93
                                                                                                                       //
      $(iframeElement).css("max-height", "");                                                                          // 95
      $(iframeElement).css("max-width", "");                                                                           // 96
      $(iframeElement).css("min-height", "");                                                                          // 97
      $(iframeElement).css("min-width", "");                                                                           // 98
                                                                                                                       //
      $(iframeElement).width(finalw - 25);                                                                             // 100
      $(iframeElement).css("max-width", finalw - 25);                                                                  // 101
      $(iframeElement).height(finalh - 25 - height_adjust);                                                            // 102
      $(iframeElement).css("max-height", finalh - 25);                                                                 // 103
      $(iframeElement).css("min-height", finalh - 25);                                                                 // 104
    };                                                                                                                 // 106
    /////// END FUNCTION DEFS                                                                                          // 107
                                                                                                                       //
                                                                                                                       //
    /////////// END WIDGET ONRENDERED                                                                                  // 360
                                                                                                                       //
                                                                                                                       //
    //////////// EVENTS                                                                                                // 364
                                                                                                                       //
    var insert_code = function insert_code(jsbin_id, codeString, codeStringRe, comments) {                             // 2
                                                                                                                       //
      var editors = document.getElementById(jsbin_id).contentWindow.editors;                                           // 368
                                                                                                                       //
      if (!editors) {                                                                                                  // 370
        return true;                                                                                                   // 371
      }                                                                                                                // 372
      var code = editors.javascript.getCode();                                                                         // 373
      var line = editors.javascript.editor.getCursor().line;                                                           // 374
      var charpos = editors.javascript.editor.getCursor().ch;                                                          // 375
      // make sure it's not already in there:                                                                          // 376
      var codeRe = new RegExp("\/\/ *c[45]_requires[\\s\\S]*\\[[\\s\\S]*" + codeStringRe + "[\\s\\S]*\\] *,[\\s\\S]*\/\/ *end_c[45]_requires");
      var codeMatch = code.match(codeRe);                                                                              // 378
      if (!codeMatch) {                                                                                                // 379
        // match to empty array                                                                                        // 380
        var match = /(\/\/ *c[45]_requires[\s\S]*\[)\s*(\] *,[\s\S]*\/\/ *end_c[45]_requires)/;                        // 381
        var results = code.match(match);                                                                               // 382
        newcode = code.replace(match, "$1\n" + codeString + " // " + comments + "\n$2");                               // 383
                                                                                                                       //
        if (newcode == code) {                                                                                         // 385
          // match to non-empty array                                                                                  // 386
          var match = /(\/\/ *c[45]_requires[\s\S]*\[)([^\]]*\] *,[\s\S]*\/\/ *end_c[45]_requires)/;                   // 387
          var results = code.match(match);                                                                             // 388
          newcode = code.replace(match, "$1\n" + codeString + ", // " + comments + "$2");                              // 389
        }                                                                                                              // 390
        code = newcode;                                                                                                // 391
        var state = { line: editors.javascript.editor.currentLine(),                                                   // 392
          character: editors.javascript.editor.getCursor().ch,                                                         // 393
          add: 0                                                                                                       // 394
        };                                                                                                             // 392
                                                                                                                       //
        editors.javascript.setCode(code);                                                                              // 397
        editors.javascript.editor.setCursor({ line: state.line + state.add, ch: state.character });                    // 398
      }                                                                                                                // 399
    };                                                                                                                 // 400
                                                                                                                       //
    /////// FUNCTION DEFS                                                                                              // 4
    dix = 0;                                                                                                           // 5
    Template.gridwidgets.onRendered(function () {                                                                      // 111
      // set whatever gridStack options you want                                                                       // 112
      var options = {                                                                                                  // 113
        width: 12,                                                                                                     // 114
        auto: false,                                                                                                   // 115
        cellHeight: 60,                                                                                                // 116
        cellWidth: 60,                                                                                                 // 117
        alwaysShowResizeHandle: /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),
        resizable: {                                                                                                   // 119
          handles: 'e, se, s, sw, w'                                                                                   // 120
        }                                                                                                              // 119
      };                                                                                                               // 113
      var $gridstack = this.$('.grid-stack');                                                                          // 123
      // initialise gridstack                                                                                          // 124
      $gridstack.gridstack(options);                                                                                   // 125
                                                                                                                       //
      $(window).resize(function (evt) {                                                                                // 127
        if (evt.target == window) {                                                                                    // 128
          var grid = $(".grid-stack").data("gridstack");                                                               // 129
          $(".grid-stack-item").each(function (index) {                                                                // 130
            var element = this;                                                                                        // 131
            var initialH = $(element).height();                                                                        // 132
            var finalh = initialH;                                                                                     // 133
            var initialW = $(element).width();                                                                         // 134
            var finalw = initialW;                                                                                     // 135
            var cellw = grid.cellWidth();                                                                              // 136
            var cellh = grid.cellHeight();                                                                             // 137
            var cells_wide = $(element).data("gs-width");                                                              // 138
            var cells_high = $(element).data('gs-height');                                                             // 139
                                                                                                                       //
            var widgetElement = $(".widgetContainer", element);                                                        // 141
            var iframeElement = $(".jsbin-embed", element);                                                            // 142
                                                                                                                       //
            $(widgetElement).width(finalw - 25);                                                                       // 144
            $(widgetElement).height(finalh - 15);                                                                      // 145
                                                                                                                       //
            $(iframeElement).css("max-height", "");                                                                    // 147
            $(iframeElement).css("max-width", "");                                                                     // 148
            $(iframeElement).css("min-height", "");                                                                    // 149
            $(iframeElement).css("min-width", "");                                                                     // 150
                                                                                                                       //
            $(iframeElement).width(finalw - 35);                                                                       // 152
            $(iframeElement).css("max-width", finalw - 35);                                                            // 153
            $(iframeElement).height(finalh - 25);                                                                      // 154
            $(iframeElement).css("max-height", finalh - 25);                                                           // 155
          });                                                                                                          // 157
        }                                                                                                              // 158
      });                                                                                                              // 159
                                                                                                                       //
      $('.grid-stack').on('dragstop', function (event, ui) {                                                           // 163
        // for some reason the moved grid-item doesn't have access to the widgetId data attribute, so get it here and hang onto it.
        var target_url = $(event.target).data("widget-id");                                                            // 165
        // save new order when items are moved.                                                                        // 166
        var grid = $(this).data('gridstack');                                                                          // 167
        var nodes = grid.grid.nodes;                                                                                   // 168
        for (var i = 0; i < nodes.length; i++) {                                                                       // 169
          var node = nodes[i];                                                                                         // 170
          var id = $(node.el).data('widgetId');                                                                        // 171
          // get widget code, update sort-order                                                                        // 172
          if (typeof id == "undefined") {                                                                              // 173
            id = target_url;                                                                                           // 174
          }                                                                                                            // 175
          if (typeof id != "undefined") {                                                                              // 176
            (function (_id) {                                                                                          // 177
              var widget = Widgets.findOne({ url: _id }); //.map(setWidgetDefaults);                                   // 178
              widget.sort_order = i;                                                                                   // 179
              Widgets.update(widget._id, widget, {}, function (arg1, arg2) {});                                        // 180
            })(id);                                                                                                    // 182
          } else {                                                                                                     // 183
            //            console.log(node);                                                                           // 184
          }                                                                                                            // 185
        }                                                                                                              // 186
      });                                                                                                              // 187
                                                                                                                       //
      $('.grid-stack').on('resizestop', function (event, items) {                                                      // 189
        var grid = this;                                                                                               // 190
        var element = event.target;                                                                                    // 191
        var widgetElement = $(".widgetContainer", element);                                                            // 192
        var iframeElement = $(".jsbin-embed", element);                                                                // 193
        // need to wait just a bit for the size to quantize to the grid...                                             // 194
        setTimeout(function () {                                                                                       // 195
          var initialH = $(element).height();                                                                          // 196
          var finalh = initialH;                                                                                       // 197
          var initialW = $(element).width();                                                                           // 198
          var finalw = initialW;                                                                                       // 199
          var widgetID = $(widgetElement).data("url");                                                                 // 200
          var widget = Widgets.findOne({ url: widgetID }); //.map(setWidgetDefaults);                                  // 201
          $(widgetElement).width(finalw - 35);                                                                         // 202
          $(widgetElement).height(finalh - 15);                                                                        // 203
                                                                                                                       //
          $(iframeElement).css("max-height", "");                                                                      // 205
          $(iframeElement).css("max-width", "");                                                                       // 206
          $(iframeElement).css("min-height", "");                                                                      // 207
          $(iframeElement).css("min-width", "");                                                                       // 208
                                                                                                                       //
          $(iframeElement).width(finalw - 35);                                                                         // 210
          $(iframeElement).css("max-width", finalw - 35);                                                              // 211
          $(iframeElement).height(finalh - 25);                                                                        // 212
          $(iframeElement).css("max-height", finalh - 25);                                                             // 213
                                                                                                                       //
          var cellw = $(grid).data("gridstack").opts.cellWidth;                                                        // 215
          var cellh = $(grid).data("gridstack").opts.cellHeight;                                                       // 216
          var cells_wide = $(element).data("gs-width");                                                                // 217
          var cells_high = $(element).data('gs-height');                                                               // 218
                                                                                                                       //
          widget.width_in_cells = cells_wide;                                                                          // 220
          widget.height_in_cells = cells_high;                                                                         // 221
          widget.width_in_px = finalw;                                                                                 // 222
          widget.height_in_px = finalh;                                                                                // 223
          Widgets.update(widget._id, widget);                                                                          // 224
        }, 350);                                                                                                       // 225
      });                                                                                                              // 227
                                                                                                                       //
      $('.grid-stack').data("inited", true);                                                                           // 229
    });                                                                                                                // 231
                                                                                                                       //
    Template.widget.onCreated(function () {                                                                            // 235
      var sortorder = this.data.sort_order;                                                                            // 236
      var id = this.data._id;                                                                                          // 237
      console.log("created");                                                                                          // 238
      console.log(id + " , " + sortorder);                                                                             // 239
    });                                                                                                                // 240
                                                                                                                       //
    /////// WIDGET ONRENDERED                                                                                          // 242
    // In the client code, below everything else                                                                       // 243
    Template.widget.onRendered(function () {                                                                           // 244
      var thisisnew = false;                                                                                           // 245
                                                                                                                       //
      if (justaddedid == this.data._id) {                                                                              // 247
        thisisnew = true; // this node was just added.                                                                 // 248
      }                                                                                                                // 249
                                                                                                                       //
      var sortorder = this.data.sort_order;                                                                            // 251
                                                                                                                       //
      var context = Template.currentData();                                                                            // 253
      var firstNode = this.firstNode;                                                                                  // 254
      var firstNodeId = $(firstNode).data("widget-id");                                                                // 255
      var lastNode = this.lastNode;                                                                                    // 256
      var lastNodeId = $(lastNode).data("widget-id");                                                                  // 257
                                                                                                                       //
      var grid = $(".grid-stack").data('gridstack');                                                                   // 259
      var widgetElement = $("#widgetContainer_" + this.data._id);                                                      // 260
      var griditem = $(widgetElement).parent().parent();                                                               // 261
                                                                                                                       //
      if (!thisisnew && grid) {                                                                                        // 263
        console.log("widget Rendered");                                                                                // 264
        console.log(this.data._id);                                                                                    // 265
        console.log(this.data.sort_order);                                                                             // 266
        grid.addWidget(this.$('.grid-stack-item'));                                                                    // 267
      } else {                                                                                                         // 268
        console.log("no grid?");                                                                                       // 269
      }                                                                                                                // 270
      // find out if the widget has been added to the grid.                                                            // 271
                                                                                                                       //
      if (thisisnew) {                                                                                                 // 273
        grid.makeWidget(griditem);                                                                                     // 274
        grid.move(griditem, 0, 0);                                                                                     // 275
        var node = grid.grid.getNodeDataByDOMEl(griditem);                                                             // 276
        //  grid.grid._fixCollisions(griditem);                                                                        // 277
      }                                                                                                                // 278
      if (!$('.grid-stack').data("inited")) {}                                                                         // 279
      // end resizable grid setup                                                                                      // 282
                                                                                                                       //
                                                                                                                       //
      (function (widget, isnew) {                                                                                      // 286
        var thisid = widget.data._id;                                                                                  // 287
        var element = document.getElementById('jsbin_' + thisid);                                                      // 288
        var thiselement = document.getElementById('widgetContainer_' + thisid);                                        // 289
        $(".widgetDisplayHeader", thiselement).hide();                                                                 // 290
                                                                                                                       //
        // maybe already exists?                                                                                       // 292
        var theElement = document.getElementById('jsbin_' + thisid);                                                   // 293
        if (theElement && theElement.contentWindow && theElement.contentWindow.document) {                             // 294
          $(theElement).load(function () {                                                                             // 295
            var widgetElement = document.getElementById('widgetContainer_' + thisid);                                  // 296
            var editors = jsbin = menu = bin = null;                                                                   // 297
            if (theElement) {                                                                                          // 298
              editors = theElement.contentWindow.editors;                                                              // 299
              jsbin = theElement.contentWindow.jsbin;                                                                  // 300
              menu = theElement.contentWindow.document.getElementById("control");                                      // 301
              bin = theElement.contentWindow.document.getElementById("bin");                                           // 302
              var thiselement = document.getElementById('widgetContainer_' + thisid);                                  // 303
              if (jsbin && jsbin.panels) {                                                                             // 304
                jsbin.panels.saveOnExit = true;                                                                        // 305
              }                                                                                                        // 306
              setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, thisid, isnew);                     // 307
            } else {                                                                                                   // 308
              console.log("no element found for jsbin_" + thisid);                                                     // 309
            }                                                                                                          // 310
          });                                                                                                          // 311
        }                                                                                                              // 312
        // this part here happens when the JSBIN stuff is loaded.                                                      // 313
        (function (this_id, isnew) {                                                                                   // 314
          if (isnew) {                                                                                                 // 315
            var widgetElement = document.getElementById('widgetContainer_' + this_id);                                 // 316
            var editors = jsbin = menu = bin = null;                                                                   // 317
            var theElement = document.getElementById('jsbin_' + this_id);                                              // 318
            if (theElement) {                                                                                          // 319
              editors = theElement.contentWindow.editors;                                                              // 320
              jsbin = theElement.contentWindow.jsbin;                                                                  // 321
              menu = theElement.contentWindow.document.getElementById("control");                                      // 322
              bin = theElement.contentWindow.document.getElementById("bin");                                           // 323
              if (jsbin && jsbin.panels) {                                                                             // 324
                jsbin.panels.saveOnExit = true;                                                                        // 325
              }                                                                                                        // 326
              setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, this_id, isnew);                    // 327
            } else {                                                                                                   // 328
              console.log("no element found for jsbin_" + this_id);                                                    // 329
            }                                                                                                          // 330
          }                                                                                                            // 331
                                                                                                                       //
          document.addEventListener("DOMNodeInserted", function (evt, item) {                                          // 334
            (function (_evt, _this_id, isnew) {                                                                        // 335
              if ($(_evt.target)[0].tagName == "IFRAME" && $(_evt.target)[0].id.replace("jsbin_", "") == _this_id) {   // 336
                $(_evt.target).load(function () {                                                                      // 337
                  var widgetElement = document.getElementById('widgetContainer_' + _this_id);                          // 338
                  var editors = jsbin = menu = bin = null;                                                             // 339
                  var theElement = document.getElementById('jsbin_' + _this_id);                                       // 340
                  if (theElement) {                                                                                    // 341
                    editors = theElement.contentWindow.editors;                                                        // 342
                    jsbin = theElement.contentWindow.jsbin;                                                            // 343
                    menu = theElement.contentWindow.document.getElementById("control");                                // 344
                    bin = theElement.contentWindow.document.getElementById("bin");                                     // 345
                    if (jsbin && jsbin.panels) {                                                                       // 346
                      jsbin.panels.saveOnExit = true;                                                                  // 347
                    }                                                                                                  // 348
                    setDisplayModeOn(widget.data, this, widgetElement, menu, bin, jsbin, _this_id, isnew);             // 349
                  } else {                                                                                             // 350
                    console.log("no element found for jsbin_" + _this_id);                                             // 351
                  }                                                                                                    // 352
                });                                                                                                    // 353
              }                                                                                                        // 354
            })(evt, this_id, isnew);                                                                                   // 355
          });                                                                                                          // 356
        })(thisid, isnew);                                                                                             // 357
      })(this, thisisnew);                                                                                             // 358
    });                                                                                                                // 359
                                                                                                                       //
    Template.help.events({                                                                                             // 403
      "click .giphy": function () {                                                                                    // 404
        function clickGiphy(e, t) {                                                                                    // 404
          $(e.target).hide();                                                                                          // 405
        }                                                                                                              // 406
                                                                                                                       //
        return clickGiphy;                                                                                             // 404
      }()                                                                                                              // 404
    });                                                                                                                // 403
                                                                                                                       //
    Template.widget.events({                                                                                           // 409
                                                                                                                       //
      "click .giphy": function () {                                                                                    // 411
        function clickGiphy(e, t) {                                                                                    // 411
          $(e.target).hide();                                                                                          // 412
        }                                                                                                              // 413
                                                                                                                       //
        return clickGiphy;                                                                                             // 411
      }(),                                                                                                             // 411
                                                                                                                       //
      "click .delete": function () {                                                                                   // 415
        function clickDelete() {                                                                                       // 415
                                                                                                                       //
          var grid = $(".grid-stack").data("gridstack");                                                               // 417
                                                                                                                       //
          var widgetElement = $("#widgetContainer_" + this._id);                                                       // 419
          var griditem = $(widgetElement).parent().parent();                                                           // 420
                                                                                                                       //
          grid.removeWidget(griditem, true);                                                                           // 422
                                                                                                                       //
          if (this.isTemplate) {                                                                                       // 424
            this.pagetype = "template";                                                                                // 425
            Widgets.update(this._id, this);                                                                            // 426
          } else {                                                                                                     // 427
            Widgets.remove(this._id);                                                                                  // 428
          }                                                                                                            // 429
          giphy_modal("erase", "Widget Deleted");                                                                      // 430
          return false;                                                                                                // 431
        }                                                                                                              // 432
                                                                                                                       //
        return clickDelete;                                                                                            // 415
      }(),                                                                                                             // 415
                                                                                                                       //
      "click .save": function () {                                                                                     // 434
        function clickSave() {                                                                                         // 434
          var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                            // 435
          var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                                // 436
          var revision = jsbin.state.revision;                                                                         // 437
                                                                                                                       //
          this.html = editors.html.getCode();                                                                          // 439
          this.javascript = editors.javascript.getCode();                                                              // 440
          this.css = editors.css.getCode();                                                                            // 441
          jsbin.saveDisabled = false;                                                                                  // 442
          jsbin.panels.save();                                                                                         // 443
          jsbin.panels.savecontent();                                                                                  // 444
          Widgets.update(this._id, this);                                                                              // 445
                                                                                                                       //
          // also trigger the jsbin save                                                                               // 447
          var dataobj = { html: this.html, css: this.css, javascript: this.javascript };                               // 448
          var url = "/api/" + this.url + "/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,               // 449
          var options = { data: dataobj };                                                                             // 450
          HTTP.post(url, options, function (error, results) {});                                                       // 451
                                                                                                                       //
          giphy_modal("saved", "Widget Content Saved");                                                                // 454
                                                                                                                       //
          return false;                                                                                                // 456
        }                                                                                                              // 457
                                                                                                                       //
        return clickSave;                                                                                              // 434
      }(),                                                                                                             // 434
                                                                                                                       //
      "click .call_webservice_url": function () {                                                                      // 460
        function clickCall_webservice_url(evt, template) {                                                             // 460
          $("#webservice_insert_modal").modal('show');                                                                 // 461
                                                                                                                       //
          $("#webservice_insert_modal_submit").click(function () {                                                     // 463
            var jsbin_id = 'jsbin_' + template.data.url;                                                               // 464
                                                                                                                       //
            var url = $("#webservice_insert_url").val().trim();                                                        // 467
            var name = $("#webservice_insert_name").val().trim();                                                      // 468
            var auth_token = $("#webservice_insert_auth_token").val().trim();                                          // 469
            var return_type = $("input[name=webservice_insert_return_type]:checked").val().trim();                     // 470
                                                                                                                       //
            url = url.replace("||PAGEID||", "'+pageId()+'");                                                           // 472
            url = url.replace("||PAGETYPE||", "'+pageType()+'");                                                       // 473
                                                                                                                       //
            var token_string;                                                                                          // 475
            if (auth_token) {                                                                                          // 476
              token_string = " \n authentication_token : '" + auth_token + "',";                                       // 477
            }                                                                                                          // 478
                                                                                                                       //
            var codeString = "{\n id:'" + name + "', \n type: 'webservice', " + token_string + " \n return_type: '" + return_type + "', \n url: '" + url + "' \n}";
            var codeStringRe = "\\{\n id:'" + name + "', \n type: 'webservice', \n return_type: '" + return_type + "', \n url: '" + url + "' \n\\}";
            var comments = " this will hold a " + return_type + " object";                                             // 482
                                                                                                                       //
            insert_code(jsbin_id, codeString, codeStringRe, comments);                                                 // 484
          });                                                                                                          // 486
        }                                                                                                              // 489
                                                                                                                       //
        return clickCall_webservice_url;                                                                               // 460
      }(),                                                                                                             // 460
                                                                                                                       //
      "click .add_code": function () {                                                                                 // 491
        function clickAdd_code(evt, template) {                                                                        // 491
                                                                                                                       //
          var pullfrom = evt.currentTarget.dataset.pullfrom;                                                           // 493
          var pulltype = evt.currentTarget.dataset.pulltype;                                                           // 494
                                                                                                                       //
          if (this.url == template.data.url) {                                                                         // 496
            return false;                                                                                              // 497
          }                                                                                                            // 498
                                                                                                                       //
          var type;                                                                                                    // 500
          var comments = "";                                                                                           // 501
          if (pulltype == "data") {                                                                                    // 502
            type = "data";                                                                                             // 503
            comments = " This will hold a JSON object";                                                                // 504
          }                                                                                                            // 505
          if (pulltype == "html") {                                                                                    // 506
            type = "html";                                                                                             // 507
            comments = " This will hold a jQuery object";                                                              // 508
          }                                                                                                            // 509
          var codeString = "{from: '" + pullfrom + "', type : '" + pulltype + "'}";                                    // 510
          var codeStringRe = "\\{from: '" + pullfrom + "', type : '" + pulltype + "'\\}";                              // 511
                                                                                                                       //
          var jsbin_id = 'jsbin_' + template.data.url;                                                                 // 513
                                                                                                                       //
          insert_code(jsbin_id, codeString, codeStringRe, comments);                                                   // 515
                                                                                                                       //
          return true;                                                                                                 // 517
        }                                                                                                              // 518
                                                                                                                       //
        return clickAdd_code;                                                                                          // 491
      }(),                                                                                                             // 491
                                                                                                                       //
      "click .test": function () {                                                                                     // 522
        function clickTest() {                                                                                         // 522
          var thiselement = document.getElementById('widgetContainer_' + this._id);                                    // 523
          var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                            // 524
          var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                                // 525
          var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");    // 526
          var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");         // 527
                                                                                                                       //
          var newbintop = 0;                                                                                           // 529
          this.maxed = !this.maxed;                                                                                    // 530
          if (this.maxed) {                                                                                            // 531
            $(menu).hide();                                                                                            // 532
            $(".editmodeonly", thiselement).hide();                                                                    // 533
            this.oldbintop = $(bin).css("top");                                                                        // 534
            $(bin).css("top", newbintop);                                                                              // 535
          } else {                                                                                                     // 536
            $(menu).show();                                                                                            // 537
            $(".editmodeonly", thiselement).show();                                                                    // 538
            $(bin).css("top", this.oldbintop);                                                                         // 539
          }                                                                                                            // 540
          return false;                                                                                                // 541
        }                                                                                                              // 542
                                                                                                                       //
        return clickTest;                                                                                              // 522
      }(),                                                                                                             // 522
      /*                                                                                                               // 543
      panel ids: html, css, javascript, console, live                                                                  //
      */                                                                                                               //
                                                                                                                       //
      // this sets it to EDIT mode                                                                                     // 547
      "click .widgetUnlock": function () {                                                                             // 548
        function clickWidgetUnlock() {                                                                                 // 548
                                                                                                                       //
          var widgetElement = document.getElementById('widgetContainer_' + this._id);                                  // 550
          var iframeElement = document.getElementById('jsbin_' + this._id);                                            // 551
                                                                                                                       //
          var editors = iframeElement.contentWindow.editors;                                                           // 553
          var jsbin = iframeElement.contentWindow.jsbin;                                                               // 554
          var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");    // 555
          var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");         // 556
                                                                                                                       //
          setEditModeOn(this, iframeElement, widgetElement, menu, bin, jsbin);                                         // 558
                                                                                                                       //
          return false;                                                                                                // 560
        }                                                                                                              // 561
                                                                                                                       //
        return clickWidgetUnlock;                                                                                      // 548
      }(),                                                                                                             // 548
                                                                                                                       //
      // this sets it to DISPLAY mode                                                                                  // 564
      "click .widgetLock": function () {                                                                               // 565
        function clickWidgetLock() {                                                                                   // 565
                                                                                                                       //
          var widgetElement = document.getElementById('widgetContainer_' + this._id);                                  // 567
          var iframeElement = document.getElementById('jsbin_' + this._id);                                            // 568
                                                                                                                       //
          var editors = iframeElement.contentWindow.editors;                                                           // 570
          var jsbin = iframeElement.contentWindow.jsbin;                                                               // 571
          var menu = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("control");    // 572
          var bin = document.getElementById('jsbin_' + this._id).contentWindow.document.getElementById("bin");         // 573
          setDisplayModeOn(this, iframeElement, widgetElement, menu, bin, jsbin, this._id, false);                     // 574
                                                                                                                       //
          return false;                                                                                                // 576
        }                                                                                                              // 577
                                                                                                                       //
        return clickWidgetLock;                                                                                        // 565
      }(),                                                                                                             // 565
                                                                                                                       //
      // setting visibility on widgets (public or private)                                                             // 580
      "click .setpublic": function () {                                                                                // 581
        function clickSetpublic() {                                                                                    // 581
          this.visibility = "public";                                                                                  // 582
          Widgets.update(this._id, this);                                                                              // 583
          return false;                                                                                                // 584
        }                                                                                                              // 585
                                                                                                                       //
        return clickSetpublic;                                                                                         // 581
      }(),                                                                                                             // 581
      "click .setprivate": function () {                                                                               // 586
        function clickSetprivate() {                                                                                   // 586
          this.visibility = "private";                                                                                 // 587
          Widgets.update(this._id, this);                                                                              // 588
          return false;                                                                                                // 589
        }                                                                                                              // 590
                                                                                                                       //
        return clickSetprivate;                                                                                        // 586
      }(),                                                                                                             // 586
                                                                                                                       //
      "click .order_up": function () {                                                                                 // 592
        function clickOrder_up() {                                                                                     // 592
          this.sort_order--;                                                                                           // 593
          Widgets.update(this._id, this);                                                                              // 594
          return false;                                                                                                // 595
        }                                                                                                              // 596
                                                                                                                       //
        return clickOrder_up;                                                                                          // 592
      }(),                                                                                                             // 592
                                                                                                                       //
      "click .order_down": function () {                                                                               // 598
        function clickOrder_down() {                                                                                   // 598
          this.sort_order++;                                                                                           // 599
          Widgets.update(this._id, this);                                                                              // 600
          return false;                                                                                                // 601
        }                                                                                                              // 602
                                                                                                                       //
        return clickOrder_down;                                                                                        // 598
      }(),                                                                                                             // 598
                                                                                                                       //
      "click .nonclickable": function () {                                                                             // 604
        function clickNonclickable() {                                                                                 // 604
          return false;                                                                                                // 605
        }                                                                                                              // 606
                                                                                                                       //
        return clickNonclickable;                                                                                      // 604
      }(),                                                                                                             // 604
                                                                                                                       //
      'click .copy': function () {                                                                                     // 609
        function clickCopy() {                                                                                         // 609
          var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                                // 610
          var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                   // 611
          var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                                // 612
          var options = { data: dataobj };                                                                             // 613
                                                                                                                       //
          HTTP.post(url, options, function (error, results) {                                                          // 615
            newWidget = { _id: results.data.url,                                                                       // 616
              createdBy: { username: Meteor.user().username,                                                           // 617
                userid: Meteor.userId() },                                                                             // 618
              isTemplate: false,                                                                                       // 619
              html: results.data.html,                                                                                 // 620
              javascript: results.data.javascript,                                                                     // 621
              css: results.data.css,                                                                                   // 622
              displayWidth: template.displayWidth,                                                                     // 623
              displayHeight: template.displayHeight,                                                                   // 624
              description: "(copied from " + template.name + ") " + template.description,                              // 625
              widgetStyle: template.widgetStyle,                                                                       // 626
              name: "copy of " + template.name,                                                                        // 627
              pagetype: pageinfo().pagetype,                                                                           // 628
              pageurl: pageinfo().pageurl,                                                                             // 629
              pageid: pageinfo().pageid,                                                                               // 630
              url: results.data.url,                                                                                   // 631
              createdAt: new Date(),                                                                                   // 632
              visibility: "private",                                                                                   // 633
              rand: Math.random() };                                                                                   // 634
            Widgets.insert(newWidget);                                                                                 // 635
          });                                                                                                          // 636
                                                                                                                       //
          giphy_modal("copy", "widget copied");                                                                        // 638
                                                                                                                       //
          return false;                                                                                                // 640
        }                                                                                                              // 641
                                                                                                                       //
        return clickCopy;                                                                                              // 609
      }(),                                                                                                             // 609
                                                                                                                       //
      "click .save_template": function () {                                                                            // 644
        function clickSave_template() {                                                                                // 644
          this.isTemplate = !this.isTemplate;                                                                          // 645
          Widgets.update(this._id, this);                                                                              // 646
          var editors = document.getElementById('jsbin_' + this._id).contentWindow.editors;                            // 647
          var jsbin = document.getElementById('jsbin_' + this._id).contentWindow.jsbin;                                // 648
                                                                                                                       //
          giphy_modal("promotion", "widget saved as a template");                                                      // 650
                                                                                                                       //
          return false;                                                                                                // 652
        }                                                                                                              // 653
                                                                                                                       //
        return clickSave_template;                                                                                     // 644
      }(),                                                                                                             // 644
                                                                                                                       //
      "click .save_to_library": function () {                                                                          // 655
        function clickSave_to_library() {                                                                              // 655
          this.isTemplate = !this.isTemplate;                                                                          // 656
          //      Widgets.update(this._id, this);                                                                      // 657
                                                                                                                       //
          var template = Widgets.findOne({ url: this.url }); //.map(setWidgetDefaults);                                // 659
          var dataobj = { html: template.html, css: template.css, javascript: template.javascript };                   // 660
          var url = "/api/save"; //?js="+jsstring+"&html="+htmlstring+"&css="+csstring,                                // 661
          var options = { data: dataobj };                                                                             // 662
                                                                                                                       //
          var newpagetype = "user_libs";                                                                               // 664
          var newpageid = Meteor.user().username;                                                                      // 665
          var newpageurl = newpagetype + "/" + newpageurl;                                                             // 666
                                                                                                                       //
          HTTP.post(url, options, function (error, results) {                                                          // 668
            newWidget = { _id: results.data.url,                                                                       // 669
              createdBy: { username: Meteor.user().username,                                                           // 670
                userid: Meteor.userId() },                                                                             // 671
              inLibrary: true,                                                                                         // 672
              html: results.data.html,                                                                                 // 673
              javascript: results.data.javascript,                                                                     // 674
              css: results.data.css,                                                                                   // 675
              displayWidth: template.displayWidth,                                                                     // 676
              displayHeight: template.displayHeight,                                                                   // 677
              description: "(copied from " + template.name + ") " + template.description,                              // 678
              widgetStyle: template.widgetStyle,                                                                       // 679
              name: "copy of " + template.name,                                                                        // 680
              pagetype: newpagetype,                                                                                   // 681
              pageurl: newpageurl,                                                                                     // 682
              pageid: newpageid,                                                                                       // 683
              this_page_only: true,                                                                                    // 684
              url: results.data.url,                                                                                   // 685
              createdAt: new Date(),                                                                                   // 686
              visibility: "private",                                                                                   // 687
              rand: Math.random() };                                                                                   // 688
            Widgets.insert(newWidget);                                                                                 // 689
          });                                                                                                          // 690
                                                                                                                       //
          giphy_modal("library", "widget added to your library");                                                      // 692
                                                                                                                       //
          return false;                                                                                                // 694
        }                                                                                                              // 695
                                                                                                                       //
        return clickSave_to_library;                                                                                   // 655
      }(),                                                                                                             // 655
                                                                                                                       //
      "click .openinfo": function () {                                                                                 // 697
        function clickOpeninfo() {                                                                                     // 697
          var thiselement = document.getElementById('widgetContainer_' + this._id);                                    // 698
          var mode = $(thiselement).data("mode");                                                                      // 699
          if (!mode || mode == "display") {                                                                            // 700
            //      $(".widgetMouseOverTarget", thiselement ).css("background", "red");                                // 701
            $(".widgetDisplayHeader", thiselement).show();                                                             // 702
            $(".widgetMouseOverTarget", thiselement).css("z-index", 5);                                                // 703
            $(".widgetDisplayHeader", thiselement).css("z-index", 10);                                                 // 704
          }                                                                                                            // 705
        }                                                                                                              // 706
                                                                                                                       //
        return clickOpeninfo;                                                                                          // 697
      }(),                                                                                                             // 697
                                                                                                                       //
      "mouseleave .widgetDisplayHeader": function () {                                                                 // 709
        function mouseleaveWidgetDisplayHeader() {                                                                     // 709
          var thiselement = document.getElementById('widgetContainer_' + this._id);                                    // 710
          $(".widgetMouseOverTarget", thiselement).css("background", "transparent");                                   // 711
          $(".widgetDisplayHeader", thiselement).hide();                                                               // 712
          $(".widgetMouseOverTarget", thiselement).css("z-index", 10);                                                 // 713
          $(".widgetDisplayHeader", thiselement).css("z-index", 5);                                                    // 714
        }                                                                                                              // 715
                                                                                                                       //
        return mouseleaveWidgetDisplayHeader;                                                                          // 709
      }()                                                                                                              // 709
                                                                                                                       //
    });                                                                                                                // 409
    ////// END EVENTS                                                                                                  // 719
                                                                                                                       //
                                                                                                                       //
    ////// HELPERS                                                                                                     // 722
                                                                                                                       //
    widgetIncrement = 0;                                                                                               // 724
    Template.widget.helpers({                                                                                          // 725
      otherwidgets: function () {                                                                                      // 726
        function otherwidgets() {                                                                                      // 726
          // Otherwise, return all of the tasks                                                                        // 727
          return Widgets.find({ pagetype: pageinfo().pagetype, _id: { $ne: this._id } }, { sort: { createdAt: -1 } }).map(setWidgetDefaults);
        }                                                                                                              // 729
                                                                                                                       //
        return otherwidgets;                                                                                           // 726
      }(),                                                                                                             // 726
                                                                                                                       //
      isPublic: function () {                                                                                          // 731
        function isPublic() {                                                                                          // 731
          if (this.visibility == "public") {                                                                           // 732
            return true;                                                                                               // 733
          }                                                                                                            // 734
          return false;                                                                                                // 735
        }                                                                                                              // 736
                                                                                                                       //
        return isPublic;                                                                                               // 731
      }(),                                                                                                             // 731
                                                                                                                       //
      pageTypeAndUrl: function () {                                                                                    // 738
        function pageTypeAndUrl() {                                                                                    // 738
                                                                                                                       //
          return "_pt_" + this.pagetype + "/" + this.url;                                                              // 740
        }                                                                                                              // 741
                                                                                                                       //
        return pageTypeAndUrl;                                                                                         // 738
      }(),                                                                                                             // 738
                                                                                                                       //
      pageUrlAndUrl: function () {                                                                                     // 743
        function pageUrlAndUrl() {                                                                                     // 743
          return "_pu_" + pageinfo().pageurl + "/" + this.url;                                                         // 744
        }                                                                                                              // 745
                                                                                                                       //
        return pageUrlAndUrl;                                                                                          // 743
      }(),                                                                                                             // 743
                                                                                                                       //
      commentsCount: function () {                                                                                     // 747
        function commentsCount(id) {                                                                                   // 747
          var value = "";                                                                                              // 748
          return value;                                                                                                // 749
        }                                                                                                              // 750
                                                                                                                       //
        return commentsCount;                                                                                          // 747
      }(),                                                                                                             // 747
                                                                                                                       //
      isMyWidget: function () {                                                                                        // 752
        function isMyWidget() {                                                                                        // 752
          // is this a widget I created?                                                                               // 753
          if (getUserXtras().godmode) {                                                                                // 754
            return true;                                                                                               // 755
          }                                                                                                            // 756
          if (this.createdBy && Meteor.user()) {                                                                       // 757
            return this.createdBy.username == Meteor.user().username;                                                  // 758
          } else {                                                                                                     // 759
            return false;                                                                                              // 760
          }                                                                                                            // 761
        }                                                                                                              // 762
                                                                                                                       //
        return isMyWidget;                                                                                             // 752
      }(),                                                                                                             // 752
                                                                                                                       //
      widgetIncrement: function (_widgetIncrement) {                                                                   // 764
        function widgetIncrement() {                                                                                   // 764
          return _widgetIncrement.apply(this, arguments);                                                              // 764
        }                                                                                                              // 764
                                                                                                                       //
        widgetIncrement.toString = function () {                                                                       // 764
          return _widgetIncrement.toString();                                                                          // 764
        };                                                                                                             // 764
                                                                                                                       //
        return widgetIncrement;                                                                                        // 764
      }(function () {                                                                                                  // 764
        var ret = widgetIncrement;                                                                                     // 765
        if (typeof this.widgetIncrement == "undefined") {                                                              // 766
          this.widgetIncrement = widgetIncrement;                                                                      // 767
          widgetIncrement++;                                                                                           // 768
        } else {                                                                                                       // 769
          ret = this.widgetIncrement;                                                                                  // 770
        }                                                                                                              // 771
        return ret;                                                                                                    // 772
      }),                                                                                                              // 773
                                                                                                                       //
      userXtras: function () {                                                                                         // 775
        function userXtras() {                                                                                         // 775
          return getUserXtras();                                                                                       // 776
        }                                                                                                              // 777
                                                                                                                       //
        return userXtras;                                                                                              // 775
      }(),                                                                                                             // 775
                                                                                                                       //
      godmode: function () {                                                                                           // 779
        function godmode() {                                                                                           // 779
          return getUserXtras().godmode;                                                                               // 780
        }                                                                                                              // 782
                                                                                                                       //
        return godmode;                                                                                                // 779
      }()                                                                                                              // 779
    });                                                                                                                // 725
                                                                                                                       //
    Template.allWidgetsLoaded.onRendered(function () {                                                                 // 787
      console.log("aaaaaall widgets loaded");                                                                          // 788
    });                                                                                                                // 789
    //////// END HELPERS                                                                                               // 790
  })();                                                                                                                // 2
}                                                                                                                      // 791
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{"extensions":[".js",".json",".html",".scss",".css"]});
require("./template.C5.js");
require("./template.allWidgetsLoaded.js");
require("./template.functions.js");
require("./template.help.js");
require("./template.modals.js");
require("./template.widget.js");
require("./template.widget_oldmenu.js");
require("./template.widgets.js");
require("./client/lib/gridstack.js");
require("./client/lib/lodash.js");
require("./client/lib/tour.js");
require("./client/lib/uiutils.js");
require("./C5.js");
require("./common_functions.js");
require("./widget.js");